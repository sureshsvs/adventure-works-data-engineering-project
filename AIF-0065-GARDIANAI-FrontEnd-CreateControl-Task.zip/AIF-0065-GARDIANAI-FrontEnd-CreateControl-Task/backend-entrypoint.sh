#!/bin/sh
set -eu

fail_runtime() {
    echo "ERROR: No usable approved Python runtime. The platform team must provide Python >=3.10 and app dependencies in the approved golden image, expose it on PATH, or supply its verified absolute path via GOLDEN_PYTHON. No packages are installed by this image." >&2
    exit 1
}

if [ -n "${GOLDEN_PYTHON:-}" ]; then
    case "$GOLDEN_PYTHON" in
        /*) [ -x "$GOLDEN_PYTHON" ] || fail_runtime ;;
        *) fail_runtime ;;
    esac
    runtime="$GOLDEN_PYTHON"
else
    runtime=""
    for candidate in python3 python; do
        if command -v "$candidate" >/dev/null 2>&1; then
            runtime="$(command -v "$candidate")"
            break
        fi
    done
    [ -n "$runtime" ] || fail_runtime
fi

# Do not import the application: its initialization may access runtime state.
if ! "$runtime" -B - <<'PY'
import importlib
import sys

if sys.version_info < (3, 10):
    sys.exit("ERROR: Approved golden image must provide Python >=3.10.")

failed = []
for module in (
    "fastapi", "uvicorn", "multipart.multipart", "pydantic_settings", "httpx",
    "openai", "pypdf", "azure.identity", "azure.ai.projects",
    "azure.storage.blob", "azure.cosmos",
):
    try:
        importlib.import_module(module)
    except Exception:
        failed.append(module)
if failed:
    sys.exit(
        "ERROR: Golden-image dependency import check failed: " + ", ".join(failed)
        + ". Ask the platform team to provide compatible app dependencies in the "
        "approved golden image; this check does not install packages."
    )
print("Approved Python runtime and dependency import checks passed.")
PY
then
    echo "ERROR: Approved runtime preflight failed. Check the golden image's Python environment with the platform team; no environment values or import exception details are logged." >&2
    exit 1
fi

if [ "${1:-}" = "--check" ]; then
    exit 0
fi
exec "$runtime" -m uvicorn gardianai_agentharness.main:app --host 0.0.0.0 --port "${PORT:-8080}"
