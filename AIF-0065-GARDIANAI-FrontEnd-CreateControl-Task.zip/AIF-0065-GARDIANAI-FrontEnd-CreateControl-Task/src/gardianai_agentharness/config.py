"""Application configuration via Pydantic settings.

Mirrors the reference architecture's ``src/config.py`` pattern. All values are
sourced from environment variables / a local ``.env`` file. The application is
designed to run fully **offline** (deterministic control engine over the bundled
sample data) when no LLM credentials are provided, and to light up the
Agent-Framework harness + SuperAgent LLM orchestration when they are.
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict

    _HAS_PYDANTIC_SETTINGS = True
except ImportError:  # pragma: no cover - offline/stdlib fallback
    _HAS_PYDANTIC_SETTINGS = False


# Repo root = three levels up from this file (src/gardianai_agentharness/config.py)
REPO_ROOT = Path(__file__).resolve().parents[2]
SAMPLE_DATA_DIR = REPO_ROOT / "sampledata" / "poc-testcases"
RUN_STORE_DIR = REPO_ROOT / ".gardianai" / "runs"
# Local cache the blob-storage pack is hydrated into (when blob storage is configured).
SAMPLE_DATA_CACHE_DIR = REPO_ROOT / ".gardianai" / "sampledata"


if _HAS_PYDANTIC_SETTINGS:

    class Settings(BaseSettings):
        """Typed application settings."""

        model_config = SettingsConfigDict(
            env_file=".env", case_sensitive=False, extra="ignore"
        )

        # --- General ---
        app_name: str = "GARdian.AI Agent Harness"
        debug: bool = False
        cors_origins: str = "http://localhost:3000,http://localhost:5173"

        # --- Auth (Azure AD bearer validation, disabled by default for PoC) ---
        auth_disabled: bool = True
        azure_ad_tenant_id: str = ""
        azure_ad_client_id: str = ""
        azure_ad_audience: str = ""

        # --- Agent Harness (per-document Q&A) via APIM / Azure OpenAI ---
        apim_endpoint: str = ""
        apim_api_key: str = ""
        # APIM project gateway (AIProjectClient.get_openai_client). Enabled when
        # APIM_ENDPOINT, a subscription key, APIM_FOUNDRY_NAME and
        # APIM_PROJECT_NAME are all set. APIM_SUB_KEY is the legacy key name,
        # used only when APIM_SUBSCRIPTION_KEY is blank.
        apim_subscription_key: str = ""
        apim_sub_key: str = ""
        apim_foundry_name: str = ""
        apim_project_name: str = ""
        agent_model_deployment_name: str = "gpt-4o"
        agent_harness_codeact: bool = False
        # Authenticate BOTH LLM backends with Entra ID (managed identity / az
        # login) instead of API keys when true; keys may then be left blank.
        azure_llm_use_managed_identity: bool = False
        # Client id of the user-assigned managed identity DefaultAzureCredential
        # should use. Required in Azure Container Apps: without it, managed
        # identity resolution can fail with "DefaultAzureCredential failed to
        # retrieve a token from the included credentials" even though an
        # identity is attached to the app.
        azure_client_id: str = ""

        # --- SuperAgent (Azure AI Foundry / Azure OpenAI) ---
        azure_ai_foundry_endpoint: str = ""
        azure_ai_foundry_api_key: str = ""
        super_agent_model: str = "gpt-4o"
        super_agent_max_active_cases: int = Field(default=4, ge=1)
        super_agent_queue_capacity: int = Field(default=16, ge=0)
        super_agent_default_max_parallel_cases: int = Field(default=1, ge=1, le=4)
        # Retrieve document content on demand via tools instead of full-text prompts.
        super_agent_tool_retrieval: bool = True
        # Run the multi-phase deep-research agent (plan/investigate/verify/synthesize).
        super_agent_deep_research: bool = True
        super_agent_research_max_steps: int = 14
        # Allow the research agent to search across other uploaded packs.
        super_agent_shared_corpus: bool = True
        # Prefer the Agent Framework harness (temp file store + CLI tools) when installed.
        super_agent_use_harness: bool = True
        super_agent_harness_max_context_tokens: int = 128_000
        super_agent_harness_max_output_tokens: int = 16_384

        # --- SuperAgent token economy ---
        # Economy mode forces the cheapest grounded path (single-pass tool
        # retrieval), low reasoning effort and a smaller benchmark template.
        super_agent_economy: bool = False
        super_agent_reasoning_effort: str = "high"
        super_agent_expected_template_chars: int = 60_000
        # Server default; the UI can override per run. When false, generate from
        # the prompt alone (ignore the benchmark expected output).
        super_agent_use_expected_template: bool = True

        # --- Document intelligence (Mistral Document AI OCR on Azure AI Foundry) ---
        gardian_ocr_deployment_name: str = ""
        gardian_ocr_endpoint: str = ""
        gardian_ocr_key: str = ""

        # --- Grounded web (test case 3: Shell newsroom) ---
        shell_newsroom_url: str = (
            "https://www.shell.com/news-and-insights/newsroom/"
            "news-and-media-releases.html"
        )

        # --- Storage ---
        sample_data_dir: str = str(SAMPLE_DATA_DIR)
        run_store_dir: str = str(RUN_STORE_DIR)

        # --- Sample data source (Azure Blob Storage; optional) ---
        # When a container plus a connection string (or account URL + managed
        # identity) is set, the pack is streamed from blob storage into
        # sample_data_cache_dir on demand and indexed instead of bundled sampledata/.
        azure_storage_connection_string: str = ""
        azure_storage_account_url: str = ""
        sample_data_container: str = "sampledata"
        sample_data_prefix: str = "poc-testcases"
        sample_data_cache_dir: str = str(SAMPLE_DATA_CACHE_DIR)
        # Blob-name prefixes (same container) for the two blob-only stores below.
        prompt_library_prefix: str = "prompt_library"
        ocr_cache_prefix: str = "ocr_cache"

        # --- Run persistence (report .docx -> blob, run document -> Cosmos DB) ---
        # "auto" uses Azure when a storage account + Cosmos DB are configured.
        run_store_backend: str = "auto"
        run_reports_container: str = "run-reports"
        cosmos_endpoint: str = ""
        cosmos_key: str = ""
        cosmos_database: str = "gardian"
        cosmos_container: str = "runs"

        # --- SharePoint report export via Microsoft Graph ---
        sharepoint_site_hostname: str = ""
        sharepoint_site_path: str = ""
        sharepoint_drive_name: str = ""
        sharepoint_folder_path: str = ""

        @property
        def cors_origin_list(self) -> list[str]:
            return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

        @property
        def llm_enabled(self) -> bool:
            """True when either the harness or SuperAgent LLM is configured."""
            mi = self.azure_llm_use_managed_identity
            return bool(
                self.apim_gateway_enabled
                or (self.apim_endpoint and (self.apim_api_key or mi))
                or (self.azure_ai_foundry_endpoint and (self.azure_ai_foundry_api_key or mi))
            )

        @property
        def apim_gateway_subscription_key(self) -> str:
            """APIM_SUBSCRIPTION_KEY, falling back to the legacy APIM_SUB_KEY."""
            return self.apim_subscription_key or self.apim_sub_key

        @property
        def apim_gateway_requested(self) -> bool:
            """True when either APIM project-gateway name is set."""
            return bool(self.apim_foundry_name or self.apim_project_name)

        @property
        def apim_gateway_enabled(self) -> bool:
            """True when the APIM project gateway (AIProjectClient) is fully configured."""
            return bool(
                self.apim_endpoint
                and self.apim_gateway_subscription_key
                and self.apim_foundry_name
                and self.apim_project_name
            )

        @property
        def ocr_enabled(self) -> bool:
            """True when the Mistral Document AI OCR endpoint is configured."""
            return bool(self.gardian_ocr_endpoint and self.gardian_ocr_key)

        @property
        def sa_reasoning_effort(self) -> str:
            return "low" if self.super_agent_economy else self.super_agent_reasoning_effort

        @property
        def sa_expected_template_chars(self) -> int:
            if self.super_agent_economy:
                return min(self.super_agent_expected_template_chars, 15_000)
            return self.super_agent_expected_template_chars

        @property
        def blob_storage_enabled(self) -> bool:
            """True when the sample-data pack should be sourced from Azure Blob Storage."""
            return bool(
                self.sample_data_container
                and (
                    self.azure_storage_connection_string
                    or self.azure_storage_account_url
                )
            )

        @property
        def azure_runs_enabled(self) -> bool:
            """True when runs (report + metadata) should persist to Azure."""
            if self.run_store_backend == "local":
                return False
            storage = bool(
                self.azure_storage_connection_string or self.azure_storage_account_url
            )
            return storage and bool(self.cosmos_endpoint)

else:  # pragma: no cover - minimal stdlib fallback when pydantic isn't installed

    import os

    class Settings:  # type: ignore[no-redef]
        def __init__(self) -> None:
            self.app_name = os.getenv("APP_NAME", "GARdian.AI Agent Harness")
            self.debug = os.getenv("DEBUG", "false").lower() == "true"
            self.cors_origins = os.getenv(
                "CORS_ORIGINS", "http://localhost:3000,http://localhost:5173"
            )
            self.auth_disabled = os.getenv("AUTH_DISABLED", "true").lower() == "true"
            self.azure_ad_tenant_id = os.getenv("AZURE_AD_TENANT_ID", "")
            self.azure_ad_client_id = os.getenv("AZURE_AD_CLIENT_ID", "")
            self.azure_ad_audience = os.getenv("AZURE_AD_AUDIENCE", "")
            self.apim_endpoint = os.getenv("APIM_ENDPOINT", "")
            self.apim_api_key = os.getenv("APIM_API_KEY", "")
            self.apim_subscription_key = os.getenv("APIM_SUBSCRIPTION_KEY", "")
            self.apim_sub_key = os.getenv("APIM_SUB_KEY", "")
            self.apim_foundry_name = os.getenv("APIM_FOUNDRY_NAME", "")
            self.apim_project_name = os.getenv("APIM_PROJECT_NAME", "")
            self.agent_model_deployment_name = os.getenv(
                "AGENT_MODEL_DEPLOYMENT_NAME", "gpt-4o"
            )
            self.agent_harness_codeact = (
                os.getenv("AGENT_HARNESS_CODEACT", "false").lower() == "true"
            )
            self.azure_llm_use_managed_identity = (
                os.getenv("AZURE_LLM_USE_MANAGED_IDENTITY", "false").lower() == "true"
            )
            self.azure_client_id = os.getenv("AZURE_CLIENT_ID", "")
            self.azure_ai_foundry_endpoint = os.getenv("AZURE_AI_FOUNDRY_ENDPOINT", "")
            self.azure_ai_foundry_api_key = os.getenv("AZURE_AI_FOUNDRY_API_KEY", "")
            self.super_agent_model = os.getenv("SUPER_AGENT_MODEL", "gpt-4o")
            self.super_agent_max_active_cases = int(os.getenv("SUPER_AGENT_MAX_ACTIVE_CASES", "4"))
            self.super_agent_queue_capacity = int(os.getenv("SUPER_AGENT_QUEUE_CAPACITY", "16"))
            self.super_agent_default_max_parallel_cases = int(
                os.getenv("SUPER_AGENT_DEFAULT_MAX_PARALLEL_CASES", "1")
            )
            if (
                self.super_agent_max_active_cases < 1
                or self.super_agent_queue_capacity < 0
                or not 1 <= self.super_agent_default_max_parallel_cases <= 4
            ):
                raise ValueError("Invalid SuperAgent scheduling settings")
            self.super_agent_tool_retrieval = (
                os.getenv("SUPER_AGENT_TOOL_RETRIEVAL", "true").lower() == "true"
            )
            self.super_agent_deep_research = (
                os.getenv("SUPER_AGENT_DEEP_RESEARCH", "true").lower() == "true"
            )
            self.super_agent_research_max_steps = int(
                os.getenv("SUPER_AGENT_RESEARCH_MAX_STEPS", "14")
            )
            self.super_agent_shared_corpus = (
                os.getenv("SUPER_AGENT_SHARED_CORPUS", "true").lower() == "true"
            )
            self.super_agent_use_harness = (
                os.getenv("SUPER_AGENT_USE_HARNESS", "true").lower() == "true"
            )
            self.super_agent_harness_max_context_tokens = int(
                os.getenv("SUPER_AGENT_HARNESS_MAX_CONTEXT_TOKENS", "128000")
            )
            self.super_agent_harness_max_output_tokens = int(
                os.getenv("SUPER_AGENT_HARNESS_MAX_OUTPUT_TOKENS", "16384")
            )
            self.super_agent_economy = (
                os.getenv("SUPER_AGENT_ECONOMY", "false").lower() == "true"
            )
            self.super_agent_reasoning_effort = os.getenv(
                "SUPER_AGENT_REASONING_EFFORT", "high"
            )
            self.super_agent_expected_template_chars = int(
                os.getenv("SUPER_AGENT_EXPECTED_TEMPLATE_CHARS", "60000")
            )
            self.super_agent_use_expected_template = (
                os.getenv("SUPER_AGENT_USE_EXPECTED_TEMPLATE", "true").lower() == "true"
            )
            self.gardian_ocr_deployment_name = os.getenv(
                "GARDIAN_OCR_DEPLOYMENT_NAME", ""
            )
            self.gardian_ocr_endpoint = os.getenv("GARDIAN_OCR_ENDPOINT", "")
            self.gardian_ocr_key = os.getenv("GARDIAN_OCR_KEY", "")
            self.shell_newsroom_url = os.getenv(
                "SHELL_NEWSROOM_URL",
                "https://www.shell.com/news-and-insights/newsroom/"
                "news-and-media-releases.html",
            )
            self.sample_data_dir = os.getenv("SAMPLE_DATA_DIR", str(SAMPLE_DATA_DIR))
            self.run_store_dir = os.getenv("RUN_STORE_DIR", str(RUN_STORE_DIR))
            self.azure_storage_connection_string = os.getenv(
                "AZURE_STORAGE_CONNECTION_STRING", ""
            )
            self.azure_storage_account_url = os.getenv(
                "AZURE_STORAGE_ACCOUNT_URL", ""
            )
            self.sample_data_container = os.getenv(
                "SAMPLE_DATA_CONTAINER", "sampledata"
            )
            self.sample_data_prefix = os.getenv("SAMPLE_DATA_PREFIX", "poc-testcases")
            self.sample_data_cache_dir = os.getenv(
                "SAMPLE_DATA_CACHE_DIR", str(SAMPLE_DATA_CACHE_DIR)
            )
            self.prompt_library_prefix = os.getenv(
                "PROMPT_LIBRARY_PREFIX", "prompt_library"
            )
            self.ocr_cache_prefix = os.getenv("OCR_CACHE_PREFIX", "ocr_cache")
            self.run_store_backend = os.getenv("RUN_STORE_BACKEND", "auto")
            self.run_reports_container = os.getenv(
                "RUN_REPORTS_CONTAINER", "run-reports"
            )
            self.cosmos_endpoint = os.getenv("COSMOS_ENDPOINT", "")
            self.cosmos_key = os.getenv("COSMOS_KEY", "")
            self.cosmos_database = os.getenv("COSMOS_DATABASE", "gardian")
            self.cosmos_container = os.getenv("COSMOS_CONTAINER", "runs")
            self.sharepoint_site_hostname = os.getenv("SHAREPOINT_SITE_HOSTNAME", "")
            self.sharepoint_site_path = os.getenv("SHAREPOINT_SITE_PATH", "")
            self.sharepoint_drive_name = os.getenv("SHAREPOINT_DRIVE_NAME", "")
            self.sharepoint_folder_path = os.getenv("SHAREPOINT_FOLDER_PATH", "")

        @property
        def cors_origin_list(self) -> list[str]:
            return [o.strip() for o in self.cors_origins.split(",") if o.strip()]

        @property
        def llm_enabled(self) -> bool:
            mi = self.azure_llm_use_managed_identity
            return bool(
                self.apim_gateway_enabled
                or (self.apim_endpoint and (self.apim_api_key or mi))
                or (self.azure_ai_foundry_endpoint and (self.azure_ai_foundry_api_key or mi))
            )

        @property
        def apim_gateway_subscription_key(self) -> str:
            """APIM_SUBSCRIPTION_KEY, falling back to the legacy APIM_SUB_KEY."""
            return self.apim_subscription_key or self.apim_sub_key

        @property
        def apim_gateway_requested(self) -> bool:
            """True when either APIM project-gateway name is set."""
            return bool(self.apim_foundry_name or self.apim_project_name)

        @property
        def apim_gateway_enabled(self) -> bool:
            """True when the APIM project gateway (AIProjectClient) is fully configured."""
            return bool(
                self.apim_endpoint
                and self.apim_gateway_subscription_key
                and self.apim_foundry_name
                and self.apim_project_name
            )

        @property
        def ocr_enabled(self) -> bool:
            return bool(self.gardian_ocr_endpoint and self.gardian_ocr_key)

        @property
        def sa_reasoning_effort(self) -> str:
            return "low" if self.super_agent_economy else self.super_agent_reasoning_effort

        @property
        def sa_expected_template_chars(self) -> int:
            if self.super_agent_economy:
                return min(self.super_agent_expected_template_chars, 15000)
            return self.super_agent_expected_template_chars

        @property
        def blob_storage_enabled(self) -> bool:
            return bool(
                self.sample_data_container
                and (
                    self.azure_storage_connection_string
                    or self.azure_storage_account_url
                )
            )

        @property
        def azure_runs_enabled(self) -> bool:
            if self.run_store_backend == "local":
                return False
            storage = bool(
                self.azure_storage_connection_string or self.azure_storage_account_url
            )
            return storage and bool(self.cosmos_endpoint)


@lru_cache
def get_settings() -> "Settings":
    return Settings()


settings = get_settings()
