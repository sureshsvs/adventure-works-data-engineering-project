"""Document store: discovers and indexes the PoC sample data.

Backs the **BC Search** experience (keyword / metadata search across the ingested
disclosure pack) and supplies document text to the Agent Harness and SuperAgent.
Everything is derived from the on-disk ``sampledata/poc-testcases`` tree, so the
platform runs against the real inputs with no external services.
"""

from __future__ import annotations

import logging
import re
import uuid
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from typing import Any

from ..config import settings
from .extractors import SUPPORTED_SUFFIXES, extract_text
from .ocr_service import get_ocr_client

logger = logging.getLogger(__name__)

# Maps a test-case folder to its control archetype (from the PoC success criteria
# spreadsheet, criterion C2 – test case coverage).
_ARCHETYPES = {
    "1": "integrity_within_document",
    "2": "detailed_section_check",
    "3": "grounded_web_check",
    "4": "cross_document_check",
}


@dataclass
class DocumentRef:
    """A single ingested file."""

    id: str
    name: str
    path: str
    doc_type: str  # pdf | docx | xlsx | pptx | ...
    kind: str  # input | prompt | expected_output | criteria
    test_case_id: str
    size_bytes: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "doc_type": self.doc_type,
            "kind": self.kind,
            "test_case_id": self.test_case_id,
            "size_bytes": self.size_bytes,
        }


@dataclass
class TestCase:
    """A PoC test case = prompt + input pack + benchmark expected output."""

    id: str
    number: str
    title: str
    archetype: str
    folder: str
    prompt_text: str = ""
    expected_output_text: str = ""
    input_documents: list[DocumentRef] = field(default_factory=list)

    def to_dict(self, include_text: bool = False) -> dict[str, Any]:
        d = {
            "id": self.id,
            "number": self.number,
            "title": self.title,
            "archetype": self.archetype,
            "input_documents": [d.to_dict() for d in self.input_documents],
        }
        if include_text:
            d["prompt_text"] = self.prompt_text
            d["expected_output_text"] = self.expected_output_text
        return d


@dataclass
class Task:
    """A persisted task whose prompt and input documents are resolved from Blob Storage."""

    id: str
    title: str
    logical_source_role_names: list[str]
    prompt_name: str
    description: str | None = None
    created_by: str | None = None
    modified_by: str | None = None
    last_modified: str | None = None
    task_scalars: dict[str, str] = field(default_factory=dict)
    prompt_text: str = ""
    input_documents: list[DocumentRef] = field(default_factory=list)
    # Period-scoped preview context; populated only when a period is resolved.
    input_documents_period: str | None = None
    unresolved_logical_source_role_names: list[str] = field(default_factory=list)
    logical_source_roles: list[dict[str, Any]] = field(default_factory=list)

    @property
    def number(self) -> int:
        return 0

    @property
    def folder(self) -> None:
        return None

    @property
    def expected_output_text(self) -> str:
        return ""

    def to_dict(self, include_prompt: bool = False) -> dict[str, Any]:
        result = {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "logical_source_role_names": self.logical_source_role_names,
            "prompt_name": self.prompt_name,
            "created_by": self.created_by,
            "modified_by": self.modified_by,
            "last_modified": self.last_modified,
            "task_scalars": dict(self.task_scalars),
        }
        # Period-scoped input documents appear only when a period was resolved.
        if self.input_documents_period is not None:
            result["input_documents"] = [d.to_dict() for d in self.input_documents]
            result["input_documents_period"] = self.input_documents_period
            result["unresolved_logical_source_role_names"] = list(
                self.unresolved_logical_source_role_names
            )
            result["logical_source_roles"] = [
                dict(entry) for entry in self.logical_source_roles
            ]
        if include_prompt:
            result["prompt_text"] = self.prompt_text
        return result


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


def _safe_name(name: str) -> str:
    """Return a filesystem-safe base name (strips any path components)."""
    base = Path(name).name.strip() or "file"
    base = re.sub(r"[^A-Za-z0-9._ ()\-]+", "_", base)
    return base[:150] or "file"


def _is_temp_file(name: str) -> bool:
    """Office lock files (``~$…``) and dotfiles must never be indexed."""
    return name.startswith("~$") or name.startswith(".")


class DocumentStore:
    """In-memory index of the sample-data disclosure pack."""

    def __init__(self, root: Path | None = None) -> None:
        self.test_cases: dict[str, TestCase] = {}
        self.documents: dict[str, DocumentRef] = {}
        self._text_cache: dict[str, str] = {}
        self.criteria_doc: DocumentRef | None = None
        self._uploads_dir = Path(settings.run_store_dir).parent / "uploads"
        # Blob-relative path per document id; empty for local/uploaded files.
        self._blob_rel: dict[str, str] = {}
        if root is None and settings.blob_storage_enabled:
            self.root = Path(settings.sample_data_cache_dir)
            if not self._build_index_from_blob():
                # Blob unavailable/empty — fall back to the bundled sampledata/ tree.
                self.root = Path(settings.sample_data_dir)
                if self.root.exists():
                    self._build_index()
        else:
            self.root = root or Path(settings.sample_data_dir)
            if self.root.exists():
                self._build_index()
        self._load_uploads()

    # ------------------------------------------------------------------ build
    def _build_index(self) -> None:
        for folder in sorted(self.root.iterdir()):
            if not folder.is_dir():
                continue
            m = re.match(r"Test case (\d+)\s*-\s*(.+)", folder.name)
            if not m:
                continue
            number, title = m.group(1), m.group(2).strip()
            tc_id = f"tc{number}"
            tc = TestCase(
                id=tc_id,
                number=number,
                title=title,
                archetype=_ARCHETYPES.get(number, "unknown"),
                folder=str(folder),
            )
            for file in sorted(folder.rglob("*")):
                if not file.is_file() or file.suffix.lower() not in SUPPORTED_SUFFIXES:
                    continue
                if _is_temp_file(file.name):
                    continue
                lower = file.name.lower()
                if "prompt" in lower:
                    kind = "prompt"
                elif "expected output" in lower:
                    kind = "expected_output"
                else:
                    kind = "input"
                doc = self._register(file, kind, tc_id)
                if kind == "prompt":
                    tc.prompt_text = self.get_text(doc.id)
                elif kind == "expected_output":
                    tc.expected_output_text = self.get_text(doc.id)
                else:
                    tc.input_documents.append(doc)
            self.test_cases[tc_id] = tc

        # PoC success criteria workbook lives at the pack root.
        for file in sorted(self.root.glob("*success criteria*.xlsx")):
            if _is_temp_file(file.name):
                continue
            self.criteria_doc = self._register(file, "criteria", "")
            break

    def _register(self, file: Path, kind: str, tc_id: str) -> DocumentRef:
        doc_id = _slug(f"{tc_id}-{kind}-{file.stem}")[:80]
        # Ensure uniqueness.
        base, n = doc_id, 1
        while doc_id in self.documents:
            n += 1
            doc_id = f"{base}-{n}"
        ref = DocumentRef(
            id=doc_id,
            name=file.name,
            path=str(file),
            doc_type=file.suffix.lower().lstrip("."),
            kind=kind,
            test_case_id=tc_id,
            size_bytes=file.stat().st_size,
        )
        self.documents[doc_id] = ref
        return ref

    # ----------------------------------------------------------- blob source
    def _build_index_from_blob(self) -> bool:
        """Index the sample-data pack listed in Azure Blob Storage.

        Files are registered with their blob metadata (no download); each file's
        bytes are streamed lazily into the local cache on first ``get_text``.
        Returns False when the pack is empty/unreachable so callers can fall back.
        """
        from .blob_storage import list_pack_blobs

        entries = list_pack_blobs()
        if not entries:
            return False
        cache = Path(settings.sample_data_cache_dir)
        tcs: dict[str, TestCase] = {}
        for rel, size in sorted(entries):
            parts = rel.split("/")
            name = parts[-1]
            if _is_temp_file(name) or Path(name).suffix.lower() not in SUPPORTED_SUFFIXES:
                continue
            top = parts[0]
            m = re.match(r"Test case (\d+)\s*-\s*(.+)", top)
            if m and len(parts) > 1:
                number, title = m.group(1), m.group(2).strip()
                tc_id = f"tc{number}"
                tc = tcs.get(tc_id)
                if tc is None:
                    tc = TestCase(
                        id=tc_id,
                        number=number,
                        title=title,
                        archetype=_ARCHETYPES.get(number, "unknown"),
                        folder=str(cache / top),
                    )
                    tcs[tc_id] = tc
                lower = name.lower()
                if "prompt" in lower:
                    kind = "prompt"
                elif "expected output" in lower:
                    kind = "expected_output"
                else:
                    kind = "input"
                doc = self._register_blob(rel, size, kind, tc_id)
                if kind == "prompt":
                    tc.prompt_text = self.get_text(doc.id)
                elif kind == "expected_output":
                    tc.expected_output_text = self.get_text(doc.id)
                else:
                    tc.input_documents.append(doc)
            elif (
                len(parts) == 1
                and "success criteria" in top.lower()
                and top.lower().endswith(".xlsx")
                and self.criteria_doc is None
            ):
                self.criteria_doc = self._register_blob(rel, size, "criteria", "")
        for tc_id in sorted(tcs):
            self.test_cases[tc_id] = tcs[tc_id]
        return True

    def _register_blob(self, rel: str, size: int, kind: str, tc_id: str) -> DocumentRef:
        stem = Path(rel).stem
        doc_id = _slug(f"{tc_id}-{kind}-{stem}")[:80]
        base, n = doc_id, 1
        while doc_id in self.documents:
            n += 1
            doc_id = f"{base}-{n}"
        local_path = Path(settings.sample_data_cache_dir) / rel
        ref = DocumentRef(
            id=doc_id,
            name=Path(rel).name,
            path=str(local_path),
            doc_type=Path(rel).suffix.lower().lstrip("."),
            kind=kind,
            test_case_id=tc_id,
            size_bytes=size,
        )
        self.documents[doc_id] = ref
        self._blob_rel[doc_id] = rel
        return ref

    def _ensure_local(self, ref: DocumentRef) -> None:
        """Stream a blob-backed document into the local cache on first use."""
        rel = self._blob_rel.get(ref.id)
        if not rel:
            return
        path = Path(ref.path)
        if path.exists() and (
            ref.size_bytes == 0 or path.stat().st_size == ref.size_bytes
        ):
            return
        from .blob_storage import download_to

        try:
            download_to(rel, path)
        except Exception:  # noqa: BLE001 - extraction handles a missing/failed file
            logger.exception("Failed to stream sample-data blob %s", rel)

    # --------------------------------------------------------------- uploads
    def register_uploaded_test_case(
        self,
        *,
        title: str,
        input_files: list[tuple[str, bytes]],
        prompt_file: tuple[str, bytes] | None = None,
        prompt_text: str = "",
        expected_file: tuple[str, bytes] | None = None,
    ) -> TestCase:
        """Persist uploaded files as a runnable custom test case (prompt + inputs)."""
        up_id = "up" + uuid.uuid4().hex[:8]
        dest = self._uploads_dir / up_id
        input_dir = dest / "Input data"
        input_dir.mkdir(parents=True, exist_ok=True)
        tc = TestCase(
            id=up_id,
            number=up_id.upper(),
            title=title.strip() or "Uploaded test case",
            archetype="custom",
            folder=str(dest),
        )

        if prompt_file is not None:
            path = dest / _safe_name(prompt_file[0])
            path.write_bytes(prompt_file[1])
            if path.suffix.lower() in SUPPORTED_SUFFIXES:
                doc = self._register(path, "prompt", up_id)
                tc.prompt_text = self.get_text(doc.id)
        elif prompt_text.strip():
            path = dest / "prompt.txt"
            path.write_text(prompt_text, encoding="utf-8")
            doc = self._register(path, "prompt", up_id)
            tc.prompt_text = prompt_text

        if expected_file is not None:
            path = dest / _safe_name(expected_file[0])
            path.write_bytes(expected_file[1])
            if path.suffix.lower() in SUPPORTED_SUFFIXES:
                doc = self._register(path, "expected_output", up_id)
                tc.expected_output_text = self.get_text(doc.id)

        for name, data in input_files:
            path = input_dir / _safe_name(name)
            path.write_bytes(data)
            if path.suffix.lower() in SUPPORTED_SUFFIXES:
                doc = self._register(path, "input", up_id)
                tc.input_documents.append(doc)

        self.test_cases[up_id] = tc
        self._persist_uploads()
        return tc

    def _load_uploads(self) -> None:
        """Re-register previously uploaded custom test cases from disk."""
        index = self._uploads_dir / "index.json"
        if not index.exists():
            return
        try:
            import json

            entries = json.loads(index.read_text(encoding="utf-8"))
        except (ValueError, OSError):
            return
        for entry in entries:
            folder = Path(entry.get("folder", ""))
            if not folder.exists():
                continue
            tc = TestCase(
                id=entry["id"],
                number=entry.get("number", entry["id"].upper()),
                title=entry.get("title", "Uploaded test case"),
                archetype="custom",
                folder=str(folder),
            )
            for rel, kind in entry.get("files", []):
                path = folder / rel
                if not path.exists() or path.suffix.lower() not in SUPPORTED_SUFFIXES:
                    continue
                doc = self._register(path, kind, tc.id)
                if kind == "prompt":
                    tc.prompt_text = self.get_text(doc.id)
                elif kind == "expected_output":
                    tc.expected_output_text = self.get_text(doc.id)
                else:
                    tc.input_documents.append(doc)
            self.test_cases[tc.id] = tc

    def _persist_uploads(self) -> None:
        import json

        entries = []
        for tc in self.test_cases.values():
            if tc.archetype != "custom":
                continue
            folder = Path(tc.folder)
            files: list[list[str]] = []
            for ref in self.documents.values():
                if ref.test_case_id != tc.id:
                    continue
                try:
                    rel = str(Path(ref.path).relative_to(folder))
                except ValueError:
                    continue
                files.append([rel, ref.kind])
            entries.append(
                {
                    "id": tc.id,
                    "number": tc.number,
                    "title": tc.title,
                    "folder": str(folder),
                    "files": files,
                }
            )
        self._uploads_dir.mkdir(parents=True, exist_ok=True)
        (self._uploads_dir / "index.json").write_text(
            json.dumps(entries, indent=2), encoding="utf-8"
        )

    def get_text(self, doc_id: str) -> str:
        if doc_id in self._text_cache:
            return self._text_cache[doc_id]
        ref = self.documents.get(doc_id)
        if not ref:
            return ""
        self._ensure_local(ref)
        text = self._extract(Path(ref.path))
        self._text_cache[doc_id] = text
        return text

    def _extract(self, path: Path) -> str:
        """Extract text, preferring Mistral OCR for PDFs/images when configured."""
        ocr = get_ocr_client()
        if ocr.available and ocr.can_handle(path):
            try:
                text = ocr.extract(path)
                if text.strip():
                    return text
            except Exception:  # noqa: BLE001 - try the document's native text layer
                logger.exception("OCR failed for %s; trying native extraction", path.name)
        try:
            return extract_text(path)
        except Exception:  # noqa: BLE001 - keep the pack usable if one file fails
            logger.exception("Text extraction failed for %s", path.name)
            if path.suffix.lower() == ".pdf":
                raise
            return ""

    def get_document(self, doc_id: str) -> DocumentRef | None:
        return self.documents.get(doc_id)

    def get_test_case(self, tc_id: str) -> TestCase | None:
        return self.test_cases.get(tc_id)

    def list_test_cases(self) -> list[TestCase]:
        return [self.test_cases[k] for k in sorted(self.test_cases)]

    # ----------------------------------------------------------------- search
    def search(
        self, query: str, kinds: list[str] | None = None, top: int = 20
    ) -> list[dict[str, Any]]:
        """Keyword search across ingested documents (BC Search)."""
        terms = [t for t in re.findall(r"\w+", query.lower()) if t]
        results: list[dict[str, Any]] = []
        for ref in self.documents.values():
            if kinds and ref.kind not in kinds:
                continue
            text = self.get_text(ref.id)
            haystack = f"{ref.name}\n{text}".lower()
            if terms:
                score = sum(haystack.count(t) for t in terms)
                name_hits = sum(ref.name.lower().count(t) for t in terms)
                score += name_hits * 5
            else:
                score = 1
            if score <= 0:
                continue
            results.append(
                {
                    **ref.to_dict(),
                    "score": score,
                    "snippet": _snippet(text, terms),
                }
            )
        results.sort(key=lambda r: r["score"], reverse=True)
        return results[:top]

    def facets(self) -> dict[str, dict[str, int]]:
        doc_type: dict[str, int] = {}
        kind: dict[str, int] = {}
        test_case: dict[str, int] = {}
        for ref in self.documents.values():
            doc_type[ref.doc_type] = doc_type.get(ref.doc_type, 0) + 1
            kind[ref.kind] = kind.get(ref.kind, 0) + 1
            if ref.test_case_id:
                test_case[ref.test_case_id] = test_case.get(ref.test_case_id, 0) + 1
        return {"doc_type": doc_type, "kind": kind, "test_case": test_case}


def _snippet(text: str, terms: list[str], width: int = 220) -> str:
    if not text:
        return ""
    if terms:
        low = text.lower()
        for t in terms:
            idx = low.find(t)
            if idx != -1:
                start = max(0, idx - width // 2)
                return text[start : start + width].replace("\n", " ").strip()
    return text[:width].replace("\n", " ").strip()


@lru_cache
def get_document_store() -> DocumentStore:
    return DocumentStore()
