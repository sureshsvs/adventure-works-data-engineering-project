"""Run persistence: report ``.docx`` + run metadata.

Two backends behind one interface:

* :class:`LocalRunStore` (default) — JSON + ``.docx`` on local disk, matching the
  original behaviour.
* :class:`AzureRunStore` — report ``.docx`` in Azure Blob Storage and the full run
  document in Azure Cosmos DB, so the run list is a cheap query (and survives
  container restarts / scale-out).

``azure.*`` imports are lazy so the app runs locally without the Azure SDKs.
"""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Protocol

from ..config import settings
from .models import GenerationRun, generation_run_from_dict

logger = logging.getLogger(__name__)
_RUN_ID_PATTERN = re.compile(r"run_[0-9a-f]{12}\Z")


class RunStore(Protocol):
    def save(self, run: GenerationRun, report_bytes: bytes) -> None: ...
    def save_metadata(self, run: GenerationRun) -> None: ...
    def load(self, run_id: str) -> GenerationRun | None: ...
    def list_summaries(self) -> list[dict[str, Any]]: ...
    def open_report(self, run_id: str) -> tuple[bytes, str] | None: ...


class LocalRunStore:
    """Persist runs as ``{run_id}.json`` + report ``.docx`` under ``run_dir``."""

    def __init__(self, run_dir: Path) -> None:
        self._dir = run_dir
        self._dir.mkdir(parents=True, exist_ok=True)

    def save(self, run: GenerationRun, report_bytes: bytes) -> None:
        if run.report_filename:
            (self._dir / run.report_filename).write_bytes(report_bytes)
        (self._dir / f"{run.run_id}.json").write_text(
            json.dumps(run.to_dict(), indent=2), encoding="utf-8"
        )

    def save_metadata(self, run: GenerationRun) -> None:
        (self._dir / f"{run.run_id}.json").write_text(
            json.dumps(run.to_dict(), indent=2), encoding="utf-8"
        )

    def load(self, run_id: str) -> GenerationRun | None:
        if not isinstance(run_id, str) or not _RUN_ID_PATTERN.fullmatch(run_id):
            return None
        path = next(
            (
                candidate
                for candidate in self._dir.glob("run_*.json")
                if candidate.stem == run_id
            ),
            None,
        )
        if path is None:
            return None
        return generation_run_from_dict(json.loads(path.read_text(encoding="utf-8")))

    def list_summaries(self) -> list[dict[str, Any]]:
        runs: list[dict[str, Any]] = []
        for f in self._dir.glob("run_*.json"):
            data = json.loads(f.read_text(encoding="utf-8"))
            runs.append(
                {
                    "run_id": data["run_id"],
                    "run_title": data.get("run_title") or data["test_case_title"],
                    "description": data.get("description", ""),
                    "report_version": data.get("report_version"),
                    "reporting_period": data.get("reporting_period"),
                    "reporting_year": data.get("reporting_year"),
                    "test_case_id": data["test_case_id"],
                    "test_case_title": data["test_case_title"],
                    "created_at": data.get("created_at", ""),
                    "mode": data.get("mode", "offline"),
                    "section_count": data.get("section_count", 0),
                    "table_count": data.get("table_count", 0),
                    "report_filename": data.get("report_filename", ""),
                }
            )
        runs.sort(key=lambda r: r["created_at"], reverse=True)
        return runs

    def open_report(self, run_id: str) -> tuple[bytes, str] | None:
        run = self.load(run_id)
        if not run or not run.report_filename:
            return None
        path = self._dir / run.report_filename
        if not path.exists():
            return None
        return path.read_bytes(), run.report_filename


class AzureRunStore:
    """Persist report .docx to Blob and the full run document to Cosmos DB."""

    def __init__(self) -> None:
        self._container = settings.run_reports_container

    # ------------------------------------------------------------ cosmos client
    def _cosmos(self):
        from azure.cosmos import CosmosClient, PartitionKey

        if settings.cosmos_key:
            client = CosmosClient(
                settings.cosmos_endpoint, credential=settings.cosmos_key
            )
        else:
            from azure.identity import DefaultAzureCredential

            client = CosmosClient(
                settings.cosmos_endpoint,
                credential=DefaultAzureCredential(
                    managed_identity_client_id=settings.azure_client_id or None
                ),
            )
        db = client.create_database_if_not_exists(settings.cosmos_database)
        return db.create_container_if_not_exists(
            id=settings.cosmos_container,
            partition_key=PartitionKey(path="/run_id"),
        )

    # -------------------------------------------------------------------- writes
    def save(self, run: GenerationRun, report_bytes: bytes) -> None:
        from . import blob_storage

        if run.report_filename:
            blob_storage.upload_bytes(
                self._container, f"{run.run_id}/{run.report_filename}", report_bytes
            )
        item = run.to_dict()
        item["id"] = run.run_id  # Cosmos item id
        self._cosmos().upsert_item(item)

    def save_metadata(self, run: GenerationRun) -> None:
        item = run.to_dict()
        item["id"] = run.run_id
        self._cosmos().upsert_item(item)

    # --------------------------------------------------------------------- reads
    def load(self, run_id: str) -> GenerationRun | None:
        try:
            item = self._cosmos().read_item(item=run_id, partition_key=run_id)
        except Exception:  # noqa: BLE001 - not found / unreachable
            return None
        return generation_run_from_dict(item)

    def list_summaries(self) -> list[dict[str, Any]]:
        try:
            query = (
                "SELECT c.run_id, c.test_case_id, c.test_case_title, c.created_at, "
                "c.mode, c.section_count, c.table_count, c.report_filename, "
                "c.run_title, c.description, "
                "c.report_version, c.reporting_period, c.reporting_year "
                "FROM c WHERE IS_DEFINED(c.test_case_id) ORDER BY c.created_at DESC"
            )
            # Runs are partitioned per run_id, so the list spans partitions.
            items = self._cosmos().query_items(
                query=query, enable_cross_partition_query=True
            )
            return [
                {
                    **dict(i),
                    "run_title": i.get("run_title") or i.get("test_case_title", ""),
                    "description": i.get("description", ""),
                    "report_version": i.get("report_version"),
                    "reporting_period": i.get("reporting_period"),
                    "reporting_year": i.get("reporting_year"),
                }
                for i in items
            ]
        except Exception:  # noqa: BLE001 - empty/unreachable container -> no runs
            logger.exception("Failed to list runs from Cosmos DB")
            return []

    def open_report(self, run_id: str) -> tuple[bytes, str] | None:
        from . import blob_storage

        run = self.load(run_id)
        if not run or not run.report_filename:
            return None
        data = blob_storage.download_bytes(
            self._container, f"{run_id}/{run.report_filename}"
        )
        if data is None:
            return None
        return data, run.report_filename


def build_run_store(run_dir: Path) -> RunStore:
    if settings.azure_runs_enabled:
        return AzureRunStore()
    return LocalRunStore(run_dir)
