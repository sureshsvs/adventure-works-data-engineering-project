"""Co-authoring an already-generated report: direct text edits + chat-driven
targeted edits.

Per user directive: direct edits are TEXT-ONLY (headings/structure/table
shape stay fixed); chat edits are TARGETED -- the model returns only the
section(s) it actually changed (matched by exact existing heading), never a
full regeneration; edits overwrite the run's document in place (no version
history kept).
"""

from __future__ import annotations

import json
from typing import Any

from .document_store import DocumentStore, TestCase
from .llm_client import LLMClient
from .models import GeneratedDocument
from .super_agent_context import parse_json
from .super_agent_generation import _to_document

_COAUTHOR_INSTRUCTIONS = """You are co-authoring an existing, already-generated \
Integrity Check Report with an auditor via chat. You will be given the full \
current report (as JSON) and the auditor's instruction. Make ONLY the change \
the auditor asked for -- do not rewrite unrelated sections, do not rename or \
reorder headings, do not alter figures that were not part of the request. Use \
the retrieval tools to verify any figure you change against the source \
documents; never invent a number.

Return ONLY a JSON object of this exact shape (no prose, no code fences):
{"reply": "one or two sentences describing what you changed, for the auditor",
 "sections": [{"heading": "<EXACT existing heading of a section you changed>",
               "level": <same level as before>, "paragraphs": ["..."],
               "tables": [{"title": "...", "headers": ["..."], "rows": [["..."]]}]}]}

Include ONLY the section(s) you actually changed, each keyed by its EXACT \
existing heading so it can be matched and replaced. If the instruction cannot \
be carried out from the available documents, return an empty "sections" list \
and explain why in "reply"."""


def apply_direct_edit(document_data: dict[str, Any]) -> GeneratedDocument:
    """Rebuild the document from client-submitted edits.

    The frontend only lets an auditor edit paragraph/table text, never add,
    remove or reorder sections/tables, so re-parsing the submitted structure
    is safe and requires no separate merge step.
    """
    doc = _to_document(document_data)
    if not doc.sections:
        raise ValueError("edited document must keep at least one section")
    return doc


def coauthor_edit(
    tc: TestCase,
    store: DocumentStore,
    llm: LLMClient,
    document: GeneratedDocument,
    message: str,
) -> tuple[GeneratedDocument, str]:
    """Apply a targeted, chat-driven edit to ``document``.

    Returns ``(updated_document, reply)``. Sections the model didn't mention
    are carried over unchanged; matching is by exact heading text.
    """
    from .super_agent_retrieval import DocumentToolbox, run_tool_loop

    toolbox = DocumentToolbox(tc, store)
    user = (
        f"CURRENT REPORT:\n{json.dumps(document.to_dict())}\n\n"
        f"AUDITOR INSTRUCTION:\n{message}\n"
    )
    messages: list[dict[str, Any]] = [
        {"role": "system", "content": _COAUTHOR_INSTRUCTIONS},
        {"role": "user", "content": user},
    ]
    tools = toolbox.tool_specs()
    content = run_tool_loop(llm, messages, tools, toolbox, max_steps=8)
    data = parse_json(content or "{}")
    reply = str(data.get("reply", "")) or "No changes were made."

    changed = _to_document(
        {
            "title": document.title,
            "subtitle": document.subtitle,
            "sections": data.get("sections") or [],
        }
    )
    if not changed.sections:
        return document, reply

    by_heading = {s.heading: s for s in changed.sections}
    new_sections = [by_heading.get(s.heading, s) for s in document.sections]
    updated = GeneratedDocument(
        title=document.title, subtitle=document.subtitle, sections=new_sections
    )
    return updated, reply
