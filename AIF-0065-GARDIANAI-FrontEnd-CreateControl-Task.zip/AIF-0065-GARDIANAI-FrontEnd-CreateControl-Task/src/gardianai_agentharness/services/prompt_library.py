"""Editable, versioned prompt library (success criterion C12).

Each entry maps a PoC test case to (a) the natural-language auditor prompt and
(b) the ordered list of control definitions the SuperAgent executes. Superusers
can edit prompts through the API; every save bumps the version and is persisted
to disk so runs record which prompt version produced them (C6 auditability).
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from functools import lru_cache
from typing import Any

from ..config import settings
from . import blob_storage
from .document_store import get_document_store


# Canonical control definitions per archetype. These are the auditable "rules"
# the engine applies; findings cite them (C6).
_CONTROL_DEFINITIONS: dict[str, list[dict[str, str]]] = {
    "integrity_within_document": [
        {
            "control_id": "TC1-C1",
            "name": "Group metric cross-consistency",
            "description": "Verify key Group metrics (Adjusted Earnings, Adjusted "
            "EBITDA, CFO, production) are consistent between the summary, segment "
            "tables and primary financial statements across all periods.",
        },
        {
            "control_id": "TC1-C2",
            "name": "Segment-to-Group roll-up",
            "description": "Recalculate segment totals and reconcile to disclosed "
            "Group totals; flag any difference beyond stated rounding.",
        },
        {
            "control_id": "TC1-C3",
            "name": "Financial statement line-by-line integrity",
            "description": "Check consistency of every line across financial "
            "statements and notes; recompute subtotals and totals.",
        },
        {
            "control_id": "TC1-C4",
            "name": "Narrative vs tabular consistency",
            "description": "Confirm figures quoted in the narrative match validated "
            "table values; flag placeholders/drafting issues.",
        },
    ],
    "detailed_section_check": [
        {
            "control_id": "TC2-C1",
            "name": "Add-up & percentage-change recalculation",
            "description": "Recompute Current Quarter + YTD add-ups and all "
            "percentage changes for the section; flag any disagreement.",
        },
        {
            "control_id": "TC2-C2",
            "name": "Prior-period comparative tie-out",
            "description": "Match prior-period comparatives to the prior "
            "publications (Q3 2025 and Q4 2024 QRA).",
        },
        {
            "control_id": "TC2-C3",
            "name": "Whole-document metric consistency",
            "description": "Check each metric against every other place it appears "
            "(Note 2, segment tables, narrative).",
        },
        {
            "control_id": "TC2-C4",
            "name": "Table headers & footnotes",
            "description": "Validate headers and footnote references are correct "
            "and applied against the right columns.",
        },
        {
            "control_id": "TC2-C5",
            "name": "Reference-letter validation",
            "description": "For each Reference letter (A, B, C...) validate the "
            "metric against the referenced section and recompute.",
        },
        {
            "control_id": "TC2-C6",
            "name": "Databook (CP sheet) tie-out",
            "description": "Reconcile financial and operational values to the "
            "Quarterly Databook CP sheet.",
        },
    ],
    "grounded_web_check": [
        {
            "control_id": "TC3-C1",
            "name": "Completeness vs public releases",
            "description": "Confirm every portfolio-development item published on "
            "the Shell newsroom (Oct–Dec 2025) is reflected in the QRA section.",
        },
        {
            "control_id": "TC3-C2",
            "name": "Narrative & data consistency vs web",
            "description": "Check the narrative and figures around each portfolio "
            "development are consistent between the website and the document.",
        },
        {
            "control_id": "TC3-C3",
            "name": "Cross-section completeness",
            "description": "Detect material portfolio actions disclosed outside the "
            "Portfolio Developments section.",
        },
    ],
    "cross_document_check": [
        {
            "control_id": "TC4-C1",
            "name": "Headline financials integrity",
            "description": "Check every headline number in the IR deck against the "
            "QRA (source of truth) across all periods, allowing only rounding.",
        },
        {
            "control_id": "TC4-C2",
            "name": "Segment table reconciliation",
            "description": "Reconcile IR-deck segment tables to the QRA segment "
            "data (Adjusted Earnings / EBITDA / CFFO).",
        },
        {
            "control_id": "TC4-C3",
            "name": "Percentage & FY calculations",
            "description": "Recompute percentage and full-year calculations and "
            "confirm the deck is supportable from the QRA.",
        },
        {
            "control_id": "TC4-C4",
            "name": "Narrative & wording consistency",
            "description": "Compare narrative, definitions/APMs and wording; flag "
            "mismatches, placeholders and footer/reference errors.",
        },
        {
            "control_id": "TC4-C5",
            "name": "Databook support",
            "description": "Use the Quarterly Databook to corroborate figures and "
            "confirm the correct databook year is referenced.",
        },
    ],
}


class PromptLibrary:
    """Persisted, versioned prompt + control-definition library (blob-only)."""

    def __init__(self) -> None:
        self._blob_name = f"{settings.prompt_library_prefix}/prompt_library.json"
        self.entries: dict[str, dict[str, Any]] = {}
        self._load_or_seed()

    def _load_or_seed(self) -> None:
        blob_storage.require_blob_storage("Prompt library")
        raw = blob_storage.download_bytes(settings.sample_data_container, self._blob_name)
        if raw is not None:
            self.entries = json.loads(raw.decode("utf-8"))
            return
        store = get_document_store()
        for tc in store.list_test_cases():
            self.entries[tc.id] = {
                "id": tc.id,
                "test_case_id": tc.id,
                "title": tc.title,
                "archetype": tc.archetype,
                "prompt": tc.prompt_text,
                "controls": _CONTROL_DEFINITIONS.get(tc.archetype, []),
                "version": 1,
                "updated_at": datetime.now(timezone.utc).isoformat(),
                "updated_by": "seed",
            }
        self._persist()

    def _persist(self) -> None:
        data = json.dumps(self.entries, indent=2).encode("utf-8")
        blob_storage.upload_bytes(settings.sample_data_container, self._blob_name, data)

    def list(self) -> list[dict[str, Any]]:
        return [self.entries[k] for k in sorted(self.entries)]

    def get(self, entry_id: str) -> dict[str, Any] | None:
        return self.entries.get(entry_id)

    def update(
        self, entry_id: str, prompt: str, updated_by: str = "superuser"
    ) -> dict[str, Any] | None:
        entry = self.entries.get(entry_id)
        if not entry:
            return None
        entry["prompt"] = prompt
        entry["version"] = int(entry.get("version", 1)) + 1
        entry["updated_at"] = datetime.now(timezone.utc).isoformat()
        entry["updated_by"] = updated_by
        self._persist()
        return entry

    def version_tag(self, entry_id: str) -> str:
        entry = self.entries.get(entry_id, {})
        return f"{entry_id}@v{entry.get('version', 1)}"


@lru_cache
def get_prompt_library() -> PromptLibrary:
    return PromptLibrary()
