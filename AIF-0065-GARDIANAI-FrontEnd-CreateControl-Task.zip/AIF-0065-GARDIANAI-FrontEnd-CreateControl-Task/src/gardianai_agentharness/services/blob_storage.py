"""Azure Blob Storage access for the sample-data pack and run reports.

The document store, OCR and Agent Harness all operate on local file paths, so the
sample-data pack is streamed from blob storage into a local cache directory on
demand (see ``DocumentStore``). This module also exposes a small blob helper used
by the run store to persist generated report artifacts.

All ``azure.*`` imports are lazy so the application still runs (against the bundled
sampledata/) when the SDK is not installed or no storage account is configured.
"""

from __future__ import annotations

import logging
import threading
from pathlib import Path
from datetime import datetime

from ..config import settings

logger = logging.getLogger(__name__)


class BlobStorageNotConfigured(RuntimeError):
    """Raised when a blob-only feature is used without a storage account set."""


class BlobStorageListingError(RuntimeError):
    """Raised when a Blob Storage listing cannot be completed."""


def require_blob_storage(feature: str) -> None:
    if not settings.blob_storage_enabled:
        raise BlobStorageNotConfigured(
            f"{feature} requires Azure Blob Storage — set AZURE_STORAGE_ACCOUNT_URL "
            "or AZURE_STORAGE_CONNECTION_STRING."
        )


def _blob_service_client():
    """Return a cached ``BlobServiceClient`` built from a connection string or
    account URL + identity.

    The client (and its ``DefaultAzureCredential``) is created once per process
    and reused, so the credential chain and token are not rebuilt on every call.
    """
    global _blob_service_client_singleton
    if _blob_service_client_singleton is not None:
        return _blob_service_client_singleton
    with _blob_service_lock:
        if _blob_service_client_singleton is not None:
            return _blob_service_client_singleton
        from azure.storage.blob import BlobServiceClient

        if settings.azure_storage_connection_string:
            client = BlobServiceClient.from_connection_string(
                settings.azure_storage_connection_string
            )
        else:
            # Managed identity / az login via DefaultAzureCredential.
            from azure.identity import DefaultAzureCredential

            credential = DefaultAzureCredential(
                managed_identity_client_id=settings.azure_client_id or None
            )
            client = BlobServiceClient(
                account_url=settings.azure_storage_account_url, credential=credential
            )
        _blob_service_client_singleton = client
        return client


_blob_service_client_singleton = None
_blob_service_lock = threading.Lock()


def _container_client(container: str):
    return _blob_service_client().get_container_client(container)


# ------------------------------------------------------------------ sample data
def _name_prefix() -> str:
    prefix = settings.sample_data_prefix.strip("/")
    return f"{prefix}/" if prefix else ""


def list_pack_blobs() -> list[tuple[str, int]]:
    """List the sample-data pack as ``(relative_path, size_bytes)`` tuples.

    Paths are relative to ``sample_data_prefix`` so they mirror the on-disk
    ``sampledata/poc-testcases`` tree. Returns an empty list on any failure.
    """
    name_prefix = _name_prefix()
    try:
        container = _container_client(settings.sample_data_container)
        entries: list[tuple[str, int]] = []
        for blob in container.list_blobs(name_starts_with=name_prefix):
            rel = blob.name[len(name_prefix):] if name_prefix else blob.name
            if not rel or rel.endswith("/"):
                continue
            entries.append((rel, int(blob.size or 0)))
        return entries
    except Exception:  # noqa: BLE001 - callers fall back to bundled sampledata/
        logger.exception("Failed to list sample-data blobs")
        return []


def download_to(rel: str, dest: Path) -> None:
    """Stream the sample-data blob at ``rel`` (under the prefix) into ``dest``."""
    name = f"{_name_prefix()}{rel}"
    container = _container_client(settings.sample_data_container)
    dest.parent.mkdir(parents=True, exist_ok=True)
    data = container.download_blob(name).readall()
    dest.write_bytes(data)


def list_task_blobs(prefix: str) -> list[tuple[str, int, datetime | None]]:
    """List task blobs below the sample-data prefix with modification times.

    Returned blob names are relative to ``sample_data_prefix``, matching the
    names consumed by ``TaskStore`` and ``download_task_blob``.
    """
    return _list_task_blobs(prefix, raise_on_error=False)


def list_task_blobs_strict(prefix: str = "") -> list[tuple[str, int, datetime | None]]:
    """List task blobs and raise if storage cannot be reached."""
    return _list_task_blobs(prefix, raise_on_error=True)


def _list_task_blobs(
    prefix: str, *, raise_on_error: bool
) -> list[tuple[str, int, datetime | None]]:
    name_prefix = _name_prefix()
    full_prefix = f"{name_prefix}{prefix.lstrip('/')}"
    try:
        container = _container_client(settings.sample_data_container)
        return [
            (blob.name[len(name_prefix):] if name_prefix else blob.name,
             int(blob.size or 0),
             blob.last_modified)
            for blob in container.list_blobs(name_starts_with=full_prefix)
            if blob.name and not blob.name.endswith("/")
        ]
    except Exception as e:  # noqa: BLE001 - optionally preserve legacy empty-list behavior
        logger.exception(
            "Failed to list task blobs under %s in container %s, exception: %s",
            full_prefix,
            settings.sample_data_container,
            e,
        )
        if raise_on_error:
            raise BlobStorageListingError(
                f"Failed to list task blobs under {full_prefix}"
            ) from e
        return []

def download_task_blob(blob_name: str, dest: Path) -> None:
    """Download a task blob to the local document cache."""
    container = _container_client(settings.sample_data_container)
    dest.parent.mkdir(parents=True, exist_ok=True)
    data = container.download_blob(f"{_name_prefix()}{blob_name.lstrip('/')}").readall()
    dest.write_bytes(data)


# ------------------------------------------------------------------ run reports
def upload_bytes(container: str, blob_name: str, data: bytes) -> None:
    """Upload ``data`` to ``container``/``blob_name`` (overwriting)."""
    client = _container_client(container)
    try:
        client.create_container()
    except Exception:  # noqa: BLE001 - container already exists / no create rights
        pass
    client.upload_blob(name=blob_name, data=data, overwrite=True)


def download_bytes(container: str, blob_name: str) -> bytes | None:
    """Download ``container``/``blob_name`` as bytes, or None if missing."""
    try:
        return _container_client(container).download_blob(blob_name).readall()
    except Exception:  # noqa: BLE001 - treat any failure as "not found"
        return None
