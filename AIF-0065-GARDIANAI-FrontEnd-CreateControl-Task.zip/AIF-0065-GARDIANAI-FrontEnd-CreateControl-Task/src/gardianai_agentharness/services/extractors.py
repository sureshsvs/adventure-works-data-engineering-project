"""Document text extractors.

Supports pdf, docx, xlsx, pptx using **stdlib only** where possible so the
platform ingests the real PoC input files (satisfies success criterion C3).
PDFs require ``pypdf``; raw PDF bytes must never be treated as extracted text.
"""

from __future__ import annotations

import re
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET

_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
_S = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_A = "{http://schemas.openxmlformats.org/drawingml/2006/main}"

SUPPORTED_SUFFIXES = {".pdf", ".docx", ".xlsx", ".pptx", ".txt", ".md", ".csv"}


def extract_text(path: Path) -> str:
    """Return the plain-text content of a supported document."""
    suffix = path.suffix.lower()
    if suffix == ".docx":
        return extract_docx(path)
    if suffix == ".xlsx":
        return extract_xlsx(path)
    if suffix == ".pptx":
        return extract_pptx(path)
    if suffix == ".pdf":
        return extract_pdf(path)
    if suffix in {".txt", ".md", ".csv"}:
        return path.read_text(encoding="utf-8", errors="ignore")
    return ""


def extract_docx(path: Path) -> str:
    """Extract paragraph text from a Word document (stdlib)."""
    with zipfile.ZipFile(path) as zf:
        xml = zf.read("word/document.xml")
    root = ET.fromstring(xml)
    lines: list[str] = []
    for para in root.iter(_W + "p"):
        text = "".join(t.text for t in para.iter(_W + "t") if t.text)
        if text.strip():
            lines.append(text)
    return "\n".join(lines)


def extract_xlsx(path: Path) -> str:
    """Extract cell values from every worksheet (stdlib), grouped by sheet."""
    with zipfile.ZipFile(path) as zf:
        shared: list[str] = []
        if "xl/sharedStrings.xml" in zf.namelist():
            sst = ET.fromstring(zf.read("xl/sharedStrings.xml"))
            for si in sst.iter(_S + "si"):
                shared.append("".join(t.text or "" for t in si.iter(_S + "t")))

        scales = _xlsx_style_scales(zf)
        sheet_names = _xlsx_sheet_names(zf)
        blocks: list[str] = []
        sheet_files = sorted(
            n for n in zf.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml", n)
        )
        for idx, name in enumerate(sheet_files):
            root = ET.fromstring(zf.read(name))
            rows: list[str] = []
            for row in root.iter(_S + "row"):
                cells: list[str] = []
                for c in row.iter(_S + "c"):
                    v = c.find(_S + "v")
                    val = ""
                    if v is not None and v.text is not None:
                        if c.get("t") == "s":
                            val = shared[int(v.text)]
                        else:
                            val = _scale_numeric(v.text, c.get("s"), scales)
                    if val:
                        cells.append(val)
                if cells:
                    rows.append("\t".join(cells))
            title = sheet_names[idx] if idx < len(sheet_names) else name
            blocks.append(f"## Sheet: {title}\n" + "\n".join(rows))
        return "\n\n".join(blocks)


def _xlsx_sheet_names(zf: zipfile.ZipFile) -> list[str]:
    try:
        wb = ET.fromstring(zf.read("xl/workbook.xml"))
        return [s.get("name", "") for s in wb.iter(_S + "sheet")]
    except KeyError:
        return []


# A number format's positive-value section can end in trailing commas (e.g.
# ``#,##0,,``), each dividing the DISPLAYED value by 1,000 vs the stored value.
# Real defect found in the Shell quarterly databook: the Q4/FY columns of every
# segment sheet use such a format, so reading the raw cell value without this
# renders them ~1,000,000x larger than every other period in the same row.
_TRAILING_COMMAS = re.compile(r"(,+)(?:\"[^\"]*\")?\s*$")


def _format_scale(format_code: str) -> int:
    """Return the divisor a number format's trailing commas encode (1 if none)."""
    positive_section = format_code.split(";", 1)[0]
    m = _TRAILING_COMMAS.search(positive_section)
    return 1000 ** len(m.group(1)) if m else 1


def _xlsx_style_scales(zf: zipfile.ZipFile) -> list[int]:
    """Return each cell style's display-scale divisor, indexed by style id (``s``)."""
    try:
        styles = ET.fromstring(zf.read("xl/styles.xml"))
    except KeyError:
        return []
    numfmts: dict[int, str] = {}
    numfmts_el = styles.find(_S + "numFmts")
    if numfmts_el is not None:
        for nf in numfmts_el.findall(_S + "numFmt"):
            fmt_id, code = nf.get("numFmtId"), nf.get("formatCode")
            if fmt_id is not None and code is not None:
                numfmts[int(fmt_id)] = code
    cellxfs_el = styles.find(_S + "cellXfs")
    if cellxfs_el is None:
        return []
    scales: list[int] = []
    for xf in cellxfs_el.findall(_S + "xf"):
        code = numfmts.get(int(xf.get("numFmtId", "0")))
        scales.append(_format_scale(code) if code else 1)
    return scales


def _scale_numeric(raw: str, style_attr: str | None, scales: list[int]) -> str:
    """Divide a numeric cell's stored value by its format's display scale."""
    scale = 1
    if style_attr is not None:
        idx = int(style_attr)
        if idx < len(scales):
            scale = scales[idx]
    if scale == 1:
        return raw
    try:
        return repr(float(raw) / scale)
    except ValueError:
        return raw


def extract_pptx(path: Path) -> str:
    """Extract text from all slides of a PowerPoint deck (stdlib)."""
    with zipfile.ZipFile(path) as zf:
        slide_files = sorted(
            n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml", n)
        )
        blocks: list[str] = []
        for i, name in enumerate(slide_files, start=1):
            root = ET.fromstring(zf.read(name))
            texts = [t.text for t in root.iter(_A + "t") if t.text]
            if texts:
                blocks.append(f"## Slide {i}\n" + "\n".join(texts))
        return "\n\n".join(blocks)


def extract_pdf(path: Path) -> str:
    """Extract the PDF text layer, failing explicitly if extraction is unavailable."""
    try:
        from pypdf import PdfReader  # type: ignore
    except ImportError as exc:
        raise RuntimeError(
            f"Cannot extract PDF '{path.name}': pypdf is not installed. "
            "Install the project's requirements in the backend environment."
        ) from exc
    try:
        reader = PdfReader(str(path))
        pages: list[str] = []
        for i, page in enumerate(reader.pages, start=1):
            text = page.extract_text() or ""
            if text.strip():
                pages.append(f"## Page {i}\n{text}")
        if pages:
            return "\n\n".join(pages)
    except Exception as exc:  # noqa: BLE001 - preserve the cause of PDF reader failures
        raise RuntimeError(f"Cannot extract PDF '{path.name}': {exc}") from exc
    raise RuntimeError(
        f"PDF '{path.name}' has no extractable text layer. "
        "Configure OCR or supply a text-readable version of the document."
    )
