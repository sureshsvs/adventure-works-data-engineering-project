"""Logical source catalog: roles, period offsets and document aliases.

A logical source role maps to a configured relative source path under a
reporting period:

``poc-testcases/Quarterly/<period>/<scope>/<source-folder>``

Each role declares a period offset relative to the selected period, a scope
(``External`` or ``Internal MI``) and a source folder. Document-reference tokens
(``{{DOC:ALIAS@VARIANT}}``) resolve through a registered alias registry to
exactly one role; the role's catalog entry alone determines the period offset.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from .period import Quarter


class PeriodOffset(Enum):
    """How a role's period relates to the selected period."""

    SELECTED = "selected"
    PREVIOUS_QUARTER = "previous_quarter"
    SAME_QUARTER_PRIOR_YEAR = "same_quarter_prior_year"

    def apply(self, selected: Quarter) -> Quarter:
        if self is PeriodOffset.SELECTED:
            return selected
        if self is PeriodOffset.PREVIOUS_QUARTER:
            return selected.previous_quarter()
        return selected.same_quarter_prior_year()


@dataclass(frozen=True)
class RoleDefinition:
    """A logical source role and its period/scope/folder mapping."""

    name: str
    offset: PeriodOffset
    scope: str
    source_folder: str


class UnknownRoleError(KeyError):
    """Raised when a logical source role name is not in the catalog."""


class UnknownDocumentAliasError(KeyError):
    """Raised when a document alias/variant pair is not registered."""


# Fixed catalog of supported logical source roles (MVP1).
ROLE_CATALOG: dict[str, RoleDefinition] = {
    "Current QRA draft": RoleDefinition(
        "Current QRA draft", PeriodOffset.SELECTED, "External", "QRA"
    ),
    "Previous quarter QRA": RoleDefinition(
        "Previous quarter QRA", PeriodOffset.PREVIOUS_QUARTER, "External", "QRA"
    ),
    "Same quarter prior year": RoleDefinition(
        "Same quarter prior year",
        PeriodOffset.SAME_QUARTER_PRIOR_YEAR,
        "External",
        "QRA",
    ),
    "Quarterly databook": RoleDefinition(
        "Quarterly databook", PeriodOffset.SELECTED, "External", "QDB"
    ),
    "IR materials": RoleDefinition(
        "IR materials", PeriodOffset.SELECTED, "External", "IR materials"
    ),
}

# The fixed set of role names returned by GET /tasks/options.
ROLE_NAMES: tuple[str, ...] = tuple(ROLE_CATALOG)

# Document-reference alias registry: (alias, variant) -> canonical role name.
DOCUMENT_ALIASES: dict[tuple[str, str], str] = {
    ("QRA", "CQ"): "Current QRA draft",
    ("QRA", "PQ"): "Previous quarter QRA",
    ("QRA", "SQLY"): "Same quarter prior year",
    ("QDB", "CQ"): "Quarterly databook",
    ("IR_MATERIALS", "CQ"): "IR materials",
}


def get_role(name: str) -> RoleDefinition:
    try:
        return ROLE_CATALOG[name]
    except KeyError as exc:
        raise UnknownRoleError(name) from exc


def resolve_alias(alias: str, variant: str) -> RoleDefinition:
    """Resolve a document ``alias@variant`` to its logical source role."""
    try:
        role_name = DOCUMENT_ALIASES[(alias, variant)]
    except KeyError as exc:
        raise UnknownDocumentAliasError(f"{alias}@{variant}") from exc
    return ROLE_CATALOG[role_name]


def role_prefix(role: RoleDefinition, selected: Quarter) -> str:
    """Build the Blob prefix (relative to the sample-data prefix) for a role.

    ``Quarterly/<period>/<scope>/<source-folder>/``
    """
    period = role.offset.apply(selected)
    return f"Quarterly/{period}/{role.scope}/{role.source_folder}/"
