"""Prompt-driven document generator.

Runs a test case's auditor prompt over its input documents and produces a
structured :class:`GeneratedDocument` that mirrors the PoC benchmark "expected
output" reports. When a SuperAgent LLM is configured it asks the model for the
report as JSON (grounded on the OCR-extracted input text and constrained by the
success-criteria guardrails in ``super_agent_generation_skills.md``); otherwise
it produces a deterministic offline draft. Configured LLM failures are surfaced
as errors rather than saving an offline report as a successful run.
"""

from __future__ import annotations

from pathlib import Path

from ..config import settings
from .document_store import DocumentStore, TestCase
from .llm_client import LLMClient
from .super_agent_context import (
    build_context,
    economy_mode,
    expected_template_chars,
    reasoning_effort,
    report,
    use_expected_template,
)
from .models import DocSection, DocTable, GeneratedDocument
from .super_agent_output import compose_report
from .super_agent_retrieval import DocumentToolbox, run_tool_loop
import logging

logger = logging.getLogger(__name__)    

_SKILLS = (Path(__file__).with_name("super_agent_generation_skills.md")).read_text(
    encoding="utf-8"
)
# Auditor domain guidance applied while retrieving and reasoning over content.
_DOMAIN_SKILLS = (Path(__file__).with_name("super_agent_skills.md")).read_text(
    encoding="utf-8"
)

# The expected-output example is a structural + content-depth template. Provide
# it in full (clipped only as a safety cap) so the model reproduces the same
# sections, tables and types of checks — deriving all figures from the inputs.
_EXPECTED_TEMPLATE_CHARS = 60_000

# Max tool-calling turns for the single-pass retrieval path.
_MAX_TOOL_STEPS = 10


def generate_document(
    tc: TestCase,
    store: DocumentStore,
    prompt: str,
    llm: LLMClient,
) -> tuple[GeneratedDocument, str]:
    """Return the generated document and the mode used ("llm" or "offline")."""
    if llm.available:
        try:
            return _generate_llm(tc, store, prompt, llm), "llm"
        except Exception as exc:  # noqa: BLE001 - surface configured LLM failures
            logger.exception("All LLM strategies failed")
            raise RuntimeError(f"LLM report generation failed: {exc}") from exc
    return _generate_offline(tc, store, prompt), "offline"


# --------------------------------------------------------------------------- LLM
def _generate_llm(
    tc: TestCase, store: DocumentStore, prompt: str, llm: LLMClient
) -> GeneratedDocument:
    """Generate via the best available strategy, degrading on failure.

    harness (Agent Framework) → deep-research → single-pass tool retrieval →
    full-context.
    """
    economy = economy_mode()
    if settings.super_agent_use_harness and not economy:
        try:
            from .super_agent_harness import generate_harness_document

            return generate_harness_document(tc, store, prompt, llm)
        except Exception as e:
            logger.exception(f"Error Message: {e}")
            pass
    if settings.super_agent_deep_research and not economy:
        try:
            from .super_agent_research import generate_research_document

            return generate_research_document(tc, store, prompt, llm)
        except Exception:  # noqa: BLE001 - fall back to the single-pass retrieval loop
            logger.exception("Deep-research strategy failed; falling back")
    if settings.super_agent_tool_retrieval:
        try:
            return _generate_agentic(tc, store, prompt, llm)
        except Exception:  # noqa: BLE001 - fall back to full-context generation
            logger.exception("Tool-retrieval strategy failed; falling back")
    report("compose", "Generating report")
    return _generate_full_context(tc, store, prompt, llm)


def _expected_template(tc: TestCase) -> str:
    if not use_expected_template() or not tc.expected_output_text:
        return ""
    return (
        "BENCHMARK EXPECTED OUTPUT (this is the exact target for structure, "
        "section ordering, table layouts and depth of analysis). Reproduce the "
        "same sections, the same tables/columns and the same kinds of checks and "
        "commentary. DO NOT copy its numbers — recompute and cite every figure "
        "from the input documents:\n"
        "-----BEGIN EXPECTED OUTPUT-----\n"
        f"{tc.expected_output_text[:expected_template_chars()]}\n"
        "-----END EXPECTED OUTPUT-----\n\n"
    )


def _generate_agentic(
    tc: TestCase, store: DocumentStore, prompt: str, llm: LLMClient
) -> GeneratedDocument:
    """Single-pass tool-retrieval: the model pulls windows on demand, then writes."""
    report("analyze", "Retrieving and analyzing documents")
    toolbox = DocumentToolbox(tc, store)
    system = _SKILLS + "\n\n# Domain knowledge\n" + _DOMAIN_SKILLS
    user = (
        f"AUDITOR PROMPT:\n{prompt}\n\n{_expected_template(tc)}"
        "AVAILABLE DOCUMENTS — retrieve content with the tools; never assert a "
        "figure you have not retrieved.\n" + toolbox.manifest_text()
    )
    messages: list[dict] = [
        {"role": "system", "content": system},
        {"role": "user", "content": user},
    ]
    tools = toolbox.tool_specs()
    run_tool_loop(
        llm, messages, tools, toolbox, _MAX_TOOL_STEPS,
        reasoning_effort=reasoning_effort(),
    )
    return compose_report(llm, messages)


def _generate_full_context(
    tc: TestCase, store: DocumentStore, prompt: str, llm: LLMClient
) -> GeneratedDocument:
    """Legacy path: push the extracted input text into a single prompt."""
    context = build_context(tc, store)

    user_content = (
        f"AUDITOR PROMPT:\n{prompt}\n\n"
        f"{_expected_template(tc)}"
        f"INPUT DOCUMENTS (extracted text):\n{context}\n\n"
        "Produce the Integrity Check Report now as the JSON object described in "
        "your skills. Match the benchmark expected output's structure and level "
        "of detail as closely as possible: include every equivalent section, the "
        "same comparison tables (with an integrity/auditor-assessment column), "
        "show your calculations, and list exceptions with a full evidence trail. "
        "Derive every figure from the input documents above — never from the "
        "benchmark."
    )

    return compose_report(llm, [
        {"role": "system", "content": _SKILLS},
        {"role": "user", "content": user_content},
    ])


def _to_document(data: dict) -> GeneratedDocument:
    sections = []
    for s in data.get("sections", []) or []:
        tables = [
            DocTable(
                headers=[str(h) for h in (t.get("headers") or [])],
                rows=[[str(c) for c in row] for row in (t.get("rows") or [])],
                title=str(t.get("title", "")),
            )
            for t in (s.get("tables") or [])
        ]
        sections.append(
            DocSection(
                heading=str(s.get("heading", "")),
                level=_clamp_level(s.get("level", 1)),
                paragraphs=[str(p) for p in (s.get("paragraphs") or []) if str(p).strip()],
                tables=tables,
            )
        )
    return GeneratedDocument(
        title=str(data.get("title", "")),
        subtitle=str(data.get("subtitle", "")),
        sections=sections,
    )


def _clamp_level(value: object) -> int:
    try:
        return max(1, min(3, int(value)))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 1


# ----------------------------------------------------------------------- offline
def _generate_offline(
    tc: TestCase, store: DocumentStore, prompt: str
) -> GeneratedDocument:
    """Deterministic draft used when no LLM is configured.

    It is intentionally explicit that the numeric integrity checks were NOT
    executed (no model available), listing the inputs, the prompt and the
    guardrails so the report is honest and auditable rather than guessing.
    """
    report("compose", "Building offline draft")
    title = f"Integrity Check Report — {tc.title}"
    subtitle = (
        "Scope: the input documents listed below; no external sources used. "
        "Mode: offline draft (no SuperAgent LLM configured)."
    )

    sections: list[DocSection] = []

    sections.append(
        DocSection(
            heading="1. Executive conclusion",
            level=1,
            paragraphs=[
                "This is an offline draft generated without a configured "
                "SuperAgent LLM, so the numeric and narrative integrity checks "
                "were not executed. Configure the Azure AI Foundry / APIM "
                "credentials to produce the full grounded report.",
                "The sections below record the exact request, the ingested "
                "input documents and the success-criteria guardrails that the "
                "grounded run will apply.",
            ],
            tables=[
                DocTable(
                    title="Exceptions / auditor follow-up",
                    headers=["Area", "Observation", "Auditor assessment"],
                    rows=[
                        [
                            "Automated checks",
                            "Not executed in offline mode.",
                            "Re-run with an LLM configured to obtain findings.",
                        ]
                    ],
                )
            ],
        )
    )

    input_rows = [
        [d.name, d.doc_type.upper(), _size_label(d.size_bytes)]
        for d in tc.input_documents
    ]
    sections.append(
        DocSection(
            heading="2. Input documents",
            level=1,
            paragraphs=[
                "The following documents were ingested for this test case and "
                "will be used as the evidence base for the integrity checks."
            ],
            tables=[
                DocTable(
                    headers=["Document", "Type", "Size"],
                    rows=input_rows or [["(none)", "", ""]],
                )
            ],
        )
    )

    sections.append(
        DocSection(
            heading="3. Auditor prompt",
            level=1,
            paragraphs=[p.strip() for p in prompt.splitlines() if p.strip()]
            or ["(no prompt provided)"],
        )
    )

    sections.append(
        DocSection(
            heading="4. Success-criteria guardrails",
            level=1,
            paragraphs=[
                "The grounded run enforces these PoC success criteria:",
            ],
            tables=[
                DocTable(
                    headers=["ID", "Guardrail"],
                    rows=[
                        ["C4", "Numeric accuracy \u2265 98\u201399%; zero missed material exceptions."],
                        ["C5", "Executive summary, control steps, calculations, tables and recommendations."],
                        ["C6", "Full evidence trail on every finding; no black-box findings."],
                        ["C7", "Deterministic and stable; state what cannot be verified rather than guessing."],
                    ],
                )
            ],
        )
    )

    return GeneratedDocument(title=title, subtitle=subtitle, sections=sections)


def _size_label(size_bytes: int) -> str:
    if size_bytes <= 0:
        return ""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.0f} KB"
    return f"{size_bytes / (1024 * 1024):.1f} MB"
