"""Upload generated reports to a configured SharePoint folder via Graph."""

from __future__ import annotations

from urllib.parse import quote

import httpx

from ..config import settings

_GRAPH_ROOT = "https://graph.microsoft.com/v1.0"
_GRAPH_SCOPE = "https://graph.microsoft.com/.default"
_DOCX_MEDIA = "application/vnd.openxmlformats-officedocument.wordprocessingml.document"


class SharePointUploadError(RuntimeError):
    """Raised when SharePoint configuration or a Graph operation fails."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


def _get_graph_access_token() -> str:
    from azure.identity import DefaultAzureCredential

    credential = DefaultAzureCredential(
        managed_identity_client_id=settings.azure_client_id or None
    )
    try:
        return credential.get_token(_GRAPH_SCOPE).token
    except Exception as exc:
        raise SharePointUploadError(
            "Could not acquire a Microsoft Graph access token. Check the app's "
            "managed identity and SharePoint permissions."
        ) from exc
    finally:
        credential.close()


def _validate_segment(value: str, label: str) -> str:
    value = value.strip()
    if (
        not value
        or value in {".", ".."}
        or "/" in value
        or "\\" in value
        or any(ord(char) < 32 for char in value)
    ):
        raise ValueError(f"{label} must be a single non-empty path segment.")
    return value


def _quoted_path(path: str) -> str:
    return "/".join(quote(part, safe="") for part in path.strip("/").split("/") if part)


def _request(
    client: httpx.Client,
    token: str,
    method: str,
    path: str,
    **kwargs,
) -> httpx.Response:
    url = path if path.startswith("https://") else f"{_GRAPH_ROOT}{path}"
    headers = {"Authorization": f"Bearer {token}", **kwargs.pop("headers", {})}
    try:
        response = client.request(
            method,
            url,
            headers=headers,
            **kwargs,
        )
    except httpx.HTTPError as exc:
        raise SharePointUploadError(
            f"Microsoft Graph request failed: {exc}"
        ) from exc
    if response.is_error:
        message = response.text[:500]
        raise SharePointUploadError(
            f"Microsoft Graph returned HTTP {response.status_code}: {message}",
            status_code=response.status_code,
        )
    return response


def upload_report(data: bytes, control_name: str, quarter: str | None = None) -> dict[str, str | None]:
    """Upload report bytes as ``<control_name>.docx`` under the quarter folder."""
    hostname = settings.sharepoint_site_hostname.strip()
    site_path = settings.sharepoint_site_path.strip()
    drive_name = settings.sharepoint_drive_name.strip()
    folder_path = settings.sharepoint_folder_path.strip("/")
    if not all((hostname, site_path, drive_name)):
        raise SharePointUploadError(
            "SharePoint export is not configured. Set SHAREPOINT_SITE_HOSTNAME, "
            "SHAREPOINT_SITE_PATH, and SHAREPOINT_DRIVE_NAME."
        )

    control_name = _validate_segment(control_name, "control_name")
    if quarter is not None:
        quarter = _validate_segment(quarter, "quarter")
    if control_name.lower().endswith(".docx"):
        control_name = control_name[:-5]
    control_name = _validate_segment(control_name, "control_name")
    filename = f"{control_name}.docx"

    token = _get_graph_access_token()
    with httpx.Client(timeout=60) as client:
        site = _request(
            client,
            token,
            "GET",
            f"/sites/{quote(hostname, safe='')}:/" f"{_quoted_path(site_path)}",
            params={"$select": "id"},
        ).json()
        site_id = quote(site["id"], safe="")

        drives_url = f"{_GRAPH_ROOT}/sites/{site_id}/drives"
        drives: list[dict] = []
        while drives_url:
            page = _request(client, token, "GET", drives_url).json()
            drives.extend(page.get("value", []))
            drives_url = page.get("@odata.nextLink", "")
        drive = next(
            (item for item in drives if item.get("name", "").casefold() == drive_name.casefold()),
            None,
        )
        if drive is None:
            raise SharePointUploadError(
                f"SharePoint document library {drive_name!r} was not found."
            )
        drive_id = quote(drive["id"], safe="")

        if folder_path:
            parent = _request(
                client,
                token,
                "GET",
                f"/drives/{drive_id}/root:/{_quoted_path(folder_path)}",
                params={"$select": "id,name,folder"},
            ).json()
        else:
            parent = _request(
                client, token, "GET", f"/drives/{drive_id}/root", params={"$select": "id"}
            ).json()
        parent_id = quote(parent["id"], safe="")

        quarter_path = quote(quarter, safe="")
        quarter_url = f"/drives/{drive_id}/items/{parent_id}:/{quarter_path}"
        try:
            quarter_item = _request(
                client,
                token,
                "GET",
                quarter_url,
                params={"$select": "id,name,folder"},
            ).json()
        except SharePointUploadError as exc:
            if exc.status_code != 404:
                raise
            try:
                quarter_item = _request(
                    client,
                    token,
                    "POST",
                    f"/drives/{drive_id}/items/{parent_id}/children",
                    json={
                        "name": quarter,
                        "folder": {},
                        "@microsoft.graph.conflictBehavior": "fail",
                    },
                ).json()
            except SharePointUploadError as create_exc:
                # A concurrent request may have created the same quarter folder.
                if create_exc.status_code != 409:
                    raise
                quarter_item = _request(
                    client,
                    token,
                    "GET",
                    quarter_url,
                    params={"$select": "id,name,folder"},
                ).json()
        if "folder" not in quarter_item:
            raise SharePointUploadError(
                f"A non-folder item named {quarter!r} already exists in the target location."
            )

        item = _request(
            client,
            token,
            "PUT",
            f"/drives/{drive_id}/items/{quote(quarter_item['id'], safe='')}:/{quote(filename, safe='')}:/content",
            content=data,
            headers={"Content-Type": _DOCX_MEDIA},
        ).json()
    return {
        "filename": item.get("name", filename),
        "item_id": item.get("id"),
        "web_url": item.get("webUrl"),
        "quarter": quarter,
    }