"""Core domain models for controls, findings, and audit runs.

These are plain dataclasses (stdlib only) so the control engine and report
generator can be exercised offline without FastAPI / Pydantic installed.
"""

from __future__ import annotations

import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:12]}"


class Severity(str, Enum):
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class ControlStatus(str, Enum):
    PASS = "pass"
    EXCEPTION = "exception"
    NEEDS_REVIEW = "needs_review"
    ERROR = "error"


class ReviewDecision(str, Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class HumanDisposition(str, Enum):
    APPROVED = "Approved"
    REJECTED = "Rejected"
    AWAITING_REVIEW = "Awaiting_Review"
    MANUAL_FALLBACK = "Manual_fallback"


@dataclass
class Evidence:
    """Evidence trail for a finding (success criterion C6 – auditability)."""

    source_document: str
    locator: str = ""  # page / paragraph / cell / URL
    rule_applied: str = ""
    detail: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class Finding:
    """A single exception / observation raised by a control."""

    title: str
    severity: Severity
    description: str
    evidence: list[Evidence] = field(default_factory=list)
    recommendation: str = ""
    calculation: str = ""  # shown working (C5)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["severity"] = self.severity.value
        return d


@dataclass
class ControlResult:
    """Outcome of running one control within a test case."""

    control_id: str
    name: str
    status: ControlStatus
    summary: str
    findings: list[Finding] = field(default_factory=list)
    steps: list[str] = field(default_factory=list)
    tables: list[dict[str, Any]] = field(default_factory=list)
    review: ReviewDecision = ReviewDecision.PENDING
    reviewer_comment: str = ""
    started_at: str = field(default_factory=_now_iso)
    completed_at: str = field(default_factory=_now_iso)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["status"] = self.status.value
        d["review"] = self.review.value
        d["findings"] = [f.to_dict() for f in self.findings]
        return d


@dataclass
class AuditRun:
    """A full SuperAgent run over a test case (or batch of test cases)."""

    test_case_id: str
    test_case_title: str
    prompt_version: str
    model: str
    mode: str  # "llm" or "offline"
    run_id: str = field(default_factory=lambda: _new_id("run"))
    status: str = "completed"
    created_at: str = field(default_factory=_now_iso)
    completed_at: str = field(default_factory=_now_iso)
    input_documents: list[str] = field(default_factory=list)
    executive_summary: str = ""
    overall_conclusion: str = ""
    controls: list[ControlResult] = field(default_factory=list)
    report_filename: str = ""

    @property
    def exception_count(self) -> int:
        return sum(
            1 for c in self.controls if c.status == ControlStatus.EXCEPTION
        )

    @property
    def finding_count(self) -> int:
        return sum(len(c.findings) for c in self.controls)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["controls"] = [c.to_dict() for c in self.controls]
        d["exception_count"] = self.exception_count
        d["finding_count"] = self.finding_count
        return d


# --------------------------------------------------------------------------- #
# Prompt-driven document generation (SuperAgent output mirroring the PoC
# "expected output" reports).
# --------------------------------------------------------------------------- #


@dataclass
class DocTable:
    """A table rendered inside a generated document section."""

    headers: list[str] = field(default_factory=list)
    rows: list[list[str]] = field(default_factory=list)
    title: str = ""

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


@dataclass
class DocSection:
    """A heading plus its narrative paragraphs and tables."""

    heading: str
    level: int = 1  # 1..3
    paragraphs: list[str] = field(default_factory=list)
    tables: list[DocTable] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["tables"] = [t.to_dict() for t in self.tables]
        return d


@dataclass
class GeneratedDocument:
    """The structured Word-document output produced from a prompt + inputs."""

    title: str = ""
    subtitle: str = ""
    sections: list[DocSection] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "subtitle": self.subtitle,
            "sections": [s.to_dict() for s in self.sections],
        }


@dataclass
class GenerationRun:
    """A SuperAgent run that generates an auditable document from a test case."""

    test_case_id: str
    test_case_title: str
    prompt_version: str
    model: str
    mode: str  # "llm" or "offline"
    run_id: str = field(default_factory=lambda: _new_id("run"))
    status: str = "completed"
    created_at: str = field(default_factory=_now_iso)
    completed_at: str = field(default_factory=_now_iso)
    input_documents: list[str] = field(default_factory=list)
    document: GeneratedDocument = field(default_factory=GeneratedDocument)
    report_filename: str = ""
    token_usage: dict[str, Any] | None = None
    # Resolved (post-default) per-run generation options, for auditability.
    use_expected_template: bool = True
    economy: bool = False
    reasoning_effort: str = ""
    run_title: str = ""
    description: str = ""
    report_version: str | None = None
    reporting_period: str | None = None
    reporting_year: str | None = None
    period: str | None = None
    task_only: bool = False
    human_disposition: HumanDisposition = HumanDisposition.AWAITING_REVIEW
    reviewer_comment: str = ""

    @property
    def section_count(self) -> int:
        return len(self.document.sections)

    @property
    def table_count(self) -> int:
        return sum(len(s.tables) for s in self.document.sections)

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["document"] = self.document.to_dict()
        d["section_count"] = self.section_count
        d["table_count"] = self.table_count
        return d


def generation_run_from_dict(data: dict[str, Any]) -> "GenerationRun":
    doc_data = data.get("document", {}) or {}
    sections = [
        DocSection(
            heading=s.get("heading", ""),
            level=int(s.get("level", 1) or 1),
            paragraphs=list(s.get("paragraphs", []) or []),
            tables=[
                DocTable(
                    headers=list(t.get("headers", []) or []),
                    rows=[list(r) for r in t.get("rows", []) or []],
                    title=t.get("title", ""),
                )
                for t in s.get("tables", []) or []
            ],
        )
        for s in doc_data.get("sections", []) or []
    ]
    document = GeneratedDocument(
        title=doc_data.get("title", ""),
        subtitle=doc_data.get("subtitle", ""),
        sections=sections,
    )
    return GenerationRun(
        run_id=data.get("run_id", _new_id("run")),
        test_case_id=data.get("test_case_id", ""),
        test_case_title=data.get("test_case_title", ""),
        prompt_version=data.get("prompt_version", ""),
        model=data.get("model", ""),
        mode=data.get("mode", "offline"),
        status=data.get("status", "completed"),
        created_at=data.get("created_at", ""),
        completed_at=data.get("completed_at", ""),
        input_documents=list(data.get("input_documents", []) or []),
        document=document,
        report_filename=data.get("report_filename", ""),
        token_usage=data.get("token_usage"),
        use_expected_template=bool(data.get("use_expected_template", True)),
        economy=bool(data.get("economy", False)),
        reasoning_effort=data.get("reasoning_effort", ""),
        run_title=data.get("run_title") or data.get("test_case_title", ""),
        description=data.get("description", ""),
        report_version=data.get("report_version"),
        reporting_period=data.get("reporting_period"),
        reporting_year=data.get("reporting_year"),
        period=data.get("period"),
        task_only=bool(data.get("task_only", False)),
        human_disposition=HumanDisposition(
            data.get("human_disposition") or HumanDisposition.AWAITING_REVIEW.value
        ),
        reviewer_comment=data.get("reviewer_comment", ""),
    )
