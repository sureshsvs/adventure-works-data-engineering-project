"""Process-wide bounded case scheduling; replace this boundary for distributed use."""

from __future__ import annotations

import contextvars
import threading
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from ..config import settings


class CapacityBusyError(RuntimeError):
    pass


@dataclass(eq=False)
class _JobGroup:
    tasks: deque[Callable[[], None]]
    parallelism: int
    active: int = 0


class CaseScheduler:
    def __init__(self, max_active: int, queue_capacity: int) -> None:
        if max_active < 1 or queue_capacity < 0:
            raise ValueError("Invalid case scheduler capacity")
        self.max_active = max_active
        self.queue_capacity = queue_capacity
        self._lock = threading.Lock()
        self._groups: deque[_JobGroup] = deque()
        self._active = 0
        self._local = threading.local()

    def submit(self, tasks: list[Callable[[], None]], parallelism: int = 1) -> None:
        """Admit a whole job atomically, never a partially accepted batch."""
        if not tasks or not 1 <= parallelism <= 4:
            raise ValueError("Jobs need tasks and parallelism in 1..4")
        with self._lock:
            waiting = sum(group.active == 0 for group in self._groups)
            if self._active >= self.max_active and waiting >= self.queue_capacity:
                raise CapacityBusyError("Server busy: generation queue is full. Please retry later.")
            self._groups.append(_JobGroup(deque(tasks), parallelism))
            self._dispatch()

    def _dispatch(self) -> None:
        # Called only under _lock. Reserve slots before starting threads.
        while self._active < self.max_active:
            group = next((
                group for group in self._groups
                if group.tasks and group.active < group.parallelism
            ), None)
            if group is None:
                return
            task = group.tasks.popleft()
            group.active += 1
            self._active += 1
            self._groups.remove(group)
            self._groups.append(group)
            threading.Thread(target=self._execute, args=(group, task), daemon=True).start()

    def _execute(self, group: _JobGroup, task: Callable[[], None]) -> None:
        self._local.executing = True
        try:
            task()
        finally:
            self._local.executing = False
            with self._lock:
                self._active -= 1
                group.active -= 1
                if not group.tasks and not group.active:
                    self._groups.remove(group)
                self._dispatch()

    def run(self, fn: Callable[[], Any]) -> Any:
        """Legacy synchronous endpoints share admission with background jobs."""
        if getattr(self._local, "executing", False):
            return fn()
        finished = threading.Event()
        result: dict[str, Any] = {}
        context = contextvars.copy_context()

        def execute() -> None:
            try:
                result["value"] = context.run(fn)
            except BaseException as exc:  # noqa: BLE001 - propagate to synchronous caller
                result["error"] = exc
            finally:
                finished.set()

        self.submit([execute])
        finished.wait()
        if "error" in result:
            raise result["error"]
        return result["value"]


_scheduler: CaseScheduler | None = None
_scheduler_lock = threading.Lock()


def get_case_scheduler() -> CaseScheduler:
    global _scheduler
    with _scheduler_lock:
        if _scheduler is None:
            _scheduler = CaseScheduler(
                settings.super_agent_max_active_cases, settings.super_agent_queue_capacity,
            )
        return _scheduler
