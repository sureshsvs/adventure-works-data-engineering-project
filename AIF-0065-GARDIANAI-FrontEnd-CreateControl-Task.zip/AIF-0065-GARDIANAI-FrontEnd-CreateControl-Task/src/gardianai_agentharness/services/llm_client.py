"""LLM client factory.

Provides two independently-configured OpenAI-compatible clients so each service
routes to its own backend (matching the reference architecture):

* **Agent Harness** → APIM / Azure OpenAI (``APIM_ENDPOINT``, gpt-5.2).
* **SuperAgent**    → Azure AI Foundry (``AZURE_AI_FOUNDRY_ENDPOINT``, gpt-5.4).

When the APIM project gateway is configured (``APIM_ENDPOINT`` +
``APIM_SUBSCRIPTION_KEY`` + ``APIM_FOUNDRY_NAME`` + ``APIM_PROJECT_NAME``), BOTH
clients route through it via ``AIProjectClient.get_openai_client`` with the APIM
routing headers (see :func:`apim_gateway_headers`).

Each client degrades to ``available == False`` when its backend is not configured
or the ``openai`` SDK is unavailable, so callers fall back to the offline paths.
Uses ``httpx[socks]`` transitively so it works with or without a SOCKS proxy.
"""

from __future__ import annotations

import logging
from typing import Any

from ..config import settings

logger = logging.getLogger(__name__)

_TOKEN_PROVIDER = None


def _aad_token_provider():
    """Cached Entra ID bearer-token provider (Azure OpenAI cognitiveservices scope)."""
    global _TOKEN_PROVIDER
    if _TOKEN_PROVIDER is None:
        from azure.identity import DefaultAzureCredential, get_bearer_token_provider

        _TOKEN_PROVIDER = get_bearer_token_provider(
            DefaultAzureCredential(
                managed_identity_client_id=settings.azure_client_id or None
            ),
            "https://cognitiveservices.azure.com/.default",
        )
    return _TOKEN_PROVIDER


def _azure_credential():
    """DefaultAzureCredential pinned to the user-assigned identity (AZURE_CLIENT_ID)."""
    from azure.identity import DefaultAzureCredential

    return DefaultAzureCredential(
        managed_identity_client_id=settings.azure_client_id or None
    )


def apim_gateway_headers() -> dict[str, str]:
    """Default headers the APIM project gateway uses to authorise and route calls."""
    return {
        "Ocp-Apim-Subscription-Key": settings.apim_gateway_subscription_key,
        "foundryMode": "new",
        "foundryName": settings.apim_foundry_name,
        "projectName": settings.apim_project_name,
    }


def warn_if_apim_gateway_incomplete() -> None:
    """Log (names only, never values) which gateway settings are missing."""
    if not settings.apim_gateway_requested or settings.apim_gateway_enabled:
        return
    missing = [
        name
        for name, value in (
            ("APIM_ENDPOINT", settings.apim_endpoint),
            ("APIM_SUBSCRIPTION_KEY (or legacy APIM_SUB_KEY)",
             settings.apim_gateway_subscription_key),
            ("APIM_FOUNDRY_NAME", settings.apim_foundry_name),
            ("APIM_PROJECT_NAME", settings.apim_project_name),
        )
        if not value
    ]
    logger.warning(
        "APIM gateway mode requested but not fully configured (missing: %s); "
        "using the non-gateway LLM backends.",
        ", ".join(missing),
    )


class LLMClient:
    """A single OpenAI-compatible chat client bound to one backend + model."""

    def __init__(
        self,
        base_url: str = "",
        api_key: str = "",
        model: str = "",
        extra_headers: dict[str, str] | None = None,
        extra_query: dict[str, str] | None = None,
        label: str = "",
        token_provider=None,
        openai_client: Any = None,
        owner: Any = None,
        credential: Any = None,
    ) -> None:
        self._model = model
        self.label = label
        self._client: Any = openai_client
        # Keeps the object that created ``openai_client`` (e.g. AIProjectClient)
        # alive and open for as long as this client is used.
        self._owner = owner
        self._credential = credential
        self._token_provider = token_provider
        # Learned from the API's 400 responses; some models (e.g. gpt-5.6-sol)
        # reject a non-default temperature and reasoning_effort combined with tools.
        self._omit_temperature = False
        self._omit_tool_reasoning = False
        if base_url and (api_key or token_provider):
            try:
                from openai import OpenAI  # type: ignore

                self._client = OpenAI(
                    base_url=base_url,
                    api_key=api_key or "managed-identity",  # placeholder; overridden per call
                    default_headers=extra_headers or None,
                    default_query=extra_query or None,
                )
            except ImportError:
                self._client = None

    @property
    def available(self) -> bool:
        return self._client is not None

    def close(self) -> None:
        """Close the underlying OpenAI client and its owner; the client becomes unavailable."""
        client, owner, credential = self._client, self._owner, self._credential
        self._client = self._owner = self._credential = None
        for obj in (client, owner, credential):
            close = getattr(obj, "close", None)
            if close is not None:
                try:
                    close()
                except Exception:  # pragma: no cover - best-effort cleanup
                    logger.debug("Error closing %s client", self.label, exc_info=True)

    @property
    def model(self) -> str:
        return self._model

    def chat(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.0,
        response_format: dict[str, Any] | None = None,
        reasoning_effort: str | None = None,
    ) -> Any:
        if not self._client:
            raise RuntimeError("LLM client is not configured (offline mode).")
        from openai import BadRequestError  # type: ignore

        client = self._client
        if self._token_provider is not None:
            client = client.with_options(api_key=self._token_provider())
        while True:
            kwargs = self._build_kwargs(
                messages, tools, temperature, response_format, reasoning_effort
            )
            try:
                resp = client.chat.completions.create(**kwargs)
                break
            except BadRequestError as e:
                param = getattr(e, "param", None)
                if param == "temperature" and "temperature" in kwargs:
                    self._omit_temperature = True
                elif param == "reasoning_effort" and tools and "reasoning_effort" in kwargs:
                    self._omit_tool_reasoning = True
                else:
                    raise
                logger.warning(
                    "%s model %s rejected '%s'; retrying without it",
                    self.label, self._model, param,
                )
        from .super_agent_context import record_usage

        record_usage(getattr(resp, "usage", None))
        return resp

    def _build_kwargs(
        self,
        messages: list[dict[str, str]],
        tools: list[dict[str, Any]] | None,
        temperature: float,
        response_format: dict[str, Any] | None,
        reasoning_effort: str | None,
    ) -> dict[str, Any]:
        kwargs: dict[str, Any] = {"model": self._model, "messages": messages}
        if not self._omit_temperature:
            kwargs["temperature"] = temperature
        if reasoning_effort and not (tools and self._omit_tool_reasoning):
            kwargs["reasoning_effort"] = reasoning_effort
            kwargs.pop("temperature", None)  # reasoning models reject non-default temperature
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"
        if response_format:
            kwargs["response_format"] = response_format
        return kwargs


def _build_apim() -> LLMClient:
    """Agent Harness backend: APIM-proxied Azure OpenAI (OpenAI v1 shape).

    This APIM gateway authenticates via the ``subscription-key`` query parameter
    (the ``Ocp-Apim-Subscription-Key`` header is not accepted here).
    """
    if not settings.apim_endpoint:
        return LLMClient(label="apim")
    base_url = settings.apim_endpoint.rstrip("/") + "/openai/v1"
    if settings.azure_llm_use_managed_identity and not settings.apim_api_key:
        return LLMClient(
            base_url=base_url,
            model=settings.agent_model_deployment_name,
            token_provider=_aad_token_provider(),
            label="apim",
        )
    if not settings.apim_api_key:
        return LLMClient(label="apim")
    return LLMClient(
        base_url=base_url,
        api_key=settings.apim_api_key,
        model=settings.agent_model_deployment_name,
        extra_headers={"Ocp-Apim-Subscription-Key": settings.apim_api_key},
        extra_query={"subscription-key": settings.apim_api_key},
        label="apim",
    )


def _build_apim_gateway(model: str) -> LLMClient:
    """APIM project gateway: ``AIProjectClient(...).get_openai_client(default_headers=...)``.

    The project client (and its ``DefaultAzureCredential``) stays open for the
    lifetime of the returned client, because the OpenAI client's bearer-token
    provider keeps using that credential on every call.
    """
    if not settings.apim_gateway_enabled:
        return LLMClient(label="apim-gateway")
    credential = None
    project_client = None
    try:
        from azure.ai.projects import AIProjectClient  # type: ignore

        credential = _azure_credential()
        project_client = AIProjectClient(
            endpoint=settings.apim_endpoint, credential=credential
        )
        openai_client = project_client.get_openai_client(
            default_headers=apim_gateway_headers()
        )
    except Exception as e:  # noqa: BLE001 - ImportError, or an SDK without get_openai_client
        logger.warning(
            "APIM gateway configured but its client could not be created (%s); "
            "falling back to the non-gateway LLM backends.",
            type(e).__name__,
        )
        for obj in (project_client, credential):
            close = getattr(obj, "close", None)
            if close is not None:
                try:
                    close()
                except Exception:  # pragma: no cover - best-effort cleanup
                    logger.debug("Error closing APIM gateway setup resource", exc_info=True)
        return LLMClient(label="apim-gateway")
    return LLMClient(
        model=model,
        openai_client=openai_client,
        owner=project_client,
        credential=credential,
        label="apim-gateway",
    )


def _foundry_base_url() -> str:
    """Derive the OpenAI v1 base URL from a Foundry project/resource endpoint."""
    endpoint = settings.azure_ai_foundry_endpoint.rstrip("/")
    # A project endpoint (…/api/projects/<name>) still shares the resource host,
    # which exposes the OpenAI-compatible surface at /openai/v1.
    marker = ".services.ai.azure.com"
    if marker in endpoint:
        host = endpoint.split(marker)[0] + marker
        return host + "/openai/v1"
    return endpoint + "/openai/v1"


def _build_foundry() -> LLMClient:
    """SuperAgent backend: Azure AI Foundry (OpenAI v1 endpoint)."""
    if not settings.azure_ai_foundry_endpoint:
        return LLMClient(label="foundry")
    if settings.azure_llm_use_managed_identity and not settings.azure_ai_foundry_api_key:
        return LLMClient(
            base_url=_foundry_base_url(),
            model=settings.super_agent_model,
            token_provider=_aad_token_provider(),
            label="foundry",
        )
    if not settings.azure_ai_foundry_api_key:
        return LLMClient(label="foundry")
    return LLMClient(
        base_url=_foundry_base_url(),
        api_key=settings.azure_ai_foundry_api_key,
        model=settings.super_agent_model,
        extra_headers={"api-key": settings.azure_ai_foundry_api_key},
        label="foundry",
    )


_harness: LLMClient | None = None
_super_agent: LLMClient | None = None


def get_harness_llm_client() -> LLMClient:
    """Client for the Agent Harness (APIM gateway / APIM / gpt-5.2), falling back to Foundry."""
    global _harness
    if _harness is None:
        warn_if_apim_gateway_incomplete()
        gateway = _build_apim_gateway(settings.agent_model_deployment_name)
        if gateway.available:
            _harness = gateway
        else:
            apim = _build_apim()
            _harness = apim if apim.available else _build_foundry()
    return _harness


def get_super_agent_llm_client() -> LLMClient:
    """Client for the SuperAgent (APIM gateway, else Azure AI Foundry / gpt-5.4, else APIM)."""
    global _super_agent
    if _super_agent is None:
        warn_if_apim_gateway_incomplete()
        gateway = _build_apim_gateway(settings.super_agent_model)
        if gateway.available:
            _super_agent = gateway
        else:
            foundry = _build_foundry()
            _super_agent = foundry if foundry.available else _build_apim()
    return _super_agent


# Backwards-compatible accessor (defaults to the harness client).
def get_llm_client() -> LLMClient:
    return get_harness_llm_client()


def close_cached_llm_clients() -> None:
    """Close cached clients and release their global references."""
    global _harness, _super_agent
    clients = (_harness, _super_agent)
    _harness = _super_agent = None
    closed: set[int] = set()
    for client in clients:
        if client is not None and id(client) not in closed:
            closed.add(id(client))
            client.close()
