"""Cosmos-backed persistence for variable definitions and the run-value set.

Three containers in the ``gardian`` database back the variable catalogs:

- ``run-value-definition`` — custom run-value definitions (partition key/id = name).
- ``task-scalar-definition`` — custom Task-scalar definitions (partition key/id = name).
- ``run-value-set`` — the singleton run-value map (fixed id/partition key ``default``).

Built-in definitions are supplied by the application and merged with the custom
ones; they cannot be modified through the API. The run-value set is a singleton:
``create`` is create-only (``409`` on conflict) and ``replace`` uses ETag
optimistic concurrency (``412`` on mismatch).
"""

from __future__ import annotations

import threading
from typing import Any

from ..config import settings
from . import prompt_variables as pv
from .variable_catalog import (
    BUILTIN_RUN_VALUES,
    BUILTIN_RUN_VALUE_NAMES,
    BUILTIN_TASK_SCALARS,
    BUILTIN_TASK_SCALAR_NAMES,
    VariableDefinition,
)

RUN_VALUE_SET_ID = "default"


class DefinitionExistsError(ValueError):
    """Raised when a custom definition name is already registered."""


class UnknownDefinitionError(KeyError):
    """Raised when a definition name is not found."""


class BuiltinImmutableError(ValueError):
    """Raised when a built-in definition is updated or deleted."""


class RunValueSetExistsError(ValueError):
    """Raised when creating the run-value set that already exists."""


class RunValueSetMissingError(KeyError):
    """Raised when the run-value set does not exist."""


class ETagMismatchError(ValueError):
    """Raised when a run-value-set update supplies a stale ETag."""


def _create_container(container_id: str, partition_path: str):
    from azure.cosmos import CosmosClient, PartitionKey

    if settings.cosmos_key:
        client = CosmosClient(settings.cosmos_endpoint, credential=settings.cosmos_key)
    else:
        from azure.identity import DefaultAzureCredential

        client = CosmosClient(
            settings.cosmos_endpoint,
            credential=DefaultAzureCredential(
                managed_identity_client_id=settings.azure_client_id or None
            ),
        )
    database = client.create_database_if_not_exists("gardian")
    return database.create_container_if_not_exists(
        id=container_id, partition_key=PartitionKey(path=partition_path)
    )


def _definition_to_dict(item: dict[str, Any]) -> dict[str, str]:
    return {
        "name": str(item["name"]),
        "meaning": str(item.get("meaning", "")),
        "example": str(item.get("example", "")),
    }


class VariableStore:
    """Catalog persistence for run-value and Task-scalar definitions + the set."""

    def __init__(
        self,
        run_value_def_container: Any | None = None,
        run_value_set_container: Any | None = None,
        task_scalar_def_container: Any | None = None,
    ) -> None:
        self._lock = threading.Lock()
        self._run_value_defs = run_value_def_container or _create_container(
            "run-value-definition", "/name"
        )
        self._run_value_set = run_value_set_container or _create_container(
            "run-value-set", "/id"
        )
        self._task_scalar_defs = task_scalar_def_container or _create_container(
            "task-scalar-definition", "/name"
        )

    # ------------------------------------------------- definition catalogs
    @staticmethod
    def _list_custom(container: Any) -> list[dict[str, str]]:
        items = container.query_items(
            query="SELECT * FROM c", enable_cross_partition_query=True
        )
        return [_definition_to_dict(item) for item in items]

    @staticmethod
    def _merge_definitions(
        builtins: tuple[VariableDefinition, ...],
        builtin_names: frozenset[str],
        custom: list[dict[str, str]],
    ) -> list[dict[str, str]]:
        merged = [d.to_dict() for d in builtins]
        for definition in custom:
            if definition["name"] not in builtin_names:
                merged.append(definition)
        return sorted(merged, key=lambda d: d["name"].casefold())

    def _create_definition(
        self, container: Any, builtin_names: frozenset[str], custom_names: set[str],
        name: str, meaning: str, example: str,
    ) -> dict[str, str]:
        pv.validate_registrable_key(name)
        if name in builtin_names or name in custom_names:
            raise DefinitionExistsError(name)
        body = {"id": name, "name": name, "meaning": meaning, "example": example}
        container.create_item(body=body)
        return _definition_to_dict(body)

    def _custom_names(self, container: Any) -> set[str]:
        return {d["name"] for d in self._list_custom(container)}

    # run values --------------------------------------------------------
    def list_run_value_definitions(self) -> list[dict[str, str]]:
        return self._merge_definitions(
            BUILTIN_RUN_VALUES, BUILTIN_RUN_VALUE_NAMES,
            self._list_custom(self._run_value_defs),
        )

    def create_run_value_definition(
        self, name: str, meaning: str, example: str
    ) -> dict[str, str]:
        with self._lock:
            return self._create_definition(
                self._run_value_defs, BUILTIN_RUN_VALUE_NAMES,
                self._custom_names(self._run_value_defs), name, meaning, example,
            )

    def get_run_value_definition(self, name: str) -> dict[str, str] | None:
        for definition in self.list_run_value_definitions():
            if definition["name"] == name:
                return definition
        return None

    def update_run_value_definition(
        self, name: str, meaning: str, example: str
    ) -> dict[str, str]:
        with self._lock:
            if name in BUILTIN_RUN_VALUE_NAMES:
                raise BuiltinImmutableError(name)
            if name not in self._custom_names(self._run_value_defs):
                raise UnknownDefinitionError(name)
            body = {"id": name, "name": name, "meaning": meaning, "example": example}
            self._run_value_defs.upsert_item(body=body)
            return _definition_to_dict(body)

    def is_registered_run_value(self, name: str) -> bool:
        return name in BUILTIN_RUN_VALUE_NAMES or name in self._custom_names(
            self._run_value_defs
        )

    # task scalars ------------------------------------------------------
    def list_task_scalar_definitions(self) -> list[dict[str, str]]:
        return self._merge_definitions(
            BUILTIN_TASK_SCALARS, BUILTIN_TASK_SCALAR_NAMES,
            self._list_custom(self._task_scalar_defs),
        )

    def create_task_scalar_definition(
        self, name: str, meaning: str, example: str
    ) -> dict[str, str]:
        with self._lock:
            return self._create_definition(
                self._task_scalar_defs, BUILTIN_TASK_SCALAR_NAMES,
                self._custom_names(self._task_scalar_defs), name, meaning, example,
            )

    def get_task_scalar_definition(self, name: str) -> dict[str, str] | None:
        for definition in self.list_task_scalar_definitions():
            if definition["name"] == name:
                return definition
        return None

    def update_task_scalar_definition(
        self, name: str, meaning: str, example: str
    ) -> dict[str, str]:
        with self._lock:
            if name in BUILTIN_TASK_SCALAR_NAMES:
                raise BuiltinImmutableError(name)
            if name not in self._custom_names(self._task_scalar_defs):
                raise UnknownDefinitionError(name)
            body = {"id": name, "name": name, "meaning": meaning, "example": example}
            self._task_scalar_defs.upsert_item(body=body)
            return _definition_to_dict(body)

    def is_registered_task_scalar(self, name: str) -> bool:
        return name in BUILTIN_TASK_SCALAR_NAMES or name in self._custom_names(
            self._task_scalar_defs
        )

    # ------------------------------------------------- run-value set
    def _read_run_value_set(self) -> dict[str, Any] | None:
        items = list(
            self._run_value_set.query_items(
                query="SELECT * FROM c", enable_cross_partition_query=True
            )
        )
        return items[0] if items else None

    def _validate_run_values(self, values: dict[str, Any]) -> dict[str, str]:
        validated: dict[str, str] = {}
        for key, value in values.items():
            if not self.is_registered_run_value(key):
                raise pv.PlaceholderError(f"unknown run-value key: {key!r}")
            if not isinstance(value, str):
                raise pv.PlaceholderError(f"run-value {key!r} must be a string")
            validated[key] = value
        return validated

    def get_run_value_set(self) -> tuple[dict[str, str], str] | None:
        item = self._read_run_value_set()
        if item is None:
            return None
        return dict(item.get("values") or {}), str(item.get("_etag", ""))

    def create_run_value_set(
        self, values: dict[str, Any]
    ) -> tuple[dict[str, str], str]:
        with self._lock:
            validated = self._validate_run_values(values)
            if self._read_run_value_set() is not None:
                raise RunValueSetExistsError("run-value set already exists")
            body = {"id": RUN_VALUE_SET_ID, "values": validated}
            created = self._run_value_set.create_item(body=body) or body
            etag = str((created or {}).get("_etag", body.get("_etag", "")))
            return validated, etag

    def replace_run_value_set(
        self, values: dict[str, Any], etag: str
    ) -> tuple[dict[str, str], str]:
        with self._lock:
            validated = self._validate_run_values(values)
            current = self._read_run_value_set()
            if current is None:
                raise RunValueSetMissingError("run-value set does not exist")
            if str(current.get("_etag", "")) != etag:
                raise ETagMismatchError("run-value set was modified")
            body = {"id": RUN_VALUE_SET_ID, "values": validated}
            replaced = self._run_value_set.replace_item(
                item=RUN_VALUE_SET_ID, body=body
            ) or body
            new_etag = str((replaced or {}).get("_etag", ""))
            return validated, new_etag


_variable_store: VariableStore | None = None


def get_variable_store() -> VariableStore:
    global _variable_store
    if _variable_store is None:
        _variable_store = VariableStore()
    return _variable_store
