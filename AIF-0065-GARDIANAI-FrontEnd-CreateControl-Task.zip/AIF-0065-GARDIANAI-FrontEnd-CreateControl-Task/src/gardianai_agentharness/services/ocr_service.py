"""Mistral Document AI (OCR) client — high-fidelity PDF text extraction.

The offline paren-scrape fallback only recovers navigation text from the source
PDFs; the actual financial figures live in compressed content streams. This
client sends each PDF to the Azure-hosted **Mistral Document AI** OCR endpoint
(``mistral-document-ai-2512``) and returns page-by-page Markdown, giving the
Agent Harness and SuperAgent the real numbers to reconcile.

Implemented with stdlib ``urllib`` so it has no hard third-party dependency, and
results are cached on disk (keyed by file path + mtime) so a document is OCR'd
only once.
"""

from __future__ import annotations

import base64
import hashlib
import io
import json
import mimetypes
import urllib.error
import urllib.request
from pathlib import Path

from ..config import settings
from . import blob_storage

_MIME_BY_SUFFIX = {
    ".pdf": "application/pdf",
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".tiff": "image/tiff",
}

# The Azure-hosted Mistral OCR parser rejects documents with more than 30 pages,
# so multi-page PDFs are split into page-windows and OCR'd sequentially.
_MAX_PAGES = 30


class MistralOCRClient:
    def __init__(self) -> None:
        self.endpoint = settings.gardian_ocr_endpoint.rstrip("/")
        self.key = settings.gardian_ocr_key
        self.model = settings.gardian_ocr_deployment_name or "mistral-document-ai-2512"

    @property
    def available(self) -> bool:
        return bool(self.endpoint and self.key)

    def can_handle(self, path: Path) -> bool:
        return path.suffix.lower() in _MIME_BY_SUFFIX

    # ------------------------------------------------------------------- public
    def extract(self, path: Path, timeout: float = 300.0) -> str:
        """Return OCR'd Markdown for ``path`` (cached). Raises on hard failure."""
        cached = self._read_cache(path)
        if cached is not None:
            return cached
        markdown = self._call_ocr(path, timeout=timeout)
        self._write_cache(path, markdown)
        return markdown

    # -------------------------------------------------------------------- calls
    def _call_ocr(self, path: Path, timeout: float) -> str:
        suffix = path.suffix.lower()
        if suffix == ".pdf":
            return self._ocr_pdf(path, timeout)
        mime = _MIME_BY_SUFFIX.get(suffix) or (
            mimetypes.guess_type(path.name)[0] or "application/octet-stream"
        )
        return self._ocr_bytes(path.read_bytes(), mime, timeout=timeout)

    def _ocr_pdf(self, path: Path, timeout: float) -> str:
        raw = path.read_bytes()
        chunks = list(_iter_pdf_chunks(raw, _MAX_PAGES))
        parts: list[str] = []
        offset = 0
        for chunk_bytes, page_count in chunks:
            md = self._ocr_bytes(
                chunk_bytes, "application/pdf", timeout=timeout, page_offset=offset
            )
            parts.append(md)
            offset += page_count
        return "\n\n".join(p for p in parts if p)

    def _ocr_bytes(
        self,
        raw: bytes,
        mime: str,
        timeout: float,
        page_offset: int = 0,
    ) -> str:
        b64 = base64.b64encode(raw).decode("ascii")
        doc_type = "image_url" if mime.startswith("image/") else "document_url"
        url_field = "image_url" if doc_type == "image_url" else "document_url"
        payload = {
            "model": self.model,
            "document": {
                "type": doc_type,
                url_field: f"data:{mime};base64,{b64}",
            },
            "include_image_base64": False,
        }
        body = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            self.endpoint,
            data=body,
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                # Azure-hosted Mistral accepts both auth styles; send both.
                "Authorization": f"Bearer {self.key}",
                "api-key": self.key,
            },
        )
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:  # surface server-side detail
            detail = exc.read().decode("utf-8", "ignore")[:500]
            raise RuntimeError(f"Mistral OCR HTTP {exc.code}: {detail}") from exc
        _record_ocr_usage(data)
        return _pages_to_markdown(data, page_offset=page_offset)

    # -------------------------------------------------------------------- cache
    def _cache_key(self, path: Path) -> str:
        stat = path.stat()
        return hashlib.sha1(
            f"{path.resolve()}::{stat.st_mtime_ns}::{stat.st_size}::{self.model}".encode()
        ).hexdigest()

    def _cache_blob_name(self, path: Path) -> str:
        return f"{settings.ocr_cache_prefix}/{self._cache_key(path)}.md"

    def _read_cache(self, path: Path) -> str | None:
        blob_storage.require_blob_storage("OCR cache")
        data = blob_storage.download_bytes(
            settings.sample_data_container, self._cache_blob_name(path)
        )
        return data.decode("utf-8") if data is not None else None

    def _write_cache(self, path: Path, text: str) -> None:
        blob_storage.upload_bytes(
            settings.sample_data_container,
            self._cache_blob_name(path),
            text.encode("utf-8"),
        )


def _record_ocr_usage(data: dict) -> None:
    """Feed Mistral OCR page usage into the active tracker (metered per page)."""
    from .super_agent_context import record_ocr

    info = data.get("usage_info") or {}
    pages = info.get("pages_processed")
    if pages is None:
        pages = len(data.get("pages") or []) or 1
    record_ocr(int(pages))


def _pages_to_markdown(data: dict, page_offset: int = 0) -> str:
    pages = data.get("pages") or []
    if not pages:
        # Some responses return a flat "markdown"/"text" field.
        return data.get("markdown") or data.get("text") or ""
    blocks: list[str] = []
    for i, page in enumerate(pages):
        idx = page.get("index", i)
        md = page.get("markdown") or page.get("text") or ""
        blocks.append(f"## Page {page_offset + int(idx) + 1}\n{md}")
    return "\n\n".join(blocks)


def _iter_pdf_chunks(raw: bytes, max_pages: int):
    """Yield ``(pdf_bytes, page_count)`` sub-documents of at most ``max_pages``.

    Uses ``pypdf`` to split large PDFs so each OCR request stays within the
    endpoint's page limit. If ``pypdf`` is unavailable, yields the whole document
    unchanged (the caller degrades to the stdlib extractor if the request fails).
    """
    try:
        from pypdf import PdfReader, PdfWriter  # type: ignore
    except ImportError:
        yield raw, max_pages
        return

    reader = PdfReader(io.BytesIO(raw))
    total = len(reader.pages)
    if total <= max_pages:
        yield raw, total
        return
    for start in range(0, total, max_pages):
        writer = PdfWriter()
        end = min(start + max_pages, total)
        for page in reader.pages[start:end]:
            writer.add_page(page)
        buf = io.BytesIO()
        writer.write(buf)
        yield buf.getvalue(), end - start


_client: MistralOCRClient | None = None


def get_ocr_client() -> MistralOCRClient:
    global _client
    if _client is None:
        _client = MistralOCRClient()
    return _client
