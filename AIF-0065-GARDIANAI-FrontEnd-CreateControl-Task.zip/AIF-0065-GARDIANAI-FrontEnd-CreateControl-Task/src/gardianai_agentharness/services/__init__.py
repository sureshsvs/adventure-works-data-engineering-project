"""Service package for the GARdian.AI Agent Harness backend."""
