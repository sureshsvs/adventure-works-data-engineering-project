"""On-demand document retrieval tools for the SuperAgent.

Instead of pushing every input document's full text into the prompt (which does
not scale to large packs), the SuperAgent exposes function tools — ``list_documents``,
``search_document`` and ``read_document`` — backed by the :class:`DocumentStore`.
The model pulls only the windows it needs, keeping context bounded while preserving
auditability: every tool result carries a document name and a human-readable
location (page / slide / sheet) so findings cite a real locator, never a raw
character offset into the concatenated extracted text. ``search_document`` can
optionally widen its scope to other uploaded packs (a lazily-loaded shared corpus).
"""

from __future__ import annotations

import json
import re
from typing import Any
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from ..config import settings
from .document_store import DocumentStore, Task, TestCase
from .super_agent_context import fetch_web

_WEB_KEY = "__web__"
_MAX_READ = 8_000
_MAX_TOOL_RESULT = 12_000
_WINDOW = 700


def _is_allowed_web_url(url: str) -> bool:
    """Allow only https shell.com pages, blocking SSRF to arbitrary/internal hosts."""
    try:
        parsed = urlparse(url)
    except ValueError:
        return False
    host = (parsed.hostname or "").lower()
    return parsed.scheme == "https" and (
        host == "shell.com" or host.endswith(".shell.com")
    )

# extractors.py marks page/slide/sheet boundaries with a '## ' heading; resolve
# an offset to the nearest preceding one so tool results carry a citable
# location (e.g. "Page 6") instead of a meaningless raw character offset.
_LOCATION_MARKER = re.compile(r"^## (.+)$", re.MULTILINE)


def _locate(text: str, offset: int) -> str:
    label = ""
    for m in _LOCATION_MARKER.finditer(text, 0, min(offset + 1, len(text))):
        label = m.group(1)
    return label


class DocumentToolbox:
    """Backs the SuperAgent's retrieval tools over one test case's documents."""

    def __init__(self, tc: TestCase, store: DocumentStore) -> None:
        self.tc = tc
        self.store = store
        self._texts: dict[str, str] = {}
        self._meta: list[dict[str, Any]] = []
        for d in tc.input_documents:
            text = store.get_text(d.id) or ""
            self._texts[d.name] = text
            self._meta.append(
                {"document": d.name, "type": d.doc_type, "chars": len(text)}
            )
        if isinstance(tc, Task) or tc.archetype == "grounded_web_check":
            web = fetch_web(settings.shell_newsroom_url)
            if web:
                self._texts[_WEB_KEY] = web
                self._meta.append(
                    {
                        "document": settings.shell_newsroom_url,
                        "type": "web",
                        "chars": len(web),
                    }
                )

        # Lazy shared corpus: inputs of every OTHER uploaded (custom) test case.
        self._corpus: dict[str, Any] = {}  # "Pack :: filename" -> DocumentRef
        self._corpus_text: dict[str, str] = {}  # extracted on first use
        if settings.super_agent_shared_corpus and not isinstance(tc, Task):
            for other in store.list_test_cases():
                if other.archetype != "custom" or other.id == tc.id:
                    continue
                for d in other.input_documents:
                    self._corpus[f"{other.title} :: {d.name}"] = d

    # ------------------------------------------------------------------ helpers
    def _display(self, key: str) -> str:
        return settings.shell_newsroom_url if key == _WEB_KEY else key

    def _corpus_text_for(self, key: str) -> str:
        if key not in self._corpus_text:
            self._corpus_text[key] = self.store.get_text(self._corpus[key].id) or ""
        return self._corpus_text[key]

    def _text_for(self, key: str) -> str:
        if key in self._texts:
            return self._texts[key]
        if key in self._corpus:
            return self._corpus_text_for(key)
        return ""

    def _resolve(self, document: str | None) -> str | None:
        if not document:
            return None
        low = document.strip().lower()
        if low in ("web", _WEB_KEY) or "newsroom" in low:
            return _WEB_KEY if _WEB_KEY in self._texts else None
        for key in list(self._texts) + list(self._corpus):
            if key == document:
                return key
        for key in list(self._texts) + list(self._corpus):
            if low in key.lower():
                return key
        return None

    def manifest_text(self) -> str:
        lines = [
            f"- {m['document']} ({m['type']}, {m['chars']} chars)" for m in self._meta
        ]
        if self._corpus:
            lines.append(
                f"- [+{len(self._corpus)} document(s) from other uploaded packs — "
                'search them with corpus="all-uploads"]'
            )
        return "\n".join(lines)

    # -------------------------------------------------------------------- tools
    def tool_specs(self) -> list[dict[str, Any]]:
        specs: list[dict[str, Any]] = [
            {
                "type": "function",
                "function": {
                    "name": "list_documents",
                    "description": "List the available documents for this test case "
                    "with their type and size in characters.",
                    "parameters": {"type": "object", "properties": {}},
                },
            },            {
                "type": "function",
                "function": {
                    "name": "search_document",
                    "description": "Search the documents for a keyword/number/phrase "
                    "and return matching text windows with the document name and a "
                    "page/slide/sheet location (the locator to cite in findings).",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "query": {
                                "type": "string",
                                "description": "Keywords, a figure, or a phrase to find.",
                            },
                            "document": {
                                "type": "string",
                                "description": "Optional exact/partial document name "
                                "to restrict the search; omit to search all.",
                            },
                            "max_results": {
                                "type": "integer",
                                "description": "Max windows to return (default 8).",
                            },
                            "corpus": {
                                "type": "string",
                                "enum": ["test-case", "all-uploads", "all"],
                                "description": "Scope: 'test-case' (default) = this "
                                "test case's documents; 'all-uploads' = other "
                                "uploaded packs; 'all' = both. Cross-pack results are "
                                'named "Pack :: filename".',
                            },
                        },
                        "required": ["query"],
                    },
                },
            },
            {
                "type": "function",
                "function": {
                    "name": "read_document",
                    "description": "Read a contiguous window of a document's text by "
                    "character offset (use after search to expand context; max "
                    f"{_MAX_READ} chars per call). Cross-pack documents are addressed "
                    'by their "Pack :: filename" name.',
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "document": {
                                "type": "string",
                                "description": "Exact/partial document name to read.",
                            },
                            "start": {
                                "type": "integer",
                                "description": "Start character offset (default 0).",
                            },
                            "length": {
                                "type": "integer",
                                "description": f"Chars to read (default 4000, max {_MAX_READ}).",
                            },
                        },
                        "required": ["document"],
                    },
                },
            },
        ]
        # Only expose live web fetching when a grounded newsroom source is present,
        # so the model can pull a full release body from a listing link.
        if _WEB_KEY in self._texts:
            specs.append(
                {
                    "type": "function",
                    "function": {
                        "name": "fetch_web_page",
                        "description": "Fetch the full text of a Shell newsroom "
                        "article/release by its URL — e.g. a link returned by "
                        "search_document over the newsroom listing. Use this to read "
                        "the full release-level facts behind a headline instead of "
                        "relying on the short listing summary. Only https shell.com "
                        "pages can be fetched. The fetched page becomes searchable "
                        "and readable by its URL via search_document/read_document.",
                        "parameters": {
                            "type": "object",
                            "properties": {
                                "url": {
                                    "type": "string",
                                    "description": "Absolute https URL of the "
                                    "shell.com article/release to fetch.",
                                },
                            },
                            "required": ["url"],
                        },
                    },
                }
            )
        return specs

    def dispatch(self, name: str, args: dict[str, Any]) -> str:
        try:
            if name == "list_documents":
                result: Any = self._meta
            elif name == "search_document":
                result = self._search(
                    str(args.get("query", "")),
                    args.get("document"),
                    int(args.get("max_results", 8) or 8),
                    str(args.get("corpus", "test-case") or "test-case"),
                )
            elif name == "read_document":
                result = self._read(
                    str(args.get("document", "")),
                    int(args.get("start", 0) or 0),
                    int(args.get("length", 4000) or 4000),
                )
            elif name == "fetch_web_page":
                result = self._fetch_url(str(args.get("url", "")))
            else:
                result = {"error": f"unknown tool: {name}"}
        except Exception as exc:  # noqa: BLE001 - surface to the model, don't crash the run
            result = {"error": f"{type(exc).__name__}: {exc}"}
        return json.dumps(result)[:_MAX_TOOL_RESULT]

    # ------------------------------------------------------------------ backing
    def _search(
        self,
        query: str,
        document: str | None,
        max_results: int,
        corpus: str = "test-case",
    ) -> list[dict[str, Any]]:
        terms = [t for t in re.findall(r"[\w.%-]+", query.lower()) if len(t) > 1]
        if not terms:
            return []
        pairs: list[tuple[str, str]] = []
        if corpus in ("test-case", "all"):
            pairs += [(k, self._texts[k]) for k in self._texts]
        if corpus in ("all-uploads", "all"):
            pairs += [(k, self._corpus_text_for(k)) for k in self._corpus]
        if document:
            target = self._resolve(document)
            pairs = [(k, t) for (k, t) in pairs if k == target]

        hits: list[dict[str, Any]] = []
        for key, text in pairs:
            low = text.lower()
            positions: set[int] = set()
            for t in terms:
                start = 0
                while len(positions) < 300:
                    i = low.find(t, start)
                    if i == -1:
                        break
                    positions.add(i)
                    start = i + len(t)
            last_end = -1
            for pos in sorted(positions):
                if pos < last_end:  # skip overlapping windows
                    continue
                s = max(0, pos - _WINDOW // 2)
                snippet = text[s : s + _WINDOW].replace("\n", " ").strip()
                score = sum(snippet.lower().count(t) for t in terms)
                hits.append(
                    {
                        "document": self._display(key),
                        "location": _locate(text, s),
                        "offset": s,
                        "score": score,
                        "snippet": snippet,
                    }
                )
                last_end = s + _WINDOW
        hits.sort(key=lambda h: h["score"], reverse=True)
        return hits[: max(1, max_results)]

    def _read(self, document: str, start: int, length: int) -> dict[str, Any]:
        key = self._resolve(document)
        if not key:
            return {
                "error": "document not found",
                "available": [m["document"] for m in self._meta] + list(self._corpus),
            }
        length = max(1, min(length, _MAX_READ))
        start = max(0, start)
        text = self._text_for(key)
        chunk = text[start : start + length]
        return {
            "document": self._display(key),
            "location": _locate(text, start),
            "start": start,
            "returned_chars": len(chunk),
            "total_chars": len(text),
            "text": chunk,
        }

    def _fetch_url(self, url: str) -> dict[str, Any]:
        url = url.strip()
        if not _is_allowed_web_url(url):
            return {
                "error": "url not allowed; only https shell.com pages can be fetched",
                "url": url,
            }
        # Pull the full release body from the article's AEM model JSON (fetch_web
        # only yields the listing teaser); fall back to fetch_web if unavailable.
        text = self._fetch_release_body(url) or fetch_web(url)
        if not text:
            return {"error": "could not fetch url (empty or unavailable)", "url": url}
        # Cache under the URL so later search_document/read_document can page it.
        if url not in self._texts:
            self._texts[url] = text
            self._meta.append({"document": url, "type": "web", "chars": len(text)})
        return {
            "document": url,
            "location": "web page",
            "start": 0,
            "returned_chars": len(text[:_MAX_READ]),
            "total_chars": len(text),
            "text": text[:_MAX_READ],
        }

    @staticmethod
    def _fetch_release_body(url: str) -> str:
        """Fetch an article page's AEM model JSON and return its full body text.

        Walks the model tree and concatenates every de-duplicated ``text`` fragment,
        so the model gets the complete release-level facts, not just the teaser.
        """
        if not url.endswith(".html"):
            return ""
        json_url = url[: -len(".html")] + ".model.json"
        try:
            req = Request(
                json_url,
                headers={"User-Agent": "GARdianAI/0.1", "Accept": "application/json"},
            )
            with urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8", "ignore"))
        except Exception:  # noqa: BLE001 - best effort; caller falls back to fetch_web
            return ""

        parts: list[str] = []
        seen: set[str] = set()

        def collect(node: Any) -> None:
            if isinstance(node, dict):
                raw = node.get("text")
                if isinstance(raw, str):
                    frag = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", raw)).strip()
                    if frag and frag not in seen:
                        seen.add(frag)
                        parts.append(frag)
                for value in node.values():
                    collect(value)
            elif isinstance(node, list):
                for item in node:
                    collect(item)

        collect(data)
        return "\n".join(parts)


# --------------------------------------------------------------------- tool loop
def assistant_message(msg: Any) -> dict[str, Any]:
    """Serialise an assistant response (with any tool calls) back into a message."""
    out: dict[str, Any] = {"role": "assistant", "content": msg.content or ""}
    calls = getattr(msg, "tool_calls", None)
    if calls:
        out["tool_calls"] = [
            {
                "id": c.id,
                "type": "function",
                "function": {"name": c.function.name, "arguments": c.function.arguments or "{}"},
            }
            for c in calls
        ]
    return out


def run_tool_loop(
    llm: Any,
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]],
    toolbox: DocumentToolbox,
    max_steps: int,
    reasoning_effort: str | None = None,
) -> str:
    """Drive a tool-calling loop until the model answers without a tool call.

    Mutates ``messages``; returns the final assistant text (may be empty when the
    step budget is exhausted mid-investigation).
    """
    last = ""
    for _ in range(max_steps):
        resp = llm.chat(messages=messages, tools=tools, reasoning_effort=reasoning_effort)
        msg = resp.choices[0].message
        messages.append(assistant_message(msg))
        calls = getattr(msg, "tool_calls", None)
        if not calls:
            return msg.content or ""
        for call in calls:
            try:
                args = json.loads(call.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            messages.append(
                {
                    "role": "tool",
                    "tool_call_id": call.id,
                    "content": toolbox.dispatch(call.function.name, args),
                }
            )
        last = msg.content or last
    return last
