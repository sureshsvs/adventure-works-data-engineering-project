"""Literal, single-pass rendering of the supported per-run placeholders."""

import re


class ReportingParameterError(ValueError):
    pass


def normalize_reporting_parameters(
    report_version: str | None = None,
    reporting_period: str | None = None,
    reporting_year: str | None = None,
) -> dict[str, str | None]:
    values = {
        "report_version": report_version,
        "reporting_period": reporting_period,
        "reporting_year": reporting_year,
    }
    for name, value in values.items():
        if value is not None:
            if not isinstance(value, str) or len(value.strip()) > 200:
                raise ReportingParameterError(f"{name} must be a string of at most 200 characters")
            values[name] = value.strip()
    if values["reporting_year"] is not None and not re.fullmatch(
        r"[0-9]{4}", values["reporting_year"]
    ):
        raise ReportingParameterError("reporting_year must be a four-digit string")
    return values


def render_reporting_prompt(
    prompt: str,
    report_version: str | None = None,
    reporting_period: str | None = None,
    reporting_year: str | None = None,
) -> str:
    values = normalize_reporting_parameters(report_version, reporting_period, reporting_year)

    def replace(match: re.Match[str]) -> str:
        name = match.group(1)
        value = values[name]
        if not value:
            raise ReportingParameterError(f"Required reporting parameter is missing: {name}")
        return value

    return re.sub(r"\{\{\s*(report_version|reporting_period|reporting_year)\s*\}\}", replace, prompt)
