"""Built-in variable definitions for run values and Task scalars.

Definitions are descriptive metadata only (``name``, ``meaning``, ``example``);
in MVP1 they do not constrain values with types, formats, enums or defaults.
Built-in definitions are supplied by the application and are immutable through
the API. Custom definitions are persisted separately (Cosmos DB) and merged
with the built-ins when listed.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class VariableDefinition:
    """Descriptive metadata for a run-value or Task-scalar key."""

    name: str
    meaning: str
    example: str

    def to_dict(self) -> dict[str, str]:
        return {"name": self.name, "meaning": self.meaning, "example": self.example}


BUILTIN_RUN_VALUES: tuple[VariableDefinition, ...] = (
    VariableDefinition("CQ", "Current quarter", "2025-Q4"),
    VariableDefinition("PQ", "Previous quarter", "2025-Q3"),
    VariableDefinition("SQLY", "Same quarter prior year", "2024-Q4"),
    VariableDefinition("QM1", "First month of the quarter", "2024-10"),
    VariableDefinition("QM2", "Second month of the quarter", "2024-11"),
    VariableDefinition("QM3", "Third month of the quarter", "2024-12"),
    VariableDefinition("RUN_NAME", "Run name", "2025-Q4 QRA Poc"),
    VariableDefinition("DELIVERABLE", "Deliverable code", "Published"),
)

BUILTIN_TASK_SCALARS: tuple[VariableDefinition, ...] = (
    VariableDefinition("SEGMENT", "Segment name for segment checks", "Integrated Gas"),
    VariableDefinition("QDB_SHEET", "Quarterly Databook sheet to check", "IG"),
)

BUILTIN_RUN_VALUE_NAMES: frozenset[str] = frozenset(d.name for d in BUILTIN_RUN_VALUES)
BUILTIN_TASK_SCALAR_NAMES: frozenset[str] = frozenset(
    d.name for d in BUILTIN_TASK_SCALARS
)
