"""Quarterly reporting-period parsing and arithmetic.

A period is a quarter written ``YYYY-Q[1-4]`` (for example ``2025-Q4``). Annual
and monthly cadences are out of scope for MVP1.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

_PERIOD_RE = re.compile(r"^(\d{4})-Q([1-4])$")


class InvalidPeriodError(ValueError):
    """Raised when a period string is not a valid ``YYYY-Q[1-4]`` quarter."""


@dataclass(frozen=True)
class Quarter:
    """An immutable reporting quarter with safe arithmetic."""

    year: int
    quarter: int

    def __str__(self) -> str:
        return f"{self.year}-Q{self.quarter}"

    def previous_quarter(self) -> "Quarter":
        if self.quarter == 1:
            return Quarter(self.year - 1, 4)
        return Quarter(self.year, self.quarter - 1)

    def same_quarter_prior_year(self) -> "Quarter":
        return Quarter(self.year - 1, self.quarter)


def parse_period(period: str) -> Quarter:
    """Parse and validate a quarterly period string.

    Rejects separators, traversal segments and any non-quarter input so the
    value is safe to use as a single path segment.
    """
    match = _PERIOD_RE.match(period or "")
    if not match:
        raise InvalidPeriodError(
            f"period must be a quarter formatted YYYY-Q[1-4]: {period!r}"
        )
    return Quarter(int(match.group(1)), int(match.group(2)))


def is_valid_period(period: str) -> bool:
    return bool(_PERIOD_RE.match(period or ""))
