# SuperAgent — Disclosure Control Domain Knowledge

Domain heuristics and formulas for executing disclosure-integrity controls over a
pack of Shell reporting documents. This is reference knowledge that supports the
process and output contract defined above — it does not redefine them.

## Inputs you work from
- The **auditor prompt** for the test case (from the versioned prompt library).
- The **control definitions** to execute (each has an id, name and description).
- The **ingested documents actually provided for this test case** — this may be a
  single document or a full pack (e.g. QRA PDF(s), IR slide deck, Quarterly
  Databook xlsx, and, only when the prompt calls for it, the Shell newsroom URL).
  Treat the listed examples as *possible* inputs, not a required set: work only
  with what was supplied and never flag an omitted document as a missing source.

## Source-of-truth hierarchy (applies only to documents actually provided)
- The **QRA — or the primary document supplied — is the source of truth**.
- **If a databook is present, it corroborates** the QRA.
- **If IR slides / other documents are present, they are checked *against* the
  QRA**, never the reverse.
Do not treat a document that was not provided as a gap in the evidence.

## Per-control mindset
Work through the controls one at a time. For **each control**:
1. Restate the control objective and list the procedures you perform.
2. Read the relevant document sections / cells / URLs, respecting the source
   hierarchy above.
3. **Show every calculation** (add-ups, percentage changes, reconciliations).
4. Decide a status: `pass`, `exception`, or `needs_review`.
5. For every exception, capture a **finding**: title, severity
   (high/medium/low), description, an **evidence trail** (document →
   page/para/cell/URL, rule applied), the shown calculation, and a
   recommendation.

## Number-consistency checks across financial statements
When the prompt asks you to check the consistency of numbers across financial
statements, **perform all necessary calculations yourself** — recompute each
derived figure from its components and compare it to the value reported in the
source, for every period the prompt covers.

### Presentation rule — Group summary metrics
When evaluating Group key financial metrics, present a multi-period comparison table titled **Group summary metrics**.

Ex: Table Columns:
| Metric | Q4 2024 | Q3 2024 | Q4 2023 | FY2024 | FY2023 | Integrity result |

Rules for the table:
- Cover all 5 comparison periods: current quarter, prior quarter, prior-year quarter, current full year, and prior full year.
- Include all key metrics from the opening announcement summary: Income attributable to Shell shareholders, Adjusted Earnings, Adjusted EBITDA, CFO, CFI, Free cash flow, Cash capex, Operating expenses, Underlying operating expenses, Basic EPS ($), and Oil & gas production.
- Use **Integrity result** as the final column header and record whether each metric ties out (e.g., "Agrees to income statement", "Agrees to cash flow statement", "CFO + CFI; agrees within rounding").

### Presentation rule — show the formula immediately before the table
For each recalculation, **state the formula used on its own line directly above
the results table**, then follow it with a table that shows each input, the
calculated value, the reported value, and the outcome. This makes the arithmetic
auditable at a glance.

Lay it out exactly like this:

Recalculation formula used
Calculated value = A + B − C

| Period | A | B | C | Calculated value | Reported value | Result |
|---|---|---|---|---|---|---|
| Q3 2025 | 5,420 | 22 | (81) | 5,523 | 5,523 | Pass |
| FY 2025 | 18,120 | 642 | (53) | 18,815 | 18,814 | Rounding |

Rules for the table:
- Give every input its own labelled column, and add a **Calculated value**, a
  **Reported value** and a **Result** column.
- Preserve the source's sign and bracket conventions for negatives, e.g. `(81)`.
- Set **Result** to `Pass` when the calculated value equals the reported value,
  `Rounding` when they differ only by an immaterial rounding amount (±1 in the
  last reported digit), and `Exception` when they differ materially — every
  `Exception` must also raise a finding with the full evidence trail (C6).

### Comparative Testing

Check:

- Current Quarter vs Previous Quarter
- Current Quarter vs Prior-Year Quarter
- Full Year vs Prior Year
- Prior Publication Consistency

### Presentation rule — website/media checks against the QRA
For website / media / newsroom checks against the QRA document, present a
**comparison matrix table** that lines up each website item against the QRA and
records the consistency assessment. Use these columns:

| Website item | Source date | Website Key facts | Reflected in QRA Portfolio development? | Consistency assessment | Audit comment |
|---|---|---|---|---|---|

Rules for the matrix:
- Add **one row per website item** checked.
- **Reflected in QRA Portfolio development?** must account for the whole QRA, not
  just the Portfolio Developments section — see the portfolio-developments
  completeness checks below (Preliminary update, NCI, segment reviews, etc.).
- Cite the QRA location in the **Audit comment** so each row is traceable, and
  raise a finding with the full evidence trail (C6) for any row whose
  **Consistency assessment** is an exception.

### Precedence rule for cross-section completeness
The matrix above assesses whether a website item is reflected anywhere in the
QRA. Separately, the Portfolio-developments completeness check must determine
whether each material portfolio action is disclosed in the specific **Portfolio
Developments** section. If a material action is disclosed elsewhere in the QRA
but is absent from that section, raise a cross-section finding even when the
matrix assessment is otherwise "reflected" or consistent. The finding must
identify both the disclosure outside Portfolio Developments and the absence
from that section.

### Commonly used recalculation formulas
Apply the relevant formula(s) for the metrics the prompt names. Use the source's
own line items as the inputs, and respect signs (identified items and NCI are
typically subtracted):

- **Adjusted Earnings incl. NCI** = Income/(loss) for the period + Current cost of
  supplies (CCS) adjustment after tax − Identified items included in income/(loss)
- **Total revenue and other income** = Revenue + JVA profit/(loss) +
  Interest and other income
- **Income before tax** = Total revenue and other income − Total expenditure
- **Income for the period** = Income before tax − Taxation
- **Income attributable to Shell plc shareholders** = Income for the period −
  Non-controlling interest (NCI)
- **Basic EPS** = Income attributable to Shell plc shareholders ÷ Weighted average
  number of basic shares
- **Cash capital expenditure** = Capital expenditure + Investments in JVs/associates
  + Investments in equity securities

These formulas are a starting toolkit — if the prompt names a metric not listed
here, derive it from the components disclosed in the source and show that formula
above its table in the same way.

## Portfolio-developments completeness checks
The "Portfolio Developments" section is **not** the only place material portfolio
actions appear in the QRA, so do not limit your search to it. Actions such as
**acquisitions, disposals, swaps, divestments, project sanctions, stake/interest
changes and entity formations** are disclosed in **several places across the
QRA** (e.g. Preliminary update, non-controlling interest, segment reviews,
subsequent events, notes and footnotes), and a single action may appear in one section
but not another.

Run this check as an explicit three-step reconciliation, and never conclude it
from keyword-search snippets alone — a search returns only a few short windows
and **cannot prove that an action is absent** from a section:

1. **Build the action inventory.** Sweep the *whole* QRA for every material
   portfolio action (acquisition, disposal, swap, divestment, project sanction,
   stake/interest change, entity formation). Search broadly and follow each hit
   into its surrounding text so you capture the counterparty, the asset, the
   percentage/stake, and the date. Record where each action is disclosed
   (section + locator).
2. **Read the Portfolio Developments section in full.** Locate the "Portfolio
   Developments" heading, then read that section *end to end* — page through it
   with successive reads by character offset until you have covered its entire
   length (use the returned `total_chars`/`returned_chars` to know when you have
   reached the end). Do not judge its contents from search windows; you must have
   the complete section text in front of you before deciding what it does and does
   not contain.
3. **Diff the inventory against that full section text.** For every action in the
   inventory, decide whether the same action is disclosed *within* the Portfolio
   Developments section you just read in full.

Present the result as a **reconciliation table** — one row per action — with
columns: `Action`, `Counterparty/asset`, `Disclosed at (section + locator)`,
`In Portfolio Developments?` (Yes / No / Inconsistent), and `Assessment`.

**Raise a finding** whenever a material portfolio action is disclosed outside the
Portfolio Developments section but is missing from — or inconsistent with — that
section, and attach the full evidence trail (C6). For an action missing from
Portfolio Developments, the finding must state where it was found elsewhere in the
QRA and that no equivalent disclosure was found in Portfolio Developments — and it
must cite that you read the section in full, not just searched it. For an action
that is disclosed in both locations but is inconsistent, the finding must identify
both QRA locations and describe the narrative or data inconsistency. If the
disclosures agree, record the Portfolio Developments location and assess the action
as covered.

The grounded newsroom source only gives you a **listing summary** (date, title, a
short teaser and the article link) per item — not the full release. To check a
portfolio development properly, **retrieve the full narrative and underlying data
for that item from the website using the `fetch_web_page` function, passing the
corresponding article's URL link** (the link returned by `search_document` over
the newsroom listing). Read that full release before deciding whether the QRA
reflects it, and cite the fetched page in your evidence trail (C6).

## IR-presentation source-reference checks
When checking the IR presentation, verify that each figure cites the **correct
source file**. A **wrong source file name reference** — e.g. citing the
"Q2 2022 Quarterly Databook" instead of the "Q4 2023 Quarterly Databook" — is a
reportable **Exception with `medium` severity**, even when the underlying number
itself is correct. Raise it as a finding with the full evidence trail (C6).

## Media-release contradictions — which source wins
When comparing against media/newsroom release information and the sources
**contradict** each other, resolve the conflict as follows:
- **Prefer the information the prompt specifies.** If the prompt scopes a date or
  range — e.g. "published from October 2023 to December 2023" — use only the
  release(s) within that window and ignore contradicting ones outside it.
- **If the prompt does not specify a date, use the information published at the
  newer date** (the most recently published release supersedes older ones).

State which source you relied on and why (prompt-specified scope, or newer
publication date), cite its publication date, and record any superseded
contradiction with the full evidence trail (C6).


