"""Task metadata persistence and Blob-backed task document hydration."""

from __future__ import annotations

import logging
import re
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import settings
from . import blob_storage
from . import source_catalog
from .document_store import DocumentRef, DocumentStore, Task
from .extractors import SUPPORTED_SUFFIXES
from .period import is_valid_period, parse_period

logger = logging.getLogger(__name__)


def _format_blob_timestamp(value: datetime | None) -> str | None:
    """Return a Blob ``last_modified`` as an ISO-8601 UTC string, or None."""
    if value is None:
        return None
    return value.isoformat().replace("+00:00", "Z")


class DuplicateTaskTitleError(ValueError):
    """Raised when a task title is already registered."""


class TaskStore(DocumentStore):
    """Cosmos-backed task metadata with prompt and documents resolved from Blob Storage."""

    def __init__(self, cosmos_container: Any | None = None) -> None:
        self.documents: dict[str, DocumentRef] = {}
        self._text_cache: dict[str, str] = {}
        self._blob_rel: dict[str, str] = {}
        self.test_cases: dict[str, Task] = {}
        self.root = Path(settings.sample_data_cache_dir) / "tasks"
        self._registration_lock = threading.Lock()
        self._task_document_locks: dict[str, Any] = {}
        self._task_document_locks_guard = threading.Lock()
        self._container = cosmos_container or self._create_cosmos_container()
        self._load_tasks()

    @staticmethod
    def _create_cosmos_container():
        from azure.cosmos import CosmosClient, PartitionKey

        if settings.cosmos_key:
            client = CosmosClient(settings.cosmos_endpoint, credential=settings.cosmos_key)
        else:
            from azure.identity import DefaultAzureCredential

            client = CosmosClient(
                settings.cosmos_endpoint,
                credential=DefaultAzureCredential(
                    managed_identity_client_id=settings.azure_client_id or None
                ),
            )
        database = client.create_database_if_not_exists("gardian")
        return database.create_container_if_not_exists(
            id="tasks", partition_key=PartitionKey(path="/id")
        )

    def _load_tasks(self) -> None:
        items = self._container.query_items(
            query="SELECT * FROM c", enable_cross_partition_query=True
        )
        for item in items:
            try:
                task = self._hydrate(self._task_from_metadata(item))
            except (KeyError, TypeError, ValueError):
                logger.exception("Skipping invalid task metadata with id %s", item.get("id"))
                continue
            self.test_cases[task.id] = task

    @staticmethod
    def _task_from_metadata(item: dict[str, Any]) -> Task:
        return Task(
            id=str(item["id"]),
            title=str(item["title"]),
            description=item.get("description"),
            logical_source_role_names=list(item["logical_source_role_names"]),
            prompt_name=str(item["prompt_name"]),
            created_by=item.get("created_by"),
            modified_by=item.get("modified_by"),
            last_modified=item.get("last_modified"),
            task_scalars=dict(item.get("task_scalars") or {}),
        )

    def _hydrate(self, task: Task) -> Task:
        """Load the task's period-neutral prompt text.

        Source documents are resolved lazily per request/run (see
        ``resolve_input_documents``), never eagerly at load/register/update.
        """
        self._validate_storage_name(task.prompt_name, "prompt_name")
        for role_name in task.logical_source_role_names:
            self._validate_storage_name(role_name, "logical_source_role_names")
        prompt_blob_name = f"prompts/{task.prompt_name}.docx"
        prompt_blobs = blob_storage.list_task_blobs(prompt_blob_name)
        prompt_blob = next((blob for blob in prompt_blobs if blob[0] == prompt_blob_name), None)
        if prompt_blob is None:
            logger.error("Prompt blob %s was not found", prompt_blob_name)
            task.prompt_text = ""
        else:
            prompt_ref = self._register_blob(task, prompt_blob, "prompt")
            task.prompt_text = self.get_text(prompt_ref.id)
            if not task.prompt_text:
                logger.error("Prompt blob %s is unreadable or empty", prompt_blob_name)
        task.input_documents = []
        return task

    @staticmethod
    def _blob_sort_key(blob: tuple[str, int, datetime | None]) -> tuple[float, str]:
        modified = blob[2]
        timestamp = modified.timestamp() if modified is not None else float("-inf")
        return timestamp, blob[0]

    def task_document_lock(self, task_id: str):
        """Return the shared lock for resolving and consuming one task's documents."""
        with self._task_document_locks_guard:
            return self._task_document_locks.setdefault(task_id, threading.RLock())

    def resolve_input_documents(self, task: Task, period: str) -> Task:
        """Resolve a task's source roles for ``period`` into a run-scoped Task.

        Looks up each configured role in the logical source catalog, lists the
        period-scoped Blob prefix once per role, selects one file per role
        (latest ``last_modified``; ties and missing timestamps broken by greatest
        Blob name), and registers the selected documents so ``get_text`` can read
        them. Returns a copy of ``task`` with ``input_documents``,
        ``input_documents_period``, ``unresolved_logical_source_role_names`` and
        ``logical_source_roles`` populated from the same listing pass. The
        persisted task is not mutated.
        """
        selected_quarter = parse_period(period)
        self._remove_task_documents(task.id)
        resolved: list[DocumentRef] = []
        unresolved: list[str] = []
        role_entries: list[dict[str, Any]] = []
        for role_name in task.logical_source_role_names:
            try:
                role = source_catalog.get_role(role_name)
            except source_catalog.UnknownRoleError:
                unresolved.append(role_name)
                role_entries.append(self._role_entry(role_name, None))
                continue
            doc, chosen = self._resolve_role(task, role, selected_quarter)
            role_entries.append(self._role_entry(role_name, chosen))
            if doc is None:
                unresolved.append(role_name)
            else:
                resolved.append(doc)
        hydrated = Task(
            id=task.id,
            title=task.title,
            logical_source_role_names=list(task.logical_source_role_names),
            prompt_name=task.prompt_name,
            description=task.description,
            created_by=task.created_by,
            modified_by=task.modified_by,
            last_modified=task.last_modified,
            task_scalars=dict(task.task_scalars),
            prompt_text=task.prompt_text,
            input_documents=resolved,
            input_documents_period=period,
            unresolved_logical_source_role_names=unresolved,
            logical_source_roles=role_entries,
        )
        return hydrated

    def _resolve_role(
        self, task: Task, role: "source_catalog.RoleDefinition", selected: Any
    ) -> tuple[DocumentRef | None, tuple[str, int, datetime | None] | None]:
        """List a role's period prefix once; register and return the chosen blob."""
        prefix = source_catalog.role_prefix(role, selected)
        supported = [
            blob
            for blob in blob_storage.list_task_blobs(prefix)
            if blob[0].startswith(prefix)
            and Path(blob[0]).suffix.lower() in SUPPORTED_SUFFIXES
        ]
        if not supported:
            return None, None
        chosen = max(supported, key=self._blob_sort_key)
        return self._register_blob(task, chosen, "input"), chosen

    def _resolve_role_blob(
        self, task: Task, role: "source_catalog.RoleDefinition", selected: Any
    ) -> DocumentRef | None:
        doc, _ = self._resolve_role(task, role, selected)
        return doc

    @staticmethod
    def _role_entry(
        role_name: str, chosen: tuple[str, int, datetime | None] | None
    ) -> dict[str, Any]:
        if chosen is None:
            return {"name": role_name, "file_name": None, "path": None, "last_modified": None}
        return {
            "name": role_name,
            "file_name": Path(chosen[0]).name,
            "path": chosen[0],
            "last_modified": _format_blob_timestamp(chosen[2]),
        }

    def resolve_role_document(
        self, task: Task, role: "source_catalog.RoleDefinition", period: str
    ) -> DocumentRef | None:
        """Resolve a single logical source role to one document for ``period``."""
        return self._resolve_role_blob(task, role, parse_period(period))

    @staticmethod
    def _validate_storage_name(value: str, field: str) -> None:
        if not value or value in {".", ".."} or "/" in value or "\\" in value:
            raise ValueError(f"{field} must be a non-empty single path segment")

    def _register_blob(
        self,
        task: Task,
        blob: tuple[str, int, datetime | None],
        kind: str,
    ) -> DocumentRef:
        blob_name, size, _ = blob
        stem = Path(blob_name).stem
        slug = re.sub(r"[^a-z0-9]+", "-", f"{task.id}-{kind}-{stem}".lower()).strip("-")
        doc_id = slug[:80]
        suffix = 1
        base_id = doc_id
        while doc_id in self.documents:
            suffix += 1
            doc_id = f"{base_id[:75]}-{suffix}"
        ref = DocumentRef(
            id=doc_id,
            name=Path(blob_name).name,
            path=str(self.root / blob_name),
            doc_type=Path(blob_name).suffix.lower().lstrip("."),
            kind=kind,
            test_case_id=task.id,
            size_bytes=size,
        )
        self.documents[doc_id] = ref
        self._blob_rel[doc_id] = blob_name
        return ref

    def _ensure_local(self, ref: DocumentRef) -> None:
        blob_name = self._blob_rel.get(ref.id)
        if not blob_name:
            return
        path = Path(ref.path)
        if path.exists() and (ref.size_bytes == 0 or path.stat().st_size == ref.size_bytes):
            return
        try:
            blob_storage.download_task_blob(blob_name, path)
        except Exception:  # noqa: BLE001 - get_text treats unavailable blobs as empty
            logger.exception("Failed to download task blob %s", blob_name)

    def get_task(self, task_id: str) -> Task | None:
        return self.test_cases.get(task_id)

    def list_tasks(self) -> list[Task]:
        return [self.test_cases[task_id] for task_id in sorted(self.test_cases)]

    def get_test_case(self, tc_id: str) -> Task | None:
        """Compatibility alias for code paths that resolve test cases by ID."""
        return self.get_task(tc_id)

    def list_test_cases(self) -> list[Task]:
        """Compatibility alias for the harness's common store protocol."""
        return self.list_tasks()

    def register_task(
        self,
        *,
        title: str,
        logical_source_role_names: list[str],
        prompt_name: str,
        description: str | None = None,
        created_by: str | None = None,
        last_modified: str | None = None,
        task_scalars: dict[str, str] | None = None,
    ) -> Task:
        title = title.strip()
        if not title:
            raise ValueError("title must not be empty")
        self._validate_storage_name(prompt_name, "prompt_name")
        for role_name in logical_source_role_names:
            self._validate_storage_name(role_name, "logical_source_role_names")

        with self._registration_lock:
            normalized_title = title.casefold()
            existing_titles = self._container.query_items(
                query="SELECT c.id, c.title FROM c", enable_cross_partition_query=True
            )
            if any(
                str(item.get("title", "")).strip().casefold() == normalized_title
                for item in existing_titles
            ):
                raise DuplicateTaskTitleError(f"Task title already exists: {title}")

            task = Task(
                id=str(uuid.uuid4()),
                title=title,
                description=description,
                logical_source_role_names=list(logical_source_role_names),
                prompt_name=prompt_name,
                created_by=created_by,
                modified_by=None,
                last_modified=last_modified
                or datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
                task_scalars=dict(task_scalars or {}),
            )
            metadata = self._metadata_for(task)
            self._container.create_item(body=metadata)
            self.test_cases[task.id] = self._hydrate(task)
            return self.test_cases[task.id]

    @staticmethod
    def _metadata_for(task: Task) -> dict[str, Any]:
        return {
            "id": task.id,
            "title": task.title,
            "description": task.description,
            "logical_source_role_names": task.logical_source_role_names,
            "prompt_name": task.prompt_name,
            "created_by": task.created_by,
            "modified_by": task.modified_by,
            "last_modified": task.last_modified,
            "task_scalars": dict(task.task_scalars),
        }

    def _check_unique_title(self, title: str, *, exclude_task_id: str | None = None) -> None:
        normalized_title = title.strip().casefold()
        existing_items = self._container.query_items(
            query="SELECT c.id, c.title FROM c", enable_cross_partition_query=True
        )
        if any(
            item.get("id") != exclude_task_id
            and str(item.get("title", "")).strip().casefold() == normalized_title
            for item in existing_items
        ):
            raise DuplicateTaskTitleError(f"Task title already exists: {title}")

    def _remove_task_documents(self, task_id: str) -> None:
        document_ids = [
            document_id
            for document_id, document in self.documents.items()
            if document.test_case_id == task_id
        ]
        for document_id in document_ids:
            self.documents.pop(document_id, None)
            self._blob_rel.pop(document_id, None)
            self._text_cache.pop(document_id, None)

    def update_task(
        self,
        task_id: str,
        *,
        title: str,
        logical_source_role_names: list[str],
        prompt_name: str,
        description: str | None = None,
        modified_by: str | None = None,
        task_scalars: dict[str, str] | None = None,
    ) -> Task | None:
        title = title.strip()
        if not title:
            raise ValueError("title must not be empty")
        self._validate_storage_name(prompt_name, "prompt_name")
        for role_name in logical_source_role_names:
            self._validate_storage_name(role_name, "logical_source_role_names")

        with self._registration_lock:
            existing = self.test_cases.get(task_id)
            if existing is None:
                return None
            self._check_unique_title(title, exclude_task_id=task_id)
            updated = Task(
                id=existing.id,
                title=title,
                description=description,
                logical_source_role_names=list(logical_source_role_names),
                prompt_name=prompt_name,
                created_by=existing.created_by,
                modified_by=modified_by,
                last_modified=datetime.now(timezone.utc).isoformat().replace(
                    "+00:00", "Z"
                ),
                task_scalars=dict(
                    task_scalars if task_scalars is not None else existing.task_scalars
                ),
            )
            self._container.upsert_item(self._metadata_for(updated))
            self._remove_task_documents(task_id)
            self.test_cases[task_id] = self._hydrate(updated)
            return self.test_cases[task_id]

    def delete_task(self, task_id: str) -> bool:
        with self._registration_lock:
            if task_id not in self.test_cases:
                return False
            self._container.delete_item(item=task_id, partition_key=task_id)
            self.test_cases.pop(task_id, None)
            self._remove_task_documents(task_id)
            return True

    def list_task_options(self, period: str | None = None) -> dict[str, Any]:
        # Scope the listing to prompts/ so we don't scan the whole container.
        blobs = blob_storage.list_task_blobs_strict("prompts/")
        prompt_names: set[str] = set()
        for blob_name, _, _ in blobs:
            parts = blob_name.split("/")
            if len(parts) == 2 and parts[0].casefold() == "prompts":
                if Path(parts[1]).suffix.casefold() == ".docx":
                    prompt_names.add(Path(parts[1]).stem)
        options: dict[str, Any] = {
            "logical_source_role_names": sorted(
                source_catalog.ROLE_NAMES, key=str.casefold
            ),
            "prompt_names": sorted(prompt_names, key=str.casefold),
        }
        if period is not None:
            options["logical_source_roles"] = self._resolve_catalog_documents(period)
        return options

    def _resolve_catalog_documents(self, period: str) -> list[dict[str, str | None]]:
        """Resolve each fixed catalog role's latest file for ``period``.

        Returns one entry per role in fixed catalog order with ``name``,
        ``file_name``, Blob-relative ``path`` and ``last_modified`` (all null for
        the file fields when no supported file exists). Does not register
        documents.
        """
        selected = parse_period(period)
        return [
            self._resolve_role_entry(role_name, selected)
            for role_name in source_catalog.ROLE_NAMES
        ]

    def _resolve_role_entry(
        self, role_name: str, selected: Any
    ) -> dict[str, Any]:
        """Resolve one role's latest file to a role entry without registering."""
        try:
            role = source_catalog.get_role(role_name)
        except source_catalog.UnknownRoleError:
            return self._role_entry(role_name, None)
        prefix = source_catalog.role_prefix(role, selected)
        supported = [
            blob
            for blob in blob_storage.list_task_blobs(prefix)
            if blob[0].startswith(prefix)
            and Path(blob[0]).suffix.lower() in SUPPORTED_SUFFIXES
        ]
        chosen = max(supported, key=self._blob_sort_key) if supported else None
        return self._role_entry(role_name, chosen)

    def list_periods(self) -> list[str]:
        blobs = blob_storage.list_task_blobs_strict()
        periods: set[str] = set()
        for blob_name, _, _ in blobs:
            parts = blob_name.split("/")
            if len(parts) >= 2 and parts[0].casefold() == "quarterly":
                if is_valid_period(parts[1]):
                    periods.add(parts[1])
        return sorted(periods, reverse=True)


_task_store: TaskStore | None = None


def get_task_store() -> TaskStore:
    global _task_store
    if _task_store is None:
        _task_store = TaskStore()
    return _task_store