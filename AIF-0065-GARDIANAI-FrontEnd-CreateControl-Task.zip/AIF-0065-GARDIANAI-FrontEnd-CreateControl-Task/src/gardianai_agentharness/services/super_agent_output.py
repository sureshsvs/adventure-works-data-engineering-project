"""Structured report output shared by all generation strategies."""

from __future__ import annotations

import json
import logging
from typing import Any

from .llm_client import LLMClient
from .models import DocSection, DocTable, GeneratedDocument
from .super_agent_context import reasoning_effort, report

logger = logging.getLogger(__name__)


def _object(properties: dict[str, Any]) -> dict[str, Any]:
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties),
        "additionalProperties": False,
    }


_TEXT = {"type": "string"}
_TEXTS = {"type": "array", "items": _TEXT}
REPORT_SCHEMA = _object({
    "title": _TEXT,
    "subtitle": _TEXT,
    "sections": {
        "type": "array",
        "items": _object({
            "heading": _TEXT,
            "level": {"type": "integer", "enum": [1, 2, 3]},
            "paragraphs": _TEXTS,
            "tables": {
                "type": "array",
                "items": _object({
                    "title": _TEXT,
                    "headers": _TEXTS,
                    "rows": {"type": "array", "items": _TEXTS},
                }),
            },
        }),
    },
})
REPORT_FORMAT = {
    "type": "json_schema",
    "json_schema": {
        "name": "integrity_report",
        "strict": True,
        "schema": REPORT_SCHEMA,
    },
}
REPORT_INSTRUCTION = (
    "Write the final report as exactly one JSON object matching the supplied "
    "schema. Choose the title, headings, section count/order, paragraphs and "
    "table columns dynamically for this prompt and the gathered evidence. "
    "Use a nonblank title, at least one substantive section, nonblank headings "
    "and heading levels 1..3. Use empty arrays for absent paragraphs or tables. "
    "Each table row must have exactly as many cells as its headers. Preserve "
    "evidence, calculations, citations and limitations; do not invent findings "
    "or repeat the investigation. Output no prose or code fences outside JSON."
)


def _validate(value: Any, schema: dict[str, Any], path: str) -> None:
    """Validate the JSON types used by the report schema without extra deps."""
    kind = schema["type"]
    if kind == "object":
        if not isinstance(value, dict):
            raise ValueError(f"{path} must be an object")
        properties = schema["properties"]
        if set(value) != set(properties):
            raise ValueError(f"{path} must contain exactly: {', '.join(properties)}")
        for key, child in properties.items():
            _validate(value[key], child, f"{path}.{key}")
    elif kind == "array":
        if not isinstance(value, list):
            raise ValueError(f"{path} must be an array")
        for index, item in enumerate(value):
            _validate(item, schema["items"], f"{path}[{index}]")
    elif kind == "string":
        if not isinstance(value, str):
            raise ValueError(f"{path} must be a string")
    elif kind == "integer":
        if type(value) is not int or value not in schema["enum"]:
            raise ValueError(f"{path} must be one of {schema['enum']}")


def parse_report(content: str) -> GeneratedDocument:
    """Reject malformed or empty reports rather than dropping unknown fields."""
    data = json.loads(content)
    _validate(data, REPORT_SCHEMA, "report")
    if not data["title"].strip():
        raise ValueError("report.title must not be blank")
    if not data["sections"]:
        raise ValueError("report.sections must contain at least one section")
    sections: list[DocSection] = []
    for index, section in enumerate(data["sections"]):
        path = f"report.sections[{index}]"
        if not section["heading"].strip():
            raise ValueError(f"{path}.heading must not be blank")
        tables = []
        for table in section["tables"]:
            if not table["headers"] or any(not h.strip() for h in table["headers"]):
                raise ValueError(f"{path}: table headers must not be empty or blank")
            if any(len(row) != len(table["headers"]) for row in table["rows"]):
                raise ValueError(f"{path}: table rows must match the header count")
            tables.append(DocTable(**table))
        if not any(p.strip() for p in section["paragraphs"]) and not any(
            any(cell.strip() for row in t.rows for cell in row) for t in tables
        ):
            raise ValueError(f"{path} must contain narrative or populated tables")
        sections.append(DocSection(
            heading=section["heading"],
            level=section["level"],
            paragraphs=section["paragraphs"],
            tables=tables,
        ))
    return GeneratedDocument(
        title=data["title"], subtitle=data["subtitle"], sections=sections
    )


def compose_report(
    llm: LLMClient, messages: list[dict[str, Any]]
) -> GeneratedDocument:
    """Compose and validate a report, retrying formatting once on the same evidence."""
    conversation = [*messages, {"role": "user", "content": REPORT_INSTRUCTION}]
    report("compose", "Composing structured report")
    for attempt in range(2):
        response = llm.chat(
            messages=conversation,
            response_format=REPORT_FORMAT,
            reasoning_effort=reasoning_effort(),
        )
        if not response.choices:
            raise RuntimeError("The model returned no report response")
        choice = response.choices[0]
        if getattr(choice.message, "refusal", None):
            raise RuntimeError("The model refused to generate the report")
        content = choice.message.content or ""
        try:
            if choice.finish_reason == "length":
                raise ValueError("Report output was truncated by the token limit")
            if choice.finish_reason != "stop":
                raise ValueError(f"Unexpected report finish reason: {choice.finish_reason}")
            return parse_report(content)
        except ValueError as exc:
            logger.warning("Report validation failed (attempt %s): %s", attempt + 1, exc)
            if attempt:
                raise RuntimeError(f"Report validation failed after a formatting retry: {exc}") from exc
            conversation.extend([
                {"role": "assistant", "content": content},
                {
                    "role": "user",
                    "content": (
                        f"Validation failed: {exc}. Correct the report structure "
                        "using the same evidence. Keep it concise enough to finish, "
                        "but retain material findings and citations. "
                        + REPORT_INSTRUCTION
                    ),
                },
            ])
    raise AssertionError("Unreachable report composition state")
