"""Shared context helpers for the SuperAgent (LLM grounding).

Small, dependency-light utilities used by the generation, retrieval and research
paths: build a full-text context block from a test case's documents, fetch a
grounded web page, and parse a JSON object out of a model response.
"""

from __future__ import annotations

from asyncio.log import logger
import contextvars
import json
import re
import urllib.request
from typing import Any, Callable

from ..config import settings
from .document_store import DocumentStore, Task, TestCase

# Per-document and total character budgets for the full-context prompt.
_PER_DOC_CHARS = 160_000
_TOTAL_CHARS = 400_000

# Per-thread progress reporter so strategy code can emit live stage updates
# without threading a callback through every function signature.
_PROGRESS: contextvars.ContextVar[Callable[[str, str], None] | None] = (
    contextvars.ContextVar("sa_progress", default=None)
)

# The stage LLM/OCR usage is attributed to (the last stage passed to report()).
_CURRENT_STAGE: contextvars.ContextVar[str] = contextvars.ContextVar(
    "sa_stage", default=""
)

# Per-thread token/OCR accumulator and a callback fired on every update so the
# service can surface a live running total while a background job is polled.
_TOKENS: contextvars.ContextVar[dict[str, Any] | None] = contextvars.ContextVar(
    "sa_tokens", default=None
)
_TOKEN_CB: contextvars.ContextVar[Callable[[dict[str, Any]], None] | None] = (
    contextvars.ContextVar("sa_token_cb", default=None)
)

# Per-run override for the benchmark expected-output template (None = use the
# settings default). Set by the service before generation on the active thread.
_USE_EXPECTED_TEMPLATE: contextvars.ContextVar[bool | None] = contextvars.ContextVar(
    "sa_use_expected_template", default=None
)


def set_use_expected_template(value: bool | None) -> None:
    _USE_EXPECTED_TEMPLATE.set(value)


def use_expected_template() -> bool:
    override = _USE_EXPECTED_TEMPLATE.get()
    return settings.super_agent_use_expected_template if override is None else override


# Per-run overrides for token-economy mode and reasoning effort (None = settings).
_ECONOMY: contextvars.ContextVar[bool | None] = contextvars.ContextVar(
    "sa_economy", default=None
)
_REASONING_EFFORT: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "sa_reasoning_effort_override", default=None
)


def set_economy(value: bool | None) -> None:
    _ECONOMY.set(value)


def set_reasoning_effort(value: str | None) -> None:
    _REASONING_EFFORT.set(value)


def economy_mode() -> bool:
    override = _ECONOMY.get()
    return settings.super_agent_economy if override is None else override


def reasoning_effort() -> str:
    if economy_mode():
        return "low"
    override = _REASONING_EFFORT.get()
    return settings.super_agent_reasoning_effort if not override else override


def expected_template_chars() -> int:
    chars = settings.super_agent_expected_template_chars
    return min(chars, 15_000) if economy_mode() else chars


def set_progress_cb(cb: Callable[[str, str], None] | None) -> None:
    _PROGRESS.set(cb)


def report(stage: str, detail: str = "") -> None:
    """Emit a progress stage to the active reporter, if any (no-op otherwise)."""
    _CURRENT_STAGE.set(stage)
    cb = _PROGRESS.get()
    if cb is not None:
        try:
            cb(stage, detail)
        except Exception:  # noqa: BLE001 - progress must never break generation
            pass


def _new_tracker() -> dict[str, Any]:
    return {
        "by_stage": {},
        "total": {"prompt": 0, "completion": 0, "total": 0},
        "ocr": {"requests": 0, "pages": 0},
    }


def reset_tokens() -> dict[str, Any]:
    """Start a fresh usage tracker for the current thread and return it."""
    tracker = _new_tracker()
    _TOKENS.set(tracker)
    return tracker


def set_token_cb(cb: Callable[[dict[str, Any]], None] | None) -> None:
    _TOKEN_CB.set(cb)


def token_totals() -> dict[str, Any]:
    """Snapshot of the current thread's usage tracker (fresh empty one if unset)."""
    return _snapshot(_TOKENS.get())


def _snapshot(tracker: dict[str, Any] | None) -> dict[str, Any]:
    if tracker is None:
        return _new_tracker()
    return json.loads(json.dumps(tracker))


def _emit_tokens(tracker: dict[str, Any]) -> None:
    cb = _TOKEN_CB.get()
    if cb is not None:
        try:
            cb(_snapshot(tracker))
        except Exception:  # noqa: BLE001 - usage tracking must never break generation
            pass


def record_usage(usage: Any) -> None:
    """Attribute an LLM response's token usage to the current stage + grand total."""
    tracker = _TOKENS.get()
    if tracker is None or usage is None:
        return
    prompt = _usage_field(usage, "prompt_tokens", "input_token_count")
    completion = _usage_field(usage, "completion_tokens", "output_token_count")
    total = _usage_field(usage, "total_tokens", "total_token_count") or (
        prompt + completion
    )
    stage = _CURRENT_STAGE.get() or "unknown"
    bucket = tracker["by_stage"].setdefault(
        stage, {"prompt": 0, "completion": 0, "total": 0}
    )
    bucket["prompt"] += prompt
    bucket["completion"] += completion
    bucket["total"] += total
    tracker["total"]["prompt"] += prompt
    tracker["total"]["completion"] += completion
    tracker["total"]["total"] += total
    _emit_tokens(tracker)


def record_ocr(pages: int, requests: int = 1) -> None:
    """Record Mistral OCR usage (metered per page, tracked apart from LLM tokens)."""
    tracker = _TOKENS.get()
    if tracker is None:
        return
    tracker["ocr"]["requests"] += int(requests)
    tracker["ocr"]["pages"] += int(pages)
    _emit_tokens(tracker)


def _usage_field(usage: Any, *names: str) -> int:
    """Read the first present token-count field, tolerating naming schemes."""
    for name in names:
        if isinstance(usage, dict):
            value = usage.get(name)
        else:
            value = getattr(usage, name, None)
        if value:
            return int(value)
    return 0


def build_context(tc: TestCase, store: DocumentStore) -> str:
    """Concatenate each input document's extracted text within a char budget."""
    blocks: list[str] = []
    total = 0
    for doc in tc.input_documents:
        text = store.get_text(doc.id)
        if not text:
            continue
        clip = text[:_PER_DOC_CHARS]
        if len(text) > _PER_DOC_CHARS:
            clip += "\n[...document truncated for context budget...]"
        block = f"=== DOCUMENT: {doc.name} ({doc.doc_type}) ===\n{clip}"
        if total + len(block) > _TOTAL_CHARS:
            break
        blocks.append(block)
        total += len(block)

    if isinstance(tc, Task) or tc.archetype == "grounded_web_check":
        web = fetch_web(settings.shell_newsroom_url)
        if web:
            blocks.append(
                f"=== GROUNDED WEB SOURCE: {settings.shell_newsroom_url} ===\n"
                f"{web[:_PER_DOC_CHARS]}"
            )
    return "\n\n".join(blocks)


def fetch_web(url: str) -> str:
    """Best-effort fetch of a public page, stripped to plain text.

    shell.com is Adobe Experience Manager: the server HTML is a near-empty
    client-render shell (confirmed live — a plain GET returns only nav/meta,
    no article text), so a `.html` page is fetched via its AEM Sling Model
    JSON exporter (`<path>.model.json`) instead, falling back to the stripped
    HTML for any URL where that doesn't apply or doesn't yield articles.
    """
    if url.endswith(".html"):
        articles = _fetch_model_json_articles(url[: -len(".html")] + ".model.json")
        if articles:
            return "\n\n".join(articles)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "GARdianAI/0.1"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            html = resp.read().decode("utf-8", "ignore")
    except Exception:  # noqa: BLE001 - best effort; caller notes if unavailable
        return ""
    text = re.sub(r"(?is)<script.*?</script>|<style.*?</style>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _fetch_model_json_articles(json_url: str) -> list[str]:
    """Walk an AEM Sling Model JSON tree and collect one line per dated article."""
    try:
        req = urllib.request.Request(
            json_url,
            headers={"User-Agent": "GARdianAI/0.1", "Accept": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode("utf-8", "ignore"))
    except Exception:  # noqa: BLE001 - best effort; caller falls back to HTML
        return []

    seen: set[str] = set()
    articles: list[str] = []

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            title, date = node.get("title"), node.get("date")
            if title and date and title not in seen:
                seen.add(title)
                summary = re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", node.get("text") or "")).strip()
                links = node.get("links")
                link = links[0].get("value", "") if isinstance(links, list) and links else ""
                articles.append(f"{date}  {title.strip()}\n{summary}\n{link}".strip())
            for value in node.values():
                walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(data)
    return articles


def parse_json(content: str) -> dict[str, Any]:
    """Parse a JSON object, tolerating text around it."""
    try:
        return json.loads(content)
    except json.JSONDecodeError as e:
        logger.exception(f"Error Message: {e}")
        start, end = content.find("{"), content.rfind("}")
        if start != -1 and end != -1:
            return json.loads(content[start : end + 1])
        raise