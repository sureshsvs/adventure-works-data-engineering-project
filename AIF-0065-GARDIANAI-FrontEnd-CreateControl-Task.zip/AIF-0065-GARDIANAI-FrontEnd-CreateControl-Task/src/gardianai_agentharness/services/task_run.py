"""Task-run preparation: validate, render prompt and assemble source documents.

Builds the run-scoped :class:`Task` for a generation run from a persisted task,
the selected period, the shared run-value set and the task's scalar values.
Follows the strict run rules: every recognised placeholder is required, and any
unresolved default source role or document reference fails before queueing.
"""

from __future__ import annotations

from dataclasses import replace

from . import prompt_variables as pv
from . import source_catalog
from .document_store import DocumentRef, Task
from .task_store import TaskStore


class TaskRunValidationError(ValueError):
    """Raised when a task run cannot be prepared (maps to HTTP 422)."""


def prepare_task_run(
    store: TaskStore,
    task: Task,
    period: str | None,
    run_values: dict[str, str],
) -> Task:
    """Resolve documents, validate placeholders and render the prompt.

    Returns a run-scoped copy of ``task`` with its rendered ``prompt_text`` and
    assembled ``input_documents`` (role defaults first, then prompt-referenced
    documents, deduplicated by Blob identity). Raises
    :class:`TaskRunValidationError` on any unresolved placeholder, source role
    or document reference.
    """
    parsed = pv.parse_prompt(task.prompt_text or "")

    needs_period = parsed.uses_period or bool(parsed.document_references) or bool(
        task.logical_source_role_names
    )
    if needs_period and not period:
        raise TaskRunValidationError("period is required to render this task")

    # Default source set from the task's configured roles.
    if period:
        hydrated = store.resolve_input_documents(task, period)
    else:
        hydrated = replace(
            task, input_documents=[], input_documents_period=None,
            unresolved_logical_source_role_names=[],
        )
    if hydrated.unresolved_logical_source_role_names:
        raise TaskRunValidationError(
            "unresolved source roles: "
            + ", ".join(hydrated.unresolved_logical_source_role_names)
        )

    merged: list[DocumentRef] = list(hydrated.input_documents)
    seen_paths = {ref.path for ref in merged}

    document_display_names: dict[str, str] = {}
    for ref in parsed.document_references:
        try:
            role = source_catalog.resolve_alias(ref.alias, ref.variant)
        except source_catalog.UnknownDocumentAliasError as exc:
            raise TaskRunValidationError(
                f"unknown document reference: {ref.token}"
            ) from exc
        doc = store.resolve_role_document(task, role, period)  # type: ignore[arg-type]
        if doc is None:
            raise TaskRunValidationError(
                f"unresolved document reference {ref.token} for role {role.name!r}"
            )
        document_display_names[ref.token] = doc.name
        if doc.path not in seen_paths:
            seen_paths.add(doc.path)
            merged.append(doc)

    # Scalar substitutions: run values plus the task's saved scalar values.
    scalar_values: dict[str, str] = {**run_values, **task.task_scalars}
    missing = sorted(
        name for name in parsed.run_or_scalar_names if name not in scalar_values
    )
    if missing:
        raise TaskRunValidationError(
            "unresolved variables: " + ", ".join(missing)
        )

    rendered = pv.render_prompt(
        task.prompt_text or "",
        period=period,
        scalar_values=scalar_values,
        document_display_names=document_display_names,
    )

    return replace(
        hydrated,
        prompt_text=rendered,
        input_documents=merged,
    )
