"""Auditable ``.docx`` report generator (stdlib only).

Builds a Word document from an :class:`AuditRun` that mirrors the structure of the
PoC benchmark "expected output" reports: executive summary / overall conclusion,
an exceptions & auditor-follow-up table, per-control sections with steps, shown
calculations, evidence trails and findings, and a final audit conclusion. Written
with ``zipfile`` + XML so no third-party dependency (e.g. python-docx) is needed
at runtime (satisfies C5 – transform findings into a clean, auditable format).
"""

from __future__ import annotations

import html
import zipfile
from pathlib import Path

from .models import AuditRun, ControlResult, GenerationRun, Severity

_CONTENT_TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>"""

_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

_DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>"""

_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:sz w:val="44"/><w:color w:val="1F3864"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:pPr><w:spacing w:before="280" w:after="120"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:sz w:val="30"/><w:color w:val="1F3864"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:pPr><w:spacing w:before="200" w:after="80"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:sz w:val="24"/><w:color w:val="2E74B5"/></w:rPr></w:style>
<w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:pPr><w:spacing w:before="160" w:after="60"/><w:outlineLvl w:val="2"/></w:pPr><w:rPr><w:b/><w:sz w:val="22"/><w:color w:val="404040"/></w:rPr></w:style>
</w:styles>"""

_SEVERITY_LABEL = {
    Severity.HIGH: "HIGH",
    Severity.MEDIUM: "MEDIUM",
    Severity.LOW: "LOW",
    Severity.INFO: "INFO",
}


def _esc(text: str) -> str:
    return html.escape(text or "", quote=False)


class _Docx:
    """Minimal WordprocessingML body builder."""

    def __init__(self) -> None:
        self._body: list[str] = []

    def _run(self, text: str, bold: bool = False, color: str | None = None) -> str:
        rpr = ""
        if bold or color:
            props = ("<w:b/>" if bold else "") + (
                f'<w:color w:val="{color}"/>' if color else ""
            )
            rpr = f"<w:rPr>{props}</w:rPr>"
        return f'<w:r>{rpr}<w:t xml:space="preserve">{_esc(text)}</w:t></w:r>'

    def para(
        self, text: str, style: str | None = None, bold: bool = False,
        color: str | None = None,
    ) -> None:
        ppr = f'<w:pPr><w:pStyle w:val="{style}"/></w:pPr>' if style else ""
        self._body.append(f"<w:p>{ppr}{self._run(text, bold, color)}</w:p>")

    def title(self, text: str) -> None:
        self.para(text, style="Title")

    def h1(self, text: str) -> None:
        self.para(text, style="Heading1")

    def h2(self, text: str) -> None:
        self.para(text, style="Heading2")

    def h3(self, text: str) -> None:
        self.para(text, style="Heading3")

    def bullet(self, text: str) -> None:
        self._body.append(
            '<w:p><w:pPr><w:numPr><w:ilvl w:val="0"/><w:numId w:val="0"/></w:numPr>'
            f'<w:ind w:left="360"/></w:pPr>{self._run("• " + text)}</w:p>'
        )

    def spacer(self) -> None:
        self._body.append("<w:p/>")

    def table(self, headers: list[str], rows: list[list[str]]) -> None:
        borders = (
            "<w:tblBorders>"
            + "".join(
                f'<w:{s} w:val="single" w:sz="4" w:space="0" w:color="BFBFBF"/>'
                for s in ("top", "left", "bottom", "right", "insideH", "insideV")
            )
            + "</w:tblBorders>"
        )
        tbl = [
            "<w:tbl><w:tblPr>"
            '<w:tblW w:w="5000" w:type="pct"/>' + borders + "</w:tblPr>"
        ]

        def cell(text: str, bold: bool, shade: str | None) -> str:
            shd = f'<w:shd w:val="clear" w:fill="{shade}"/>' if shade else ""
            return (
                f"<w:tc><w:tcPr>{shd}</w:tcPr>"
                f"<w:p>{self._run(text, bold=bold)}</w:p></w:tc>"
            )

        tbl.append(
            "<w:tr>" + "".join(cell(h, True, "1F3864") for h in headers) + "</w:tr>"
        )
        # header text should be white on dark fill
        tbl[-1] = tbl[-1].replace(
            "<w:r><w:rPr><w:b/></w:rPr>",
            '<w:r><w:rPr><w:b/><w:color w:val="FFFFFF"/></w:rPr>',
        )
        for i, row in enumerate(rows):
            shade = "F2F5FA" if i % 2 else None
            cells = "".join(
                cell(str(c), False, shade) for c in row + [""] * (len(headers) - len(row))
            )
            tbl.append(f"<w:tr>{cells}</w:tr>")
        tbl.append("</w:tbl>")
        self._body.append("".join(tbl))
        self.spacer()

    def to_document_xml(self) -> str:
        return (
            '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            "<w:body>" + "".join(self._body) + "</w:body></w:document>"
        )


def _severity_color(sev: Severity) -> str:
    return {"HIGH": "C00000", "MEDIUM": "BF8F00", "LOW": "548235", "INFO": "808080"}[
        _SEVERITY_LABEL[sev]
    ]


def _control_section(doc: _Docx, ctrl: ControlResult) -> None:
    doc.h2(f"{ctrl.control_id} — {ctrl.name}")
    doc.para(f"Status: {ctrl.status.value.upper()}    Review: {ctrl.review.value}",
             bold=True)
    if ctrl.summary:
        doc.para(ctrl.summary)
    if ctrl.steps:
        doc.h3("Procedures performed")
        for s in ctrl.steps:
            doc.bullet(s)
    for tbl in ctrl.tables:
        if tbl.get("title"):
            doc.h3(tbl["title"])
        doc.table(tbl.get("headers", []), tbl.get("rows", []))
    if ctrl.findings:
        doc.h3("Findings")
        rows = []
        for f in ctrl.findings:
            ev = "; ".join(
                f"{e.source_document} [{e.locator or 'n/a'}] rule={e.rule_applied}"
                for e in f.evidence
            )
            rows.append([
                _SEVERITY_LABEL[f.severity],
                f.title,
                f.description,
                ev,
                f.recommendation,
            ])
        doc.table(
            ["Severity", "Finding", "Description", "Evidence trail", "Recommendation"],
            rows,
        )
    else:
        doc.para("No exceptions raised by this control.", color="548235")
    doc.spacer()


def build_report(run: AuditRun, out_dir: Path) -> Path:
    """Render ``run`` to a .docx file under ``out_dir`` and return its path."""
    doc = _Docx()
    doc.title("Integrity Check Report — GARdian.AI")
    doc.para(f"{run.test_case_title}", bold=True)
    doc.para(
        f"Run ID: {run.run_id}    Generated: {run.completed_at}    Mode: {run.mode}"
    )
    doc.para(
        f"Model: {run.model}    Prompt version: {run.prompt_version}"
    )
    doc.para("Input documents: " + ", ".join(run.input_documents))
    doc.spacer()

    doc.h1("1. Executive summary")
    if run.executive_summary:
        for para in run.executive_summary.split("\n"):
            if para.strip():
                doc.para(para.strip())
    doc.para("Overall conclusion:", bold=True)
    doc.para(run.overall_conclusion or "See per-control findings below.")

    # Exceptions & auditor follow-up table.
    doc.h1("2. Exceptions & auditor follow-up")
    exc_rows = []
    for ctrl in run.controls:
        for f in ctrl.findings:
            if f.severity in (Severity.HIGH, Severity.MEDIUM, Severity.LOW):
                exc_rows.append([
                    ctrl.control_id,
                    _SEVERITY_LABEL[f.severity],
                    f.title,
                    f.recommendation or "—",
                ])
    if exc_rows:
        doc.table(["Control", "Severity", "Observation", "Recommended action"], exc_rows)
    else:
        doc.para("No material exceptions were identified.", color="548235")

    doc.h1("3. Controls performed")
    for ctrl in run.controls:
        _control_section(doc, ctrl)

    doc.h1("4. Audit conclusion")
    doc.para(
        f"{run.finding_count} finding(s) were raised across {len(run.controls)} "
        f"control(s); {run.exception_count} control(s) reported exceptions. "
        "Every finding above carries an evidence trail (document, locator, rule) "
        "for reviewer validation."
    )
    doc.para(
        "This report was produced by GARdian.AI and is intended as first-pass "
        "control evidence for human review and approval.",
        color="808080",
    )

    out_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{run.test_case_id}_{run.run_id}_integrity_report.docx"
    path = out_dir / filename
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", _CONTENT_TYPES)
        zf.writestr("_rels/.rels", _RELS)
        zf.writestr("word/_rels/document.xml.rels", _DOC_RELS)
        zf.writestr("word/styles.xml", _STYLES)
        zf.writestr("word/document.xml", doc.to_document_xml())
    return path


def _write_docx(doc: _Docx, path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("[Content_Types].xml", _CONTENT_TYPES)
        zf.writestr("_rels/.rels", _RELS)
        zf.writestr("word/_rels/document.xml.rels", _DOC_RELS)
        zf.writestr("word/styles.xml", _STYLES)
        zf.writestr("word/document.xml", doc.to_document_xml())
    return path


def build_generated_report(run: GenerationRun, out_dir: Path) -> Path:
    """Render a prompt-generated :class:`GenerationRun` document to a .docx file."""
    gen = run.document
    doc = _Docx()
    doc.title(gen.title or run.test_case_title or "Integrity Check Report")
    doc.para(f"Run title: {run.run_title or run.test_case_title}", bold=True)
    doc.para(f"Test case: {run.test_case_title}")
    if run.description:
        for line in run.description.splitlines():
            doc.para(f"Description: {line}")
    if gen.subtitle:
        for line in gen.subtitle.split("\n"):
            if line.strip():
                doc.para(line.strip(), color="808080")
    doc.para(
        f"Run ID: {run.run_id}    Generated: {run.completed_at}    Mode: {run.mode}"
    )
    doc.para(f"Model: {run.model}    Prompt version: {run.prompt_version}")
    if run.input_documents:
        doc.para("Input documents: " + ", ".join(run.input_documents))
    doc.spacer()

    _heading = {1: doc.h1, 2: doc.h2, 3: doc.h3}
    for section in gen.sections:
        _heading.get(section.level, doc.h1)(section.heading)
        for para in section.paragraphs:
            doc.para(para)
        for tbl in section.tables:
            if tbl.title:
                doc.h3(tbl.title)
            if tbl.headers:
                doc.table(tbl.headers, tbl.rows)
        doc.spacer()

    doc.para(
        "This report was produced by GARdian.AI and is intended as first-pass "
        "control evidence for human review and approval.",
        color="808080",
    )

    out_dir.mkdir(parents=True, exist_ok=True)
    filename = f"{run.test_case_id}_{run.run_id}_generated_report.docx"
    return _write_docx(doc, out_dir / filename)
