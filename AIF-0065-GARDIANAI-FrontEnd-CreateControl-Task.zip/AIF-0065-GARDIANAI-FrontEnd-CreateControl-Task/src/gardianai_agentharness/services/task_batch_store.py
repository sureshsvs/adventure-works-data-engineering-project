"""Durable task batches, separate from generated run summaries.

The scheduler is single-process, not a distributed queue. Unfinished records
without a live local worker are interrupted, never silently resumed. Deploy one
scheduler process per store; cross-process execution/leases are not supported.
"""

from __future__ import annotations

import json
import re
import threading
import uuid
from pathlib import Path
from typing import Any

from ..config import settings
from .run_store import AzureRunStore

_ID = re.compile(r"batch_[0-9a-f]{12}\Z")
# Shared by service instances in this process, so a second instance cannot
# mistake another instance's live work for a crashed scheduler.
batch_lock = threading.RLock()
live_batches: set[str] = set()


class LocalTaskBatchStore:
    def __init__(self, run_dir: Path) -> None:
        self._dir = run_dir / "task_batches"
        self._dir.mkdir(parents=True, exist_ok=True)

    def save(self, record: dict[str, Any]) -> None:
        path = self._dir / f"{record['batch_id']}.json"
        scratch = path.with_suffix(f".{uuid.uuid4().hex}.part")
        try:
            scratch.write_text(json.dumps(record, indent=2), encoding="utf-8")
            scratch.replace(path)
        finally:
            scratch.unlink(missing_ok=True)

    def load(self, batch_id: str) -> dict[str, Any] | None:
        if not isinstance(batch_id, str) or not _ID.fullmatch(batch_id):
            return None
        path = next(
            (candidate for candidate in self._dir.glob("batch_*.json")
             if candidate.stem == batch_id),
            None,
        )
        return json.loads(path.read_text(encoding="utf-8")) if path is not None else None

    def list(self) -> list[dict[str, Any]]:
        return [json.loads(path.read_text(encoding="utf-8"))
                for path in self._dir.glob("batch_*.json")]

    def delete(self, batch_id: str) -> None:
        if _ID.fullmatch(batch_id):
            (self._dir / f"{batch_id}.json").unlink(missing_ok=True)


class AzureTaskBatchStore:
    def __init__(self) -> None:
        self._runs = AzureRunStore()

    def save(self, record: dict[str, Any]) -> None:
        self._runs._cosmos().upsert_item({
            **record, "id": record["batch_id"], "run_id": record["batch_id"],
            "record_type": "task_batch",
        })

    def load(self, batch_id: str) -> dict[str, Any] | None:
        if not isinstance(batch_id, str) or not _ID.fullmatch(batch_id):
            return None
        from azure.cosmos.exceptions import CosmosResourceNotFoundError

        try:
            item = self._runs._cosmos().read_item(item=batch_id, partition_key=batch_id)
        except CosmosResourceNotFoundError:
            return None
        return self._record(item) if item.get("record_type") == "task_batch" else None

    @staticmethod
    def _record(item: dict[str, Any]) -> dict[str, Any]:
        return {key: value for key, value in item.items()
                if key not in {"id", "run_id", "record_type"} and not key.startswith("_")}

    def list(self) -> list[dict[str, Any]]:
        return [self._record(dict(item)) for item in self._runs._cosmos().query_items(
            query="SELECT * FROM c WHERE c.record_type = 'task_batch'",
            enable_cross_partition_query=True,
        )]

    def delete(self, batch_id: str) -> None:
        self._runs._cosmos().delete_item(item=batch_id, partition_key=batch_id)


def build_task_batch_store(run_dir: Path):
    return AzureTaskBatchStore() if settings.azure_runs_enabled else LocalTaskBatchStore(run_dir)
