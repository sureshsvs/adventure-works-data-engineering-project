"""SuperAgent — prompt-driven document generator.

Runs a PoC test case's auditor prompt over its ingested input documents and
produces an auditable Word document that mirrors the benchmark "expected output"
reports (C5). Persists each run (id, status, timestamps – C3/C6), renders a
downloadable ``.docx`` (C5) and supports full regeneration. Uses the configured
SuperAgent LLM when available and a deterministic offline draft otherwise, so the
flow stays demonstrable without credentials.
"""

from __future__ import annotations

import threading
import uuid
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..config import settings
from .case_scheduler import get_case_scheduler
from .document_store import Task, get_document_store
from .llm_client import get_super_agent_llm_client
from .models import GenerationRun, HumanDisposition
from .prompt_library import get_prompt_library
from .period import InvalidPeriodError, parse_period
from .report_service import build_generated_report
from .reporting_parameters import (
    ReportingParameterError,
    normalize_reporting_parameters,
    render_reporting_prompt,
)
from .run_store import build_run_store
from .super_agent_coauthor import apply_direct_edit, coauthor_edit
from .super_agent_context import (
    economy_mode,
    report,
    reset_tokens,
    set_economy,
    set_progress_cb,
    set_reasoning_effort,
    set_token_cb,
    set_use_expected_template,
    token_totals,
)
from .super_agent_context import reasoning_effort as get_reasoning_effort
from .super_agent_context import use_expected_template as get_use_expected_template
from .super_agent_generation import generate_document
from .task_run import TaskRunValidationError, prepare_task_run
from .task_store import TaskStore, get_task_store
from .task_batch_store import batch_lock, build_task_batch_store, live_batches
from .variable_store import get_variable_store


class UnknownTaskError(ValueError):
    """Raised when a task-run request refers to no registered task."""


class UnrunnableTaskError(ValueError):
    """Raised when a hydrated task has neither prompt text nor input documents."""


class TaskBatchValidationError(ValueError):
    def __init__(self, errors: list[dict[str, str]]) -> None:
        self.errors = errors
        super().__init__("One or more tasks cannot be run")


class SuperAgentService:
    def __init__(self) -> None:
        self._store = get_document_store()
        self._task_store: TaskStore | None = None
        self._variable_store: Any | None = None
        self._library = get_prompt_library()
        self._llm = get_super_agent_llm_client()
        self._run_dir = Path(settings.run_store_dir)
        self._run_dir.mkdir(parents=True, exist_ok=True)
        # Report .docx is built into _run_dir (local scratch) then handed to the store.
        self._runs = build_run_store(self._run_dir)
        self._batches = build_task_batch_store(self._run_dir)
        self._jobs: dict[str, dict[str, Any]] = {}
        self._jobs_lock = threading.Lock()
        self._scheduler = get_case_scheduler()

    # --------------------------------------------------------------- generate
    def generate(
        self,
        test_case_id: str,
        use_expected_template: bool | None = None,
        economy: bool | None = None,
        reasoning_effort: str | None = None,
        one_off_prompt: str | None = None,
        *,
        run_title: str | None = None,
        description: str = "",
        report_version: str | None = None,
        reporting_period: str | None = None,
        reporting_year: str | None = None,
        task_only: bool = False,
        period: str | None = None,
    ) -> dict[str, Any]:
        if task_only:
            if not self._get_task_store().get_task(test_case_id):
                raise ValueError(f"Unknown task: {test_case_id}")
            parameters = normalize_reporting_parameters(None, None, None)
        else:
            if not self._store.get_test_case(test_case_id):
                if not self._get_task_store().get_task(test_case_id):
                    raise ValueError(f"Unknown test case: {test_case_id}")
                task_only = True
                parameters = normalize_reporting_parameters(None, None, None)
            else:
                run_title = self._validate_run_title(run_title or "")
                parameters = normalize_reporting_parameters(
                    report_version, reporting_period, reporting_year
                )
                self._render_prompt(test_case_id, parameters)
        return self._scheduler.run(
            lambda: self._generate_with_task_lock(
                test_case_id,
                use_expected_template,
                economy,
                reasoning_effort,
                run_title=run_title or "",
                description=description,
                one_off_prompt=one_off_prompt,
                task_only=task_only,
                period=period,
                **parameters,
            )
        )

    def _generate_with_task_lock(
        self, test_case_id: str, *args: Any, **kwargs: Any
    ) -> dict[str, Any]:
        if not kwargs.get("task_only"):
            return self._generate(test_case_id, *args, **kwargs)
        with self._get_task_store().task_document_lock(test_case_id):
            return self._generate(test_case_id, *args, **kwargs)

    def _render_prompt(self, test_case_id: str, parameters: dict[str, Any]) -> str:
        tc = self._store.get_test_case(test_case_id)
        if not tc:
            raise ValueError(f"Unknown test case: {test_case_id}")
        entry = self._library.get(tc.id) or {}
        prompt = entry.get("prompt", tc.prompt_text) or tc.prompt_text
        return render_reporting_prompt(prompt, **parameters)

    def _generate(
        self, test_case_id: str, use_expected_template: bool | None,
        economy: bool | None, reasoning_effort: str | None, *,
        run_title: str, description: str, one_off_prompt: str | None,
        task_only: bool, period: str | None = None, **parameters: Any,
    ) -> dict[str, Any]:
        reset_tokens()
        description = description.strip()
        set_use_expected_template(use_expected_template)
        set_economy(economy)
        set_reasoning_effort(reasoning_effort)
        if task_only:
            store = self._get_task_store()
            tc = store.get_task(test_case_id)
        else:
            tc, store = self._resolve_test_case(test_case_id)
        if not tc:
            raise ValueError(f"Unknown test case: {test_case_id}")

        report("prepare", "Loading test case & prompt")
        if isinstance(tc, Task):
            tc = prepare_task_run(store, tc, period, self._run_values())
            prompt = tc.prompt_text
        else:
            prompt = self._render_prompt(test_case_id, parameters)
        if one_off_prompt:
            prompt += f"\n{one_off_prompt}"

        document, mode = generate_document(tc, store, prompt, self._llm)
        report("render", "Rendering .docx")
        if isinstance(tc, Task):
            report_title = tc.title
            prompt_version = f"{tc.prompt_name}@v1"
        else:
            report_title = f"Test case {tc.number} — {tc.title}"
            prompt_version = self._library.version_tag(tc.id)
        run = GenerationRun(
            test_case_id=tc.id,
            test_case_title=report_title,
            prompt_version=prompt_version,
            model=self._llm.model if self._llm.available else "deterministic-offline",
            mode=mode,
            input_documents=[d.name for d in tc.input_documents],
            document=document,
            token_usage=token_totals(),
            completed_at=datetime.now(timezone.utc).isoformat(),
            use_expected_template=get_use_expected_template(),
            economy=economy_mode(),
            reasoning_effort=get_reasoning_effort(),
            run_title=self._validate_run_title(run_title or report_title),
            description=description,
            period=period,
            task_only=task_only,
            **parameters,
        )
        report_path = build_generated_report(run, self._run_dir)
        run.report_filename = report_path.name
        self._runs.save(run, report_path.read_bytes())
        return run.to_dict()

    def regenerate(
        self,
        run_id: str,
        use_expected_template: bool | None = None,
        economy: bool | None = None,
        reasoning_effort: str | None = None,
        *,
        report_version: str | None = None,
        reporting_period: str | None = None,
        reporting_year: str | None = None,
        one_off_prompt: str | None = None,
    ) -> dict[str, Any]:
        run = self._load(run_id)
        if not run:
            raise ValueError(f"Unknown run: {run_id}")
        return self.generate(
            run.test_case_id, use_expected_template, economy, reasoning_effort,
            run_title=run.run_title or run.test_case_title,
            description=run.description,
            one_off_prompt=one_off_prompt,
            task_only=run.task_only,
            period=run.period,
            **self._regeneration_parameters(run, report_version, reporting_period, reporting_year),
        )

    @staticmethod
    def _regeneration_parameters(
        run: GenerationRun, report_version: str | None,
        reporting_period: str | None, reporting_year: str | None,
    ) -> dict[str, str | None]:
        return normalize_reporting_parameters(
            run.report_version if report_version is None else report_version,
            run.reporting_period if reporting_period is None else reporting_period,
            run.reporting_year if reporting_year is None else reporting_year,
        )

    def update_disposition(
        self,
        run_id: str,
        disposition: HumanDisposition,
        reviewer_comment: str = "",
    ) -> dict[str, Any]:
        run = self._load(run_id)
        if not run:
            raise ValueError(f"Unknown run: {run_id}")
        run.human_disposition = disposition
        run.reviewer_comment = reviewer_comment
        self._runs.save_metadata(run)
        return run.to_dict()

    # ------------------------------------------------------------- background
    @staticmethod
    def _validate_run_title(run_title: str) -> str:
        if not isinstance(run_title, str):
            raise ValueError("Run title is required")
        title = run_title.strip()
        if not title:
            raise ValueError("Run title is required")
        return title

    def start_generation(
        self,
        test_case_id: str,
        use_expected_template: bool | None = None,
        economy: bool | None = None,
        reasoning_effort: str | None = None,
        one_off_prompt: str | None = None,
        *,
        run_title: str,
        description: str = "",
        report_version: str | None = None,
        reporting_period: str | None = None,
        reporting_year: str | None = None,
    ) -> str:
        run_title = self._validate_run_title(run_title)
        if not self._store.get_test_case(test_case_id):
            raise ValueError(f"Unknown test case: {test_case_id}")
        parameters = normalize_reporting_parameters(
            report_version, reporting_period, reporting_year
        )
        self._render_prompt(test_case_id, parameters)
        return self._start(
            lambda: self.generate(
                test_case_id, use_expected_template, economy, reasoning_effort,
                one_off_prompt=one_off_prompt,
                run_title=run_title, description=description,
                **{key: value for key, value in parameters.items() if value is not None},
            )
        )

    def start_batch_generation(
        self,
        test_case_ids: list[str],
        use_expected_template: bool | None = None,
        economy: bool | None = None,
        reasoning_effort: str | None = None,
        *,
        run_title: str,
        description: str = "",
        max_parallel_cases: int | None = None,
        report_version: str | None = None,
        reporting_period: str | None = None,
        reporting_year: str | None = None,
    ) -> str:
        run_title = self._validate_run_title(run_title)
        description = description.strip()
        if max_parallel_cases is None:
            max_parallel_cases = settings.super_agent_default_max_parallel_cases
        if type(max_parallel_cases) is not int or not 1 <= max_parallel_cases <= 4:
            raise ReportingParameterError("max_parallel_cases must be between 1 and 4")
        parameters = normalize_reporting_parameters(report_version, reporting_period, reporting_year)
        if not test_case_ids:
            raise ValueError("At least one test case is required")
        test_cases = [self._store.get_test_case(test_case_id) for test_case_id in test_case_ids]
        unknown_ids = [
            test_case_id
            for test_case_id, test_case in zip(test_case_ids, test_cases)
            if test_case is None
        ]
        if unknown_ids:
            raise ValueError(f"Unknown test case(s): {', '.join(unknown_ids)}")
        for test_case_id in test_case_ids:
            self._render_prompt(test_case_id, parameters)

        job_id = uuid.uuid4().hex[:12]
        items = [
            {
                "test_case_id": test_case.id,
                "test_case_title": f"Test case {test_case.number} — {test_case.title}",
                "status": "queued",
                "run": None,
                "error": None,
                "tokens": None,
                "stage": "queued",
                "detail": "",
            }
            for test_case in test_cases
            if test_case is not None
        ]
        with self._jobs_lock:
            self._jobs[job_id] = {
                "stage": "queued",
                "detail": "",
                "done": False,
                "error": None,
                "run": None,
                "tokens": None,
                "batch": True,
                "run_title": run_title,
                "description": description,
                "max_parallel_cases": max_parallel_cases,
                **parameters,
                "status": "queued",
                "total": len(items),
                "finished_count": 0,
                "current_item_index": None,
                "current_test_case_id": None,
                "items": items,
            }

        def worker(index: int) -> None:
            item = items[index]
            reset_tokens()
            set_progress_cb(
                lambda stage, detail="": self._update_batch_progress(job_id, index, stage, detail)
            )
            set_token_cb(lambda snap: self._update_batch_progress(job_id, index, tokens=snap))
            with self._jobs_lock:
                job = self._jobs[job_id]
                job["status"] = "running"
                job["stage"] = "running"
                if max_parallel_cases == 1:
                    job["current_item_index"] = index + 1
                    job["current_test_case_id"] = item["test_case_id"]
                item["status"] = "running"
                item["stage"] = "prepare"
            try:
                run = self.generate(
                    item["test_case_id"], use_expected_template, economy, reasoning_effort,
                    run_title=run_title, description=description,
                    **{key: value for key, value in parameters.items() if value is not None},
                )
                self._update_batch_item(job_id, index, status="completed", run=run)
            except Exception as exc:  # noqa: BLE001 - isolate item failures
                self._update_batch_item(job_id, index, status="failed", error=str(exc))
            finally:
                with self._jobs_lock:
                    job = self._jobs[job_id]
                    job["finished_count"] += 1
                    if max_parallel_cases == 1:
                        job["current_item_index"] = None
                        job["current_test_case_id"] = None
                    if job["finished_count"] == job["total"]:
                        has_failures = any(i["status"] == "failed" for i in items)
                        job["status"] = "completed_with_errors" if has_failures else "completed"
                        job["stage"] = "done"
                        job["detail"] = ""
                        job["done"] = True

        self._admit(job_id, [lambda index=index: worker(index) for index in range(len(items))],
                    max_parallel_cases)
        return job_id

    def _update_batch_progress(
        self, job_id: str, index: int, stage: str | None = None,
        detail: str = "", tokens: dict[str, Any] | None = None,
    ) -> None:
        with self._jobs_lock:
            job = self._jobs[job_id]
            item = job["items"][index]
            if stage is not None:
                item["stage"], item["detail"] = stage, detail
                if job["max_parallel_cases"] == 1:
                    job["stage"], job["detail"] = stage, detail
            if tokens is not None:
                item["tokens"] = tokens
                aggregate = {"total": {}, "by_stage": {}, "ocr": {}}
                for current in job["items"]:
                    usage = current["tokens"] or {}
                    for bucket in ("total", "ocr"):
                        for key, value in usage.get(bucket, {}).items():
                            aggregate[bucket][key] = aggregate[bucket].get(key, 0) + value
                    for name, counts in usage.get("by_stage", {}).items():
                        target = aggregate["by_stage"].setdefault(name, {})
                        for key, value in counts.items():
                            target[key] = target.get(key, 0) + value
                job["tokens"] = aggregate

    def _update_batch_item(
        self,
        job_id: str,
        index: int,
        *,
        status: str,
        run: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> None:
        with self._jobs_lock:
            job = self._jobs.get(job_id)
            if job is None:
                return
            item = job["items"][index]
            item["status"] = status
            if run is not None:
                item["run"] = run
            if error is not None:
                item["error"] = error
            item["stage"] = "done" if status == "completed" else "error"
    def start_task_generation(
        self,
        task_id: str,
        economy: bool | None = None,
        reasoning_effort: str | None = None,
        one_off_prompt: str | None = None,
        period: str | None = None,
    ) -> str:
        self._validate_task_run(task_id, period)
        return self._start(
            lambda: self.generate(
                task_id, economy=economy, reasoning_effort=reasoning_effort,
                one_off_prompt=one_off_prompt, task_only=True, period=period,
            )
        )

    def _validate_task_run(self, task_id: str, period: str | None = None) -> Task:
        task_store = self._get_task_store()
        task = task_store.get_task(task_id)
        if task is None:
            raise UnknownTaskError(f"Unknown task: {task_id}")
        if not (task.prompt_text or "").strip() and not task.logical_source_role_names:
            raise UnrunnableTaskError(
                "Task has no prompt text or source roles"
            )
        # Validate the run resolves before queueing a job.
        try:
            if period is not None:
                if not isinstance(period, str):
                    raise TaskRunValidationError("period must be formatted YYYY-Q[1-4]")
                parse_period(period)
            with task_store.task_document_lock(task_id):
                prepare_task_run(task_store, task, period, self._run_values())
        except (TaskRunValidationError, InvalidPeriodError) as exc:
            raise UnrunnableTaskError(str(exc)) from exc
        return task

    @staticmethod
    def _validate_task_ids(task_ids: list[str]) -> None:
        if not isinstance(task_ids, list) or not task_ids:
            raise ValueError("At least one task is required")
        if any(not isinstance(task_id, str) or not task_id.strip() for task_id in task_ids):
            raise ValueError("Task IDs must be nonempty strings")
        if len(set(task_ids)) != len(task_ids):
            raise ValueError("Duplicate task IDs are not allowed")

    def preflight_tasks(
        self, task_ids: list[str], period: str | None = None,
    ) -> dict[str, Any]:
        self._validate_task_ids(task_ids)
        errors = []
        for task_id in task_ids:
            try:
                self._validate_task_run(task_id, period)
            except (UnknownTaskError, UnrunnableTaskError) as exc:
                errors.append({"task_id": task_id, "detail": str(exc)})
        return {"valid": not errors, "errors": errors}

    def start_task_batch_generation(
        self, task_ids: list[str], *, run_title: str, description: str = "",
        period: str | None = None, grouping: str = "", economy: bool | None = None,
        reasoning_effort: str | None = None, use_expected_template: bool | None = None,
        max_parallel_cases: int | None = None, one_off_prompt: str | None = None,
    ) -> str:
        run_title = self._validate_run_title(run_title)
        for name, value in (("description", description), ("grouping", grouping)):
            if not isinstance(value, str):
                raise ValueError(f"{name} must be a string")
        for name, value in (("economy", economy), ("use_expected_template", use_expected_template)):
            if value is not None and type(value) is not bool:
                raise ValueError(f"{name} must be a boolean")
        if reasoning_effort is not None and reasoning_effort not in ("low", "medium", "high"):
            raise ValueError("reasoning_effort must be low, medium or high")
        if period is not None and (not isinstance(period, str) or not period.strip()):
            raise ValueError("period must be a nonempty string")
        if period is not None:
            parse_period(period)
        if one_off_prompt is not None and not isinstance(one_off_prompt, str):
            raise ValueError("one_off_prompt must be a string")
        if max_parallel_cases is None:
            max_parallel_cases = settings.super_agent_default_max_parallel_cases
        if type(max_parallel_cases) is not int or not 1 <= max_parallel_cases <= 4:
            raise ValueError("max_parallel_cases must be between 1 and 4")
        preflight = self.preflight_tasks(task_ids, period)
        if not preflight["valid"]:
            raise TaskBatchValidationError(preflight["errors"])
        resolved_economy = settings.super_agent_economy if economy is None else economy
        batch_id = f"batch_{uuid.uuid4().hex[:12]}"
        created_at = datetime.now(timezone.utc).isoformat()
        record = {
            "batch_id": batch_id, "job_id": batch_id, "batch": True,
            "run_title": run_title, "description": description.strip(),
            "period": period, "grouping": grouping.strip(),
            "status": "queued", "stage": "queued", "done": False,
            "total": len(task_ids), "finished_count": 0,
            "created_at": created_at, "started_at": None, "completed_at": None,
            "economy": resolved_economy,
            "reasoning_effort": (
                "low" if resolved_economy
                else reasoning_effort or settings.super_agent_reasoning_effort
            ),
            "use_expected_template": (
                settings.super_agent_use_expected_template
                if use_expected_template is None else use_expected_template
            ),
            "max_parallel_cases": max_parallel_cases, "one_off_prompt": one_off_prompt,
            "items": [{
                "task_id": task_id,
                "task_title": self._get_task_store().get_task(task_id).title,
                "job_id": uuid.uuid4().hex[:12], "status": "queued",
                "run_id": None, "run": None, "error": None,
                "created_at": created_at, "started_at": None, "completed_at": None,
            } for task_id in task_ids],
        }
        with batch_lock:
            live_batches.add(batch_id)
            try:
                self._batches.save(record)
                self._scheduler.submit([
                    lambda index=index: self._run_task_batch_item(batch_id, index)
                    for index in range(len(task_ids))
                ], max_parallel_cases)
            except Exception:
                live_batches.discard(batch_id)
                self._batches.delete(batch_id)
                raise
        return batch_id

    def _run_task_batch_item(self, batch_id: str, index: int) -> None:
        with batch_lock:
            record = self._batches.load(batch_id)
            started_at = datetime.now(timezone.utc).isoformat()
            record["status"] = record["stage"] = "running"
            record["started_at"] = record.get("started_at") or started_at
            record["items"][index]["status"] = "running"
            record["items"][index]["started_at"] = started_at
            self._batches.save(record)
        item = record["items"][index]
        set_progress_cb(None)
        set_token_cb(None)
        try:
            run = self.generate(
                item["task_id"], task_only=True, period=record["period"],
                run_title=record["run_title"], description=record["description"],
                economy=record["economy"], reasoning_effort=record["reasoning_effort"],
                use_expected_template=record["use_expected_template"],
                one_off_prompt=record["one_off_prompt"],
            )
            result = {"status": "completed", "run": run, "run_id": run["run_id"]}
        except Exception as exc:  # noqa: BLE001 - one failure must not stop other tasks
            result = {"status": "failed", "error": str(exc)}
        with batch_lock:
            record = self._batches.load(batch_id)
            record["items"][index].update(result)
            completed_at = datetime.now(timezone.utc).isoformat()
            record["items"][index]["completed_at"] = completed_at
            record["finished_count"] += 1
            if record["finished_count"] == record["total"]:
                record["done"] = True
                record["completed_at"] = completed_at
                record["stage"] = "done"
                record["status"] = (
                    "completed_with_errors"
                    if any(item["status"] == "failed" for item in record["items"])
                    else "completed"
                )
            self._batches.save(record)
            if record["done"]:
                live_batches.discard(batch_id)

    def _recover_task_batch(self, record: dict[str, Any]) -> dict[str, Any]:
        if record["status"] in ("queued", "running") and record["batch_id"] not in live_batches:
            interrupted_at = datetime.now(timezone.utc).isoformat()
            for item in record["items"]:
                if item["status"] in ("queued", "running"):
                    item.update(
                        status="interrupted", error="Scheduler stopped before task completion",
                        completed_at=interrupted_at,
                    )
            record.update(
                status="interrupted", stage="done", done=True,
                finished_count=record["total"],
                completed_at=interrupted_at,
            )
            self._batches.save(record)
        return record

    def list_task_batches(self) -> list[dict[str, Any]]:
        with batch_lock:
            records = [self._recover_task_batch(record) for record in self._batches.list()]
            return sorted(records, key=lambda record: record["created_at"], reverse=True)

    def get_task_batch(self, batch_id: str) -> dict[str, Any] | None:
        if not hasattr(self, "_batches"):
            return None
        with batch_lock:
            record = self._batches.load(batch_id)
            return self._recover_task_batch(record) if record else None

    def start_regeneration(
        self,
        run_id: str,
        use_expected_template: bool | None = None,
        economy: bool | None = None,
        reasoning_effort: str | None = None,
        *,
        report_version: str | None = None,
        reporting_period: str | None = None,
        reporting_year: str | None = None,
        one_off_prompt: str | None = None,
    ) -> str:
        run = self._load(run_id)
        if not run:
            raise ValueError(f"Unknown run: {run_id}")
        if run.task_only or not self._store.get_test_case(run.test_case_id):
            self._validate_task_run(run.test_case_id, run.period)
            return self._start(
                lambda: self.generate(
                    run.test_case_id,
                    use_expected_template,
                    economy,
                    reasoning_effort,
                    one_off_prompt=one_off_prompt,
                    run_title=run.run_title or run.test_case_title,
                    description=run.description,
                    task_only=True,
                    period=run.period,
                )
            )
        return self.start_generation(
            run.test_case_id, use_expected_template, economy, reasoning_effort,
            one_off_prompt=one_off_prompt,
            run_title=run.run_title or run.test_case_title, description=run.description,
            **self._regeneration_parameters(run, report_version, reporting_period, reporting_year),
        )

    def _start(self, fn: Any) -> str:
        job_id = uuid.uuid4().hex[:12]
        with self._jobs_lock:
            self._jobs[job_id] = {
                "stage": "queued", "detail": "", "done": False,
                "error": None, "run": None, "tokens": None,
                "status": "queued",
            }

        def worker() -> None:
            self._update(job_id, "running")
            set_progress_cb(lambda stage, detail="": self._update(job_id, stage, detail))
            reset_tokens()
            set_token_cb(lambda snap: self._update(job_id, tokens=snap))
            try:
                run = fn()
                self._update(job_id, "done", "", done=True, run=run)
            except Exception as exc:  # noqa: BLE001 - report failure to the poller
                self._update(job_id, "error", str(exc), done=True, error=str(exc))

        self._admit(job_id, [worker])
        return job_id

    def _admit(self, job_id: str, tasks: list[Any], parallelism: int = 1) -> None:
        try:
            self._scheduler.submit(tasks, parallelism)
        except Exception:
            with self._jobs_lock:
                self._jobs.pop(job_id, None)
            raise

    def _update(
        self, job_id: str, stage: str | None = None, detail: str = "", *,
        done: bool = False, run: Any = None, error: str | None = None,
        tokens: dict[str, Any] | None = None,
    ) -> None:
        with self._jobs_lock:
            j = self._jobs.get(job_id)
            if j is None:
                return
            if stage is not None:
                j["stage"], j["detail"] = stage, detail
                j["status"] = stage if stage in ("done", "error") else "running"
            if done:
                j["done"] = True
            if run is not None:
                j["run"] = run
            if error is not None:
                j["error"] = error
            if tokens is not None:
                j["tokens"] = tokens

    def job_status(self, job_id: str) -> dict[str, Any] | None:
        with self._jobs_lock:
            j = self._jobs.get(job_id)
            if j:
                return deepcopy(j)
        return self.get_task_batch(job_id)

    # -------------------------------------------------------------------- reads
    def list_runs(self) -> list[dict[str, Any]]:
        return self._runs.list_summaries()

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        run = self._load(run_id)
        return run.to_dict() if run else None

    def open_report(self, run_id: str) -> tuple[bytes, str] | None:
        return self._runs.open_report(run_id)

    # ------------------------------------------------------------- co-author
    def update_document(self, run_id: str, document_data: dict[str, Any]) -> dict[str, Any]:
        run = self._load(run_id)
        if not run:
            raise ValueError(f"Unknown run: {run_id}")
        run.document = apply_direct_edit(document_data)
        return self._persist_edit(run)

    def coauthor(self, run_id: str, message: str) -> dict[str, Any]:
        run = self._load(run_id)
        if not run:
            raise ValueError(f"Unknown run: {run_id}")
        if not message.strip():
            raise RuntimeError("message must not be empty")
        if not self._llm.available:
            raise RuntimeError("Co-authoring requires the SuperAgent LLM to be configured")
        tc, store = self._resolve_test_case(run.test_case_id)
        if not tc:
            raise ValueError(f"Unknown test case: {run.test_case_id}")
        run.document, reply = coauthor_edit(tc, store, self._llm, run.document, message)
        result = self._persist_edit(run)
        result["reply"] = reply
        return result

    def _persist_edit(self, run: GenerationRun) -> dict[str, Any]:
        run.completed_at = datetime.now(timezone.utc).isoformat()
        report_path = build_generated_report(run, self._run_dir)
        run.report_filename = report_path.name
        self._runs.save(run, report_path.read_bytes())
        return run.to_dict()

    def _load(self, run_id: str) -> GenerationRun | None:
        return self._runs.load(run_id)

    def _resolve_test_case(self, test_case_id: str):
        test_case = self._store.get_test_case(test_case_id)
        if test_case is not None:
            return test_case, self._store
        task_store = self._get_task_store()
        return task_store.get_task(test_case_id), task_store

    def _get_task_store(self) -> TaskStore:
        if self._task_store is None:
            self._task_store = get_task_store()
        return self._task_store

    def _get_variable_store(self) -> Any:
        if self._variable_store is None:
            self._variable_store = get_variable_store()
        return self._variable_store

    def _run_values(self) -> dict[str, str]:
        existing = self._get_variable_store().get_run_value_set()
        return existing[0] if existing is not None else {}


_service: SuperAgentService | None = None
_service_lock = threading.Lock()


def get_super_agent_service() -> SuperAgentService:
    global _service
    with _service_lock:
        if _service is None:
            _service = SuperAgentService()
    return _service
