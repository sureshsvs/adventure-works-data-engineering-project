"""Deep-reasoning / research agent for the SuperAgent.

Runs a four-phase audit — PLAN, INVESTIGATE (tool retrieval), VERIFY/REFLECT,
SYNTHESIZE — on the SuperAgent model, grounded in the domain skills. The model
retrieves only the document windows it needs (scales to large packs) and cites a
document + offset for every figure, then emits the final report as JSON. Raises
on failure so the caller can fall back to the single-pass or offline paths.
"""

from __future__ import annotations

from ..config import settings
from .document_store import DocumentStore, TestCase
from .llm_client import LLMClient
from .super_agent_context import reasoning_effort, report
from .super_agent_output import compose_report
from .models import GeneratedDocument
from .super_agent_generation import (
    _DOMAIN_SKILLS,
    _SKILLS,
    _expected_template,
)
from .super_agent_retrieval import DocumentToolbox, run_tool_loop

_PLAN = (
    "PHASE 1 — PLAN. Using the auditor prompt, the benchmark structure and the "
    "domain knowledge, list the specific integrity checks and sub-questions to "
    "investigate (which metrics to reconcile, which tables to tie out, which "
    "periods to compare). Output a short numbered plan. You may call "
    "list_documents to orient yourself. Do not write the report yet."
)
_INVESTIGATE = (
    "PHASE 2 — INVESTIGATE. Work through your plan. Use search_document and "
    "read_document to retrieve the exact figures and passages for each check. "
    "Perform the calculations (add-ups, % changes, reconciliations) and record "
    "the result plus the locator (document + offset) for each. Continue until "
    "every plan item has supporting evidence. Do not write the final report yet."
)
_VERIFY = (
    "PHASE 3 — VERIFY. Re-check your calculations and look for gaps, "
    "contradictions or missed material exceptions. Retrieve any extra evidence "
    "needed to resolve them. Explicitly flag anything that cannot be verified "
    "from the documents rather than guessing."
)
_SYNTHESIZE = (
    "PHASE 4 — SYNTHESIZE. Output the Integrity Check Report as the JSON object "
    "described in your skills, grounded only in the evidence you gathered. "
    "Include every equivalent benchmark section, comparison tables with an "
    "integrity/auditor-assessment column, shown calculations, and an exceptions "
    "list with a full evidence trail (document + locator)."
)


def generate_research_document(
    tc: TestCase, store: DocumentStore, prompt: str, llm: LLMClient
) -> GeneratedDocument:
    toolbox = DocumentToolbox(tc, store)
    system = (
        _SKILLS
        + "\n\n# Domain knowledge (apply throughout planning, retrieval and review)\n"
        + _DOMAIN_SKILLS
    )
    intro = (
        f"AUDITOR PROMPT:\n{prompt}\n\n"
        f"{_expected_template(tc)}"
        "AVAILABLE DOCUMENTS — you have NOT read them. Retrieve content with the "
        "tools; never assert a figure you have not retrieved.\n"
        + toolbox.manifest_text()
    )
    messages: list[dict] = [
        {"role": "system", "content": system},
        {"role": "user", "content": intro},
    ]
    tools = toolbox.tool_specs()

    report("analyze", "Planning the checks")
    messages.append({"role": "user", "content": _PLAN})
    run_tool_loop(llm, messages, tools, toolbox, max_steps=4, reasoning_effort="medium")

    report("analyze", "Investigating documents")
    messages.append({"role": "user", "content": _INVESTIGATE})
    run_tool_loop(
        llm, messages, tools, toolbox,
        max_steps=settings.super_agent_research_max_steps,
        reasoning_effort=reasoning_effort(),
    )

    report("review", "Verifying calculations")
    messages.append({"role": "user", "content": _VERIFY})
    run_tool_loop(
        llm, messages, tools, toolbox, max_steps=6,
        reasoning_effort=reasoning_effort(),
    )

    report("compose", "Composing the report")
    messages.append({"role": "user", "content": _SYNTHESIZE})
    return compose_report(llm, messages)
