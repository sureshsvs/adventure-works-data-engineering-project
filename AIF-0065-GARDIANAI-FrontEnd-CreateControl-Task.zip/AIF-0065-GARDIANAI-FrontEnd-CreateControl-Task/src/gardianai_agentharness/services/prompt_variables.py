"""Prompt placeholder grammar, parsing and rendering.

Supported placeholders (double braces, case-sensitive):

- ``{{Period}}`` — the selected reporting period (reserved special token).
- ``{{NAME}}`` — a run value or a Task scalar (identifier ``[A-Z][A-Z0-9_]*``).
- ``{{DOC:ALIAS@VARIANT}}`` — a document reference; ``VARIANT`` is ``CQ``,
  ``PQ`` or ``SQLY``.

The parser only recognises complete, well-formed tokens. Ordinary brace text
that does not match a supported placeholder is left untouched. Names use the
``[A-Z][A-Z0-9_]*`` grammar and are unique case-insensitively. ``Period`` and
``DOC`` are reserved and may not be registered as run-value or scalar keys.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

# Identifier grammar shared by run values, Task scalars and document aliases.
IDENTIFIER_RE = re.compile(r"[A-Z][A-Z0-9_]*")

# Reserved names that cannot be registered as run-value or Task-scalar keys.
RESERVED_NAMES = frozenset({"Period", "DOC"})

DOC_VARIANTS = frozenset({"CQ", "PQ", "SQLY"})

PERIOD_TOKEN = "Period"

# A scalar/run-value token: ``{{NAME}}``.
_SIMPLE_TOKEN_RE = re.compile(r"\{\{(" + IDENTIFIER_RE.pattern + r")\}\}")

# A document token: ``{{DOC:ALIAS@VARIANT}}``.
_DOC_TOKEN_RE = re.compile(
    r"\{\{DOC:(" + IDENTIFIER_RE.pattern + r")@(" + IDENTIFIER_RE.pattern + r")\}\}"
)

# The reserved period token: ``{{Period}}`` (exact spelling).
_PERIOD_TOKEN_RE = re.compile(r"\{\{Period\}\}")

# Any complete double-brace token, used to detect malformed placeholders.
_ANY_TOKEN_RE = re.compile(r"\{\{(.*?)\}\}", re.DOTALL)


class PlaceholderError(ValueError):
    """Raised when a prompt contains a malformed or unknown placeholder."""


@dataclass(frozen=True)
class DocumentReference:
    """A parsed ``{{DOC:ALIAS@VARIANT}}`` token."""

    alias: str
    variant: str

    @property
    def token(self) -> str:
        return f"{{{{DOC:{self.alias}@{self.variant}}}}}"


@dataclass
class ParsedPrompt:
    """The placeholders discovered in a prompt template."""

    uses_period: bool = False
    run_or_scalar_names: set[str] = field(default_factory=set)
    document_references: list[DocumentReference] = field(default_factory=list)


def is_valid_identifier(name: str) -> bool:
    return bool(name) and bool(re.fullmatch(IDENTIFIER_RE, name))


def validate_registrable_key(name: str) -> None:
    """Validate a custom run-value or Task-scalar key name."""
    if not is_valid_identifier(name):
        raise PlaceholderError(
            f"variable name must match [A-Z][A-Z0-9_]*: {name!r}"
        )
    if name in RESERVED_NAMES:
        raise PlaceholderError(f"{name!r} is a reserved name")


def _token_body(match: re.Match[str]) -> str:
    return match.group(1)


def parse_prompt(text: str) -> ParsedPrompt:
    """Parse all supported placeholders from a prompt template.

    Fails on any complete ``{{...}}`` token that is not a recognised
    placeholder. Ordinary single braces and non-token text are ignored.
    """
    result = ParsedPrompt()
    seen_doc: set[tuple[str, str]] = set()

    for match in _ANY_TOKEN_RE.finditer(text):
        token = match.group(0)
        if _PERIOD_TOKEN_RE.fullmatch(token):
            result.uses_period = True
            continue
        doc_match = _DOC_TOKEN_RE.fullmatch(token)
        if doc_match:
            alias, variant = doc_match.group(1), doc_match.group(2)
            if variant not in DOC_VARIANTS:
                raise PlaceholderError(
                    f"document variant must be one of {sorted(DOC_VARIANTS)}: {token}"
                )
            key = (alias, variant)
            if key not in seen_doc:
                seen_doc.add(key)
                result.document_references.append(DocumentReference(alias, variant))
            continue
        simple_match = _SIMPLE_TOKEN_RE.fullmatch(token)
        if simple_match:
            result.run_or_scalar_names.add(simple_match.group(1))
            continue
        raise PlaceholderError(f"malformed or unknown placeholder: {token}")

    return result


def render_prompt(
    text: str,
    *,
    period: str | None,
    scalar_values: dict[str, str],
    document_display_names: dict[str, str],
) -> str:
    """Substitute recognised placeholders with their values.

    ``scalar_values`` covers both run values and Task scalars (a flat map of
    name to string). ``document_display_names`` maps each ``DocumentReference``
    token to the display name substituted into the prompt. Missing values are
    the caller's responsibility to validate before rendering.
    """

    def replace(match: re.Match[str]) -> str:
        token = match.group(0)
        if _PERIOD_TOKEN_RE.fullmatch(token):
            return period if period is not None else token
        doc_match = _DOC_TOKEN_RE.fullmatch(token)
        if doc_match:
            return document_display_names.get(token, token)
        simple_match = _SIMPLE_TOKEN_RE.fullmatch(token)
        if simple_match:
            name = simple_match.group(1)
            return scalar_values.get(name, token)
        return token

    return _ANY_TOKEN_RE.sub(replace, text)
