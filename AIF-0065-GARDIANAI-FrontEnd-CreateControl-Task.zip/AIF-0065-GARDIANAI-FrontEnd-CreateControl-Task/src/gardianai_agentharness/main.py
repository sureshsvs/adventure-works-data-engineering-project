"""FastAPI application entry point for the GARdian.AI SuperAgent backend.

Exposes the SuperAgent (deep-research report generation + upload), the editable
prompt library, and test-case/document metadata. Runnable fully offline against
the bundled sample data; lights up LLM reasoning when APIM / Azure AI Foundry
credentials are set.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from starlette.requests import Request

from .config import settings
from .api.routes import (
    health,
    prompts,
    super_agent,
    tasks,
    testcases,
    variables,
)
from .services.blob_storage import BlobStorageNotConfigured
from .services.llm_client import close_cached_llm_clients


@asynccontextmanager
async def lifespan(_: FastAPI) -> AsyncIterator[None]:
    try:
        yield
    finally:
        close_cached_llm_clients()


app = FastAPI(
    title=settings.app_name,
    version="0.1.0",
    description="GARdian.AI — automated disclosure-integrity SuperAgent that "
    "generates auditable reports from a prompt and input documents.",
    # Docs/schema are only exposed in debug mode; disabled by default.
    docs_url="/docs" if settings.debug else None,
    redoc_url="/redoc" if settings.debug else None,
    openapi_url="/openapi.json" if settings.debug else None,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origin_list,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["Retry-After"],
)


@app.exception_handler(BlobStorageNotConfigured)
def _blob_storage_not_configured(request: Request, exc: BlobStorageNotConfigured) -> JSONResponse:
    return JSONResponse(status_code=503, content={"detail": str(exc)})


_API = "/api"
app.include_router(health.router, prefix=_API)
app.include_router(testcases.router, prefix=_API)
app.include_router(super_agent.router, prefix=_API)
app.include_router(tasks.router, prefix=_API)
app.include_router(variables.router, prefix=_API)
app.include_router(prompts.router, prefix=_API)


@app.get("/")
def root() -> dict:
    return {
        "app": settings.app_name,
        "docs": "/docs" if settings.debug else None,
        "health": "/api/health",
    }
