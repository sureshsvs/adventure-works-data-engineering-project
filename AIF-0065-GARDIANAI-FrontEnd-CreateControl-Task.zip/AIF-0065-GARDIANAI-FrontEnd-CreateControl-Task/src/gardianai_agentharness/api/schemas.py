"""Pydantic request/response schemas for the API layer."""

from __future__ import annotations

from typing import Annotated, Literal

from pydantic import BaseModel, Field, StringConstraints, field_validator

from ..config import settings

RunTitle = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]
RunDescription = Annotated[str, StringConstraints(strip_whitespace=True)]
ReportingText = Annotated[
    str, StringConstraints(strip_whitespace=True, max_length=200)
]
ReportingYear = Annotated[
    str, StringConstraints(strip_whitespace=True, pattern=r"^[0-9]{4}$")
]

from ..services.models import HumanDisposition


class ReportingParametersRequest(BaseModel):
    report_version: ReportingText | None = None
    reporting_period: ReportingText | None = None
    reporting_year: ReportingYear | None = None


class RunMetadataRequest(ReportingParametersRequest):
    run_title: RunTitle
    description: RunDescription = ""


class SuperAgentRunRequest(RunMetadataRequest):
    test_case_id: str
    use_expected_template: bool | None = None
    economy: bool | None = None
    reasoning_effort: str | None = None
    one_off_prompt: str | None = None


class TaskRunRequest(BaseModel):
    task_id: str
    period: str | None = None
    economy: bool | None = None
    reasoning_effort: Literal["high", "medium", "low"] | None = None
    one_off_prompt: str | None = None


class TaskPreflightRequest(BaseModel):
    task_ids: list[RunTitle] = Field(..., min_length=1)
    period: str | None = None

    @field_validator("task_ids")
    @classmethod
    def unique_task_ids(cls, values: list[str]) -> list[str]:
        if len(set(values)) != len(values):
            raise ValueError("Select each task only once")
        return values


class TaskBatchRequest(TaskPreflightRequest):
    run_title: RunTitle
    description: RunDescription = ""
    grouping: RunDescription = ""
    max_parallel_cases: int = Field(
        default_factory=lambda: settings.super_agent_default_max_parallel_cases,
        strict=True, ge=1, le=4,
    )
    use_expected_template: bool | None = None
    economy: bool | None = None
    reasoning_effort: Literal["high", "medium", "low"] | None = None
    one_off_prompt: str | None = None


class TaskValidationFailure(BaseModel):
    task_id: str
    detail: str


class TaskPreflightResponse(BaseModel):
    valid: bool
    errors: list[TaskValidationFailure]


class TaskBatchStartResponse(BaseModel):
    batch_id: str
    job_id: str


class TaskBatchItemResponse(BaseModel):
    task_id: str
    task_title: str
    job_id: str
    status: str
    run_id: str | None = None
    run: dict | None = None
    error: str | None = None
    started_at: str | None = None
    completed_at: str | None = None


class TaskBatchResponse(BaseModel):
    batch_id: str
    job_id: str
    run_title: str
    description: str
    period: str | None = None
    grouping: str
    max_parallel_cases: int
    use_expected_template: bool | None = None
    economy: bool | None = None
    reasoning_effort: str | None = None
    status: str
    done: bool
    total: int
    finished_count: int
    created_at: str
    started_at: str | None = None
    completed_at: str | None = None
    items: list[TaskBatchItemResponse]


class TaskBatchHistoryResponse(BaseModel):
    batches: list[TaskBatchResponse]


class TaskCreateRequest(BaseModel):
    title: str
    logical_source_role_names: list[str]
    prompt_name: str
    description: str | None = None
    created_by: str | None = None
    task_scalars: dict[str, str] | None = None


class TaskUpdateRequest(BaseModel):
    title: str
    logical_source_role_names: list[str]
    prompt_name: str
    description: str | None = None
    modified_by: str | None = None
    task_scalars: dict[str, str] | None = None


class VariableDefinitionRequest(BaseModel):
    name: str
    meaning: str = ""
    example: str = ""


class VariableDefinitionUpdateRequest(BaseModel):
    meaning: str = ""
    example: str = ""


class RunValueSetRequest(BaseModel):
    values: dict[str, str] = Field(default_factory=dict)


class SuperAgentBatchRequest(RunMetadataRequest):
    test_case_ids: list[str] = Field(..., min_length=1)
    max_parallel_cases: int = Field(
        default_factory=lambda: settings.super_agent_default_max_parallel_cases,
        strict=True,
        ge=1,
        le=4,
    )
    use_expected_template: bool | None = None
    economy: bool | None = None
    reasoning_effort: str | None = None


class RegenerateRequest(ReportingParametersRequest):
    run_id: str
    use_expected_template: bool | None = None
    economy: bool | None = None
    reasoning_effort: str | None = None
    one_off_prompt: str | None = None


class DispositionUpdateRequest(BaseModel):
    disposition: HumanDisposition
    reviewer_comment: str = Field(default="", max_length=2000)


class PromptUpdateRequest(BaseModel):
    prompt: str = Field(..., min_length=1)
    updated_by: str = "superuser"


class DocTableIn(BaseModel):
    title: str = ""
    headers: list[str] = Field(default_factory=list)
    rows: list[list[str]] = Field(default_factory=list)


class DocSectionIn(BaseModel):
    heading: str
    level: int = 1
    paragraphs: list[str] = Field(default_factory=list)
    tables: list[DocTableIn] = Field(default_factory=list)


class UpdateDocumentRequest(BaseModel):
    title: str = ""
    subtitle: str = ""
    sections: list[DocSectionIn] = Field(default_factory=list)


class CoauthorRequest(BaseModel):
    message: str = Field(..., min_length=1)
