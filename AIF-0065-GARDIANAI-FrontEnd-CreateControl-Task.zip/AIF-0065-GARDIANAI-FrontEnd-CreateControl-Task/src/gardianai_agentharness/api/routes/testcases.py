"""Test case & document metadata endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from fastapi.responses import PlainTextResponse

from ...services.document_store import get_document_store

router = APIRouter(prefix="/testcases", tags=["testcases"])


@router.get("/")
def list_test_cases() -> dict:
    store = get_document_store()
    return {"test_cases": [tc.to_dict() for tc in store.list_test_cases()]}


@router.get("/{test_case_id}")
def get_test_case(test_case_id: str) -> dict:
    tc = get_document_store().get_test_case(test_case_id)
    if not tc:
        raise HTTPException(status_code=404, detail="Test case not found")
    return tc.to_dict(include_text=True)


@router.get("/document/{document_id}", response_class=PlainTextResponse)
def get_document_text(document_id: str) -> str:
    store = get_document_store()
    if not store.get_document(document_id):
        raise HTTPException(status_code=404, detail="Document not found")
    return store.get_text(document_id)
