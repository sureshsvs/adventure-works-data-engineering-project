"""SuperAgent endpoints — generate a document, upload a test case, download it."""

from __future__ import annotations

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import Response

from ...services.case_scheduler import CapacityBusyError
from ...services.document_store import get_document_store
from ...services.period import InvalidPeriodError
from ...services.sharepoint_storage import SharePointUploadError, upload_report
from ...services.task_run import TaskRunValidationError
from ...services.super_agent_service import (
    ReportingParameterError,
    TaskBatchValidationError,
    UnknownTaskError,
    UnrunnableTaskError,
    get_super_agent_service,
)
from ..schemas import (
    CoauthorRequest,
    DispositionUpdateRequest,
    RegenerateRequest,
    SuperAgentBatchRequest,
    SuperAgentRunRequest,
    TaskRunRequest,
    TaskBatchRequest,
    TaskBatchStartResponse,
    TaskBatchResponse,
    TaskBatchHistoryResponse,
    TaskPreflightRequest,
    TaskPreflightResponse,
    UpdateDocumentRequest,
)

router = APIRouter(prefix="/super-agent", tags=["super-agent"])

_DOCX_MEDIA = (
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
)


@router.post("/generate")
def generate(req: SuperAgentRunRequest) -> dict:
    try:
        return get_super_agent_service().generate(
            req.test_case_id, req.use_expected_template, req.economy, req.reasoning_effort,
            run_title=req.run_title, description=req.description,
            report_version=req.report_version,
            reporting_period=req.reporting_period,
            reporting_year=req.reporting_year,
            one_off_prompt=req.one_off_prompt,
        )
    except CapacityBusyError as exc:
        raise HTTPException(status_code=429, detail=f"Generation capacity busy: {exc}") from exc
    except ReportingParameterError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/regenerate")
def regenerate(req: RegenerateRequest) -> dict:
    try:
        return get_super_agent_service().regenerate(
            req.run_id,
            req.use_expected_template,
            req.economy,
            req.reasoning_effort,
            report_version=req.report_version,
            reporting_period=req.reporting_period,
            reporting_year=req.reporting_year,
            one_off_prompt=req.one_off_prompt,
        )
    except CapacityBusyError as exc:
        raise HTTPException(status_code=429, detail=f"Generation capacity busy: {exc}") from exc
    except (
        ReportingParameterError, UnrunnableTaskError, TaskRunValidationError, InvalidPeriodError
    ) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@router.post("/generate/start")
def generate_start(req: SuperAgentRunRequest) -> dict:
    try:
        return {
            "job_id": get_super_agent_service().start_generation(
                req.test_case_id,
                req.use_expected_template,
                req.economy,
                req.reasoning_effort,
                run_title=req.run_title,
                description=req.description,
                report_version=req.report_version,
                reporting_period=req.reporting_period,
                reporting_year=req.reporting_year,
                one_off_prompt=req.one_off_prompt,
            )
        }
    except CapacityBusyError as exc:
        raise HTTPException(status_code=429, detail=f"Generation capacity busy: {exc}") from exc
    except ReportingParameterError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/generate/batch/start")
def generate_batch_start(req: SuperAgentBatchRequest) -> dict:
    try:
        return {
            "job_id": get_super_agent_service().start_batch_generation(
                req.test_case_ids,
                req.use_expected_template,
                req.economy,
                req.reasoning_effort,
                run_title=req.run_title,
                description=req.description,
                report_version=req.report_version,
                reporting_period=req.reporting_period,
                reporting_year=req.reporting_year,
                max_parallel_cases=req.max_parallel_cases,
            )
        }
    except CapacityBusyError as exc:
        raise HTTPException(status_code=429, detail=f"Generation capacity busy: {exc}") from exc
    except ReportingParameterError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/tasks/generate/start")
def task_generate_start(req: TaskRunRequest) -> dict:
    try:
        job_id = get_super_agent_service().start_task_generation(
            req.task_id,
            req.economy,
            req.reasoning_effort,
            one_off_prompt=req.one_off_prompt,
            period=req.period,
        )
        return {"job_id": job_id}
    except CapacityBusyError as exc:
        raise HTTPException(
            status_code=429,
            detail=f"Generation queue is full. Retry this request later: {exc}",
            headers={"Retry-After": "2"},
        ) from exc
    except UnknownTaskError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except UnrunnableTaskError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.post("/tasks/generate/preflight", response_model=TaskPreflightResponse)
def task_preflight(req: TaskPreflightRequest) -> dict:
    return get_super_agent_service().preflight_tasks(req.task_ids, req.period)


@router.post("/tasks/generate/batch/start", response_model=TaskBatchStartResponse)
def task_batch_start(req: TaskBatchRequest) -> dict:
    try:
        batch_id = get_super_agent_service().start_task_batch_generation(
            **req.model_dump()
        )
        return {"batch_id": batch_id, "job_id": batch_id}
    except CapacityBusyError as exc:
        raise HTTPException(
            status_code=429,
            detail=f"Generation queue is full. Retry this batch later: {exc}",
            headers={"Retry-After": "2"},
        ) from exc
    except TaskBatchValidationError as exc:
        raise HTTPException(
            status_code=422,
            detail={"message": "No tasks were queued. Resolve the task errors.", "errors": exc.errors},
        ) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/tasks/batches", response_model=TaskBatchHistoryResponse)
def task_batch_history() -> dict:
    return {"batches": get_super_agent_service().list_task_batches()}


@router.get("/tasks/batches/{batch_id}", response_model=TaskBatchResponse)
def task_batch_detail(batch_id: str) -> dict:
    batch = get_super_agent_service().get_task_batch(batch_id)
    if batch is None:
        raise HTTPException(status_code=404, detail="Task batch not found")
    return batch


@router.post("/regenerate/start")
def regenerate_start(req: RegenerateRequest) -> dict:
    try:
        return {
            "job_id": get_super_agent_service().start_regeneration(
                req.run_id,
                req.use_expected_template,
                req.economy,
                req.reasoning_effort,
                report_version=req.report_version,
                reporting_period=req.reporting_period,
                reporting_year=req.reporting_year,
                one_off_prompt=req.one_off_prompt,
            )
        }
    except CapacityBusyError as exc:
        raise HTTPException(status_code=429, detail=f"Generation capacity busy: {exc}") from exc
    except (
        ReportingParameterError, UnrunnableTaskError, TaskRunValidationError, InvalidPeriodError
    ) as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/jobs/{job_id}")
def job_status(job_id: str) -> dict:
    st = get_super_agent_service().job_status(job_id)
    if st is None:
        raise HTTPException(status_code=404, detail="Job not found")
    return st


@router.post("/upload")
async def upload(
    title: str = Form(""),
    prompt_text: str = Form(""),
    prompt_file: UploadFile | None = File(None),
    expected_file: UploadFile | None = File(None),
    input_files: list[UploadFile] = File(default=[]),
) -> dict:
    inputs = [(f.filename or "input", await f.read()) for f in input_files]
    inputs = [(name, data) for name, data in inputs if data]
    if not inputs:
        raise HTTPException(
            status_code=400, detail="At least one input file is required."
        )
    if prompt_file is None and not prompt_text.strip():
        raise HTTPException(
            status_code=400, detail="A prompt file or prompt text is required."
        )

    prompt = None
    if prompt_file is not None:
        prompt = (prompt_file.filename or "prompt", await prompt_file.read())
    expected = None
    if expected_file is not None:
        data = await expected_file.read()
        if data:
            expected = (expected_file.filename or "expected", data)

    tc = get_document_store().register_uploaded_test_case(
        title=title,
        input_files=inputs,
        prompt_file=prompt,
        prompt_text=prompt_text,
        expected_file=expected,
    )
    return tc.to_dict(include_text=True)


@router.get("/runs")
def list_runs() -> dict:
    return {"runs": get_super_agent_service().list_runs()}


@router.get("/runs/{run_id}")
def get_run(run_id: str) -> dict:
    run = get_super_agent_service().get_run(run_id)
    if not run:
        raise HTTPException(status_code=404, detail="Run not found")
    return run


@router.patch("/runs/{run_id}/disposition")
def update_disposition(run_id: str, req: DispositionUpdateRequest) -> dict:
    try:
        return get_super_agent_service().update_disposition(
            run_id, req.disposition, req.reviewer_comment
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.put("/runs/{run_id}/document")
def update_document(run_id: str, req: UpdateDocumentRequest) -> dict:
    try:
        return get_super_agent_service().update_document(run_id, req.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/runs/{run_id}/coauthor")
def coauthor(run_id: str, req: CoauthorRequest) -> dict:
    try:
        return get_super_agent_service().coauthor(run_id, req.message)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/runs/{run_id}/report")
def download_report(run_id: str) -> Response:
    result = get_super_agent_service().open_report(run_id)
    if not result:
        raise HTTPException(status_code=404, detail="Report not found")

    # TODO: remove the code.  This is for temp testing on sharepoint upload
    # data, _ = result
    # try:
    #     return upload_report(data, "control_1", "Q1-2025")
    # except ValueError as exc:
    #     raise HTTPException(status_code=400, detail=str(exc)) from exc
    # except SharePointUploadError as exc:
    #     raise HTTPException(status_code=502, detail=str(exc)) from exc
    
    data, filename = result
    return Response(
        content=data,
        media_type=_DOCX_MEDIA,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            # A co-authoring edit re-renders this same filename in place; never
            # let the browser/proxy serve a stale copy from before the edit.
            "Cache-Control": "no-store",
        },
    )

@router.post("/runs/{run_id}/report/sharepoint")
def upload_to_sharepoint(run_id: str, control_name: str, quarter: str| None = None) -> dict:
    result = get_super_agent_service().open_report(run_id)
    if not result:
        raise HTTPException(status_code=404, detail="Report not found")
    data, _ = result
    try:
        return upload_report(data, control_name, quarter)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except SharePointUploadError as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc
