"""Task CRUD endpoints."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, Response

from ...services.blob_storage import BlobStorageListingError
from ...services.document_store import Task
from ...services.period import InvalidPeriodError
from ...services.task_store import (
    DuplicateTaskTitleError,
    TaskStore,
    get_task_store,
)
from ...services.variable_store import get_variable_store
from ..schemas import TaskCreateRequest, TaskUpdateRequest

router = APIRouter(tags=["tasks"])


def _validate_task_scalars(task_scalars: dict[str, str] | None) -> None:
    if not task_scalars:
        return
    store = get_variable_store()
    for key in task_scalars:
        if not store.is_registered_task_scalar(key):
            raise HTTPException(
                status_code=422, detail=f"unknown task-scalar key: {key}"
            )


def _preview(store: TaskStore, task: Task, period: str | None) -> dict:
    """Serialize a task, hydrating period-scoped input documents when asked."""
    if period is None:
        return task.to_dict()
    try:
        with store.task_document_lock(task.id):
            hydrated = store.resolve_input_documents(task, period)
    except InvalidPeriodError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except BlobStorageListingError as exc:
        raise HTTPException(status_code=503, detail="Source catalog unavailable") from exc
    return hydrated.to_dict()


@router.post("/tasks", status_code=201)
def create_task(req: TaskCreateRequest, period: str | None = Query(default=None)) -> dict:
    _validate_task_scalars(req.task_scalars)
    try:
        task = get_task_store().register_task(**req.model_dump())
    except DuplicateTaskTitleError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return _preview(get_task_store(), task, period)


@router.get("/tasks")
def list_tasks() -> dict[str, list[dict]]:
    return {"tasks": [task.to_dict() for task in get_task_store().list_tasks()]}


@router.get("/tasks/options")
def list_task_options(period: str | None = Query(default=None)) -> dict:
    try:
        return get_task_store().list_task_options(period)
    except InvalidPeriodError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except BlobStorageListingError as exc:
        raise HTTPException(status_code=503, detail="Task options are unavailable") from exc


@router.get("/periods")
def list_periods() -> dict[str, list[str]]:
    try:
        return {"periods": get_task_store().list_periods()}
    except BlobStorageListingError as exc:
        raise HTTPException(status_code=503, detail="Periods are unavailable") from exc


@router.get("/tasks/{task_id}")
def get_task(task_id: str, period: str | None = Query(default=None)) -> dict:
    task = get_task_store().get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return _preview(get_task_store(), task, period)


@router.put("/tasks/{task_id}")
def update_task(
    task_id: str, req: TaskUpdateRequest, period: str | None = Query(default=None)
) -> dict:
    _validate_task_scalars(req.task_scalars)
    try:
        task = get_task_store().update_task(task_id, **req.model_dump())
    except DuplicateTaskTitleError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return _preview(get_task_store(), task, period)


@router.delete("/tasks/{task_id}", status_code=204)
def delete_task(task_id: str) -> Response:
    if not get_task_store().delete_task(task_id):
        raise HTTPException(status_code=404, detail="Task not found")
    return Response(status_code=204)