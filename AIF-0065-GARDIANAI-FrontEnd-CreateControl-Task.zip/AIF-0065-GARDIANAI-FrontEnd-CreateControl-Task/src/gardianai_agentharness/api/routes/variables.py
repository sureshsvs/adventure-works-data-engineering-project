"""Variable catalog and run-value-set endpoints."""

from __future__ import annotations

from fastapi import APIRouter, Header, HTTPException, Response

from ...services import prompt_variables as pv
from ...services.variable_store import (
    BuiltinImmutableError,
    DefinitionExistsError,
    ETagMismatchError,
    RunValueSetExistsError,
    RunValueSetMissingError,
    UnknownDefinitionError,
    get_variable_store,
)
from ..schemas import (
    RunValueSetRequest,
    VariableDefinitionRequest,
    VariableDefinitionUpdateRequest,
)

router = APIRouter(tags=["variables"])


# ----------------------------------------------------- run-value definitions
@router.get("/runs/variables")
def list_run_value_definitions() -> dict[str, list[dict]]:
    return {"run_values": get_variable_store().list_run_value_definitions()}


@router.post("/runs/variables", status_code=201)
def create_run_value_definition(req: VariableDefinitionRequest) -> dict:
    try:
        return get_variable_store().create_run_value_definition(
            req.name, req.meaning, req.example
        )
    except DefinitionExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except pv.PlaceholderError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/runs/variables/{name}")
def get_run_value_definition(name: str) -> dict:
    definition = get_variable_store().get_run_value_definition(name)
    if definition is None:
        raise HTTPException(status_code=404, detail="Run-value definition not found")
    return definition


@router.put("/runs/variables/{name}")
def update_run_value_definition(
    name: str, req: VariableDefinitionUpdateRequest
) -> dict:
    try:
        return get_variable_store().update_run_value_definition(
            name, req.meaning, req.example
        )
    except BuiltinImmutableError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except UnknownDefinitionError as exc:
        raise HTTPException(status_code=404, detail="Run-value definition not found") from exc


# --------------------------------------------------- task-scalar definitions
@router.get("/variables/task-scalars")
def list_task_scalar_definitions() -> dict[str, list[dict]]:
    return {"task_scalars": get_variable_store().list_task_scalar_definitions()}


@router.post("/variables/task-scalars", status_code=201)
def create_task_scalar_definition(req: VariableDefinitionRequest) -> dict:
    try:
        return get_variable_store().create_task_scalar_definition(
            req.name, req.meaning, req.example
        )
    except DefinitionExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except pv.PlaceholderError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@router.get("/variables/task-scalars/{name}")
def get_task_scalar_definition(name: str) -> dict:
    definition = get_variable_store().get_task_scalar_definition(name)
    if definition is None:
        raise HTTPException(status_code=404, detail="Task-scalar definition not found")
    return definition


@router.put("/variables/task-scalars/{name}")
def update_task_scalar_definition(
    name: str, req: VariableDefinitionUpdateRequest
) -> dict:
    try:
        return get_variable_store().update_task_scalar_definition(
            name, req.meaning, req.example
        )
    except BuiltinImmutableError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except UnknownDefinitionError as exc:
        raise HTTPException(status_code=404, detail="Task-scalar definition not found") from exc


# ------------------------------------------------------- run-value singleton
@router.post("/run-value-set", status_code=201)
def create_run_value_set(req: RunValueSetRequest, response: Response) -> dict:
    try:
        values, etag = get_variable_store().create_run_value_set(req.values)
    except RunValueSetExistsError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except pv.PlaceholderError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if etag:
        response.headers["ETag"] = etag
    return {"values": values}


@router.get("/run-value-set")
def get_run_value_set(response: Response) -> dict:
    result = get_variable_store().get_run_value_set()
    if result is None:
        raise HTTPException(status_code=404, detail="Run-value set not found")
    values, etag = result
    if etag:
        response.headers["ETag"] = etag
    return {"values": values}


@router.put("/run-value-set")
def replace_run_value_set(
    req: RunValueSetRequest,
    response: Response,
    if_match: str | None = Header(default=None, alias="If-Match"),
) -> dict:
    if not if_match:
        raise HTTPException(status_code=428, detail="If-Match header is required")
    try:
        values, etag = get_variable_store().replace_run_value_set(req.values, if_match)
    except RunValueSetMissingError as exc:
        raise HTTPException(status_code=404, detail="Run-value set not found") from exc
    except ETagMismatchError as exc:
        raise HTTPException(status_code=412, detail=str(exc)) from exc
    except pv.PlaceholderError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    if etag:
        response.headers["ETag"] = etag
    return {"values": values}
