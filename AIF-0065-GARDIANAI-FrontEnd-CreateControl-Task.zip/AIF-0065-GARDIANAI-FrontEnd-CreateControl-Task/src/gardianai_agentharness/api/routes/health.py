"""Health & readiness endpoints."""

from __future__ import annotations

from fastapi import APIRouter

from ...config import settings
from ...services.document_store import get_document_store
from ...services.llm_client import (
    get_harness_llm_client,
    get_super_agent_llm_client,
)
from ...services.ocr_service import get_ocr_client

router = APIRouter(tags=["health"])


@router.get("/health")
def health() -> dict:
    store = get_document_store()
    harness = get_harness_llm_client()
    super_agent = get_super_agent_llm_client()
    llm_enabled = harness.available or super_agent.available
    return {
        "status": "ok",
        "app": settings.app_name,
        "llm_enabled": llm_enabled,
        "harness_llm": {
            "available": harness.available,
            "backend": harness.label,
            "model": harness.model,
        },
        "super_agent_llm": {
            "available": super_agent.available,
            "backend": super_agent.label,
            "model": super_agent.model,
        },
        "ocr_enabled": get_ocr_client().available,
        "mode": "llm" if llm_enabled else "offline",
        "test_cases": len(store.test_cases),
        "documents": len(store.documents),
    }
