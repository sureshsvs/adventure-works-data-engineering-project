"""Prompt library endpoints (success criterion C12 — superuser maintainable)."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from ...services.prompt_library import get_prompt_library
from ..schemas import PromptUpdateRequest

router = APIRouter(prefix="/prompts", tags=["prompts"])


@router.get("/")
def list_prompts() -> dict:
    return {"prompts": get_prompt_library().list()}


@router.get("/{entry_id}")
def get_prompt(entry_id: str) -> dict:
    entry = get_prompt_library().get(entry_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Prompt not found")
    return entry


@router.put("/{entry_id}")
def update_prompt(entry_id: str, req: PromptUpdateRequest) -> dict:
    entry = get_prompt_library().update(entry_id, req.prompt, req.updated_by)
    if not entry:
        raise HTTPException(status_code=404, detail="Prompt not found")
    return entry
