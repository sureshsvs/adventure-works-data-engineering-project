# GARdian.AI Agent Harness — Technical Design Document

> Status: Living document · Last updated: 2026-08-09
> Audience: engineers, reviewers, and GAR (Group Audit & Reporting) stakeholders.

## 1. Purpose & scope

GARdian.AI is an automated **disclosure-integrity control** platform for Shell
GAR. It ingests a pack of financial-reporting documents (Quarterly Results
Announcement PDFs, Investor-Relations slide decks, quarterly databooks), and,
for each PoC test case, runs an auditor prompt over the input documents to
produce an **auditable Word (`.docx`) integrity-check report** that mirrors the
benchmark "expected output" reports.

This document describes the system architecture, the SuperAgent document-generation
pipeline, the data model, ingestion/extraction, persistence, the API and frontend,
security considerations, and how the design maps to the PoC success criteria.

### Goals
- Ingest `pdf / docx / xlsx / pptx` reliably and index them for the SuperAgent's
  on-demand retrieval and reasoning (C3).
- Generate, from a **prompt + input documents**, a structured, auditable `.docx`
  report matching the benchmark structure and analytical depth (C5).
- Ground every figure/finding in the source documents with a full evidence trail (C6).
- Run **fully offline** (stdlib only, deterministic) for demos, and **light up an
  LLM** (Azure AI Foundry / APIM) plus **Mistral Document AI OCR** when configured.
- Let users **upload** their own input files + prompt (+ optional expected output)
  as a runnable custom test case.
- Keep prompts in a **versioned, superuser-editable library** (C12).

### Non-goals
- Write-back to SharePoint / MC-compliant production data handling (future MVP1).
- Automated pass/fail scoring of a run against the benchmark.
- Full role-based access control (an nginx/auth seam exists for it; not implemented here).

## 2. High-level architecture

Three tiers, mirroring the reference `dto-mobility-shortfall-searchui` topology:

```mermaid
flowchart LR
  subgraph Client
    SPA["React SPA (Vite :5173)\nSuperAgent · Prompts"]
  end
  subgraph Proxy
    NGINX["nginx reverse proxy\nserves SPA · proxies /api"]
  end
  subgraph Backend
    API["FastAPI (:8000)\n/api/*"]
    subgraph Services
      DS["document_store\n(index + extract + uploads)"]
      SAS["super_agent_service\n(orchestrate + persist)"]
      GEN["super_agent_generation\n(strategy selection)"]
      RES["super_agent_research\n(plan/investigate/verify/synthesize)"]
      RET["super_agent_retrieval\n(list/search/read tools + corpus)"]
      RPT["report_service\n(stdlib .docx)"]
      PL["prompt_library\n(versioned)"]
      LLM["llm_client\n(Foundry / APIM)"]
      OCR["ocr_service\n(Mistral Document AI)"]
    end
  end
  SPA -->|/api/*| NGINX -->|proxy /api| API
  API --> DS & SAS & RPT & PL
  SAS --> GEN --> RES --> RET --> DS
  GEN --> RET
  RES --> LLM
  GEN --> LLM
  GEN --> RPT
  DS --> OCR
```

- **SPA** ([frontend/src](frontend/src)) — routing/UI; talks only to `/api/*`.
- **Reverse proxy** ([frontend/nginx.conf.template](frontend/nginx.conf.template)) —
  nginx serves the built SPA and proxies `/api/*` to FastAPI. The seam for auth,
  rate limiting and TLS termination. In local dev the Vite server proxies `/api`
  directly to FastAPI.
- **Backend** ([src/gardianai_agentharness](src/gardianai_agentharness)) — FastAPI
  app with the domain services below.

### Offline vs LLM mode
Every capability degrades gracefully. With no credentials the backend uses stdlib
extractors and deterministic fallbacks. Setting APIM / Azure AI Foundry keys turns
on LLM reasoning; setting `GARDIAN_OCR_*` turns on high-fidelity PDF OCR. `mode` is
surfaced by `GET /api/health` and stamped onto every run (`llm` | `offline`).

LLM auth is key **or** identity: with `AZURE_LLM_USE_MANAGED_IDENTITY=true` (keys
blank) both backends authenticate via `DefaultAzureCredential`
(scope `https://cognitiveservices.azure.com/.default`) instead of an API key. The
raw `LLMClient` injects a fresh bearer token per call via `get_bearer_token_provider`
(so the cached client never serves an expired token); the Agent Framework harness
passes the credential straight to `OpenAIChatClient(credential=...)`.

### Storage (local by default, Azure optional)
State is local unless a storage account is configured (`AZURE_STORAGE_CONNECTION_STRING`
or `AZURE_STORAGE_ACCOUNT_URL` + managed identity). When set: the sample-data pack is
**streamed from Blob on demand** into a local cache and indexed as usual (`get_text` is
the single materialisation point); run reports (`.docx`) go to **Blob** and the full
run document goes to **Cosmos DB** (queried for the run list). The OCR cache +
streamed pack are designed to sit on an **Azure Files** mount at `.gardianai/` for
durability across restarts; the harness temp workdir stays on local disk. All
`azure.*` imports are lazy, so the app still runs with no SDK / no account.

The **prompt library** and **OCR cache** are **blob-only** (no local-disk
fallback): both live as prefixes (`PROMPT_LIBRARY_PREFIX`/`OCR_CACHE_PREFIX`,
default `prompt_library`/`ocr_cache`) inside the same `sample_data_container` as
the sample-data pack. `blob_storage.require_blob_storage(feature)` raises
`BlobStorageNotConfigured` when no storage account is configured, mapped to an
HTTP 503 by a `main.py` exception handler — a deliberate fail-fast instead of a
silent local-disk degrade, since both need to be shared/durable across container
replicas.

With a **user-assigned managed identity**, `DefaultAzureCredential()` needs an
explicit `managed_identity_client_id` to reliably resolve which identity to use;
`settings.azure_client_id` (`AZURE_CLIENT_ID`) is threaded into every
`DefaultAzureCredential(...)` call site (blob, Cosmos, both LLM backends) for
this reason.

## 3. Backend module map

| Module | Responsibility |
| --- | --- |
| [main.py](src/gardianai_agentharness/main.py) | FastAPI app, CORS, router registration. |
| [config.py](src/gardianai_agentharness/config.py) | Pydantic settings (with stdlib fallback), paths, `llm_enabled`/`ocr_enabled`, `blob_storage_enabled`/`azure_runs_enabled`. |
| [api/routes/](src/gardianai_agentharness/api/routes) | `health`, `testcases`, `super_agent`, `prompts`. |
| [api/schemas.py](src/gardianai_agentharness/api/schemas.py) | Pydantic request models. |
| [services/document_store.py](src/gardianai_agentharness/services/document_store.py) | Index sample data (local or blob) + uploads; extract text; register uploaded test cases. |
| [services/blob_storage.py](src/gardianai_agentharness/services/blob_storage.py) | Azure Blob access: list/stream the sample-data pack; upload/download run artifacts (lazy SDK import); `BlobStorageNotConfigured` + `require_blob_storage()` guard for the blob-only prompt library/OCR cache. |
| [services/run_store.py](src/gardianai_agentharness/services/run_store.py) | Run persistence backends: `LocalRunStore` (disk) and `AzureRunStore` (report to Blob, full run document to Cosmos DB). |
| [services/extractors.py](src/gardianai_agentharness/services/extractors.py) | Stdlib `pdf/docx/xlsx/pptx/txt/csv` text extraction, incl. per-cell xlsx number-format scale resolution. |
| [services/ocr_service.py](src/gardianai_agentharness/services/ocr_service.py) | Mistral Document AI OCR client (optional), blob-cached (no local fallback). |
| [services/super_agent_service.py](src/gardianai_agentharness/services/super_agent_service.py) | Orchestrate generate/regenerate/co-author, persist runs via `run_store`, resolve reports. |
| [services/super_agent_generation.py](src/gardianai_agentharness/services/super_agent_generation.py) | Selects the generation strategy (harness → deep-research → tool retrieval → full-context → offline). |
| [services/super_agent_harness.py](src/gardianai_agentharness/services/super_agent_harness.py) | Agent Framework harness strategy: temp file store + read-only file-access tools + compaction (optional, needs `agent-framework`). |
| [services/super_agent_research.py](src/gardianai_agentharness/services/super_agent_research.py) | Multi-phase deep-research agent (plan/investigate/verify/synthesize). |
| [services/super_agent_retrieval.py](src/gardianai_agentharness/services/super_agent_retrieval.py) | On-demand retrieval tools (list/search/read + shared corpus) and the tool-calling loop; resolves each hit's character offset to a citable page/slide/sheet `location`. |
| [services/super_agent_context.py](src/gardianai_agentharness/services/super_agent_context.py) | Shared grounding helpers (build context, fetch web, parse JSON). |
| [services/super_agent_coauthor.py](src/gardianai_agentharness/services/super_agent_coauthor.py) | Post-generation report editing: direct text edits (`apply_direct_edit`) and targeted, chat-driven section edits (`coauthor_edit`). |
| [services/report_service.py](src/gardianai_agentharness/services/report_service.py) | Render a `GeneratedDocument` to `.docx` (stdlib `zipfile` + WordprocessingML). |
| [services/models.py](src/gardianai_agentharness/services/models.py) | Domain dataclasses. |
| [services/prompt_library.py](src/gardianai_agentharness/services/prompt_library.py) | Versioned prompt store seeded from the sample prompts (blob-only persistence). |
| [services/llm_client.py](src/gardianai_agentharness/services/llm_client.py) | Two OpenAI-compatible clients (SuperAgent → Foundry, fallback APIM). |

## 4. SuperAgent document-generation pipeline

The SuperAgent turns a **test case** into an auditable `.docx`. A test case = a
prompt + a set of input documents + (optionally) a benchmark expected output.

```mermaid
sequenceDiagram
  participant UI as SPA
  participant API as FastAPI
  participant SAS as super_agent_service
  participant GEN as super_agent_generation
  participant RES as super_agent_research
  participant TB as retrieval tools
  participant LLM as llm_client (Foundry)
  participant RPT as report_service

  UI->>API: POST /api/super-agent/generate {test_case_id}
  API->>SAS: generate(test_case_id)
  SAS->>GEN: generate_document(tc, store, prompt, llm)
  alt deep-research (default) & LLM available
    GEN->>RES: generate_research_document(...)
    loop Plan -> Investigate -> Verify
      RES->>LLM: chat(tools, reasoning_effort)
      LLM-->>RES: tool calls (search/read_document)
      RES->>TB: dispatch(tool, args)
      TB-->>RES: windows (document + offset)
    end
    RES->>LLM: SYNTHESIZE (json_object)
    LLM-->>RES: JSON {title, subtitle, sections[]}
    RES-->>GEN: GeneratedDocument
  else single-pass / full-context / offline
    GEN-->>GEN: tool loop, full-text prompt, or deterministic draft
  end
  GEN-->>SAS: GeneratedDocument, mode
  SAS->>RPT: build_generated_report(run)
  SAS->>SAS: persist run JSON (.gardianai/runs)
  SAS-->>API: GenerationRun.to_dict()
  API-->>UI: run (with sections preview + report link)
```

### 4.1 Generation strategies (tiered, degrade on failure)
`_generate_llm` picks the best available strategy and falls back on any failure:
**harness → deep-research → single-pass tool retrieval → full-context**, then offline.

- **Agent Framework harness** ([super_agent_harness.py](src/gardianai_agentharness/services/super_agent_harness.py), top tier when `super_agent_use_harness` and `agent-framework` are installed):
  writes the pack into a `tempfile` working directory and runs `create_harness_agent`
  with **read-only file-access tools** scoped to that directory (a
  `FileSystemAgentFileStore`; no host shell), context-window compaction, and a
  todo + plan/execute workflow. The model reads files on demand and returns the
  report JSON. Web is disabled except the mounted `web_shell_newsroom.md`; other
  uploaded packs are mounted under `corpus/` when `super_agent_shared_corpus` is set.
- **Deep-research agent** ([super_agent_research.py](src/gardianai_agentharness/services/super_agent_research.py), `super_agent_deep_research`):
  a four-phase audit on the SuperAgent model — **PLAN** the checks, **INVESTIGATE**
  by retrieving evidence with tools + doing the maths, **VERIFY/REFLECT** (re-check
  calculations, hunt for gaps/contradictions), **SYNTHESIZE** the JSON report.
  Runs with `reasoning_effort` (medium for plan, `SUPER_AGENT_REASONING_EFFORT` thereafter; `low` under economy).
- **Single-pass tool retrieval** (`super_agent_tool_retrieval`): one tool-calling
  loop, then write.
- **Full-context** (legacy): concatenate all extracted input text into one prompt
  via `_build_context` (per-doc/total budgets `160_000` / `400_000`). Test case 3
  additionally fetches the grounded Shell newsroom page.
- **Token economy** (`super_agent_economy`): one switch that forces the single-pass
  tool-retrieval path (skips harness + deep-research), sets `reasoning_effort=low`
  and caps the benchmark template to 15k chars. Otherwise reasoning is
  `SUPER_AGENT_REASONING_EFFORT` and template size is `SUPER_AGENT_EXPECTED_TEMPLATE_CHARS`.

All strategies include the **benchmark expected output** (`_expected_template`, up
to `settings.sa_expected_template_chars`, default `60_000`) as a structural template
and inject the auditor **domain skills** (`super_agent_skills.md`) alongside the
generation skills.

### 4.1.1 Token economy (cost controls)
LLM cost is driven by the multi-step harness / deep-research loops (each step is a
full model call at high reasoning) and by the benchmark template + shared corpus
injected into context. Three settings tune this; `super_agent_economy` is the
one-switch profile, the other two apply independently.

| Setting | Default | Effect |
| --- | --- | --- |
| `SUPER_AGENT_ECONOMY` (`super_agent_economy`) | `false` | When `true`, `_generate_llm` skips the harness and deep-research tiers and goes straight to **single-pass tool retrieval**; the `sa_reasoning_effort` property returns `low`; and `sa_expected_template_chars` caps the benchmark template at `15_000`. |
| `SUPER_AGENT_REASONING_EFFORT` (`super_agent_reasoning_effort`) | `high` | `high \| medium \| low` — reasoning effort passed to the tool-retrieval loop and the deep-research investigate/verify/synthesize phases (used when economy is `false`). Surfaced via the `sa_reasoning_effort` property. |
| `SUPER_AGENT_EXPECTED_TEMPLATE_CHARS` (`super_agent_expected_template_chars`) | `60_000` | Chars of the benchmark expected-output injected by `_expected_template`. Surfaced via `sa_expected_template_chars`. |

Related levers that also reduce tokens: `SUPER_AGENT_SHARED_CORPUS=false` (don't pull
other packs into context), `SUPER_AGENT_RESEARCH_MAX_STEPS` (fewer deep-research
calls), `SUPER_AGENT_HARNESS_MAX_CONTEXT_TOKENS` / `SUPER_AGENT_HARNESS_MAX_OUTPUT_TOKENS`
(harness budgets), a cheaper `SUPER_AGENT_MODEL`, and the **offline** path (no
Foundry credentials) which uses zero tokens. Per-run token usage is tracked in
[super_agent_context.py](src/gardianai_agentharness/services/super_agent_context.py)
and surfaced while a job is polled.

### 4.1.2 On-demand retrieval tools ([super_agent_retrieval.py](src/gardianai_agentharness/services/super_agent_retrieval.py))
Rather than pushing full document text into the prompt (which does not scale), the
agent pulls only what it needs via function tools over the `DocumentStore`:
- `list_documents()` — manifest of the test case's documents.
- `search_document(query, document?, corpus?)` — keyword windows with a document
  name + a `location` (the nearest preceding `## Page N`/`## Slide N`/`## Sheet: X`
  marker already embedded by the extractors — e.g. "Page 6") plus the raw character
  `offset` (internal navigation only, not for citing). `corpus="all-uploads"` widens
  the search to **other uploaded packs** (a lazily-loaded shared corpus;
  `super_agent_shared_corpus`).
- `read_document(document, start, length)` — expand context around a hit (≤8k chars);
  its result also carries a `location`.

`run_tool_loop` drives the tool-calling turns (assistant → tool results → …) until
the model answers; results are capped (12k) and reads bounded so context stays
small regardless of pack size. Every figure must come from a tool result, cited by
document + **location** (C6) — the generation skills explicitly instruct the model
never to cite the raw offset, which is a meaningless internal implementation detail.

### 4.1.3 SuperAgent service reference

Detail on each `super_agent_*` module, in call order from the API down.

**[super_agent_service.py](src/gardianai_agentharness/services/super_agent_service.py) — `SuperAgentService`**
Top-level orchestrator held as a process-wide singleton (`get_super_agent_service`).
- `generate(test_case_id)`: looks up the test case, resolves its **current prompt
  version** from the prompt library (falling back to the test case's own prompt
  text), calls `generate_document` for the `GeneratedDocument` + `mode`, builds the
  `GenerationRun` (title, `prompt_version`, `model`, `input_documents`, token usage
  snapshot, `completed_at`), renders it to `.docx` via `report_service`, and hands
  the run + rendered bytes to the injected `RunStore` (`self._runs`, built by
  `build_run_store` — local disk or Azure Blob/Cosmos depending on config).
- `regenerate(run_id)`: loads the existing run and calls `generate` again on the
  same `test_case_id` — **runs are immutable**, so this always produces a new
  `run_id` rather than mutating the original.
- `start_generation` / `start_regeneration`: fire-and-forget variants that spawn a
  daemon thread running `generate`/`regenerate`, tracked in an in-memory
  `_jobs` dict (`job_id → {stage, detail, done, error, run, tokens}`) guarded by a
  lock; `job_status(job_id)` is polled by the SPA. Before running, the worker wires
  a per-thread progress callback (`set_progress_cb`) and token callback
  (`set_token_cb`/`reset_tokens`) so strategy code can report stages/usage without
  any callback threaded through its signature (see `super_agent_context.py`).
- `list_runs` / `get_run` / `open_report`: thin pass-throughs to the `RunStore`.

**[super_agent_generation.py](src/gardianai_agentharness/services/super_agent_generation.py) — strategy selection & fallbacks**
`generate_document(tc, store, prompt, llm)` is the single entry point used by the
service: if an LLM is configured it calls `_generate_llm` and catches any exception
to degrade to `_generate_offline`; otherwise it goes straight to offline. `_generate_llm`
implements the **tiered fallback** described in §4.1 (harness → deep-research →
tool retrieval → full-context), each wrapped in its own `try/except` so a failure
in one tier (e.g. `agent-framework` not installed, or a bad LLM response) silently
degrades to the next rather than failing the run. This module also owns the shared
building blocks the other strategy modules import: `_SKILLS` / `_DOMAIN_SKILLS`
(the generation + auditor skill text, loaded once from the adjacent `.md` files),
`_expected_template(tc)` (wraps the benchmark output, capped by
`settings.sa_expected_template_chars`), `_to_document(...)` (validates/normalises
the model's JSON into a `GeneratedDocument`, clamping heading levels to 1–3 and
dropping empty paragraphs), and the legacy `_generate_full_context` /
`_generate_offline` paths.

**[super_agent_harness.py](src/gardianai_agentharness/services/super_agent_harness.py) — Agent Framework harness (top tier)**
`generate_harness_document(tc, store, prompt, llm)`: creates a `tempfile.mkdtemp`
working directory, `_materialise`s the pack into it (`documents/*.md` from
`store.get_text`, `prompt.md`, `expected_output.md`, `web_shell_newsroom.md` for
test case 3, and a `corpus/<pack>/…` tree of other uploaded packs when
`super_agent_shared_corpus` is set), then runs `create_harness_agent` from
`agent_framework` with a `FileSystemAgentFileStore` scoped to that directory,
**read-only** file-access tools (`file_access_disable_write_tools=True`), context
compaction (`super_agent_harness_max_context_tokens`/`_max_output_tokens`), and web
search disabled. The working directory (and, per the earlier fix, the agent's own
`agent-file-memory/` scratch files nested inside it) is deleted in a `finally`
block regardless of outcome. Raises on any failure — including `agent-framework`
not being installed — so `_generate_llm` falls back to deep-research.

**[super_agent_research.py](src/gardianai_agentharness/services/super_agent_research.py) — deep-research agent**
`generate_research_document(tc, store, prompt, llm)` runs a **four-phase** audit
over one shared `messages` list, appending each phase's instruction and driving a
`run_tool_loop` (from `super_agent_retrieval`) before moving on:
1. **PLAN** (`max_steps=4`, `reasoning_effort="medium"`, fixed) — list the specific
   checks to investigate; may call `list_documents` to orient itself.
2. **INVESTIGATE** (`max_steps=settings.super_agent_research_max_steps`,
   `reasoning_effort=settings.super_agent_reasoning_effort`) — retrieve figures via
   `search_document`/`read_document` and perform the calculations.
3. **VERIFY** (`max_steps=6`, same reasoning effort) — re-check the maths, hunt for
   gaps/contradictions, flag anything unverifiable rather than guessing.
4. **SYNTHESIZE** — a final non-tool `llm.chat(response_format={"type":"json_object"})`
   call that emits the report JSON, parsed via `parse_json` and normalised via
   `_to_document`. Raises `ValueError` if the result has no sections (empty output
   is treated as a failure so the caller falls back further).

**[super_agent_retrieval.py](src/gardianai_agentharness/services/super_agent_retrieval.py) — `DocumentToolbox` + `run_tool_loop`**
Shared by both the deep-research and single-pass tool-retrieval tiers.
`DocumentToolbox(tc, store)` pre-extracts each input document's text (via
`store.get_text`), the grounded web page for test case 3, and lazily indexes a
**shared corpus** of every *other* custom (uploaded) test case's inputs when
`super_agent_shared_corpus` is enabled — corpus text is only extracted on first
access (`_corpus_text_for`), not eagerly. It exposes three OpenAI-style function
tools: `list_documents` (manifest with type/char-count), `search_document`
(keyword-window search returning `{document, offset, score, snippet}`, scoped to
`test-case` / `all-uploads` / `all` via the `corpus` argument, cross-pack hits named
`"Pack :: filename"`), and `read_document` (expand a window by offset, capped at
`_MAX_READ = 8_000` chars). `run_tool_loop` drives the assistant↔tool turns for up
to `max_steps`, appending each tool result (truncated to `_MAX_TOOL_RESULT = 12_000`
chars) back into `messages`, and returns once the model responds without a further
tool call (or the step budget is exhausted, returning the last text seen).

**[super_agent_context.py](src/gardianai_agentharness/services/super_agent_context.py) — shared grounding & telemetry helpers**
Small, dependency-light utilities used across every strategy module:
- `build_context` / `_PER_DOC_CHARS` / `_TOTAL_CHARS` — the full-context (legacy)
  prompt builder with per-document and total character budgets.
- `fetch_web(url)` — a single stdlib `urllib.request` GET for the grounded Shell
  newsroom fetch (test case 3 only; not user-controlled, mitigating SSRF).
- `parse_json(text)` — best-effort extraction of a JSON object from a model
  response (tolerates surrounding prose/code fences).
- **Progress reporting**: `report(stage, detail)` / `set_progress_cb` use a
  `contextvars.ContextVar` so strategy code can emit live stage updates
  (`prepare · analyze · review · compose · render`) without threading a callback
  through every function signature; the service wires this per background-job
  thread. `report()` is a no-op when no callback is registered (the synchronous
  `/generate` path).
- **Token/usage tracking**: `reset_tokens()` / `record_usage(usage)` /
  `record_ocr(pages, requests)` / `token_totals()` maintain a per-thread tracker
  (`by_stage`, running `total`, and separate OCR page/request counters) attributed
  to whatever stage `report()` last set; `set_token_cb` lets the service push live
  snapshots to the job store while a background generation is polled.

### 4.2 Output contract
The model returns:
```json
{
  "title": "string",
  "subtitle": "string",
  "sections": [
    { "heading": "1. Executive conclusion", "level": 1,
      "paragraphs": ["..."],
      "tables": [{ "title": "...", "headers": ["..."], "rows": [["..."]] }] }
  ]
}
```
`_to_document` normalises/validates this into the typed model (levels clamped to
1–3, all cells stringified, empty paragraphs dropped). An empty `sections` list
raises, triggering the offline fallback.

### 4.3 Offline fallback
When no SuperAgent LLM is configured, `_generate_offline` produces an **honest**
draft: it explicitly states the numeric checks were *not* executed and records the
prompt, the ingested inputs (as a table), and the success-criteria guardrails.
This keeps the flow demonstrable without fabricating findings (C7 — fail loudly).

### 4.4 Regeneration
`regenerate(run_id)` re-runs generation for the same test case, producing a **new**
run id (runs are immutable records, not mutated in place).

### 4.5 Report co-authoring ([super_agent_coauthor.py](src/gardianai_agentharness/services/super_agent_coauthor.py))
Once a report exists, an auditor can revise it two ways — both **overwrite the
run's document/report in place** (no version history; a deliberate simplicity
trade-off, unlike `regenerate`'s new-run-id semantics):
- **Direct edit** (`apply_direct_edit`, `PUT /api/super-agent/runs/{id}/document`):
  text-only — the client submits the full document JSON with edited
  paragraph/table text but the same headings/structure (the SPA never lets a
  user add/remove/reorder sections or tables), so it is simply re-parsed via the
  same `_to_document` normaliser used by generation.
- **Chat co-authoring** (`coauthor_edit`, `POST /api/super-agent/runs/{id}/coauthor`):
  **targeted**, not a full regeneration. The model is given the current report
  JSON plus the auditor's message and the *same* `DocumentToolbox`/`run_tool_loop`
  used during generation (so a changed figure is still grounded against the
  source documents), and must return only the section(s) it actually changed,
  each keyed by its **exact existing heading**. Sections whose heading isn't
  returned are carried over unchanged — matching is a straight dict lookup by
  heading, so an unrelated section can never be silently rewritten. The model
  also returns a short `reply` describing the change, shown in the SPA's chat
  transcript.

Both paths share `SuperAgentService._persist_edit(run)`: re-render the `.docx`
via `report_service`, update `report_filename`/`completed_at`, and re-save
through the same `RunStore` used by `generate` (local disk or Blob + Cosmos DB).

### 4.6 Prompt variable resolution (run values & Task scalars)

A `Task` prompt is a template with case-sensitive double-brace placeholders,
resolved into a run-scoped prompt by
[prompt_variables.py](src/gardianai_agentharness/services/prompt_variables.py)
and [task_run.py](src/gardianai_agentharness/services/task_run.py) just before a
run is queued. Three independent substitution channels exist:

- `{{Period}}` — the selected reporting period (e.g. `2025-Q4`).
- `{{NAME}}` (grammar `[A-Z][A-Z0-9_]*`) — a **run value** *or* a **Task scalar**.
- `{{DOC:ALIAS@VARIANT}}` — a document reference (`VARIANT` ∈ `CQ`/`PQ`/`SQLY`)
  resolved to a display name via the source catalog.

**Where each value comes from:**
- **Run values** are the shared singleton run-value set in Cosmos DB, fetched
  lazily by `SuperAgentService._run_values()` (returns the `values` half of the
  stored `(values, etag)` pair, or `{}`).
- **Task scalars** are saved per task on `Task.task_scalars` (persisted in the
  `tasks` container) and travel inside the `Task` object itself.

**Merge & precedence** — `prepare_task_run` collapses both into one flat map;
the grammar does not distinguish run value from scalar. Task scalars are spread
last, so a Task scalar **overrides** a run value of the same name:

```python
# task_run.py
scalar_values = {**run_values, **task.task_scalars}   # task scalar wins on collision
missing = sorted(n for n in parsed.run_or_scalar_names if n not in scalar_values)
if missing:
    raise TaskRunValidationError("unresolved variables: " + ", ".join(missing))
```

Every `{{NAME}}` the parser discovered must exist in the merged map, or the run
fails with HTTP `422` **before** rendering. `render_prompt` then substitutes each
token from its own channel — `{{Period}}` from `period`, `{{NAME}}` from
`scalar_values`, `{{DOC:…}}` from `document_display_names` — leaving any
unrecognised brace text untouched.

```mermaid
flowchart LR
  RVS["run-value-set<br/>(Cosmos singleton)"] -->|_run_values| PTR[prepare_task_run]
  TS["task.task_scalars<br/>(persisted on Task)"] --> PTR
  PTR -->|"{**run_values, **task_scalars}"| SV[scalar_values]
  SV --> RP["render_prompt · {{NAME}}"]
  PER[period] --> RP2["render_prompt · {{Period}}"]
  DOC[document_display_names] --> RP3["render_prompt · {{DOC:…}}"]
  RP --> OUT[rendered prompt_text]
  RP2 --> OUT
  RP3 --> OUT
```

## 5. Upload → custom test case

Uploaded files are treated exactly like a built-in test case.

```mermaid
sequenceDiagram
  participant UI as SPA (UploadPanel)
  participant API as FastAPI /super-agent/upload
  participant DS as document_store
  UI->>API: multipart: title, prompt_file|prompt_text, expected_file?, input_files[]
  API->>DS: register_uploaded_test_case(...)
  DS->>DS: sanitize names, write to .gardianai/uploads/<id>/
  DS->>DS: extract text, register DocumentRefs, persist index.json
  DS-->>API: TestCase (archetype="custom")
  API-->>UI: test case (now selectable + runnable)
```

Design points ([document_store.py](src/gardianai_agentharness/services/document_store.py)):
- Each upload gets id `up<8-hex>` and a folder `.gardianai/uploads/<id>/` with an
  `Input data/` subfolder; the prompt/expected files sit at the folder root.
- Filenames pass through `_safe_name` (strips path components, whitelists chars,
  caps length) to prevent **path traversal** and odd-filename issues.
- The prompt can be a file (`.docx/.txt/.md`) **or** pasted text (written to
  `prompt.txt`). Expected output is optional.
- A metadata `index.json` is written so uploads survive a backend restart; on init
  the store re-registers them from disk.

## 6. Document ingestion & extraction

### 6.1 Indexing
`DocumentStore._build_index` walks `sampledata/poc-testcases/`, matching folders
`Test case N - <title>`. Each file is classified by name:
- contains `prompt` → **prompt**
- contains `expected output` → **expected_output**
- otherwise → **input**

Office lock/temp files (`~$…`) and dotfiles are skipped via `_is_temp_file`.

> **Why this matters:** a Word lock file `~$…expected output.docx` was previously
> indexed as a second `expected_output` and, sorting after the real file,
> overwrote the extracted benchmark text with empty — starving the generator of
> its template. Excluding `~$…`/dotfiles fixed both content and format fidelity.

The success-criteria workbook at the pack root is registered as `criteria`.

### 6.2 Text extraction ([extractors.py](src/gardianai_agentharness/services/extractors.py))
Stdlib-only (`zipfile` + `ElementTree`), since every Office format is really a zip
of XML parts — no `openpyxl`/`python-docx`/`python-pptx` dependency:

- **docx** — unzip, read `word/document.xml`, walk every `<w:p>` (paragraph) and
  join its `<w:t>` (text run) children; one line of output per non-empty
  paragraph.
- **xlsx** — three parts read together:
  1. `xl/sharedStrings.xml` — Excel deduplicates string literals into one table;
     a cell that holds text just references an index into it (`shared[i]`).
  2. `xl/styles.xml` — `<numFmts>` (custom number formats, e.g. `#,##0,,`) plus
     `<cellXfs>` (the style list; a cell's `s` attribute indexes into it) are
     combined into a per-style **scale divisor**: each trailing comma in a
     format's positive-value section means "displayed value = stored value ÷
     1,000". Applied via `_scale_numeric` to the full-precision float (never
     rounded) before rendering, so a discrepancy can still be proven to be
     rounding vs. a real error.
  3. `xl/worksheets/sheetN.xml` — the actual `<row>`/`<c>` cell grid, one file
     per sheet, mapped to sheet **names** from `xl/workbook.xml` by file order.
     Each cell is either `t="s"` (look up `shared[int(v.text)]`) or numeric
     (`_scale_numeric(v.text, c.get("s"), scales)`); rows become tab-joined
     lines, sheets become `"## Sheet: <name>\n<rows>"` blocks.

  This traced a real defect: the Shell databook's Q4/FY columns use a
  `#,##0,,`-style format, so reading the *raw stored value* without step 2
  rendered those columns **~1,000,000x too large** relative to every other
  period in the same row — indistinguishable from a genuine databook error
  until traced back to the number format.
- **pptx** — unzip, read each `ppt/slides/slideN.xml` in order, collect every
  `<a:t>` (text run) on the slide; one `"## Slide N\n<text>"` block per slide.
- **pdf** — `pypdf.PdfReader.extract_text()` per page when the package is
  available, producing `"## Page N\n<text>"` blocks; falls back to a regex
  scrape of literal `(...)` string operators in uncompressed content streams
  when `pypdf` is unavailable (misses Flate-compressed streams — most modern
  PDFs — so it's a last resort that keeps the document searchable by name only).
  See §6.3 for the OCR path, which supersedes this for financial figures.
- **txt/md/csv** — read directly as UTF-8 text, no parsing.

Every format emits the same **`## Page N` / `## Slide N` / `## Sheet: X`**
marker convention at document/page/slide/sheet boundaries — this is what makes
location resolution (§6.4) work uniformly regardless of source format.

### 6.3 OCR ([ocr_service.py](src/gardianai_agentharness/services/ocr_service.py))
When `GARDIAN_OCR_*` is set, PDFs/images are sent to Azure-hosted **Mistral
Document AI** (`mistral-document-ai-2512`), returning page-by-page Markdown that
recovers the real financial figures the stdlib PDF fallback cannot (financial
figures live in compressed content streams the paren-scrape fallback can't
reach). PDFs over the 30-page limit are split into page-windows via `pypdf` and
OCR'd sequentially; each window's returned page indices are offset so page
numbers stay correct across the whole document. Results are **blob-cached**
(§2, blob-only — no local-disk fallback), keyed by a hash of
`path + mtime + size + model` (so a re-run only re-OCRs a document that actually
changed) at `ocr_cache/<hash>.md` inside `sample_data_container`.
`DocumentStore._extract` prefers OCR when `ocr.available and ocr.can_handle(path)`,
then falls back to the stdlib extractor above.

### 6.4 Querying extracted text
Extraction produces plain text (with the `## Page/Slide/Sheet` markers above);
querying it is a separate, format-agnostic layer:

1. **`DocumentStore.get_text(doc_id)`** ([document_store.py](src/gardianai_agentharness/services/document_store.py))
   is the *single materialisation point* — it calls `extract_text()` (dispatching
   by suffix to one of §6.2's extractors, or OCR first per §6.3) once per
   document and caches the result in `self._text_cache`. Every other component
   reads text through this method; none re-implements extraction.
2. **`DocumentToolbox`** ([super_agent_retrieval.py](src/gardianai_agentharness/services/super_agent_retrieval.py))
   pre-fetches each input document's text via `get_text` when a test case starts,
   then exposes it to the LLM through two function tools:
   - `search_document(query, document?, corpus?)` — case-insensitive substring
     search for each query term over the flattened text, taking a `±350`-char
     window (`_WINDOW = 700`) around each hit.
   - `read_document(document, start, length)` — a raw slice `text[start:start+length]`
     (≤ 8,000 chars) to expand context around a hit.
3. **`_locate(text, offset)`** resolves every hit to a citable location: it scans
   backward from the hit's character offset for the nearest preceding
   `## Page N` / `## Slide N` / `## Sheet: X` marker and returns that heading
   (e.g. `"Sheet: CP"`). Both tools attach this as a `location` field — the
   generation skills instruct the model to cite `location`, never the raw
   `offset`, which is a meaningless internal implementation detail.

Worked example: `search_document("chemicals sales volumes")` finds a hit at
character 34,791 of the CP sheet's flattened text; `_locate` walks backward to
the last `## Sheet: CP` marker before that offset; the tool returns
`{"document": "...databook.xlsx", "location": "Sheet: CP", "offset": 34791,
"snippet": "..."}`, which the model cites in the report as `Sheet: CP` rather
than an opaque character position.

## 7. Data model ([models.py](src/gardianai_agentharness/services/models.py))

Plain dataclasses (stdlib) so the pipeline runs without FastAPI/Pydantic.

```mermaid
classDiagram
  class GenerationRun {
    run_id, test_case_id, test_case_title
    prompt_version, model, mode, status
    created_at, completed_at
    input_documents[]
    document: GeneratedDocument
    report_filename
    use_expected_template, economy, reasoning_effort
    +section_count
    +table_count
  }
  class GeneratedDocument { title, subtitle, sections[] }
  class DocSection { heading, level, paragraphs[], tables[] }
  class DocTable { title, headers[], rows[][] }
  GenerationRun --> GeneratedDocument
  GeneratedDocument --> DocSection
  DocSection --> DocTable
```

- `to_dict()` on each type yields JSON-serialisable output with computed
  `section_count` / `table_count`.
- `generation_run_from_dict()` reconstructs a run from persisted JSON (used to
  serve run detail and resolve the report path).
- `use_expected_template` / `economy` / `reasoning_effort` record the **resolved**
  (post-default) per-run generation options — not the raw nullable request
  params — via the `super_agent_context` getters, so every run (including ones
  that used the server defaults) is displayable without a `None` case; surfaced
  next to the token-usage summary in the SPA.
- Legacy control types (`ControlResult`, `Finding`, `Evidence`, `AuditRun`) remain
  in the module for the legacy control-report renderer (`report_service.build_report`)
  but are no longer part of the SuperAgent flow.

## 8. DOCX rendering ([report_service.py](src/gardianai_agentharness/services/report_service.py))

`build_generated_report(run, out_dir)` renders a `GeneratedDocument` to a valid
`.docx` using the stdlib `_Docx` WordprocessingML builder (title, `h1/h2/h3`,
paragraphs, bordered/striped tables) and `zipfile`. No `python-docx` dependency.
The subtitle is split on newlines; each section renders its heading at the mapped
level, then paragraphs, then tables. Output file:
`.gardianai/runs/<test_case_id>_<run_id>_generated_report.docx`.

## 9. Persistence & run storage

- Runs: `.gardianai/runs/run_<id>.json` (full run) plus the rendered `.docx`, or
  Blob (`.docx`) + Cosmos DB (run document) when a storage account + Cosmos are
  configured (`azure_runs_enabled`). Co-authoring edits (`update_document`/
  `coauthor`) overwrite the same run record/report through this same store —
  no separate version history is kept.
- `list_runs()` reads all run JSONs (or queries Cosmos) and **sorts by
  `created_at` descending** (ISO-8601 UTC, so lexical sort == chronological) —
  newest first.
- Uploads: `.gardianai/uploads/<id>/…` with `uploads/index.json`.
- Prompt library + OCR cache: **blob-only**, no local-disk path — stored as
  `prompt_library/prompt_library.json` and `ocr_cache/<hash>.md` blobs inside
  `sample_data_container` (§2). Raises `BlobStorageNotConfigured` (→ HTTP 503)
  when no storage account is set, rather than falling back to disk.
- The `.gardianai/` tree (runs, uploads, harness scratch) is runtime state and
  git-ignored.

## 10. Prompt library & guardrails

[prompt_library.py](src/gardianai_agentharness/services/prompt_library.py) seeds one
entry per test case from its `prompt.docx`, versioned and superuser-editable via
`GET/PUT /api/prompts/{id}` (C12). Each run records `prompt_version` (e.g.
`tc1@v3`) for auditability. The **PoC success criteria** (C4/C5/C6/C7 + scope
discipline) are embedded as hard guardrails in the generation skills file so they
constrain every generated report.

## 11. LLM client ([llm_client.py](src/gardianai_agentharness/services/llm_client.py))

Two independently-configured OpenAI-compatible clients:
- **SuperAgent** → Azure AI Foundry (`AZURE_AI_FOUNDRY_*`, e.g. gpt-5.4), falling
  back to APIM.
- **APIM client** → APIM-proxied Azure OpenAI (`APIM_*`, e.g. gpt-5.2); the
  SuperAgent's fallback backend, also reported by `/api/health`.
- **APIM project gateway** (`apim-gateway`) → when `APIM_ENDPOINT`,
  `APIM_SUBSCRIPTION_KEY` (legacy `APIM_SUB_KEY`), `APIM_FOUNDRY_NAME` and
  `APIM_PROJECT_NAME` are all set, BOTH clients (and the Agent Framework harness)
  use `AIProjectClient.get_openai_client(default_headers=...)` with the
  `Ocp-Apim-Subscription-Key` / `foundryMode=new` / `foundryName` / `projectName`
  headers and `DefaultAzureCredential` (pinned to `AZURE_CLIENT_ID`).

Each degrades to `available == False` without credentials or the `openai` SDK.
`httpx[socks]` is used transitively so it works with or without a SOCKS proxy.
`chat()` accepts an optional `reasoning_effort` (used by the deep-research phases);
reasoning models reject a custom temperature, so it is dropped when effort is set.

Every `DefaultAzureCredential()` construction (both LLM backends, Blob, Cosmos)
passes `managed_identity_client_id=settings.azure_client_id or None`. Without it,
a **user-assigned** managed identity (the norm in Azure Container Apps) cannot
always be resolved reliably, and the failure surfaces as the generic
`DefaultAzureCredential failed to retrieve a token from the included
credentials` — indistinguishable from "no identity attached at all". Locally
(no `AZURE_CLIENT_ID` set), the parameter is `None` and `DefaultAzureCredential`
falls through to `AzureCliCredential` as before.

## 12. API surface

| Method & path | Purpose |
| --- | --- |
| `GET /api/health` | Status, LLM/OCR availability, mode, index size. |
| `GET /api/testcases/` | List test cases (+ uploaded) and their input documents. |
| `GET /api/testcases/{id}` | Test case detail incl. prompt & expected-output text. |
| `POST /api/super-agent/generate` | Generate the `.docx` report for a test case (synchronous). |
| `POST /api/super-agent/generate/start` | Start generation as a background job; returns `{job_id}`. |
| `POST /api/super-agent/regenerate` | Regenerate (new run) for an existing run (synchronous). |
| `POST /api/super-agent/regenerate/start` | Start regeneration as a background job; returns `{job_id}`. |
| `GET /api/super-agent/jobs/{job_id}` | Live job status: `{stage, detail, done, error, run}` (polled for the progress stepper). |
| `POST /api/super-agent/upload` | Upload inputs + prompt (+ expected) as a test case. |
| `GET /api/super-agent/runs` | Run history (newest first). |
| `GET /api/super-agent/runs/{id}` | Run detail (document preview). |
| `GET /api/super-agent/runs/{id}/report` | Download the `.docx` (via the authenticated client on the SPA side — not a raw `<a href>` — so an APIM subscription key/bearer token is actually attached). |
| `PUT /api/super-agent/runs/{id}/document` | Save a direct (text-only) edit to a run's document; re-renders the report in place. |
| `POST /api/super-agent/runs/{id}/coauthor` | Chat-driven, targeted edit — the model changes only the section(s) the message asked for; `{reply, ...run}`. |
| `GET/PUT /api/prompts/{id}` | View / edit the versioned prompt library. |

## 13. Frontend design

React + Vite SPA ([frontend/src](frontend/src)); two routes in
[App.tsx](frontend/src/App.tsx): **SuperAgent** and **Prompt Library** (the app
redirects `/` → `/super-agent`). All HTTP goes through a typed axios
client ([api.ts](frontend/src/services/api.ts)) to `/api`.

**SuperAgent page** ([SuperAgentPage.tsx](frontend/src/pages/SuperAgentPage.tsx)):
- Test-case selector (built-in + uploaded) + **Generate document**.
- **Upload panel**: title, prompt file *or* pasted text, optional expected output,
  multiple input files → `FormData` → creates a runnable test case.
- **Live progress**: Generate/Regenerate start a background job and poll
  `GET /jobs/{id}` (~800 ms), driving an animated stepper (Preparing → Analyzing →
  Reviewing → Composing → Rendering) with a progress bar, elapsed timer and the
  current stage detail.
- **Result view**: rendered document preview (title, subtitle, sections →
  headings/paragraphs/tables), the resolved per-run options (benchmark template /
  economy / reasoning effort) next to the token-usage summary, **Regenerate**, and
  **Download report (.docx)** (fetched via the authenticated axios client as a
  blob, then saved via an object-URL link — not a raw `<a href>`, so
  APIM/bearer headers are attached).
- **Report co-authoring**: an **Edit** toggle turns each paragraph/table cell into
  a `<textarea>`/`<input>` bound to a local draft, saved via `PUT .../document`;
  a persistent **chat panel** below the report sends a targeted edit instruction
  via `POST .../coauthor` and appends the model's `reply` to a transcript — both
  refresh the displayed run in place (`onRunUpdated`).
- **Run history**: newest-first, each row opens the run and offers the same
  authenticated **Download .docx** control.

**Sign-in status** ([App.tsx](frontend/src/App.tsx)): on mount, fetches
`/.auth/me` (Azure Easy Auth) and, when a session exists, shows the signed-in
user's name and a **Log out** link (`/.auth/logout?post_logout_redirect_uri=...`,
a plain navigation — required for Easy Auth to clear its cookie, not a fetch)
in the top bar. Renders nothing when there's no Easy Auth session (e.g. local dev).

### 13.1 Live progress mechanism
`start_generation` / `start_regeneration` run the pipeline in a daemon thread and
record stage updates in a thread-safe job store polled via `GET /jobs/{id}`. Strategy
code emits stages through a per-thread `report(stage, detail)` reporter (a
`contextvars.ContextVar` set inside the worker thread — see
[super_agent_context.py](src/gardianai_agentharness/services/super_agent_context.py)),
so no callback is threaded through the strategy signatures and the synchronous
`/generate` path is unaffected (progress is a no-op there). Stage vocabulary:
`prepare · analyze · review · compose · render · done` (+ `error`).

## 14. Security considerations (OWASP-aware)

- **Path traversal (uploads):** `_safe_name` strips directory components and
  whitelists characters; files are written only under `.gardianai/uploads/<id>/`.
- **File upload validation:** only `SUPPORTED_SUFFIXES` are registered/extracted;
  at least one input file is required; unsupported files are ignored.
- **XML parsing:** extraction uses `ElementTree` over local, trusted sample files;
  uploaded Office files are parsed the same way. (For untrusted input at scale,
  `defusedxml` would be the hardening step — noted as future work.)
- **SSRF:** the only outbound fetch is the fixed Shell newsroom URL (test case 3),
  configurable via settings — not user-controlled per request.
- **Data scope (shared corpus):** cross-pack search (`corpus="all-uploads"`) spans
  only user-uploaded packs, never the built-in sample data; it is lazily loaded and
  can be disabled with `super_agent_shared_corpus=false`.
- **Secrets:** all credentials come from env/`.env`; none are logged or returned.
- **Transport/auth seam:** the nginx reverse proxy is where TLS termination,
  Azure AD / OBO auth and rate limiting attach (not implemented in the PoC).
- **Prompt-injection awareness:** ingested document text is untrusted content; the
  system prompt constrains scope ("use only the provided inputs") and the output
  is a structured report rather than executable actions. The chat co-authoring
  instruction is user-supplied but still constrained the same way — the model
  only ever returns report JSON (never executes anything), and a changed figure
  must still be grounded via the same retrieval tools, so a crafted chat message
  cannot make the model act outside the report-editing contract.
- **Report download:** the SPA downloads `.docx` reports through the same
  authenticated axios client used for every other API call (blob response +
  object-URL save), not a raw `<a href>` — a plain anchor navigation carries no
  custom headers, so an APIM-fronted deployment would silently drop the
  subscription key/bearer token on that one request.

## 15. Configuration ([config.py](src/gardianai_agentharness/config.py))

Key env vars (`.env`):
- `APIM_ENDPOINT` / `APIM_API_KEY` / `AGENT_MODEL_DEPLOYMENT_NAME` — Agent Harness.
- `APIM_SUBSCRIPTION_KEY` (legacy fallback `APIM_SUB_KEY`) / `APIM_FOUNDRY_NAME` / `APIM_PROJECT_NAME` — APIM project gateway for both LLM clients.
- `AZURE_AI_FOUNDRY_ENDPOINT` / `AZURE_AI_FOUNDRY_API_KEY` / `SUPER_AGENT_MODEL` — SuperAgent.
- `AZURE_LLM_USE_MANAGED_IDENTITY` — authenticate BOTH LLM backends with Entra ID / managed identity instead of API keys (leave the keys blank).
- `AZURE_CLIENT_ID` — the user-assigned managed identity's client id, passed to every `DefaultAzureCredential(managed_identity_client_id=...)` call (blob, Cosmos, both LLM backends). Required in Azure Container Apps; blank locally (falls through to `AzureCliCredential`).
- `GARDIAN_OCR_ENDPOINT` / `GARDIAN_OCR_KEY` / `GARDIAN_OCR_DEPLOYMENT_NAME` — OCR.
- `SUPER_AGENT_DEEP_RESEARCH` / `SUPER_AGENT_TOOL_RETRIEVAL` / `SUPER_AGENT_RESEARCH_MAX_STEPS` / `SUPER_AGENT_SHARED_CORPUS` — SuperAgent generation strategy.
- `SUPER_AGENT_USE_HARNESS` / `SUPER_AGENT_HARNESS_MAX_CONTEXT_TOKENS` / `SUPER_AGENT_HARNESS_MAX_OUTPUT_TOKENS` — Agent Framework harness tier (compaction budgets).
- `SUPER_AGENT_ECONOMY` / `SUPER_AGENT_REASONING_EFFORT` / `SUPER_AGENT_EXPECTED_TEMPLATE_CHARS` — **token economy** (cheapest path, reasoning effort, benchmark template size).
- `AZURE_STORAGE_CONNECTION_STRING` / `AZURE_STORAGE_ACCOUNT_URL` — enables Blob (+ Cosmos, if also set) storage; `PROMPT_LIBRARY_PREFIX` / `OCR_CACHE_PREFIX` (default `prompt_library`/`ocr_cache`) — blob-name prefixes for the blob-only prompt library/OCR cache inside `SAMPLE_DATA_CONTAINER`.
- `SHELL_NEWSROOM_URL`, `SAMPLE_DATA_DIR`, `RUN_STORE_DIR`, `CORS_ORIGINS`.

`llm_enabled` / `ocr_enabled` / `blob_storage_enabled` are derived and surfaced by
`/api/health` (the first two) or gate the prompt library/OCR cache (the third).

## 16. Testing strategy ([tests/test_pipeline.py](tests/test_pipeline.py))

Offline, stdlib-only end-to-end checks:
- Sample data is indexed (tc1–tc4 present) and search returns hits.
- `generate` for every test case yields a document with a title + sections and a
  **well-formed `.docx`** (verified by unzipping and parsing `word/document.xml`).
- `regenerate` creates a new run id.
- Upload registers a runnable custom test case that generates a valid report.
- The retrieval toolbox is smoke-tested (tool specs, own-scope vs `all-uploads`
  search, and cross-pack read).
- `tests/conftest.py`: an autouse fixture fakes Azure Blob Storage in-memory
  (and marks `blob_storage_enabled=True`) so the blob-only prompt library/OCR
  cache don't need a real storage account to test; `test_prompt_library.py` /
  `test_ocr_cache.py` cover seed/persist/reload and cache-hit/miss behaviour,
  plus the `BlobStorageNotConfigured` failure path.
- `test_extractors.py`: the xlsx number-format scale fix (a hand-built minimal
  workbook with a `#,##0,,`-style format).
- `test_super_agent_retrieval.py`: offset→page/slide/sheet `location` resolution.

> The sandbox cannot install PyPI packages, so tests are also runnable by calling
> the functions directly with the project venv (a minimal `pytest.mark` shim).

## 17. Success-criteria mapping

| Criterion | How it's addressed |
| --- | --- |
| **C3** Ingestion & outputs | Stdlib extractors for pdf/docx/xlsx/pptx + OCR; runs stored with id/status/timestamps. |
| **C5** Output quality | Prompt-driven `.docx` with exec summary, sections, tables, calculations, recommendations, guided by the benchmark. |
| **C6** Auditability | Guardrails require an evidence trail per finding; `prompt_version` + `model` + timestamps recorded on every run. |
| **C7** Robustness | Deterministic offline fallback that fails loudly rather than guessing; `temperature=0`. |
| **C12** Prompt library | Versioned, superuser-editable prompts; runs record the version used. |

C4 (numeric accuracy) is bounded by model quality; the design maximises it with
on-demand retrieval (targeted windows cited by offset), a dedicated verify/reflect
phase, the full benchmark structure as a template, and a strict no-figure-copying
rule.

## 18. Known limitations & future work

- **Model quality (C4):** older Foundry models under-detect exceptions; upgrading
  the deployment is the main lever. Verified live: a databook number-format bug
  (below) had been producing spurious "databook mismatch" exceptions and
  distracting the model from real ones — fixing extraction alone (no prompt
  changes) recovered all three benchmark exceptions on a real test case.
- **Deep-research cost/latency:** the multi-phase agent is materially slower and
  more token-heavy than a single call; it is gated by `super_agent_deep_research`
  (fall back to the single-pass retrieval loop or full-context via the flags).
- **Harness tier:** validated against the installed `agent-framework` (read-only
  file-access provider over a `FileSystemAgentFileStore`; no arbitrary host shell).
  It falls back automatically where the framework is absent or the LLM is offline.
  Benign runtime warnings: `FileSystemAgentFileStore` is experimental, and the
  in-memory history provider notes server-side history. The harness's built-in
  `AgentModeProvider` plan/execute workflow expects a human to approve the
  plan→execute switch by default (`disable_mode=True` turns this off, since the
  harness runs unattended via the API with no one to answer the prompt).
- **No automated benchmark scoring** yet (run vs expected-output diff/UI).
- **Co-authoring has no version history:** both direct edits and chat edits
  overwrite the run's document/report in place (a deliberate simplicity choice);
  there is no way to see or revert to a prior edit short of `regenerate` (which
  discards edits and starts over from the original prompt).
- **XML hardening:** move to `defusedxml` for untrusted uploads at scale.
- **AuthN/Z:** implement Azure AD / OBO and role-based access at the nginx proxy (C10/C11).
- **Write-back:** SharePoint output persistence for the target operating model.
