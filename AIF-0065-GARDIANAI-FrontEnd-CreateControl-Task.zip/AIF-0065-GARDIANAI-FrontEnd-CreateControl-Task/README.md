# GARdian.AI — Agent Harness

An automated **disclosure-integrity control** platform for Shell GAR (Group Audit
& Reporting). It replicates the three-tier architecture of the reference
`dto-mobility-shortfall-searchui` app (React SPA → nginx reverse proxy → FastAPI
backend with a SuperAgent) for the financial-disclosure domain, driven by the
bundled poc-testcases and success criteria.

The app centres on the **SuperAgent**, supported by a **Prompt Library** editor.

| Capability | What it does |
| --- | --- |
| **SuperAgent** | A **deep-research agent** (plan → investigate → verify → synthesise) that runs a test case's prompt over its input documents, retrieving only what it needs via tools, and **generates an auditable, downloadable `.docx` report** matching the benchmark expected output. Users can **upload** their own inputs + prompt (+ optional expected output) as a new test case, **regenerate** any run, and optionally search across other uploaded packs. |
| **Report co-authoring** | Once a report is generated, an auditor can **edit it directly** (paragraph/table text, in place) or **co-author it via chat** — a targeted request (e.g. "fix the capex figure in section 3") is applied to only the affected section(s), grounded against the source documents; both save by re-rendering the `.docx` over the same run (no separate version history). |
| **Prompt Library** | Versioned, superuser-editable auditor prompts; every run records the prompt version used. |
| **Sign-in status** | When the app runs behind Azure Easy Auth, the signed-in user's name and a **Log out** control appear in the top bar; hidden when there's no Easy Auth session (e.g. local dev). |

> Architecture, data model, pipelines and security are documented in
> **[Design.md](Design.md)** (Technical Design Document).

## poc-testcases (control archetypes)

Sourced from `sampledata/poc-testcases/`:

1. **High-level integrity check** — within a single QRA document.
2. **Detailed segment check** — Chemicals & Products: add-ups, %-changes, prior-period comparatives, databook tie-out.
3. **Portfolio developments check** — QRA section vs the grounded Shell newsroom.
4. **QRA vs IR slides check** — cross-document integrity (QRA = source of truth) + databook.

The generated report mirrors the benchmark `expected output.docx`: a titled
integrity-check report with an executive conclusion, an exceptions &
auditor-follow-up table, numbered analysis sections interleaving narrative with
comparison tables (each carrying an integrity/auditor-assessment column), shown
calculations, evidence trails and a final audit conclusion. The benchmark expected
output is fed to the model as the structural template; **every figure is recomputed
from the input documents** rather than copied.

## Success criteria coverage (`DRAFT_GARdian.AI PoC success criteria.xlsx`)

- **C3** – ingests pdf/docx/xlsx/pptx; runs are stored with run IDs, status and timestamps.
- **C5** – reports include executive summary, sections, calculations, tables and recommendations, rendered as clean `.docx`, guided by the benchmark structure.
- **C6** – guardrails require an evidence trail per finding; runs record prompt version, model and timestamps; no black-box findings.
- **C7** – deterministic offline fallback that **fails loudly** (states what it could not verify) rather than guessing; `temperature=0`.
- **C12** – versioned, superuser-editable prompt library; runs record the prompt version used.

The PoC success criteria (C4/C5/C6/C7 + scope discipline) are embedded as hard
guardrails in the SuperAgent generation skills so they constrain every report.

## Architecture

```
React SPA (Vite, :5173)
   └── /api/*  →  nginx reverse proxy  →  FastAPI backend (:8000)
                     (serves the built SPA + proxies /api in production;
                      in local dev Vite proxies /api straight to FastAPI)
                             ├── Document store       (services/document_store.py)
                             ├── SuperAgent           (services/super_agent_service.py)
                             │     ├─ strategy selection (super_agent_generation.py)
                             │     ├─ harness agent      (super_agent_harness.py)
                             │     ├─ deep-research agent (super_agent_research.py)
                             │     └─ retrieval tools     (super_agent_retrieval.py)
                             ├── Prompt library        (services/prompt_library.py)
                             ├── OCR (Mistral Doc AI)  (services/ocr_service.py)
                             └── DOCX report generator (services/report_service.py)
```

### Storage (local by default, Azure optional)
Runs fully local out of the box: the sample-data pack is read from `sampledata/`
and runs (report `.docx` + metadata) are written under `.gardianai/`. Configure a
storage account in `.env` to externalise state for containerised deployments:

| Data | Local default | Azure |
| --- | --- | --- |
| Sample-data pack | `sampledata/` | **Blob** (streamed on demand into `SAMPLE_DATA_CACHE_DIR`) |
| Run reports (`.docx`) | `.gardianai/runs/` | **Blob** (`RUN_REPORTS_CONTAINER`) |
| Run documents / metadata | `.gardianai/runs/*.json` | **Cosmos DB** (`COSMOS_DATABASE`/`COSMOS_CONTAINER`) |
| OCR + sample-data cache | `.gardianai/` | mount **Azure Files** at `.gardianai/` |

Auth is via `AZURE_STORAGE_CONNECTION_STRING` or `AZURE_STORAGE_ACCOUNT_URL`
(managed identity / `DefaultAzureCredential`). With nothing set, everything stays
on local disk — no Azure SDK calls are made. Mount an Azure Files share at
`.gardianai/` so the OCR cache and streamed pack persist across restarts; keep the
harness temp workdir on the container's local disk.

**Prompt library + OCR cache are blob-only** (no local-disk fallback — a
deliberate change from earlier local-file behaviour): both are stored as
prefixes (`PROMPT_LIBRARY_PREFIX`/`OCR_CACHE_PREFIX`, default `prompt_library`/
`ocr_cache`) inside the same `SAMPLE_DATA_CONTAINER` used for the sample-data
pack. If no storage account is configured, any request that needs them (the
prompt library, or an OCR extraction) fails fast with a clear `503
BlobStorageNotConfigured` error rather than silently degrading.

With a **user-assigned managed identity** (Azure Container Apps), also set
`AZURE_CLIENT_ID` to that identity's client id — `DefaultAzureCredential()`
otherwise cannot reliably resolve which identity to use and can fail with
"failed to retrieve a token from the included credentials" even though an
identity is attached to the app.

### Run labels

Enter a **run title** (required) and **description** (optional) before starting a
single generation or batch. For a batch, every result inherits those
labels and retains its own test-case name and automatically generated unique
**run ID**. Run IDs cannot be entered or changed by users.

Labels appear in run history, the opened run and the downloaded Word report.
They are metadata, separate from the LLM-generated report title and instructions;
they do not change the analysis. Regeneration retains the original labels and
creates a new run ID. Older runs remain readable and use their test-case title
when no run title was saved.

API clients must send `run_title` and may send `description` to
`POST /api/super-agent/generate`, `/generate/start` and `/generate/batch/start`.
Whitespace-only or missing titles return HTTP 422. Regeneration requests continue
to identify the source by `run_id` and inherit its labels.

### Bounded execution and per-run reporting (#33)

Keep batches **sequential by default** (`max_parallel_cases: 1`); optionally select
up to `4` to execute cases in that batch concurrently. Each case still saves
an independent run and Word report. An item failure does not abort other items.

All generation/regeneration endpoints, including the legacy synchronous endpoints,
share one server-side scheduler. It defaults to **four active cases** across users
and jobs, with room for **16 waiting jobs**. Admission is atomic for a batch: its
remaining items stay in its admitted job rather than creating unbounded threads.
The queue limit counts jobs waiting to start (not individual cases inside a batch).
Active batches remain bounded by both their per-batch limit and the global limit.
When full, admission returns **HTTP 429** with a “Server busy” message; retry later.
No partially admitted batch remains after rejection.

| Environment variable | Default | Meaning |
| --- | --- | --- |
| `SUPER_AGENT_MAX_ACTIVE_CASES` | `4` | Global active-case limit, positive integer |
| `SUPER_AGENT_QUEUE_CAPACITY` | `16` | Waiting-job limit; `0` rejects when all slots are occupied |
| `SUPER_AGENT_DEFAULT_MAX_PARALLEL_CASES` | `1` | Default for API clients omitting the batch option, constrained to 1–4 |

Settings are read at process startup. Job status retains existing `stage`/`done`
fields and adds explicit `status`: `queued` → `running` → `done`/`error` for
single jobs. Batch terminal statuses remain `completed`/`completed_with_errors`.
Each batch item has its own `status`, `stage`, `detail`, `tokens`, `run`, and `error`;
job-level tokens aggregate all items. Legacy `current_test_case_id` and
`current_item_index` are populated only in sequential mode. Poll
`GET /api/super-agent/jobs/{job_id}` to show waiting and active work.

Optional reporting fields apply only to the current run:

| Request field | Prompt placeholder | Validation |
| --- | --- | --- |
| `report_version` | `{{report_version}}` | Trimmed string, at most 200 characters |
| `reporting_period` | `{{reporting_period}}` | Trimmed string, at most 200 characters |
| `reporting_year` | `{{reporting_year}}` | Four-digit **string**, e.g. `"2026"` |

For example, a prompt may contain `Review {{reporting_period}} {{reporting_year}},
version {{report_version}}.` Replacement is literal and single-pass (not template
evaluation). Missing or empty values for supported placeholders return HTTP 422
**before admission**. Unrelated placeholders are left untouched. The shared prompt
library text/version is never modified; the selected parameters are saved in run
metadata and returned in run details/summaries.

API migration: existing requests remain valid unless their prompts contain one of
these unresolved placeholders. Add the optional reporting fields to single or batch
requests, and `max_parallel_cases` (integer 1 through 4) to batch requests. Regeneration
inherits each saved reporting field when omitted or `null`; explicitly supplied
fields override only that field. Empty version/period strings explicitly clear a
value (and fail validation if its placeholder is required). Older runs load with
unset reporting values. Edits and coauthoring preserve saved metadata.

**Deployment trade-off:** admission, active counts and sample job status are in-memory
and process-local. Run **one backend process/worker and one replica**
to enforce this capacity across all users. Restarting loses queued sample jobs/status.
Multiple workers/replicas need a distributed queue/lease implementation at the
`CaseScheduler` boundary before scaling; shared report storage alone is not
coordination. No frontend deployment workflow changes are required.

### Task-ID batches and preparation

Task execution is separate from the sample/test-case endpoints above. In the
SuperAgent task-batch panel, select tasks and supply a run title, description,
grouping and period. The browser checks preparation with the backend before
submitting; missing periods, source files, document references or variables block
execution with per-task messages. Start repeats the same checks to prevent stale
preflight results from admitting invalid work.

| Method & path | Contract |
| --- | --- |
| `POST /api/super-agent/tasks/generate/preflight` | `{task_ids, period}` → `{valid, errors: [{task_id, detail}]}`; does not queue work |
| `POST /api/super-agent/tasks/generate/start` | Existing single-task request; unknown task → 404, preparation failure → 422, full queue → 429 |
| `POST /api/super-agent/tasks/generate/batch/start` | `{task_ids, run_title, description?, grouping?, period?, max_parallel_cases?, economy?, reasoning_effort?, use_expected_template?, one_off_prompt?}` → `{batch_id, job_id}` |
| `GET /api/super-agent/tasks/batches` | `{batches: [...]}` durable history |
| `GET /api/super-agent/tasks/batches/{batch_id}` | Durable batch detail including each task's job ID, status, result, run ID and error; unknown batch → 404 |

Task IDs must be nonempty and unique, the title must be nonblank, parallelism is
an integer from 1–4, and reasoning effort is `low`, `medium` or `high`. The task
`period` (for example `2025-Q4`) resolves source documents and prompt variables;
it is distinct from sample `reporting_period`. Generation saves the task period
and task identity for regeneration. Existing runs without these fields still load.
All selected tasks are validated before admission. Batch preparation failures
return 422 with `detail.errors: [{task_id, detail}]`; **none** of the tasks are
queued. Task admission 429 responses include `Retry-After: 2`; rejected batches
leave no accepted-looking record. The frontend retries only explicit 429 admission
rejections, at most three times with backoff and Retry-After, within bounded wait
and request budgets. It does not retry 404, 422 or ambiguous network failures.

Batch states are `queued` → `running` → `completed` / `completed_with_errors`.
Worker failures are isolated to their task. History, metadata and terminal results
survive service restart; browser reload reads backend state and resumes status
polling, never resubmitting generation. Unfinished persisted tasks whose scheduler
has stopped become `interrupted`, retaining already completed task results. Work is
**not** automatically resumed: review partial results before starting a new batch.

No schema migration or new dependencies are required. Local mode writes atomic
JSON records under `RUN_STORE_DIR/task_batches/`; keep that directory on persistent
storage along with existing reports. Azure mode uses the existing Cosmos container
and `/run_id` partition key, with `record_type: task_batch`; batch records are
excluded from ordinary run history. The existing managed identity needs the same
Cosmos read/write/delete permissions. Deploy backend and frontend together.
Durable metadata does **not** make scheduling distributed: the single-process,
single-replica restriction above also applies to task batches and restart recovery.

### Offline vs LLM mode
The backend runs **fully offline** against `sampledata/` using local extractors —
no Azure services required for a demo. Offline, the SuperAgent emits an honest
draft that records the prompt, inputs and guardrails and states the numeric checks
were not executed. Set APIM / Azure AI Foundry credentials in `.env` to light up
the SuperAgent's LLM generation (the Agent Framework harness by default, else
deep-research + on-demand retrieval over the document bodies).

PDF text-layer extraction requires `pypdf` (included in `requirements.txt`).
Missing dependencies, unreadable PDFs and PDFs without a text layer produce an
explicit extraction error; raw binary streams are never sent to the model as
document text. Scanned/image-only PDFs require configured OCR or a text-readable
replacement. Restart the backend after installing extraction dependencies to
clear its in-memory document-text cache.

LLM auth accepts either API keys (`APIM_API_KEY` / `AZURE_AI_FOUNDRY_API_KEY`) or
**Entra ID / managed identity**: set `AZURE_LLM_USE_MANAGED_IDENTITY=true` and leave
the keys blank. Both backends then authenticate via `DefaultAzureCredential`
(scope `https://cognitiveservices.azure.com/.default`); the running identity needs
the **Cognitive Services OpenAI User** role on the AI Foundry resource.

In **LLM mode** the SuperAgent picks the best available strategy and degrades on
failure: **harness → deep-research → single-pass tool retrieval → full-context**.
If all configured LLM strategies fail, the job reports an error rather than saving
an offline draft as a completed run. Offline drafts remain available when no LLM
is configured.

Final reports use a shared structured-output JSON schema: titles, headings,
section count/order and table columns are chosen dynamically by the model, while
field names remain consistent for display and Word export. The report is validated
for nonblank titles/headings, substantive sections and matching table widths. An
invalid response gets one formatting retry on the same evidence, without repeating
the investigation. Tool retrieval always ends with a separate structured report
call; harness drafts are validated and, if necessary, formatted through that same
call. Configured deployments must support OpenAI-compatible JSON-schema output.

The default **Agent Framework harness** (`create_harness_agent`,
needs `agent-framework`) writes the pack into a temp working directory and gives
the model read-only file tools over it plus context compaction and a plan/execute
workflow. The **deep-research** fallback runs on `SUPER_AGENT_MODEL` (Azure AI
Foundry): **plan → investigate** (retrieving only the windows it needs via
`search_document` / `read_document`, with an optional shared corpus across other
uploaded packs) **→ verify → synthesise** the report as JSON rendered to `.docx`.
Both scale past the prompt limit and cite every figure by document/file.
Toggle strategies with `SUPER_AGENT_USE_HARNESS` / `SUPER_AGENT_DEEP_RESEARCH` /
`SUPER_AGENT_TOOL_RETRIEVAL` / `SUPER_AGENT_SHARED_CORPUS`. Every figure is
recomputed from the inputs.

### 💰 Token economy (controlling cost)
LLM cost is dominated by the multi-step harness / deep-research loops (each step is
a full model call at high reasoning) and by the benchmark template + shared corpus
stuffed into context. Three settings control this:

| Setting | Default | Effect |
| --- | --- | --- |
| `SUPER_AGENT_ECONOMY` | `false` | **One switch.** `true` forces the cheapest grounded path (single-pass tool retrieval — skips harness + deep-research), drops reasoning to `low`, and caps the benchmark template at 15k chars. |
| `SUPER_AGENT_REASONING_EFFORT` | `high` | `high \| medium \| low` — reasoning effort for the retrieval/deep-research calls (used when economy is `false`). |
| `SUPER_AGENT_EXPECTED_TEMPLATE_CHARS` | `60000` | Chars of the benchmark "expected output" injected into the prompt. |

Low-cost recipe:
```bash
SUPER_AGENT_ECONOMY=true            # cheapest path + low reasoning + small template
SUPER_AGENT_SHARED_CORPUS=false     # don't pull other packs into context
SUPER_AGENT_MODEL=gpt-4o            # cheaper model
```
Or keep full deep-research but dial only the reasoning down (`SUPER_AGENT_ECONOMY=false`,
`SUPER_AGENT_REASONING_EFFORT=medium`). For zero-cost demos, leave the Foundry
credentials blank to run the deterministic **offline** path. Live token usage is
tracked per run and surfaced while a job is polled.

### Document intelligence (Mistral Document AI OCR)
Set `GARDIAN_OCR_*` in `.env` to extract the source PDFs with the Azure-hosted
**Mistral Document AI** model (`mistral-document-ai-2512`). This recovers the real
financial figures from the compressed PDF bodies (which the stdlib fallback
cannot), giving the SuperAgent accurate numbers to reconcile.
PDFs over the endpoint's 30-page limit are split into page-windows automatically,
and OCR results are **blob-cached** (keyed by path+mtime+size+model) so each
document is processed once.

### Extraction & querying (pdf/docx/xlsx/pptx)
Every format is extracted to plain text with stdlib only (`zipfile` +
`ElementTree` — Office files are zipped XML) and annotated with `## Page N` /
`## Slide N` / `## Sheet: X` markers at document/page/slide/sheet boundaries.
xlsx cells resolve their **number-format display scale** per cell (a `#,##0,,`
style format divides the stored value for display) so a chart column isn't
misread ~1,000,000x too large. The SuperAgent then queries this text via
`search_document`/`read_document` tools, which resolve every hit back to its
nearest marker (e.g. `"Sheet: CP"`) as a citable **location** — never a raw
character offset. See [Design.md §6](Design.md#6-document-ingestion--extraction)
for the full mechanics.

### APIM key naming & deployment secrets
Three similarly named settings exist; they are **not** interchangeable:

| Name | Used by | Purpose |
| --- | --- | --- |
| `APIM_SUBSCRIPTION_KEY` | Backend runtime | Server-side `Ocp-Apim-Subscription-Key` for the APIM project gateway (`AIProjectClient.get_openai_client(default_headers=...)`), together with `APIM_FOUNDRY_NAME` / `APIM_PROJECT_NAME`. |
| `APIM_API_KEY` | Backend runtime | Legacy OpenAI-compatible APIM route only (used when the gateway settings are blank). |
| `APIM_SUB_KEY` | Frontend workflow / container | Key the SPA forwards to the backend (`VITE_APIM_SUBSCRIPTION_KEY`). Also the legacy fallback for the backend key in deployment. |

The APIM gateway integration lives in backend code
([llm_client.py](src/gardianai_agentharness/services/llm_client.py)): when
`APIM_ENDPOINT`, `APIM_SUBSCRIPTION_KEY` (or legacy `APIM_SUB_KEY`),
`APIM_FOUNDRY_NAME` and `APIM_PROJECT_NAME` are all set, both the harness and the
SuperAgent clients (including the Agent Framework harness) are created via
`AIProjectClient(endpoint=APIM_ENDPOINT, credential=DefaultAzureCredential(...))
.get_openai_client(default_headers={"Ocp-Apim-Subscription-Key": ..., "foundryMode":
"new", "foundryName": ..., "projectName": ...})`. `DefaultAzureCredential` is pinned
to `AZURE_CLIENT_ID` when set. Partial configuration logs a warning (names only)
and falls back to the `APIM_API_KEY` / Foundry paths. Requires `azure-ai-projects`
(2.x, provides `get_openai_client`) and `azure-identity`; the async harness path
additionally needs `aiohttp` (without it the harness falls back to the
deep-research / retrieval strategies). The backend image installs
`azure-ai-projects` (2.x) and `azure-identity` so a configured gateway is available.

`Deploy.ContainerApp.yml` (backend) only passes these values to the Container App:
`APIM_FOUNDRY_NAME` / `APIM_PROJECT_NAME` from `.github/variables/<env>.env`, and
`APIM_SUBSCRIPTION_KEY` from the GitHub Environment secret `APIM_SUBSCRIPTION_KEY`,
falling back to the existing `APIM_SUB_KEY` secret — so no secret rename is needed.
The key is stored as a Container Apps secret and injected through a `secretref`.
With either name blank the backend keeps its previous behaviour. Never commit key
values to the repo or `.env` files.

## Run it

```bash
cp .env.example .env                      # optional: add LLM credentials
cp frontend/.env.example frontend/.env
./start.sh                                # starts the backend + Vite SPA
```

Then open http://localhost:5173. API docs are at http://localhost:8000/docs.

### Production (nginx reverse proxy)

Build the SPA into an nginx image that serves the static build and reverse-proxies
`/api` to the FastAPI backend (replacing the old Node BFF):

```bash
docker build -t gardianai-web ./frontend
docker run -p 8080:80 -e API_BACKEND=http://host.docker.internal:8000 gardianai-web
```

Then open http://localhost:8080. `API_BACKEND` points nginx at the FastAPI backend
(defaults to `http://backend:8000` for docker-compose). See
[frontend/nginx.conf.template](frontend/nginx.conf.template).

### Backend golden-image contract

The backend keeps the platform-approved base
`aztcacrngw0065devaif.azurecr.io/mc-aif-golden-repo/aif-golden-env:latest`.
The app image does **not** install Python or packages, create an isolated venv,
or use `requirements.txt` or a replacement dependency manifest. The golden-image
owner must provide Python >=3.10 and compatible FastAPI/Uvicorn, multipart,
Pydantic settings, HTTPX, OpenAI, PyPDF and Azure Identity/Projects/Blob/Cosmos
libraries. Optional harness functionality additionally needs `agent_framework`.

`backend-entrypoint.sh --check` validates the existing interpreter and dependency
imports at build time and before startup, without importing/initializing the app,
installing anything, or printing environment values. This is a prerequisite
check, **not** proof that app startup or deployment succeeds.
It selects `python3`, then `python` from the inherited `PATH`. If the approved
environment is off PATH, the platform team must first verify its absolute
interpreter path and set GitHub variable `GOLDEN_PYTHON`; the workflow passes it
as a build argument, retained for startup. An invalid explicit path fails without
fallback. No guessed paths, symlinks, or package isolation are used.

The earlier `python: not found` / `python3: not found` failures establish only
that those commands were unavailable, not that no interpreter exists elsewhere.
If registry access is blocked, the image's PATH, ENTRYPOINT and off-PATH runtime
remain unverified. On an authorized runner, inspect the approved image configuration
(`docker image inspect --format '{{json .Config.Env}} {{json .Config.Entrypoint}}'
<approved-image>`, locally; do not publish environment contents) and check runtime
locations with its owner. The inherited ENTRYPOINT is not overridden here. If no
usable Python environment exists, the platform must publish a Python-enabled
approved golden image; removing a failing build step alone cannot fix runtime.

After an authorized private-image build, run the built backend with `--network=none`,
without Azure credentials/configuration, and with temporary writable state; probe
`http://127.0.0.1:8080/api/health` **inside** that container using its verified
interpreter. This offline smoke test must be performed on the actual approved
image, not a public substitute. Registry/build failures block this verification.

### Azure Files deployment settings

The backend workflow uses `.github/scripts/azure_files_storage.sh`. Mode precedence
is the first non-empty value (trimmed and case-normalized):

1. GitHub environment/repository variable `AZURE_FILES_AUTH_MODE`, passed separately
   as `AZURE_FILES_AUTH_MODE_VAR` so an unset/blank variable cannot erase the file.
2. `AZURE_FILES_AUTH_MODE` loaded from `.github/variables/<environment>.env`.
3. Default `validate`.

Only `validate` and `account-key` are accepted. `validate` only reads the named
environment storage and checks the expected account, share and `ReadWrite` mode;
it creates nothing and never changes auth. `dev.env` opts into `account-key`;
set the GitHub variable to `validate` to override that opt-in.

`account-key` requires GitHub secret `AZURE_FILES_ACCOUNT_KEY` (storage account
key, **not SAS**) before any Azure call. It idempotently creates the share and
registers it with `--azure-file-account-key`, then verifies the registration.
The key is masked in Actions; raw CLI output/resource dumps are suppressed.
Missing keys or invalid modes fail without managed-identity fallback. The account,
share and registration come from `STORAGE_ACCOUNT_NAME`, `AZURE_FILES_SHARE_NAME`,
`ACA_STORAGE_NAME`, `ACA_ENV_NAME` and `RESOURCE_GROUP`.
Application Azure login/Blob/Cosmos/LLM identities and existing mount definitions
are unchanged; the commented mount-update block remains disabled.

### Manual start (two terminals)

Use an existing, platform-provided Python environment with the backend libraries
above. Select its interpreter first; do not provision dependencies in the app image.

```bash
# 1. FastAPI backend
PYTHONPATH=src PORT=8000 sh ./backend-entrypoint.sh

# Windows (with the approved interpreter selected)
$env:PYTHONPATH = (Join-Path (Get-Location) "src")
python -m uvicorn gardianai_agentharness.main:app --reload --port 8000

# 2. React SPA
cd frontend && npm install && npm run dev

#2nd terminal on windows:
Set-Location .\frontend
npm install
npm run dev
```

## Running debugger locally
 Global protect VPN on
 Run: az login

 Command Palette → “Python: Select Interpreter” → choose the approved, pre-provisioned Python interpreter.

## API surface

| Method & path | Purpose |
| --- | --- |
| `GET /api/health` | Status, mode (offline/llm), index size. |
| `GET /api/testcases/` | List test cases + input documents. |
| `POST /api/super-agent/generate` | Generate the auditable `.docx` report for a test case (runs its prompt over the input docs). |
| `POST /api/super-agent/regenerate` | Regenerate the document for an existing run. |
| `POST /api/super-agent/upload` | Upload input files + prompt (+ optional expected output) as a new test case. |
| `GET /api/super-agent/runs` | Run history. |
| `GET /api/super-agent/runs/{id}/report` | Download the `.docx` report. |
| `PUT /api/super-agent/runs/{id}/document` | Save a direct edit (paragraph/table text) to a run's document; re-renders the report in place. |
| `POST /api/super-agent/runs/{id}/coauthor` | Chat-driven, targeted edit — the model changes only the section(s) the message asked for. |
| `GET/PUT /api/prompts/{id}` | View / edit the versioned prompt library (C12). |

## Tests

Deployment contract tests use only the standard library and mock Azure/runtime
commands; they do not prove the private image builds or deploys:

```bash
python3 -m unittest tests.test_deploy_config -v
shellcheck backend-entrypoint.sh .github/scripts/azure_files_storage.sh
```

In an existing environment with the app and test dependencies available:

```bash
PYTHONPATH=src pytest tests/     # offline, stdlib-only end-to-end checks
```

The suite ingests the sample data, generates a report for every test case, uploads
a custom test case and generates from it, and asserts each generated `.docx` is
well-formed. `tests/conftest.py` fakes Azure Blob Storage in-memory so the
blob-only prompt library/OCR cache still run offline. Also covered: the xlsx
number-format scale fix (`test_extractors.py`) and offset→page/slide/sheet
location resolution for retrieval citations (`test_super_agent_retrieval.py`).

Tests isolate uploads, run reports and sample-data caches in temporary directories,
reset document/service caches per test, and disable live LLM/OCR clients. Test
uploads must not appear among the running application's test-case options.
