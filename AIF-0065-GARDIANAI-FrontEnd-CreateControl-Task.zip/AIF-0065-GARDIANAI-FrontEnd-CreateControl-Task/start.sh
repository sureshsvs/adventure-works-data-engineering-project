#!/usr/bin/env bash
#
# Start both tiers for local development:
#   1. FastAPI backend  (http://localhost:8000)
#   2. React (Vite) SPA (http://localhost:5173)
#
# Vite proxies /api to the backend in dev; in production nginx is the reverse
# proxy (see frontend/Dockerfile + frontend/nginx.conf.template).
#
# The backend runs fully offline against sampledata/ when no LLM credentials are
# set. Configure .env to enable the Agent Harness + SuperAgent LLM paths.

set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT"

cleanup() { kill 0 2>/dev/null || true; }
trap cleanup EXIT

# --- 1. Python backend ---
if [ ! -d ".venv" ]; then
  echo "[setup] creating .venv"
  python3.12 -m venv .venv
fi
# shellcheck disable=SC1091
source .venv/bin/activate
pip install -q -r requirements.txt || echo "[warn] pip install failed; offline stdlib mode still works"
echo "[start] FastAPI on http://localhost:8000"
PYTHONPATH=src python3.12 -m uvicorn gardianai_agentharness.main:app --reload --port 8000 &

# --- 2. React frontend ---
( cd frontend && npm install && echo "[start] Vite on http://localhost:5173" && npm run dev ) &

wait
