"""Tool results must cite a real page/slide/sheet location, not a raw offset.

Real user complaint: generated reports cited "slides offset 12909" / "QRA
offsets 7000 and 52000" -- meaningless internal character positions into the
concatenated extracted text. `extract_pdf`/`extract_pptx`/`extract_xlsx` already
mark boundaries with a `## Page N` / `## Slide N` / `## Sheet: X` heading;
`_locate` resolves an offset to the nearest preceding one of those.
"""

from __future__ import annotations

from gardianai_agentharness.services.super_agent_retrieval import _locate

_TEXT = (
    "## Page 1\nfirst page text\n\n"
    "## Page 2\nsecond page text more content here\n\n"
    "## Page 3\nthird page text"
)


def test_locate_resolves_offset_to_nearest_preceding_page():
    offset = _TEXT.index("second page text")
    assert _locate(_TEXT, offset) == "Page 2"


def test_locate_offset_on_first_page_before_any_marker_boundary():
    offset = _TEXT.index("first page text")
    assert _locate(_TEXT, offset) == "Page 1"


def test_locate_offset_past_all_markers_resolves_to_last_page():
    offset = len(_TEXT) - 1
    assert _locate(_TEXT, offset) == "Page 3"


def test_locate_with_no_markers_returns_empty_string():
    assert _locate("plain text with no markers", 5) == ""
