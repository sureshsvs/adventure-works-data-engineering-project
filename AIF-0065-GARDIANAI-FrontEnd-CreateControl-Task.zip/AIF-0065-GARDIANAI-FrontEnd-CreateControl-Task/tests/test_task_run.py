from __future__ import annotations

from contextlib import nullcontext
from pathlib import Path

from gardianai_agentharness.services.document_store import Task
from gardianai_agentharness.services.case_scheduler import CaseScheduler
from gardianai_agentharness.services import super_agent_service as service_module
from gardianai_agentharness.services.super_agent_service import (
    SuperAgentService,
    UnknownTaskError,
    UnrunnableTaskError,
)


def _service_with_task(task):
    service = object.__new__(SuperAgentService)
    service._scheduler = CaseScheduler(4, 16)
    service._task_store = type(
        "TaskStoreStub",
        (),
        {
            "get_task": lambda self, task_id: task,
            "task_document_lock": lambda self, task_id: nullcontext(),
        },
    )()
    service._variable_store = type(
        "VarStoreStub", (), {"get_run_value_set": lambda self: None}
    )()
    service._scheduler = type("SchedulerStub", (), {"run": lambda self, fn: fn()})()
    return service


def test_start_task_generation_resolves_only_task_store_and_forwards_settings(monkeypatch):
    task = Task(
        id="task-id",
        title="Task",
        logical_source_role_names=[],
        prompt_name="prompt",
        prompt_text="hydrated prompt",
    )
    service = _service_with_task(task)
    queued = {}

    def start_job(callback):
        queued["callback"] = callback
        return "job-id"

    monkeypatch.setattr(service, "_start", start_job)

    job_id = service.start_task_generation(
        "task-id", economy=True, reasoning_effort="low", one_off_prompt="ignored"
    )

    assert job_id == "job-id"
    generated = {}
    monkeypatch.setattr(
        service,
        "generate",
        lambda task_id, **kwargs: generated.update(task_id=task_id, **kwargs),
    )
    queued["callback"]()
    assert generated == {
        "task_id": "task-id",
        "economy": True,
        "reasoning_effort": "low",
        "one_off_prompt": "ignored",
        "task_only": True,
        "period": None,
    }


def test_task_generation_uses_hydrated_prompt_without_prompt_library(monkeypatch, tmp_path):
    task = Task(
        id="task-id",
        title="Task",
        logical_source_role_names=[],
        prompt_name="prompt",
        prompt_text="hydrated task prompt",
    )
    service = _service_with_task(task)
    service._store = type("EmptyDocumentStore", (), {"get_test_case": lambda self, task_id: None})()
    service._library = type(
        "PromptLibrary",
        (),
        {
            "get": lambda self, task_id: (_ for _ in ()).throw(
                AssertionError("Task generation must not use the Prompt Library")
            ),
            "version_tag": lambda self, task_id: "task-prompt",
        },
    )()
    service._llm = type("LLM", (), {"available": False, "model": "offline"})()
    service._run_dir = tmp_path
    service._runs = type("RunStore", (), {"save": lambda self, run, data: None})()

    class ReportPath:
        name = "report.docx"

        @staticmethod
        def read_bytes():
            return b"docx"

    monkeypatch.setattr(service_module, "generate_document", lambda tc, store, prompt, llm: (
        _empty_generated_document(), "offline"
    ) if prompt == "hydrated task prompt" else (_ for _ in ()).throw(
        AssertionError(f"Unexpected task prompt: {prompt}")
    ))
    monkeypatch.setattr(service_module, "build_generated_report", lambda run, directory: ReportPath())

    run = service.generate("task-id", task_only=True)

    assert run["test_case_id"] == "task-id"
    assert run["test_case_title"] == "Task"
    assert run["prompt_version"] == "prompt@v1"


def _empty_generated_document():
    from gardianai_agentharness.services.models import GeneratedDocument

    return GeneratedDocument(title="Report", sections=[])


def test_start_task_generation_rejects_missing_task_before_queueing():
    service = _service_with_task(None)

    try:
        service.start_task_generation("missing")
    except UnknownTaskError:
        pass
    else:
        raise AssertionError("Expected unknown task to fail")


def test_start_task_generation_rejects_empty_hydrated_task_before_queueing():
    task = Task(
        id="task-id",
        title="Task",
        logical_source_role_names=[],
        prompt_name="prompt",
    )
    service = _service_with_task(task)

    try:
        service.start_task_generation("task-id")
    except UnrunnableTaskError:
        pass
    else:
        raise AssertionError("Expected empty task to fail")