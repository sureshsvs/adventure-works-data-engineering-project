from __future__ import annotations

import pytest

from gardianai_agentharness.services import prompt_variables as pv
from gardianai_agentharness.services import source_catalog as sc
from gardianai_agentharness.services.period import (
    InvalidPeriodError,
    Quarter,
    parse_period,
)
from gardianai_agentharness.services.source_catalog import PeriodOffset


# --------------------------------------------------------------------- period
@pytest.mark.parametrize(
    "text,year,quarter",
    [("2025-Q4", 2025, 4), ("2024-Q1", 2024, 1), ("1999-Q2", 1999, 2)],
)
def test_parse_period_valid(text, year, quarter):
    assert parse_period(text) == Quarter(year, quarter)


@pytest.mark.parametrize(
    "bad", ["2025-Q5", "2025Q4", "2025-q4", "2025-Q", "../2025-Q4", "2025-Q4/x", ""]
)
def test_parse_period_invalid(bad):
    with pytest.raises(InvalidPeriodError):
        parse_period(bad)


def test_previous_quarter_wraps_year():
    assert parse_period("2025-Q1").previous_quarter() == Quarter(2024, 4)
    assert parse_period("2025-Q4").previous_quarter() == Quarter(2025, 3)


def test_same_quarter_prior_year():
    assert parse_period("2025-Q4").same_quarter_prior_year() == Quarter(2024, 4)


# ---------------------------------------------------------------- placeholders
def test_parse_prompt_classifies_tokens():
    parsed = pv.parse_prompt(
        "Review {{Period}} for {{SEGMENT}} using {{DOC:QRA@CQ}} and {{CQ}}."
    )
    assert parsed.uses_period is True
    assert parsed.run_or_scalar_names == {"SEGMENT", "CQ"}
    assert parsed.document_references == [pv.DocumentReference("QRA", "CQ")]


def test_parse_prompt_dedupes_document_references_in_order():
    parsed = pv.parse_prompt("{{DOC:QRA@PQ}} {{DOC:QRA@CQ}} {{DOC:QRA@PQ}}")
    assert parsed.document_references == [
        pv.DocumentReference("QRA", "PQ"),
        pv.DocumentReference("QRA", "CQ"),
    ]


def test_parse_prompt_rejects_malformed_token():
    with pytest.raises(pv.PlaceholderError):
        pv.parse_prompt("hello {{bad name}} world")


def test_parse_prompt_rejects_bad_doc_variant():
    with pytest.raises(pv.PlaceholderError):
        pv.parse_prompt("{{DOC:QRA@XX}}")


def test_parse_prompt_preserves_ordinary_braces():
    # Single braces and non-token text must not be treated as placeholders.
    parsed = pv.parse_prompt("a { b } c {{CQ}}")
    assert parsed.run_or_scalar_names == {"CQ"}


def test_validate_registrable_key_rejects_reserved_and_lowercase():
    with pytest.raises(pv.PlaceholderError):
        pv.validate_registrable_key("Period")
    with pytest.raises(pv.PlaceholderError):
        pv.validate_registrable_key("DOC")
    with pytest.raises(pv.PlaceholderError):
        pv.validate_registrable_key("lower")
    pv.validate_registrable_key("RUN_NAME")


def test_render_prompt_substitutes_values():
    rendered = pv.render_prompt(
        "{{Period}} {{CQ}} {{SEGMENT}} {{DOC:QRA@CQ}}",
        period="2025-Q4",
        scalar_values={"CQ": "2024-Q1", "SEGMENT": "Integrated Gas"},
        document_display_names={"{{DOC:QRA@CQ}}": "Shell QRA Q4 2025.pdf"},
    )
    assert rendered == "2025-Q4 2024-Q1 Integrated Gas Shell QRA Q4 2025.pdf"


def test_render_prompt_empty_string_value_is_valid():
    rendered = pv.render_prompt(
        "[{{DELIVERABLE}}]",
        period=None,
        scalar_values={"DELIVERABLE": ""},
        document_display_names={},
    )
    assert rendered == "[]"


# -------------------------------------------------------------- source catalog
def test_role_catalog_has_fixed_names():
    assert sc.ROLE_NAMES == (
        "Current QRA draft",
        "Previous quarter QRA",
        "Same quarter prior year",
        "Quarterly databook",
        "IR materials",
    )


def test_resolve_alias_maps_to_roles():
    assert sc.resolve_alias("QRA", "CQ").name == "Current QRA draft"
    assert sc.resolve_alias("QRA", "PQ").name == "Previous quarter QRA"
    assert sc.resolve_alias("QRA", "SQLY").name == "Same quarter prior year"
    assert sc.resolve_alias("QDB", "CQ").name == "Quarterly databook"
    assert sc.resolve_alias("IR_MATERIALS", "CQ").name == "IR materials"


def test_resolve_alias_unknown():
    with pytest.raises(sc.UnknownDocumentAliasError):
        sc.resolve_alias("QRA", "ZZ")


def test_role_prefix_applies_offset_once():
    selected = parse_period("2025-Q4")
    assert (
        sc.role_prefix(sc.get_role("Current QRA draft"), selected)
        == "Quarterly/2025-Q4/External/QRA/"
    )
    assert (
        sc.role_prefix(sc.get_role("Previous quarter QRA"), selected)
        == "Quarterly/2025-Q3/External/QRA/"
    )
    assert (
        sc.role_prefix(sc.get_role("Same quarter prior year"), selected)
        == "Quarterly/2024-Q4/External/QRA/"
    )


def test_period_offset_q1_boundary():
    selected = parse_period("2025-Q1")
    assert PeriodOffset.PREVIOUS_QUARTER.apply(selected) == Quarter(2024, 4)
    assert PeriodOffset.SAME_QUARTER_PRIOR_YEAR.apply(selected) == Quarter(2024, 1)
