from __future__ import annotations

import pytest

from gardianai_agentharness.services import prompt_variables as pv
from gardianai_agentharness.services import variable_store as vs


class FakeContainer:
    """Minimal Cosmos container stub tracking a monotonic ``_etag``."""

    def __init__(self):
        self.items: dict[str, dict] = {}
        self._seq = 0

    def _next_etag(self) -> str:
        self._seq += 1
        return f"etag-{self._seq}"

    def query_items(self, query, **kwargs):
        return [dict(item) for item in self.items.values()]

    def create_item(self, body):
        item = dict(body)
        item["_etag"] = self._next_etag()
        self.items[item["id"]] = item
        return dict(item)

    def upsert_item(self, body):
        item = dict(body)
        item["_etag"] = self._next_etag()
        self.items[item["id"]] = item
        return dict(item)

    def replace_item(self, item, body):
        new = dict(body)
        new["_etag"] = self._next_etag()
        self.items[item] = new
        return dict(new)


def make_store():
    return vs.VariableStore(
        run_value_def_container=FakeContainer(),
        run_value_set_container=FakeContainer(),
        task_scalar_def_container=FakeContainer(),
    )


# --------------------------------------------------------- definitions
def test_list_run_value_definitions_includes_builtins_sorted():
    store = make_store()
    names = [d["name"] for d in store.list_run_value_definitions()]
    assert "CQ" in names and "RUN_NAME" in names
    assert names == sorted(names, key=str.casefold)


def test_create_custom_run_value_definition():
    store = make_store()
    created = store.create_run_value_definition("REGION", "Region code", "APAC")
    assert created == {"name": "REGION", "meaning": "Region code", "example": "APAC"}
    assert store.is_registered_run_value("REGION")
    assert store.get_run_value_definition("REGION")["meaning"] == "Region code"


def test_create_definition_rejects_builtin_and_duplicate_and_bad_name():
    store = make_store()
    with pytest.raises(vs.DefinitionExistsError):
        store.create_run_value_definition("CQ", "x", "y")
    store.create_run_value_definition("REGION", "Region", "APAC")
    with pytest.raises(vs.DefinitionExistsError):
        store.create_run_value_definition("REGION", "again", "z")
    with pytest.raises(pv.PlaceholderError):
        store.create_run_value_definition("lower", "x", "y")
    with pytest.raises(pv.PlaceholderError):
        store.create_run_value_definition("Period", "x", "y")


def test_update_builtin_run_value_is_immutable():
    store = make_store()
    with pytest.raises(vs.BuiltinImmutableError):
        store.update_run_value_definition("CQ", "x", "y")


def test_update_unknown_custom_definition():
    store = make_store()
    with pytest.raises(vs.UnknownDefinitionError):
        store.update_run_value_definition("REGION", "x", "y")


def test_task_scalar_definitions_crud():
    store = make_store()
    assert store.is_registered_task_scalar("SEGMENT")
    store.create_task_scalar_definition("DIVISION", "Division", "Upstream")
    assert store.is_registered_task_scalar("DIVISION")
    updated = store.update_task_scalar_definition("DIVISION", "Division name", "Up")
    assert updated["meaning"] == "Division name"


# --------------------------------------------------------- run-value set
def test_run_value_set_create_get_replace():
    store = make_store()
    assert store.get_run_value_set() is None

    values, etag = store.create_run_value_set({"CQ": "2025-Q4", "RUN_NAME": ""})
    assert values == {"CQ": "2025-Q4", "RUN_NAME": ""}
    assert etag

    got_values, got_etag = store.get_run_value_set()
    assert got_values == values
    assert got_etag == etag

    new_values, new_etag = store.replace_run_value_set({"CQ": "2025-Q3"}, got_etag)
    assert new_values == {"CQ": "2025-Q3"}
    assert new_etag != got_etag


def test_run_value_set_create_only_conflict():
    store = make_store()
    store.create_run_value_set({"CQ": "2025-Q4"})
    with pytest.raises(vs.RunValueSetExistsError):
        store.create_run_value_set({"CQ": "2025-Q3"})


def test_run_value_set_replace_missing():
    store = make_store()
    with pytest.raises(vs.RunValueSetMissingError):
        store.replace_run_value_set({"CQ": "2025-Q4"}, "etag-1")


def test_run_value_set_replace_etag_mismatch():
    store = make_store()
    _, etag = store.create_run_value_set({"CQ": "2025-Q4"})
    with pytest.raises(vs.ETagMismatchError):
        store.replace_run_value_set({"CQ": "2025-Q3"}, "stale")
    # Correct etag still works.
    store.replace_run_value_set({"CQ": "2025-Q3"}, etag)


def test_run_value_set_rejects_unknown_key_and_non_string():
    store = make_store()
    with pytest.raises(pv.PlaceholderError):
        store.create_run_value_set({"NOPE": "x"})
    with pytest.raises(pv.PlaceholderError):
        store.create_run_value_set({"CQ": 5})
