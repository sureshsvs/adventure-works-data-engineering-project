from __future__ import annotations

from fastapi import FastAPI
from fastapi.testclient import TestClient

from gardianai_agentharness.api.routes import variables as variables_routes
from gardianai_agentharness.services import variable_store as vs
from tests.test_variable_store import FakeContainer


def _client(monkeypatch):
    store = vs.VariableStore(
        run_value_def_container=FakeContainer(),
        run_value_set_container=FakeContainer(),
        task_scalar_def_container=FakeContainer(),
    )
    monkeypatch.setattr(variables_routes, "get_variable_store", lambda: store)
    app = FastAPI()
    app.include_router(variables_routes.router, prefix="/api")
    return TestClient(app), store


def test_list_run_value_definitions(monkeypatch):
    client, _ = _client(monkeypatch)
    body = client.get("/api/runs/variables").json()
    names = [d["name"] for d in body["run_values"]]
    assert "CQ" in names and "RUN_NAME" in names


def test_create_run_value_definition_and_conflict(monkeypatch):
    client, _ = _client(monkeypatch)
    resp = client.post("/api/runs/variables", json={"name": "REGION", "meaning": "r", "example": "APAC"})
    assert resp.status_code == 201
    assert resp.json()["name"] == "REGION"
    assert client.post("/api/runs/variables", json={"name": "REGION"}).status_code == 409
    assert client.post("/api/runs/variables", json={"name": "CQ"}).status_code == 409
    assert client.post("/api/runs/variables", json={"name": "lower"}).status_code == 422


def test_update_builtin_run_value_conflict(monkeypatch):
    client, _ = _client(monkeypatch)
    assert client.put("/api/runs/variables/CQ", json={"meaning": "x"}).status_code == 409
    assert client.put("/api/runs/variables/NOPE", json={"meaning": "x"}).status_code == 404


def test_task_scalar_definition_crud(monkeypatch):
    client, _ = _client(monkeypatch)
    body = client.get("/api/variables/task-scalars").json()
    assert any(d["name"] == "SEGMENT" for d in body["task_scalars"])
    assert client.post(
        "/api/variables/task-scalars", json={"name": "DIVISION", "meaning": "d"}
    ).status_code == 201
    assert client.get("/api/variables/task-scalars/DIVISION").status_code == 200


def test_run_value_set_lifecycle(monkeypatch):
    client, _ = _client(monkeypatch)
    assert client.get("/api/run-value-set").status_code == 404

    created = client.post("/api/run-value-set", json={"values": {"CQ": "2025-Q4"}})
    assert created.status_code == 201
    assert created.json() == {"values": {"CQ": "2025-Q4"}}
    etag = created.headers.get("ETag")
    assert etag

    # create-only conflict
    assert client.post("/api/run-value-set", json={"values": {"CQ": "x"}}).status_code == 409

    got = client.get("/api/run-value-set")
    assert got.json() == {"values": {"CQ": "2025-Q4"}}

    # PUT requires If-Match
    assert client.put("/api/run-value-set", json={"values": {"CQ": "2025-Q3"}}).status_code == 428
    # stale etag -> 412
    assert client.put(
        "/api/run-value-set", json={"values": {"CQ": "2025-Q3"}}, headers={"If-Match": "stale"}
    ).status_code == 412
    # correct etag -> 200
    ok = client.put(
        "/api/run-value-set", json={"values": {"CQ": "2025-Q3"}}, headers={"If-Match": etag}
    )
    assert ok.status_code == 200
    assert ok.json() == {"values": {"CQ": "2025-Q3"}}


def test_run_value_set_rejects_unknown_key(monkeypatch):
    client, _ = _client(monkeypatch)
    assert client.post("/api/run-value-set", json={"values": {"NOPE": "x"}}).status_code == 422
