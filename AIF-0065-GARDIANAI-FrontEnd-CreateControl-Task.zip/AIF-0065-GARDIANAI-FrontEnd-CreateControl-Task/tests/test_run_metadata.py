"""User run labels persist independently of generated report contents."""

from __future__ import annotations

import io
import json
import time
import zipfile
from unittest.mock import Mock
from xml.etree import ElementTree as ET

import pytest
from fastapi.testclient import TestClient

from gardianai_agentharness.api.schemas import SuperAgentRunRequest
from gardianai_agentharness.main import app
from gardianai_agentharness.services.models import generation_run_from_dict
from gardianai_agentharness.services.run_store import AzureRunStore
from gardianai_agentharness.services.super_agent_service import get_super_agent_service


@pytest.fixture
def service_and_case():
    service = get_super_agent_service()
    case = service._store.register_uploaded_test_case(
        title="Metadata input",
        input_files=[("input.csv", b"metric,value\nRevenue,100\n")],
        prompt_text="Check the supplied figures.",
    )
    return service, case


def _await_job(service, job_id):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        result = service.job_status(job_id)
        assert result is not None
        if result["done"]:
            return result
        time.sleep(0.01)
    pytest.fail("Background run did not finish")


def test_metadata_round_trips_through_storage_history_and_word(service_and_case):
    service, case = service_and_case
    run = service.generate(
        case.id, run_title="  Q4 review <tag> & sign-off  ",
        description="  Review notes\nSecond line  ",
    )
    assert run["run_title"] == "Q4 review <tag> & sign-off"
    assert run["description"] == "Review notes\nSecond line"
    assert run["run_id"].startswith("run_")
    loaded = service.get_run(run["run_id"])
    assert loaded is not None
    assert loaded["run_title"] == run["run_title"]
    assert loaded["description"] == run["description"]
    summary = service.list_runs()[0]
    assert summary["run_id"] == run["run_id"]
    assert summary["run_title"] == run["run_title"]
    assert summary["description"] == run["description"]
    report = service.open_report(run["run_id"])
    assert report is not None
    with zipfile.ZipFile(io.BytesIO(report[0])) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    text = "\n".join(root.itertext())
    assert run["run_title"] in text
    assert run["run_id"] in text
    assert "Review notes" in text and "Second line" in text
    assert run["test_case_title"] in text
    assert run["document"]["title"] != run["run_title"]


@pytest.mark.parametrize("background", [False, True])
def test_regeneration_inherits_labels_with_new_id(service_and_case, background):
    service, case = service_and_case
    run = service.generate(case.id, run_title="Original", description="Keep this note")
    if background:
        result = _await_job(service, service.start_regeneration(run["run_id"]))
        assert result["error"] is None
        again = result["run"]
    else:
        again = service.regenerate(run["run_id"])
    assert again["run_id"] != run["run_id"]
    assert again["run_title"] == run["run_title"]
    assert again["description"] == run["description"]
    assert len(service.list_runs()) == 2


def test_document_edits_preserve_labels(service_and_case):
    service, case = service_and_case
    run = service.generate(case.id, run_title="User label", description="User notes")
    document = run["document"]
    document["sections"][0]["paragraphs"] = ["An edited paragraph"]
    updated = service.update_document(run["run_id"], document)
    assert updated["run_title"] == run["run_title"]
    assert updated["description"] == run["description"]
    assert updated["run_id"] == run["run_id"]
    assert service.get_run(run["run_id"])["description"] == "User notes"


def test_legacy_runs_without_metadata_remain_readable(service_and_case):
    service, case = service_and_case
    run = service.generate(case.id, run_title="Temporary label")
    legacy = dict(run)
    legacy.pop("run_title")
    legacy.pop("description")
    path = service._run_dir / f"{run['run_id']}.json"
    path.write_text(json.dumps(legacy), encoding="utf-8")
    restored = generation_run_from_dict(legacy)
    assert restored.run_id == run["run_id"]
    assert restored.run_title == run["test_case_title"]
    assert restored.description == ""
    loaded = service.get_run(run["run_id"])
    assert loaded["run_title"] == run["test_case_title"]
    assert service.list_runs()[0]["run_title"] == run["test_case_title"]
    again = service.regenerate(run["run_id"])
    assert again["run_title"] == run["test_case_title"]


def test_cosmos_summaries_include_new_fields_and_normalize_old_runs(monkeypatch):
    container = Mock()
    container.query_items.return_value = [
        {"run_id": "run_new", "test_case_title": "Case", "run_title": "Review", "description": "Notes"},
        {"run_id": "run_old", "test_case_title": "Old case"},
    ]
    store = AzureRunStore()
    monkeypatch.setattr(store, "_cosmos", lambda: container)
    summaries = store.list_summaries()
    assert summaries[0]["run_title"] == "Review"
    assert summaries[0]["description"] == "Notes"
    assert summaries[1]["run_title"] == "Old case"
    assert summaries[1]["description"] == ""
    query = container.query_items.call_args.kwargs["query"]
    assert "c.run_title" in query and "c.description" in query


def test_cosmos_saves_and_loads_labels(service_and_case, monkeypatch):
    service, case = service_and_case
    generated = service.generate(case.id, run_title="Azure review", description="Azure notes")
    run = generation_run_from_dict(generated)
    container = Mock()
    store = AzureRunStore()
    monkeypatch.setattr(store, "_cosmos", lambda: container)
    store.save(run, b"fixture report")
    item = container.upsert_item.call_args.args[0]
    assert item["id"] == run.run_id
    assert item["run_title"] == "Azure review"
    assert item["description"] == "Azure notes"
    container.read_item.return_value = item
    loaded = store.load(run.run_id)
    assert loaded is not None
    assert loaded.run_id == run.run_id
    assert loaded.run_title == "Azure review"
    assert loaded.description == "Azure notes"


@pytest.mark.parametrize("endpoint,case_field", [
    ("/api/super-agent/generate", {"test_case_id": "unused"}),
    ("/api/super-agent/generate/start", {"test_case_id": "unused"}),
    ("/api/super-agent/generate/batch/start", {"test_case_ids": ["unused"]}),
])
@pytest.mark.parametrize("metadata", [{}, {"run_title": ""}, {"run_title": " \t\n "}])
def test_api_rejects_missing_or_whitespace_title(endpoint, case_field, metadata):
    with TestClient(app) as client:
        response = client.post(endpoint, json={**case_field, **metadata})
    assert response.status_code == 422
    assert any(error["loc"][-1] == "run_title" for error in response.json()["detail"])


@pytest.mark.parametrize("endpoint", [
    "/api/super-agent/generate",
    "/api/super-agent/generate/start",
    "/api/super-agent/generate/batch/start",
])
def test_api_creates_labeled_runs(service_and_case, endpoint):
    service, case = service_and_case
    payload = {"run_title": "  API review  ", "description": "  API note  "}
    if "batch" in endpoint:
        payload["test_case_ids"] = [case.id]
    else:
        payload["test_case_id"] = case.id
    with TestClient(app) as client:
        response = client.post(endpoint, json=payload)
        assert response.status_code == 200, response.text
        if endpoint.endswith("/start"):
            status = _await_job(service, response.json()["job_id"])
            assert status["error"] is None
            run = status["items"][0]["run"] if "batch" in endpoint else status["run"]
        else:
            run = response.json()
        assert run["run_title"] == "API review"
        assert run["description"] == "API note"
        detail = client.get(f"/api/super-agent/runs/{run['run_id']}")
        assert detail.status_code == 200
        assert detail.json()["run_title"] == "API review"
        assert client.get("/api/super-agent/runs").json()["runs"][0]["description"] == "API note"


def test_description_is_optional_and_schema_trims_title():
    request = SuperAgentRunRequest(test_case_id="tc1", run_title="  Named run  ")
    assert request.run_title == "Named run"
    assert request.description == ""


@pytest.mark.parametrize("endpoint", [
    "/api/super-agent/regenerate", "/api/super-agent/regenerate/start",
])
def test_api_regeneration_preserves_run_labels(service_and_case, endpoint):
    service, case = service_and_case
    original = service.generate(case.id, run_title="Preserve me", description="Source notes")
    with TestClient(app) as client:
        response = client.post(endpoint, json={"run_id": original["run_id"]})
    assert response.status_code == 200, response.text
    if endpoint.endswith("/start"):
        job = _await_job(service, response.json()["job_id"])
        assert job["error"] is None
        again = job["run"]
    else:
        again = response.json()
    assert again["run_id"] != original["run_id"]
    assert again["run_title"] == "Preserve me"
    assert again["description"] == "Source notes"


@pytest.mark.parametrize("method", ["generate", "start_generation", "start_batch_generation"])
def test_service_rejects_blank_title_before_starting_work(service_and_case, method):
    service, case = service_and_case
    case_arg = [case.id] if method == "start_batch_generation" else case.id
    with pytest.raises(ValueError, match="Run title is required"):
        getattr(service, method)(case_arg, run_title=" \n ")
    assert service.list_runs() == []
