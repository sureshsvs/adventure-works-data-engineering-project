from __future__ import annotations

import threading
import time
from datetime import datetime, timezone

import pytest

from gardianai_agentharness.services import super_agent_service as module
from gardianai_agentharness.services import task_store as ts_module
from gardianai_agentharness.services.case_scheduler import CapacityBusyError, CaseScheduler
from gardianai_agentharness.services.document_store import Task
from gardianai_agentharness.services.models import GeneratedDocument, generation_run_from_dict
from gardianai_agentharness.services.super_agent_service import SuperAgentService, TaskBatchValidationError
from gardianai_agentharness.services.task_batch_store import (
    AzureTaskBatchStore, LocalTaskBatchStore, live_batches,
)


def task(task_id="task", prompt="Review"):
    return Task(id=task_id, title=f"Title {task_id}", prompt_name="review",
                prompt_text=prompt, logical_source_role_names=[])


def service_with_tasks(monkeypatch, tasks):
    service = SuperAgentService()
    by_id = {item.id: item for item in tasks}
    service._task_store = type("Tasks", (), {
        "get_task": lambda self, key: by_id.get(key),
        "resolve_input_documents": lambda self, selected, period: selected,
        "task_document_lock": lambda self, key: threading.RLock(),
    })()
    service._variable_store = type("Values", (), {"get_run_value_set": lambda self: None})()
    service._scheduler = CaseScheduler(2, 2)
    return service


def wait_done(service, batch_id):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        record = service.get_task_batch(batch_id)
        if record["done"]:
            return record
        time.sleep(0.005)
    pytest.fail("Batch did not finish")


def test_real_task_render_sources_period_and_both_regenerations(monkeypatch):
    service = service_with_tasks(monkeypatch, [])
    modified = datetime(2026, 1, 1, tzinfo=timezone.utc)
    entries = [
        ("Quarterly/2025-Q4/External/QRA/current.pdf", 10, modified),
        ("Quarterly/2025-Q3/External/QRA/previous.pdf", 10, modified),
    ]
    monkeypatch.setattr(ts_module.blob_storage, "list_task_blobs",
                        lambda prefix: [entry for entry in entries if entry[0].startswith(prefix)])
    container = type("Container", (), {"query_items": lambda self, **kwargs: []})()
    store = ts_module.TaskStore(cosmos_container=container)
    selected = task("collision", "Period {{Period}} {{SEGMENT}} {{DOC:QRA@PQ}}")
    selected.logical_source_role_names = ["Current QRA draft"]
    selected.task_scalars = {"SEGMENT": "Gas"}
    monkeypatch.setattr(store, "get_task", lambda key: selected)
    service._task_store = store
    # A sample with the same ID must not divert task regeneration to samples.
    monkeypatch.setattr(service._store, "get_test_case", lambda key: object())
    prompts = []

    def generate(tc, actual_store, prompt, llm):
        assert actual_store is store
        assert sorted(ref.name for ref in tc.input_documents) == ["current.pdf", "previous.pdf"]
        prompts.append(prompt)
        return GeneratedDocument(title="Rendered task"), "offline"

    monkeypatch.setattr(module, "generate_document", generate)
    run = service.generate("collision", task_only=True, period="2025-Q4", one_off_prompt="Extra")
    assert prompts == ["Period 2025-Q4 Gas previous.pdf\nExtra"]
    assert service.open_report(run["run_id"])[0].startswith(b"PK")
    persisted = service._runs.load(run["run_id"])
    assert persisted.period == "2025-Q4" and persisted.task_only is True
    regenerated = service.regenerate(run["run_id"])
    assert regenerated["task_only"] and regenerated["period"] == "2025-Q4"
    job = service.start_regeneration(run["run_id"], one_off_prompt="Again")
    deadline = time.monotonic() + 5
    while not service.job_status(job)["done"] and time.monotonic() < deadline:
        time.sleep(0.005)
    result = service.job_status(job)
    assert result["error"] is None
    assert result["run"]["period"] == "2025-Q4"
    assert prompts[-1] == "Period 2025-Q4 Gas previous.pdf\nAgain"
    old = generation_run_from_dict({"test_case_id": "sample"})
    assert old.period is None and old.task_only is False


def test_concurrent_runs_of_same_task_keep_period_documents_isolated(monkeypatch):
    service = service_with_tasks(monkeypatch, [])
    entries = [
        ("Quarterly/2025-Q4/External/QRA/current.pdf", 10, datetime(2026, 1, 1, tzinfo=timezone.utc)),
        ("Quarterly/2025-Q3/External/QRA/current.pdf", 10, datetime(2025, 10, 1, tzinfo=timezone.utc)),
    ]
    monkeypatch.setattr(
        ts_module.blob_storage, "list_task_blobs",
        lambda prefix: [entry for entry in entries if entry[0].startswith(prefix)],
    )
    container = type("Container", (), {"query_items": lambda self, **kwargs: []})()
    store = ts_module.TaskStore(cosmos_container=container)
    selected = task("collision", "Review {{Period}}")
    selected.logical_source_role_names = ["Current QRA draft"]
    monkeypatch.setattr(store, "get_task", lambda key: selected)
    service._task_store = store

    first_started = threading.Event()
    second_started = threading.Event()
    release_first = threading.Event()
    observed = {}

    def generate(tc, actual_store, prompt, llm):
        if "2025-Q4" in prompt:
            first_started.set()
            assert release_first.wait(3)
        else:
            second_started.set()
        observed[prompt] = [actual_store._blob_rel[ref.id] for ref in tc.input_documents]
        return GeneratedDocument(title="Period report"), "offline"

    monkeypatch.setattr(module, "generate_document", generate)
    failures = []

    def run(period):
        try:
            service.generate("collision", task_only=True, period=period)
        except Exception as exc:  # noqa: BLE001 - surface thread failures in the test
            failures.append(exc)

    first = threading.Thread(target=run, args=("2025-Q4",))
    second = threading.Thread(target=run, args=("2025-Q3",))
    first.start()
    try:
        assert first_started.wait(2)
        second.start()
        assert not second_started.wait(0.1)
    finally:
        release_first.set()
    first.join(3)
    second.join(3)

    assert not first.is_alive() and not second.is_alive()
    assert not failures
    assert observed["Review 2025-Q4"] == ["Quarterly/2025-Q4/External/QRA/current.pdf"]
    assert observed["Review 2025-Q3"] == ["Quarterly/2025-Q3/External/QRA/current.pdf"]


def test_preflight_all_errors_and_atomic_validation(monkeypatch):
    service = service_with_tasks(monkeypatch, [
        task("good"), task("bad", "{{MISSING}}"), task("empty", "  "),
    ])
    expected = service.preflight_tasks(["good", "missing", "bad", "empty"])
    assert not expected["valid"]
    assert [error["task_id"] for error in expected["errors"]] == ["missing", "bad", "empty"]
    admitted = []
    monkeypatch.setattr(service._scheduler, "submit", lambda *args: admitted.append(args))
    with pytest.raises(TaskBatchValidationError) as caught:
        service.start_task_batch_generation(["good", "missing", "bad", "empty"], run_title="Review")
    assert caught.value.errors == expected["errors"]
    assert not admitted and service.list_task_batches() == []


@pytest.mark.parametrize("ids,kwargs", [
    ([], {}), (["good", "good"], {}), ([""], {}), (["good"], {"run_title": ""}),
    (["good"], {"max_parallel_cases": True}), (["good"], {"max_parallel_cases": 5}),
    (["good"], {"economy": "yes"}), (["good"], {"reasoning_effort": "invalid"}),
    (["good"], {"period": "2025-Q9"}), (["good"], {"grouping": []}),
])
def test_invalid_batch_settings_do_not_persist(monkeypatch, ids, kwargs):
    service = service_with_tasks(monkeypatch, [task("good")])
    with pytest.raises(ValueError):
        service.start_task_batch_generation(ids, **{"run_title": "Review", **kwargs})
    assert service.list_task_batches() == []


def test_durable_batch_isolates_failures_and_retrieves_after_new_instance(monkeypatch):
    service = service_with_tasks(monkeypatch, [task("good"), task("bad")])
    calls = []

    def generate(task_id, **kwargs):
        calls.append((task_id, kwargs))
        if task_id == "bad":
            raise RuntimeError("isolated failure")
        return {"run_id": "run_123456789abc"}

    monkeypatch.setattr(service, "generate", generate)
    batch_id = service.start_task_batch_generation(
        ["good", "bad"], run_title=" Review ", description=" Details ",
        period="2025-Q4", grouping="group", max_parallel_cases=2,
        economy=True, reasoning_effort="low", use_expected_template=False,
        one_off_prompt="Extra",
    )
    final = wait_done(service, batch_id)
    assert final["status"] == "completed_with_errors"
    assert final["finished_count"] == final["total"] == 2
    assert final["job_id"] == batch_id
    assert final["created_at"] <= final["started_at"] <= final["completed_at"]
    assert all(
        item["created_at"] <= item["started_at"] <= item["completed_at"]
        for item in final["items"]
    )
    assert len({item["job_id"] for item in final["items"]}) == 2
    assert final["items"][0]["run_id"] == "run_123456789abc"
    assert final["items"][1]["error"] == "isolated failure"
    assert all(kwargs["task_only"] and kwargs["one_off_prompt"] == "Extra" for _, kwargs in calls)
    other = SuperAgentService()
    assert other.get_task_batch(batch_id) == final
    assert other.list_task_batches() == [final]
    assert other.job_status(batch_id) == final
    assert other.list_runs() == []
    assert other.get_task_batch("../escape") is None


def test_admission_has_queued_record_capacity_cleanup_and_no_live_corruption(monkeypatch):
    service = service_with_tasks(monkeypatch, [task()])
    scheduler = CaseScheduler(1, 0)
    service._scheduler = scheduler
    release, started = threading.Event(), threading.Event()

    def generate(*args, **kwargs):
        started.set()
        assert release.wait(3)
        return {"run_id": "run_123456789abc"}

    monkeypatch.setattr(service, "generate", generate)
    original_submit = scheduler.submit

    def submit(tasks, parallelism):
        assert any(record["status"] == "queued" for record in service._batches.list())
        original_submit(tasks, parallelism)

    monkeypatch.setattr(scheduler, "submit", submit)
    batch_id = service.start_task_batch_generation(["task"], run_title="Review")
    try:
        assert started.wait(2)
        other = SuperAgentService()
        assert other.get_task_batch(batch_id)["status"] == "running"
        with pytest.raises(CapacityBusyError):
            service.start_task_batch_generation(["task"], run_title="Rejected")
        assert len(service.list_task_batches()) == 1
    finally:
        release.set()
    assert wait_done(service, batch_id)["status"] == "completed"
    assert batch_id not in live_batches


@pytest.mark.parametrize("state", ["queued", "running"])
def test_restart_interruption_is_durable_and_keeps_finished_results(monkeypatch, state):
    service = service_with_tasks(monkeypatch, [task()])
    record = {
        "batch_id": "batch_123456789abc", "job_id": "batch_123456789abc",
        "status": state, "done": False, "created_at": "2026-01-01",
        "total": 2, "finished_count": 1,
        "items": [
            {"task_id": "finished", "status": "completed", "run_id": "run_saved"},
            {"task_id": "pending", "status": state},
        ],
    }
    service._batches.save(record)
    recovered = SuperAgentService().list_task_batches()[0]
    assert recovered["status"] == "interrupted" and recovered["done"]
    assert recovered["finished_count"] == 2
    assert recovered["items"][0]["run_id"] == "run_saved"
    assert recovered["items"][1]["status"] == "interrupted"
    assert recovered["items"][1]["completed_at"] == recovered["completed_at"]
    assert service._batches.load(record["batch_id"]) == recovered


def test_azure_batch_store_uses_existing_partition_and_discriminator(monkeypatch):
    store = AzureTaskBatchStore()
    items = {}
    queries = []

    class Cosmos:
        def upsert_item(self, item):
            items[item["id"]] = dict(item)

        def read_item(self, item, partition_key):
            assert item == partition_key
            return items[item]

        def query_items(self, query, enable_cross_partition_query):
            queries.append(query)
            assert enable_cross_partition_query
            return list(items.values())

        def delete_item(self, item, partition_key):
            assert item == partition_key
            del items[item]

    monkeypatch.setattr(store._runs, "_cosmos", lambda: Cosmos())
    record = {"batch_id": "batch_123456789abc", "status": "queued", "items": []}
    store.save(record)
    assert items[record["batch_id"]]["record_type"] == "task_batch"
    # Import remains lazy; fake the already-existing optional SDK for this test.
    import sys
    import types
    exceptions = types.ModuleType("azure.cosmos.exceptions")
    exceptions.CosmosResourceNotFoundError = type("CosmosResourceNotFoundError", (Exception,), {})
    monkeypatch.setitem(sys.modules, "azure.cosmos.exceptions", exceptions)
    assert store.load(record["batch_id"]) == record
    assert store.list() == [record]
    assert "record_type = 'task_batch'" in queries[0]
    store.delete(record["batch_id"])
    assert not items


def test_local_atomic_batch_store_leaves_run_summaries_clean(tmp_path):
    store = LocalTaskBatchStore(tmp_path)
    record = {"batch_id": "batch_123456789abc", "status": "queued"}
    store.save(record)
    store.save({**record, "status": "completed"})
    assert store.load(record["batch_id"])["status"] == "completed"
    assert not list((tmp_path / "task_batches").glob("*.part"))
    assert not list(tmp_path.glob("run_*.json"))
    store.delete(record["batch_id"])
    assert store.list() == []


def test_sample_generation_and_regeneration_remain_sample_runs(monkeypatch):
    service = service_with_tasks(monkeypatch, [])
    sample = service._store.register_uploaded_test_case(
        title="Sample", input_files=[("input.csv", b"item,value\nRevenue,100\n")],
        prompt_text="Review the supplied figures",
    )
    run = service.generate(sample.id, run_title="Sample run", report_version="v2",
                           reporting_period="Q4", reporting_year="2025")
    assert not run["task_only"] and run["period"] is None
    result = service.regenerate(run["run_id"])
    assert not result["task_only"]
    assert result["report_version"] == "v2" and result["reporting_year"] == "2025"
    assert service.open_report(result["run_id"])[0].startswith(b"PK")


def test_single_task_one_off_prompt_reaches_actual_generation(monkeypatch):
    service = service_with_tasks(monkeypatch, [task(prompt="Review {{Period}}")])
    prompts = []
    monkeypatch.setattr(module, "generate_document", lambda tc, store, prompt, llm: (
        prompts.append(prompt) or GeneratedDocument(title="Report"), "offline",
    ))
    job = service.start_task_generation("task", period="2025-Q4", one_off_prompt="Extra")
    deadline = time.monotonic() + 5
    while not service.job_status(job)["done"] and time.monotonic() < deadline:
        time.sleep(0.005)
    assert service.job_status(job)["error"] is None
    assert prompts == ["Review 2025-Q4\nExtra"]


def test_azure_run_summaries_exclude_batch_documents(monkeypatch):
    from gardianai_agentharness.services.run_store import AzureRunStore
    queries = []
    store = AzureRunStore()

    class Cosmos:
        def query_items(self, query, **kwargs):
            queries.append(query)
            return []

    monkeypatch.setattr(store, "_cosmos", lambda: Cosmos())
    assert store.list_summaries() == []
    assert "WHERE IS_DEFINED(c.test_case_id)" in queries[0]


def test_batch_store_selection_matches_run_store(monkeypatch, tmp_path):
    from gardianai_agentharness.config import settings
    from gardianai_agentharness.services.task_batch_store import build_task_batch_store
    assert isinstance(build_task_batch_store(tmp_path), LocalTaskBatchStore)
    monkeypatch.setattr(settings, "run_store_backend", "azure")
    monkeypatch.setattr(settings, "cosmos_endpoint", "https://fake.cosmos.azure.com")
    assert isinstance(build_task_batch_store(tmp_path), AzureTaskBatchStore)


def test_real_task_batch_persists_independent_reports(monkeypatch):
    service = service_with_tasks(monkeypatch, [
        task("first", "Review {{Period}}"), task("second", "Check {{Period}}"),
    ])
    prompts = []
    monkeypatch.setattr(module, "generate_document", lambda tc, store, prompt, llm: (
        prompts.append(prompt) or GeneratedDocument(title=tc.title), "offline",
    ))
    final = wait_done(service, service.start_task_batch_generation(
        ["first", "second"], run_title="Quarterly review", period="2025-Q4",
        max_parallel_cases=2, one_off_prompt="Extra",
    ))
    assert final["status"] == "completed"
    assert sorted(prompts) == ["Check 2025-Q4\nExtra", "Review 2025-Q4\nExtra"]
    assert len({item["run_id"] for item in final["items"]}) == 2
    assert len(service.list_runs()) == 2
    for item in final["items"]:
        saved = service.get_run(item["run_id"])
        assert saved["period"] == "2025-Q4" and saved["task_only"]
        assert saved["run_title"] == "Quarterly review"
        assert service.open_report(item["run_id"])[0].startswith(b"PK")


def test_real_api_generate_poll_report_and_restart_retrieval(monkeypatch):
    import io
    import zipfile

    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from gardianai_agentharness.api.routes import super_agent as routes

    service = service_with_tasks(monkeypatch, [task("quarter", "Review {{Period}}")])
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    app = FastAPI()
    app.include_router(routes.router, prefix="/api")
    client = TestClient(app)
    preflight = client.post("/api/super-agent/tasks/generate/preflight", json={
        "task_ids": ["quarter"], "period": "2025-Q4",
    })
    assert preflight.status_code == 200 and preflight.json()["valid"]
    response = client.post("/api/super-agent/tasks/generate/batch/start", json={
        "task_ids": ["quarter"], "run_title": "Quarterly API review",
        "period": "2025-Q4", "max_parallel_cases": 1, "one_off_prompt": "API instruction",
    })
    assert response.status_code == 200
    batch_id = response.json()["batch_id"]
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        poll = client.get(f"/api/super-agent/jobs/{batch_id}")
        assert poll.status_code == 200
        if poll.json()["done"]:
            break
        time.sleep(0.005)
    record = poll.json()
    assert record["status"] == "completed"
    run_id = record["items"][0]["run_id"]
    download = client.get(f"/api/super-agent/runs/{run_id}/report")
    assert download.status_code == 200
    with zipfile.ZipFile(io.BytesIO(download.content)) as report:
        xml = report.read("word/document.xml").decode()
        assert "Review 2025-Q4" in xml and "API instruction" in xml
    restarted = SuperAgentService()
    restarted._task_store = service._task_store
    restarted._variable_store = service._variable_store
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: restarted)
    detail = client.get(f"/api/super-agent/tasks/batches/{batch_id}")
    assert detail.status_code == 200
    assert detail.json()["items"][0]["task_title"] == "Title quarter"
    assert detail.json()["max_parallel_cases"] == 1
    history = client.get("/api/super-agent/tasks/batches")
    assert history.status_code == 200 and len(history.json()["batches"]) == 1
    assert client.get(f"/api/super-agent/runs/{run_id}/report").content == download.content
    regenerated = client.post("/api/super-agent/regenerate", json={"run_id": run_id})
    assert regenerated.status_code == 200
    assert regenerated.json()["task_only"] and regenerated.json()["period"] == "2025-Q4"
    assert len(restarted.list_runs()) == 2


@pytest.mark.parametrize("period", ["2025-Q9", "", "../escape"])
def test_real_single_task_api_invalid_period_is_422_before_admission(monkeypatch, period):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from gardianai_agentharness.api.routes import super_agent as routes

    service = service_with_tasks(monkeypatch, [task("quarter", "Review {{Period}}")])
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    app = FastAPI()
    app.include_router(routes.router, prefix="/api")
    client = TestClient(app)
    response = client.post("/api/super-agent/tasks/generate/start", json={
        "task_id": "quarter", "period": period,
    })
    assert response.status_code == 422
    assert not service._jobs and not service.list_task_batches()
    unknown = client.post("/api/super-agent/tasks/generate/start", json={
        "task_id": "missing", "period": period,
    })
    assert unknown.status_code == 404


def test_preflight_unexpected_backend_value_error_is_not_validation_data(monkeypatch):
    from fastapi import FastAPI
    from fastapi.testclient import TestClient
    from gardianai_agentharness.api.routes import super_agent as routes

    service = service_with_tasks(monkeypatch, [task()])

    def fail(*args):
        raise ValueError("private backend exception")

    monkeypatch.setattr(service, "_validate_task_run", fail)
    with pytest.raises(ValueError, match="private backend exception"):
        service.preflight_tasks(["task"])
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    app = FastAPI()
    app.include_router(routes.router, prefix="/api")
    response = TestClient(app, raise_server_exceptions=False).post(
        "/api/super-agent/tasks/generate/preflight", json={"task_ids": ["task"]},
    )
    assert response.status_code == 500
    assert "private backend exception" not in response.text
