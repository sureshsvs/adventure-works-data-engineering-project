"""Shared fixtures.

Prompt library and OCR cache are blob-only in production. This fixture fakes
Azure Blob Storage in-memory (and marks it "configured") for every test, so the
suite stays hermetic/offline while still exercising the real blob-backed code
paths. Individual tests can override `settings.azure_storage_account_url` back
to "" to exercise the "not configured" (raises) behaviour.
"""

from __future__ import annotations

import pytest

from gardianai_agentharness.config import settings
from gardianai_agentharness.services import blob_storage
from gardianai_agentharness.services import llm_client, ocr_service, super_agent_service
from gardianai_agentharness.services.document_store import get_document_store
from gardianai_agentharness.services.prompt_library import get_prompt_library


@pytest.fixture(autouse=True)
def isolated_runtime(fake_blob_storage, monkeypatch, tmp_path):
    """Never write uploads/runs into a developer's live store or call their LLM."""
    monkeypatch.setattr(settings, "run_store_dir", str(tmp_path / "runs"))
    monkeypatch.setattr(settings, "sample_data_cache_dir", str(tmp_path / "sampledata"))
    monkeypatch.setattr(settings, "run_store_backend", "local")
    monkeypatch.setattr(settings, "gardian_ocr_endpoint", "")
    monkeypatch.setattr(settings, "gardian_ocr_key", "")
    monkeypatch.setattr(llm_client, "_harness", llm_client.LLMClient())
    monkeypatch.setattr(llm_client, "_super_agent", llm_client.LLMClient())
    monkeypatch.setattr(ocr_service, "_client", None)
    monkeypatch.setattr(super_agent_service, "_service", None)
    get_document_store.cache_clear()
    get_prompt_library.cache_clear()
    yield
    get_document_store.cache_clear()
    get_prompt_library.cache_clear()


@pytest.fixture(autouse=True)
def fake_blob_storage(monkeypatch):
    store: dict[tuple[str, str], bytes] = {}

    def fake_upload_bytes(container: str, blob_name: str, data: bytes) -> None:
        store[(container, blob_name)] = data

    def fake_download_bytes(container: str, blob_name: str) -> bytes | None:
        return store.get((container, blob_name))

    monkeypatch.setattr(blob_storage, "upload_bytes", fake_upload_bytes)
    monkeypatch.setattr(blob_storage, "download_bytes", fake_download_bytes)
    # Sample-data pack listing is unrelated to this fixture; keep it empty so
    # DocumentStore falls back to the bundled sampledata/ tree, same as today.
    monkeypatch.setattr(blob_storage, "list_pack_blobs", lambda: [])
    monkeypatch.setattr(
        settings, "azure_storage_account_url", "https://fake.blob.core.windows.net"
    )
    monkeypatch.setattr(settings, "azure_storage_connection_string", "")
    return store
