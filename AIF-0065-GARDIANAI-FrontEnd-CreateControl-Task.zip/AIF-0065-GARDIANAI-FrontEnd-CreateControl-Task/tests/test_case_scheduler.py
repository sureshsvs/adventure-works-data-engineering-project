from __future__ import annotations

import threading
import time

import pytest
from pydantic import ValidationError

from gardianai_agentharness.api.schemas import SuperAgentBatchRequest
from gardianai_agentharness.config import Settings
from gardianai_agentharness.services.case_scheduler import (
    CapacityBusyError,
    CaseScheduler,
)
from gardianai_agentharness.services.models import GeneratedDocument
from gardianai_agentharness.services.super_agent_context import record_usage, report
from gardianai_agentharness.services.super_agent_service import (
    SuperAgentService,
    get_super_agent_service,
)


def wait_done(service, job_id):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        status = service.job_status(job_id)
        if status["done"]:
            return status
        time.sleep(0.005)
    pytest.fail("Job did not finish")


def create_case(service, title="Case"):
    return service._store.register_uploaded_test_case(
        title=title, input_files=[("input.csv", b"item,value\nRevenue,100\n")],
        prompt_text="Review the figures.",
    )


@pytest.mark.parametrize("field,value", [
    ("super_agent_max_active_cases", 0),
    ("super_agent_queue_capacity", -1),
    ("super_agent_default_max_parallel_cases", 0),
    ("super_agent_default_max_parallel_cases", 5),
])
def test_invalid_scheduler_settings_fail_at_startup(field, value):
    with pytest.raises(ValidationError):
        Settings(_env_file=None, **{field: value})


@pytest.mark.parametrize("parallelism", [0, 5, -1, True, 1.5, "2"])
def test_batch_rejects_invalid_parallelism(parallelism):
    with pytest.raises(ValidationError):
        SuperAgentBatchRequest(
            test_case_ids=["case"], run_title="Review", max_parallel_cases=parallelism,
        )


@pytest.mark.parametrize("parallelism", [1, 2, 4])
def test_batch_parallelism_and_per_item_usage(monkeypatch, parallelism):
    service = get_super_agent_service()
    service._scheduler = CaseScheduler(4, 2)
    cases = [create_case(service, f"Case {index}") for index in range(5)]
    release = threading.Event()
    started = threading.Event()
    lock = threading.Lock()
    active = peak = 0
    calls = []
    reported = 0

    def generate(test_case_id, *args, **kwargs):
        nonlocal active, peak, reported
        with lock:
            active += 1
            peak = max(peak, active)
            calls.append(test_case_id)
        try:
            report("generate", test_case_id)
            record_usage({"prompt_tokens": 5, "completion_tokens": 3})
            with lock:
                reported += 1
                if reported == parallelism:
                    started.set()
            assert release.wait(3)
            if test_case_id == cases[1].id:
                raise RuntimeError("isolated failure")
            return {"run_id": test_case_id}
        finally:
            with lock:
                active -= 1

    monkeypatch.setattr(service, "generate", generate)
    job_id = service.start_batch_generation(
        [case.id for case in cases], run_title="Review", max_parallel_cases=parallelism,
    )
    try:
        assert started.wait(2)
        status = service.job_status(job_id)
        assert status["status"] == "running"
        assert len([item for item in status["items"] if item["status"] == "running"]) == parallelism
        if parallelism > 1:
            assert status["current_test_case_id"] is None
        for item in status["items"][:parallelism]:
            assert item["detail"] == item["test_case_id"]
            assert item["tokens"]["total"]["total"] == 8
        assert status["tokens"]["total"]["total"] == 8 * parallelism
    finally:
        release.set()
    status = wait_done(service, job_id)
    assert peak == parallelism
    assert status["status"] == "completed_with_errors"
    assert status["finished_count"] == len(cases)
    assert [item["status"] for item in status["items"]] == [
        "completed" if case.id != cases[1].id else "failed" for case in cases
    ]
    assert all(item["tokens"]["total"]["total"] == 8 for item in status["items"])
    assert status["tokens"]["total"]["total"] == 8 * len(cases)


def test_shared_capacity_single_batch_regeneration_and_sync(monkeypatch):
    first = get_super_agent_service()
    case = create_case(first)
    original = first.generate(case.id, run_title="Original")
    second = SuperAgentService()
    assert first._scheduler is second._scheduler
    scheduler = CaseScheduler(2, 1)
    first._scheduler = second._scheduler = scheduler
    release = threading.Event()
    started = threading.Event()
    lock = threading.Lock()
    active = peak = 0

    def generate(*args, **kwargs):
        nonlocal active, peak
        with lock:
            active += 1
            peak = max(peak, active)
            if active == 2:
                started.set()
        try:
            assert release.wait(3)
            return original
        finally:
            with lock:
                active -= 1

    monkeypatch.setattr(first, "_generate", generate)
    monkeypatch.setattr(second, "_generate", generate)
    batch = first.start_batch_generation([case.id, case.id], run_title="Batch")
    single = second.start_generation(case.id, run_title="Single")
    try:
        assert started.wait(2)
        queued = second.start_regeneration(original["run_id"])
        assert second.job_status(queued)["status"] == "queued"
        assert second.job_status(queued)["stage"] == "queued"
        jobs_before = len(first._jobs)
        for submit in (
            lambda: first.start_generation(case.id, run_title="Busy"),
            lambda: first.start_batch_generation([case.id], run_title="Busy"),
            lambda: first.start_regeneration(original["run_id"]),
            lambda: first.generate(case.id, run_title="Busy"),
            lambda: first.regenerate(original["run_id"]),
        ):
            with pytest.raises(CapacityBusyError, match="busy.*queue is full"):
                submit()
            assert len(first._jobs) == jobs_before
    finally:
        release.set()
    assert wait_done(first, batch)["status"] == "completed"
    assert wait_done(second, single)["status"] == "done"
    assert wait_done(second, queued)["status"] == "done"
    assert peak == 2


def test_zero_queue_and_failed_work_release_capacity():
    scheduler = CaseScheduler(1, 0)
    release = threading.Event()
    started = threading.Event()

    def task():
        started.set()
        assert release.wait(2)

    scheduler.submit([task])
    try:
        assert started.wait(1)
        with pytest.raises(CapacityBusyError):
            scheduler.submit([lambda: None])
    finally:
        release.set()
    deadline = time.monotonic() + 2
    while scheduler._active and time.monotonic() < deadline:
        time.sleep(0.005)
    with pytest.raises(RuntimeError, match="failure"):
        scheduler.run(lambda: (_ for _ in ()).throw(RuntimeError("failure")))
    # run() signals the caller just before releasing the scheduling slot.
    while scheduler._active and time.monotonic() < deadline:
        time.sleep(0.005)
    assert scheduler.run(lambda: 42) == 42


def test_identical_single_jobs_keep_distinct_scheduler_records():
    scheduler = CaseScheduler(2, 1)
    release = threading.Event()
    scheduler.submit([lambda: release.wait(2)])
    scheduler.submit([lambda: release.wait(2)])
    try:
        with scheduler._lock:
            assert len({id(group) for group in scheduler._groups}) == 2
    finally:
        release.set()
    deadline = time.monotonic() + 2
    while scheduler._active and time.monotonic() < deadline:
        time.sleep(0.005)
    assert scheduler._active == 0
    assert not scheduler._groups


def test_simultaneous_submissions_cannot_over_admit():
    scheduler = CaseScheduler(2, 3)
    barrier = threading.Barrier(10)
    release = threading.Event()
    lock = threading.Lock()
    admitted = rejected = 0

    def submit():
        nonlocal admitted, rejected
        barrier.wait()
        try:
            scheduler.submit([lambda: release.wait(3)])
            with lock:
                admitted += 1
        except CapacityBusyError:
            with lock:
                rejected += 1

    threads = [threading.Thread(target=submit) for _ in range(10)]
    try:
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join(2)
        assert admitted == 5
        assert rejected == 5
        with scheduler._lock:
            assert scheduler._active == 2
            assert len(scheduler._groups) == 5
    finally:
        release.set()
    deadline = time.monotonic() + 2
    while scheduler._groups and time.monotonic() < deadline:
        time.sleep(0.005)
    assert not scheduler._groups


def test_parallel_batch_saves_independent_reports():
    service = get_super_agent_service()
    cases = [create_case(service, f"Parallel report {index}") for index in range(2)]
    status = wait_done(service, service.start_batch_generation(
        [case.id for case in cases], run_title="Parallel reports", max_parallel_cases=2,
        report_version="v2", reporting_period="Q4", reporting_year="2026",
    ))
    assert status["status"] == "completed"
    runs = [item["run"] for item in status["items"]]
    assert len({run["run_id"] for run in runs}) == 2
    assert len({run["report_filename"] for run in runs}) == 2
    for case, run in zip(cases, runs):
        assert run["test_case_id"] == case.id
        assert run["report_version"] == "v2"
        saved = service.get_run(run["run_id"])
        assert saved["reporting_year"] == "2026"
        assert service.open_report(run["run_id"])[0].startswith(b"PK")


def test_synchronous_runs_initialize_and_isolate_usage(monkeypatch):
    from gardianai_agentharness.services import super_agent_service

    service = get_super_agent_service()
    case = create_case(service)

    def generate_document(*args):
        record_usage({"prompt_tokens": 5, "completion_tokens": 3})
        return GeneratedDocument(title="Review"), "offline"

    monkeypatch.setattr(super_agent_service, "generate_document", generate_document)
    first = service.generate(case.id, run_title="First")
    second = service.generate(case.id, run_title="Second")
    assert first["token_usage"]["total"]["total"] == 8
    assert second["token_usage"]["total"]["total"] == 8
