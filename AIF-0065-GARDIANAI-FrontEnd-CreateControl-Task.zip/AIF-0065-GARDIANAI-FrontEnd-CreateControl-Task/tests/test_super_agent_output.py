"""Report output-contract regressions; no network or model calls."""

from __future__ import annotations

import copy
import json
import threading
import time
import zipfile
from types import SimpleNamespace
from unittest.mock import Mock
from xml.etree import ElementTree as ET

import pytest

from gardianai_agentharness.config import settings
from gardianai_agentharness.services import super_agent_generation as generation
from gardianai_agentharness.services import super_agent_harness as harness
from gardianai_agentharness.services import super_agent_research as research
from gardianai_agentharness.services.case_scheduler import get_case_scheduler
from gardianai_agentharness.services.llm_client import LLMClient
from gardianai_agentharness.services.models import GenerationRun
from gardianai_agentharness.services.report_service import build_generated_report
from gardianai_agentharness.services.super_agent_output import (
    REPORT_FORMAT,
    compose_report,
    parse_report,
)
from gardianai_agentharness.services.super_agent_service import SuperAgentService


@pytest.fixture
def report_data():
    return {
        "title": "A new review, not a hard-coded benchmark title",
        "subtitle": "",
        "sections": [
            {
                "heading": "Future test case findings",
                "level": 2,
                "paragraphs": ["Revenue 100 ties to input.csv, row 2."],
                "tables": [],
            },
            {
                "heading": "A dynamically chosen comparison",
                "level": 1,
                "paragraphs": [],
                "tables": [{
                    "title": "",
                    "headers": ["Metric", "Value", "Evidence"],
                    "rows": [["Revenue", "100", "input.csv, row 2"]],
                }],
            },
        ],
    }


def _response(content, *, finish_reason="stop", refusal=None):
    return SimpleNamespace(choices=[SimpleNamespace(
        finish_reason=finish_reason,
        message=SimpleNamespace(content=content, refusal=refusal),
    )])


def test_dynamic_titles_sections_and_tables_are_preserved(report_data):
    assert parse_report(json.dumps(report_data)).to_dict() == report_data


def test_dynamic_report_exports_to_word(report_data, tmp_path):
    document = parse_report(json.dumps(report_data))
    run = GenerationRun(
        test_case_id="dynamic", test_case_title="Dynamic case",
        prompt_version="v1", model="test", mode="llm", document=document,
    )
    path = build_generated_report(run, tmp_path)
    with zipfile.ZipFile(path) as archive:
        root = ET.fromstring(archive.read("word/document.xml"))
    text = "".join(root.itertext())
    assert report_data["title"] in text
    assert all(section["heading"] in text for section in report_data["sections"])
    assert "input.csv, row 2" in text


@pytest.mark.parametrize("failure", [
    "wrapper", "empty_sections", "blank_title", "blank_heading", "wrong_level",
    "empty_section", "bad_row", "non_string_cell", "extra_field",
])
def test_invalid_reports_are_rejected(report_data, failure):
    data = copy.deepcopy(report_data)
    if failure == "wrapper":
        data = {"report": data}
    elif failure == "empty_sections":
        data["sections"] = []
    elif failure == "blank_title":
        data["title"] = " "
    elif failure == "blank_heading":
        data["sections"][0]["heading"] = ""
    elif failure == "wrong_level":
        data["sections"][0]["level"] = True
    elif failure == "empty_section":
        data["sections"][0]["paragraphs"] = []
    elif failure == "bad_row":
        data["sections"][1]["tables"][0]["rows"] = [["Revenue"]]
    elif failure == "non_string_cell":
        data["sections"][1]["tables"][0]["rows"][0][1] = 100
    elif failure == "extra_field":
        data["invented_field"] = "content would otherwise disappear"
    with pytest.raises(ValueError):
        parse_report(json.dumps(data))


@pytest.mark.parametrize("bad_content", ["", "not JSON", "{} {}", '{"title":'])
def test_malformed_json_is_not_silently_truncated(bad_content):
    with pytest.raises(ValueError):
        parse_report(bad_content)


def test_composition_requests_strict_schema_and_keeps_input_unchanged(report_data):
    llm = Mock(spec=LLMClient)
    llm.chat.return_value = _response(json.dumps(report_data))
    messages = [{"role": "user", "content": "Evidence: input.csv row 2: Revenue=100"}]
    original = copy.deepcopy(messages)
    assert compose_report(llm, messages).to_dict() == report_data
    assert messages == original
    llm.chat.assert_called_once()
    assert llm.chat.call_args.kwargs["response_format"] == REPORT_FORMAT
    assert "tools" not in llm.chat.call_args.kwargs


@pytest.mark.parametrize("bad_response", [
    _response('{"unexpected_shape": "analysis"}'),
    _response("not JSON"),
    _response("", finish_reason="length"),
])
def test_retry_formats_the_same_evidence(report_data, bad_response):
    llm = Mock(spec=LLMClient)
    llm.chat.side_effect = [bad_response, _response(json.dumps(report_data))]
    messages = [{"role": "tool", "content": "Revenue 100, input.csv row 2"}]
    assert compose_report(llm, messages).to_dict() == report_data
    assert llm.chat.call_count == 2
    retried = llm.chat.call_args.kwargs["messages"]
    assert retried[0] == messages[0]
    assert "Validation failed" in retried[-1]["content"]
    assert bad_response.choices[0].message.content == retried[-2]["content"]


def test_retry_is_bounded_and_refusals_are_not_retried():
    llm = Mock(spec=LLMClient)
    llm.chat.return_value = _response("{}")
    with pytest.raises(RuntimeError, match="after a formatting retry"):
        compose_report(llm, [])
    assert llm.chat.call_count == 2
    llm.chat.reset_mock()
    llm.chat.return_value = _response(None, refusal="refused")
    with pytest.raises(RuntimeError, match="refused"):
        compose_report(llm, [])
    llm.chat.assert_called_once()


def test_api_errors_are_not_treated_as_formatting_errors():
    llm = Mock(spec=LLMClient)
    llm.chat.side_effect = RuntimeError("network failure")
    with pytest.raises(RuntimeError, match="network failure"):
        compose_report(llm, [])
    llm.chat.assert_called_once()


def test_missing_response_is_explicit():
    llm = Mock(spec=LLMClient)
    llm.chat.return_value = SimpleNamespace(choices=[])
    with pytest.raises(RuntimeError, match="no report response"):
        compose_report(llm, [])
    llm.chat.assert_called_once()


def test_tool_retrieval_always_finishes_with_structured_composition(monkeypatch, report_data):
    tc = SimpleNamespace(prompt_text="Check Revenue", expected_output_text="")
    toolbox = Mock()
    toolbox.manifest_text.return_value = "input.csv"
    monkeypatch.setattr(generation, "DocumentToolbox", Mock(return_value=toolbox))

    def investigate(llm, messages, *args, **kwargs):
        messages.append({"role": "assistant", "content": "Revenue verified at 100."})
        return "Investigation is prose, not JSON"

    monkeypatch.setattr(generation, "run_tool_loop", investigate)
    llm = Mock(spec=LLMClient)
    llm.chat.return_value = _response(json.dumps(report_data))
    assert generation._generate_agentic(tc, Mock(), "Check Revenue", llm).title == report_data["title"]
    assert any(
        m["content"] == "Revenue verified at 100."
        for m in llm.chat.call_args.kwargs["messages"]
    )


def test_research_and_full_context_use_the_same_output_contract(monkeypatch, report_data):
    tc = SimpleNamespace(prompt_text="Check Revenue", expected_output_text="")
    toolbox = Mock()
    toolbox.manifest_text.return_value = "input.csv"
    monkeypatch.setattr(research, "DocumentToolbox", Mock(return_value=toolbox))
    monkeypatch.setattr(research, "run_tool_loop", Mock(return_value="Investigation"))
    monkeypatch.setattr(generation, "build_context", Mock(return_value="Revenue=100"))
    llm = Mock(spec=LLMClient)
    llm.chat.return_value = _response(json.dumps(report_data))
    assert research.generate_research_document(tc, Mock(), "Check", llm).title
    assert generation._generate_full_context(tc, Mock(), "Check", llm).title
    assert all(
        call.kwargs["response_format"] == REPORT_FORMAT
        for call in llm.chat.call_args_list
    )


def test_harness_repairs_invalid_draft_without_repeating_investigation(
    monkeypatch, report_data
):
    monkeypatch.setattr(harness, "_materialise", Mock(return_value="documents/"))
    monkeypatch.setattr(harness, "DocumentToolbox", Mock())
    run_harness = Mock()

    async def draft(*args):
        run_harness()
        return '{"unexpected_shape": "Revenue=100, input.csv row 2"}'

    monkeypatch.setattr(harness, "_run_harness", draft)
    llm = Mock(spec=LLMClient)
    llm.chat.return_value = _response(json.dumps(report_data))
    assert harness.generate_harness_document(Mock(), Mock(), "Check", llm).title
    run_harness.assert_called_once()
    assert "Revenue=100, input.csv row 2" in llm.chat.call_args.kwargs["messages"][1]["content"]


def test_configured_failure_is_not_an_offline_success(monkeypatch):
    monkeypatch.setattr(generation, "_generate_llm", Mock(side_effect=ValueError("bad report")))
    offline = Mock()
    monkeypatch.setattr(generation, "_generate_offline", offline)
    with pytest.raises(RuntimeError, match="LLM report generation failed"):
        generation.generate_document(Mock(), Mock(), "Check", Mock(available=True))
    offline.assert_not_called()
    offline.return_value = Mock()
    assert generation.generate_document(Mock(), Mock(), "Check", Mock(available=False))[1] == "offline"
    offline.assert_called_once()


def test_background_job_surfaces_failure_without_a_run():
    service = SuperAgentService.__new__(SuperAgentService)
    service._jobs = {}
    service._jobs_lock = threading.Lock()
    service._scheduler = get_case_scheduler()

    def fail():
        raise RuntimeError("LLM report generation failed: invalid schema")

    job_id = service._start(fail)
    deadline = time.monotonic() + 2
    status = service.job_status(job_id)
    while status and not status["done"] and time.monotonic() < deadline:
        time.sleep(0.01)
        status = service.job_status(job_id)
    assert status is not None and status["done"]
    assert status["stage"] == "error"
    assert status["error"] == "LLM report generation failed: invalid schema"
    assert status["run"] is None


def test_all_strategies_failing_propagates_error(monkeypatch):
    monkeypatch.setattr(settings, "super_agent_use_harness", False)
    monkeypatch.setattr(settings, "super_agent_deep_research", True)
    monkeypatch.setattr(settings, "super_agent_tool_retrieval", True)
    monkeypatch.setattr(generation, "economy_mode", lambda: False)
    monkeypatch.setattr(research, "generate_research_document", Mock(side_effect=ValueError("research")))
    monkeypatch.setattr(generation, "_generate_agentic", Mock(side_effect=ValueError("retrieval")))
    monkeypatch.setattr(generation, "_generate_full_context", Mock(side_effect=ValueError("composition")))
    with pytest.raises(RuntimeError, match="composition"):
        generation.generate_document(Mock(), Mock(), "Check", Mock(available=True))


@pytest.mark.parametrize("method,req", [
    ("generate", SimpleNamespace(
        test_case_id="tc1", use_expected_template=False, economy=False,
        reasoning_effort="high", run_title="Review", description="",
        report_version=None, reporting_period=None, reporting_year=None,
        one_off_prompt=None,
    )),
    ("regenerate", SimpleNamespace(
        run_id="run1", use_expected_template=False, economy=False,
        reasoning_effort="high",
        report_version=None, reporting_period=None, reporting_year=None,
        one_off_prompt=None,
    )),
])
def test_sync_api_surfaces_generation_failure(monkeypatch, method, req):
    from fastapi import HTTPException
    from gardianai_agentharness.api.routes import super_agent as routes

    service = Mock()
    getattr(service, method).side_effect = RuntimeError("LLM report generation failed")
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    with pytest.raises(HTTPException) as error:
        getattr(routes, method)(req)
    assert error.value.status_code == 502
    assert error.value.detail == "LLM report generation failed"
