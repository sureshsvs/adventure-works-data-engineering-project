"""Exercise the actual frontend API and admission workflow with existing tsc/Node."""

from __future__ import annotations

import json
from pathlib import Path
import shutil
import subprocess

import pytest


FRONTEND = Path(__file__).resolve().parents[1] / "frontend"


@pytest.fixture(scope="module")
def compiled_frontend(tmp_path_factory):
    compiler = FRONTEND / "node_modules" / ".bin" / "tsc"
    if not compiler.exists() or not shutil.which("node"):
        pytest.skip("Existing frontend dependencies and Node are required")
    output = tmp_path_factory.mktemp("task-batch-build")
    try:
        (output / "package.json").write_text('{"type":"module"}')
        (output / "node_modules").symlink_to(
            FRONTEND / "node_modules", target_is_directory=True,
        )
        result = subprocess.run(
            [
                str(compiler), "--target", "ES2020", "--module", "ESNext",
                "--moduleResolution", "bundler", "--lib", "ES2020,DOM,DOM.Iterable",
                "--skipLibCheck", "--rootDir", "src", "--outDir", str(output),
                "src/vite-env.d.ts", "src/types.ts", "src/services/api.ts",
                "src/services/taskBatchAdmission.ts",
            ],
            cwd=FRONTEND, capture_output=True, text=True, timeout=60,
        )
        assert result.returncode == 0, result.stdout + result.stderr
        # Node does not provide Vite's import.meta.env or extension resolution.
        api_file = output / "services" / "api.js"
        api_file.write_text(
            api_file.read_text().replace("import.meta.env.VITE_API_URL", "undefined")
        )
        admission_file = output / "services" / "taskBatchAdmission.js"
        admission_file.write_text(
            admission_file.read_text().replace("from './api'", "from './api.js'")
        )
        yield admission_file.as_uri()
    finally:
        shutil.rmtree(output)


NODE_WORKFLOW = r"""
import axios, { AxiosError } from 'axios';
const scenario = JSON.parse(process.argv[1]);
const requests = [], waits = [], messages = [], events = [];
let now = 1760000000000, starts = 0;
Date.now = () => now;
globalThis.window = {
  setTimeout(callback, ms) {
    waits.push(ms);
    now += ms;
    queueMicrotask(callback);
    return waits.length;
  },
  clearTimeout() {},
};
axios.defaults.adapter = async (config) => {
  const response = (data, status = 200, headers = {}) => ({
    data, status, headers, config, statusText: String(status),
  });
  if (config.url === '/.auth/me') return response([]);
  requests.push({ url: config.url, body: JSON.parse(config.data), timeout: config.timeout });
  if (config.url.endsWith('/preflight')) {
    events.push('preflight');
    if (scenario.preflightStatus) {
      const rejected = response({ detail: 'Preparation service unavailable' }, scenario.preflightStatus);
      throw new AxiosError('Preparation rejected', undefined, config, undefined, rejected);
    }
    return response(scenario.preflight ?? { valid: true, errors: [] });
  }
  events.push('admission');
  starts++;
  now += scenario.requestDuration ?? 0;
  if (scenario.networkError) throw new AxiosError('Network Error', 'ERR_NETWORK', config);
  const statuses = scenario.statuses ?? [200];
  const status = statuses[Math.min(starts - 1, statuses.length - 1)];
  if (status !== 200) {
    const header = scenario.retryAfter === 'date'
      ? new Date(now + 6000).toUTCString() : scenario.retryAfter;
    const rejected = response({
      detail: scenario.detail ?? 'Admission rejected',
    }, status, { 'retry-after': header });
    throw new AxiosError('Admission rejected', undefined, config, undefined, rejected);
  }
  return response({ batch_id: 'accepted-batch', job_id: 'accepted-batch' });
};
const { prepareAndAdmitTaskBatch } = await import(MODULE_URL);
const controller = new AbortController();
let result, failure;
try {
  result = await prepareAndAdmitTaskBatch(
    ['task-a', 'task-b'],
    {
      runTitle: '  Quarterly review  ', description: '  Evidence  ',
      period: scenario.omitPeriod ? undefined : '2026-Q4', ...scenario.options,
    },
    controller.signal,
    (message) => messages.push(message),
    () => events.push('prepared'),
  );
} catch (error) {
  failure = {
    message: error.message, errors: error.errors,
    status: error.response?.status, detail: error.response?.data?.detail,
  };
}
console.log(JSON.stringify({ result, failure, requests, waits, messages, events, starts }));
"""


def workflow(compiled_frontend, **scenario):
    script = NODE_WORKFLOW.replace("MODULE_URL", json.dumps(compiled_frontend))
    result = subprocess.run(
        ["node", "--input-type=module", "--eval", script, json.dumps(scenario)],
        cwd=FRONTEND, capture_output=True, text=True, timeout=20,
    )
    assert result.returncode == 0, result.stdout + result.stderr
    return json.loads(result.stdout)


def test_payload_and_authoritative_preflight_sequence(compiled_frontend):
    result = workflow(compiled_frontend, options={
        "grouping": "Finance", "maxParallelCases": 4, "economy": True,
        "reasoningEffort": "medium", "useExpectedTemplate": True,
    })
    assert result["events"] == ["preflight", "prepared", "admission"]
    assert result["result"] == {"batch_id": "accepted-batch", "job_id": "accepted-batch"}
    assert result["requests"][0] == {
        "url": "/super-agent/tasks/generate/preflight",
        "body": {"task_ids": ["task-a", "task-b"], "period": "2026-Q4"},
        "timeout": 30000,
    }
    admission = result["requests"][1]
    assert admission["url"] == "/super-agent/tasks/generate/batch/start"
    assert admission["body"] == {
        "task_ids": ["task-a", "task-b"], "run_title": "Quarterly review",
        "description": "Evidence", "period": "2026-Q4", "grouping": "Finance",
        "max_parallel_cases": 4, "economy": True, "reasoning_effort": "medium",
        "use_expected_template": True,
    }
    assert 0 < admission["timeout"] <= 15000


def test_default_grouping_and_parallelism(compiled_frontend):
    result = workflow(compiled_frontend)
    assert result["requests"][1]["body"]["grouping"] == ""
    assert result["requests"][1]["body"]["max_parallel_cases"] == 1


def test_periodless_tasks_are_admitted_after_server_preflight(compiled_frontend):
    result = workflow(compiled_frontend, omitPeriod=True)
    assert result["events"] == ["preflight", "prepared", "admission"]
    assert "period" not in result["requests"][0]["body"]
    assert "period" not in result["requests"][1]["body"]
    assert result["result"]["batch_id"] == "accepted-batch"


def test_period_scoped_tasks_without_period_are_blocked_by_server(compiled_frontend):
    errors = [{"task_id": "task-a", "detail": "A period is required for this task"}]
    result = workflow(
        compiled_frontend, omitPeriod=True, preflight={"valid": False, "errors": errors},
    )
    assert result["events"] == ["preflight"]
    assert "period" not in result["requests"][0]["body"]
    assert result["starts"] == 0
    assert result["failure"]["errors"] == errors


@pytest.mark.parametrize("valid", [False, True])
def test_preflight_errors_never_reach_admission(compiled_frontend, valid):
    errors = [{"task_id": "task-b", "detail": "Ledger missing for period"}]
    result = workflow(compiled_frontend, preflight={"valid": valid, "errors": errors})
    assert result["starts"] == 0
    assert result["events"] == ["preflight"]
    assert result["failure"]["errors"] == errors
    assert "no batch was queued" in result["failure"]["message"]


def test_invalid_preflight_without_details_still_blocks(compiled_frontend):
    result = workflow(compiled_frontend, preflight={"valid": False, "errors": []})
    assert result["starts"] == 0
    assert result["failure"]["errors"] == []


@pytest.mark.parametrize("status", [404, 422, 429])
def test_preflight_http_errors_are_not_retried(compiled_frontend, status):
    result = workflow(compiled_frontend, preflightStatus=status)
    assert len(result["requests"]) == 1
    assert result["starts"] == 0
    assert result["failure"]["status"] == status
    assert result["waits"] == []


def test_atomic_422_detail_is_preserved_and_never_retried(compiled_frontend):
    detail = {
        "message": "Task preparation changed",
        "errors": [{"task_id": "task-a", "detail": "Prompt no longer exists"}],
    }
    result = workflow(compiled_frontend, statuses=[422], detail=detail)
    assert result["starts"] == 1
    assert result["failure"]["status"] == 422
    assert result["failure"]["detail"] == detail
    assert result["waits"] == []


@pytest.mark.parametrize("status", [404, 500])
def test_unknown_http_errors_are_not_retried(compiled_frontend, status):
    result = workflow(compiled_frontend, statuses=[status])
    assert result["starts"] == 1
    assert result["failure"]["status"] == status
    assert result["waits"] == []


def test_network_outcome_is_not_retried(compiled_frontend):
    result = workflow(compiled_frontend, networkError=True)
    assert result["starts"] == 1
    assert result["failure"]["message"] == "Network Error"
    assert result["waits"] == []


def test_429_exponential_backoff_then_success(compiled_frontend):
    result = workflow(compiled_frontend, statuses=[429, 429, 429, 200])
    assert result["starts"] == 4
    assert result["waits"] == [1000, 2000, 4000]
    assert result["events"].count("preflight") == 1
    assert result["result"]["batch_id"] == "accepted-batch"
    assert len(result["messages"]) == 3


def test_429_exhausts_after_three_retries(compiled_frontend):
    result = workflow(compiled_frontend, statuses=[429])
    assert result["starts"] == 4
    assert result["waits"] == [1000, 2000, 4000]
    assert "exhausted" in result["failure"]["message"]
    assert "No batch was accepted" in result["failure"]["message"]


@pytest.mark.parametrize(("retry_after", "expected"), [("5", 5000), ("date", 6000), ("invalid", 1000)])
def test_retry_after_seconds_date_and_fallback(compiled_frontend, retry_after, expected):
    result = workflow(compiled_frontend, statuses=[429, 200], retryAfter=retry_after)
    assert result["starts"] == 2
    assert result["waits"] == [expected]


def test_retry_after_beyond_wait_budget_does_not_retry_early(compiled_frontend):
    result = workflow(compiled_frontend, statuses=[429], retryAfter="120")
    assert result["starts"] == 1
    assert result["waits"] == []
    assert "exhausted" in result["failure"]["message"]


def test_cumulative_wait_budget_is_bounded(compiled_frontend):
    result = workflow(compiled_frontend, statuses=[429], retryAfter="20")
    assert result["starts"] == 2
    assert result["waits"] == [20000]
    assert "exhausted" in result["failure"]["message"]


def test_overall_admission_deadline_is_bounded(compiled_frontend):
    result = workflow(compiled_frontend, statuses=[429], requestDuration=19000)
    assert result["starts"] == 3
    assert result["waits"] == [1000, 2000]
    assert "exhausted" in result["failure"]["message"]
