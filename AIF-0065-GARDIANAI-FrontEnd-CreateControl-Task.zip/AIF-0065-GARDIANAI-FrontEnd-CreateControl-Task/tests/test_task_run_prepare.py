from __future__ import annotations

from datetime import datetime, timezone

import pytest

from gardianai_agentharness.services import task_store as ts_module
from gardianai_agentharness.services.document_store import Task
from gardianai_agentharness.services.task_run import (
    TaskRunValidationError,
    prepare_task_run,
)


def _store(monkeypatch, tmp_path, entries):
    monkeypatch.setattr(ts_module.settings, "sample_data_cache_dir", str(tmp_path))
    monkeypatch.setattr(
        ts_module.blob_storage,
        "list_task_blobs",
        lambda prefix: [e for name, e in entries.items() if name.startswith(prefix)],
    )

    class FakeContainer:
        def query_items(self, query, **kwargs):
            return []

    return ts_module.TaskStore(cosmos_container=FakeContainer())


def test_prepare_task_run_renders_and_merges(monkeypatch, tmp_path):
    modified = datetime(2026, 1, 1, tzinfo=timezone.utc)
    entries = {
        "Quarterly/2025-Q4/External/QRA/current.pdf": (
            "Quarterly/2025-Q4/External/QRA/current.pdf", 10, modified,
        ),
        "Quarterly/2025-Q3/External/QRA/previous.pdf": (
            "Quarterly/2025-Q3/External/QRA/previous.pdf", 10, modified,
        ),
    }
    store = _store(monkeypatch, tmp_path, entries)
    task = Task(
        id="t1",
        title="t",
        logical_source_role_names=["Current QRA draft"],
        prompt_name="review",
        prompt_text="Period {{Period}} segment {{SEGMENT}} prev {{DOC:QRA@PQ}}",
        task_scalars={"SEGMENT": "Integrated Gas"},
    )

    run_task = prepare_task_run(store, task, "2025-Q4", {"CQ": "2025-Q4"})

    assert run_task.prompt_text == (
        "Period 2025-Q4 segment Integrated Gas prev previous.pdf"
    )
    # Default role doc + prompt-referenced doc, deduped by path.
    assert sorted(d.name for d in run_task.input_documents) == [
        "current.pdf",
        "previous.pdf",
    ]


def test_prepare_task_run_requires_period(monkeypatch, tmp_path):
    store = _store(monkeypatch, tmp_path, {})
    task = Task(
        id="t1", title="t", logical_source_role_names=[], prompt_name="p",
        prompt_text="needs {{Period}}",
    )
    with pytest.raises(TaskRunValidationError):
        prepare_task_run(store, task, None, {})


def test_prepare_task_run_unresolved_role(monkeypatch, tmp_path):
    store = _store(monkeypatch, tmp_path, {})
    task = Task(
        id="t1", title="t",
        logical_source_role_names=["Current QRA draft"],
        prompt_name="p", prompt_text="hi",
    )
    with pytest.raises(TaskRunValidationError):
        prepare_task_run(store, task, "2025-Q4", {})


def test_prepare_task_run_missing_variable(monkeypatch, tmp_path):
    store = _store(monkeypatch, tmp_path, {})
    task = Task(
        id="t1", title="t", logical_source_role_names=[], prompt_name="p",
        prompt_text="hello {{SEGMENT}}",
    )
    with pytest.raises(TaskRunValidationError):
        prepare_task_run(store, task, "2025-Q4", {})


def test_prepare_task_run_unresolved_document_reference(monkeypatch, tmp_path):
    store = _store(monkeypatch, tmp_path, {})
    task = Task(
        id="t1", title="t", logical_source_role_names=[], prompt_name="p",
        prompt_text="{{DOC:QRA@CQ}}",
    )
    with pytest.raises(TaskRunValidationError):
        prepare_task_run(store, task, "2025-Q4", {})
