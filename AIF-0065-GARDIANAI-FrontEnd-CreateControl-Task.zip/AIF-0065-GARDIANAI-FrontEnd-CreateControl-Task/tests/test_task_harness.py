from __future__ import annotations

from gardianai_agentharness.services.document_store import Task
from gardianai_agentharness.services import super_agent_retrieval


def test_task_toolbox_enables_web_and_skips_shared_corpus(monkeypatch):
    task = Task(
        id="task-id",
        title="Task",
        logical_source_role_names=[],
        prompt_name="prompt",
    )

    class Store:
        def get_text(self, doc_id):
            return ""

        def list_test_cases(self):
            raise AssertionError("Task retrieval must not expand the shared corpus")

    monkeypatch.setattr(super_agent_retrieval.settings, "super_agent_shared_corpus", True)
    monkeypatch.setattr(super_agent_retrieval, "fetch_web", lambda url: "web source text")

    toolbox = super_agent_retrieval.DocumentToolbox(task, Store())

    assert "web" in toolbox.manifest_text().lower()