"""Unit tests for per-stage LLM + OCR usage tracking."""

from __future__ import annotations

from gardianai_agentharness.services import super_agent_context as ctx
from gardianai_agentharness.services.models import (
    GenerationRun,
    generation_run_from_dict,
)


class _Usage:
    def __init__(self, prompt: int, completion: int, total: int) -> None:
        self.prompt_tokens = prompt
        self.completion_tokens = completion
        self.total_tokens = total


def test_usage_attributed_to_current_stage_and_grand_total():
    ctx.reset_tokens()
    ctx.report("analyze", "planning")
    ctx.record_usage(_Usage(100, 40, 140))
    ctx.report("compose", "writing")
    ctx.record_usage(_Usage(200, 60, 260))

    totals = ctx.token_totals()
    assert totals["by_stage"]["analyze"] == {
        "prompt": 100, "completion": 40, "total": 140,
    }
    assert totals["by_stage"]["compose"] == {
        "prompt": 200, "completion": 60, "total": 260,
    }
    assert totals["total"] == {"prompt": 300, "completion": 100, "total": 400}


def test_total_tokens_inferred_when_absent():
    ctx.reset_tokens()
    ctx.report("analyze")
    ctx.record_usage({"prompt_tokens": 10, "completion_tokens": 5})
    assert ctx.token_totals()["total"]["total"] == 15


def test_agent_framework_field_names_supported():
    ctx.reset_tokens()
    ctx.report("analyze")
    ctx.record_usage(
        {"input_token_count": 7, "output_token_count": 3, "total_token_count": 10}
    )
    assert ctx.token_totals()["total"] == {"prompt": 7, "completion": 3, "total": 10}


def test_ocr_tracked_separately_from_tokens():
    ctx.reset_tokens()
    ctx.report("analyze")
    ctx.record_ocr(12)
    ctx.record_ocr(6, requests=1)
    totals = ctx.token_totals()
    assert totals["ocr"] == {"requests": 2, "pages": 18}
    assert totals["total"]["total"] == 0


def test_token_cb_receives_live_snapshot():
    ctx.reset_tokens()
    seen: list[int] = []
    ctx.set_token_cb(lambda snap: seen.append(snap["total"]["total"]))
    ctx.report("analyze")
    ctx.record_usage(_Usage(10, 5, 15))
    ctx.record_usage(_Usage(20, 0, 20))
    ctx.set_token_cb(None)
    assert seen == [15, 35]


def test_no_tracker_is_a_safe_noop():
    ctx.reset_tokens()  # establish a tracker, then clear it
    ctx._TOKENS.set(None)
    ctx.record_usage(_Usage(1, 1, 2))  # must not raise
    ctx.record_ocr(3)  # must not raise


def test_token_usage_roundtrips_through_generation_run():
    usage = {
        "by_stage": {"analyze": {"prompt": 1, "completion": 2, "total": 3}},
        "total": {"prompt": 1, "completion": 2, "total": 3},
        "ocr": {"requests": 1, "pages": 4},
    }
    run = GenerationRun(
        test_case_id="tc1",
        test_case_title="t",
        prompt_version="v1",
        model="m",
        mode="llm",
        token_usage=usage,
    )
    restored = generation_run_from_dict(run.to_dict())
    assert restored.token_usage == usage
