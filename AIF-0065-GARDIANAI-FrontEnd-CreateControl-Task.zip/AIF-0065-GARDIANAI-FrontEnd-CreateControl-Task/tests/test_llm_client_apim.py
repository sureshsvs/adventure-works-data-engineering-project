"""Offline (mocked) checks for the APIM project-gateway LLM client path."""

from __future__ import annotations

import asyncio
import sys
import types
from unittest.mock import MagicMock, Mock

import pytest

from gardianai_agentharness.config import Settings, settings
from gardianai_agentharness.services import llm_client
from gardianai_agentharness.services import super_agent_harness as harness

_APIM_ENV = (
    "APIM_ENDPOINT",
    "APIM_API_KEY",
    "APIM_SUBSCRIPTION_KEY",
    "APIM_SUB_KEY",
    "APIM_FOUNDRY_NAME",
    "APIM_PROJECT_NAME",
)


@pytest.fixture
def no_cached_clients(monkeypatch):
    monkeypatch.setattr(llm_client, "_harness", None)
    monkeypatch.setattr(llm_client, "_super_agent", None)


@pytest.fixture
def gateway_settings(monkeypatch):
    monkeypatch.setattr(settings, "apim_endpoint", "https://apim.example.test/project")
    monkeypatch.setattr(settings, "apim_api_key", "")
    monkeypatch.setattr(settings, "apim_subscription_key", "sub-key")
    monkeypatch.setattr(settings, "apim_sub_key", "")
    monkeypatch.setattr(settings, "apim_foundry_name", "my-foundry")
    monkeypatch.setattr(settings, "apim_project_name", "my-project")
    monkeypatch.setattr(settings, "azure_client_id", "umi-client-id")
    monkeypatch.setattr(settings, "azure_ai_foundry_endpoint", "")
    monkeypatch.setattr(settings, "azure_ai_foundry_api_key", "")
    monkeypatch.setattr(settings, "azure_llm_use_managed_identity", False)
    monkeypatch.setattr(settings, "agent_model_deployment_name", "harness-model")
    monkeypatch.setattr(settings, "super_agent_model", "super-model")


@pytest.fixture
def fake_sdk(monkeypatch):
    """Fake azure.ai.projects / azure.identity (sync) modules."""
    project_client = Mock(name="project_client")
    project_client.get_openai_client.return_value = Mock(name="openai_client")
    project_cls = Mock(return_value=project_client)
    credential_cls = Mock(name="DefaultAzureCredential")
    monkeypatch.setitem(
        sys.modules, "azure.ai.projects", types.SimpleNamespace(AIProjectClient=project_cls)
    )
    monkeypatch.setitem(
        sys.modules,
        "azure.identity",
        types.SimpleNamespace(DefaultAzureCredential=credential_cls),
    )
    return types.SimpleNamespace(
        project_cls=project_cls, project_client=project_client, credential_cls=credential_cls
    )


# --- configuration ---------------------------------------------------------


def _settings_from_env(monkeypatch, **env: str) -> Settings:
    for name in _APIM_ENV:
        monkeypatch.delenv(name, raising=False)
    for name, value in env.items():
        monkeypatch.setenv(name, value)
    return Settings(_env_file=None)


def test_subscription_key_takes_precedence_over_legacy_sub_key(monkeypatch):
    s = _settings_from_env(monkeypatch, APIM_SUBSCRIPTION_KEY="new", APIM_SUB_KEY="legacy")
    assert s.apim_gateway_subscription_key == "new"


def test_legacy_sub_key_is_used_when_subscription_key_unset(monkeypatch):
    s = _settings_from_env(monkeypatch, APIM_SUB_KEY="legacy")
    assert s.apim_gateway_subscription_key == "legacy"


def test_gateway_enabled_only_when_fully_configured(monkeypatch):
    full = {
        "APIM_ENDPOINT": "https://apim.example.test",
        "APIM_SUBSCRIPTION_KEY": "k",
        "APIM_FOUNDRY_NAME": "f",
        "APIM_PROJECT_NAME": "p",
    }
    s = _settings_from_env(monkeypatch, **full)
    assert s.apim_gateway_enabled and s.apim_gateway_requested and s.llm_enabled

    for missing in full:
        partial = {k: v for k, v in full.items() if k != missing}
        assert not _settings_from_env(monkeypatch, **partial).apim_gateway_enabled

    s = _settings_from_env(monkeypatch)
    assert not s.apim_gateway_requested and not s.apim_gateway_enabled


# --- headers + client construction -----------------------------------------


def test_gateway_headers_names_and_values(gateway_settings):
    assert llm_client.apim_gateway_headers() == {
        "Ocp-Apim-Subscription-Key": "sub-key",
        "foundryMode": "new",
        "foundryName": "my-foundry",
        "projectName": "my-project",
    }


def test_gateway_headers_use_legacy_sub_key(gateway_settings, monkeypatch):
    monkeypatch.setattr(settings, "apim_subscription_key", "")
    monkeypatch.setattr(settings, "apim_sub_key", "legacy-key")
    assert llm_client.apim_gateway_headers()["Ocp-Apim-Subscription-Key"] == "legacy-key"


def test_gateway_mode_selected_for_both_clients(
    gateway_settings, fake_sdk, no_cached_clients
):
    harness_client = llm_client.get_harness_llm_client()
    super_client = llm_client.get_super_agent_llm_client()

    assert harness_client.label == super_client.label == "apim-gateway"
    assert harness_client.available and super_client.available
    assert harness_client.model == "harness-model"
    assert super_client.model == "super-model"
    fake_sdk.credential_cls.assert_called_with(managed_identity_client_id="umi-client-id")
    fake_sdk.project_cls.assert_called_with(
        endpoint="https://apim.example.test/project",
        credential=fake_sdk.credential_cls.return_value,
    )
    fake_sdk.project_client.get_openai_client.assert_called_with(
        default_headers=llm_client.apim_gateway_headers()
    )
    # The project client is kept open while the OpenAI client is in use.
    fake_sdk.project_client.close.assert_not_called()


def test_gateway_chat_uses_open_project_openai_client(gateway_settings, fake_sdk):
    client = llm_client._build_apim_gateway("m")
    openai_client = fake_sdk.project_client.get_openai_client.return_value
    openai_client.chat.completions.create.return_value = Mock(usage=None)

    client.chat([{"role": "user", "content": "hi"}])

    kwargs = openai_client.chat.completions.create.call_args.kwargs
    assert kwargs["model"] == "m"
    openai_client.close.assert_not_called()
    fake_sdk.project_client.close.assert_not_called()

    close_order = []
    openai_client.close.side_effect = lambda: close_order.append("openai")
    fake_sdk.project_client.close.side_effect = lambda: close_order.append("project")
    fake_sdk.credential_cls.return_value.close.side_effect = lambda: close_order.append(
        "credential"
    )
    client.close()
    openai_client.close.assert_called_once()
    fake_sdk.project_client.close.assert_called_once()
    fake_sdk.credential_cls.return_value.close.assert_called_once()
    assert close_order == ["openai", "project", "credential"]
    assert not client.available
    with pytest.raises(RuntimeError):
        client.chat([{"role": "user", "content": "hi"}])


def test_app_shutdown_closes_and_clears_cached_clients(monkeypatch):
    from gardianai_agentharness.main import app

    harness_client = Mock()
    super_agent_client = Mock()
    monkeypatch.setattr(llm_client, "_harness", harness_client)
    monkeypatch.setattr(llm_client, "_super_agent", super_agent_client)

    async def run_lifespan():
        async with app.router.lifespan_context(app):
            pass

    asyncio.run(run_lifespan())

    harness_client.close.assert_called_once()
    super_agent_client.close.assert_called_once()
    assert llm_client._harness is None
    assert llm_client._super_agent is None


# --- fallback / offline ----------------------------------------------------


def test_incomplete_gateway_falls_back_to_apim_key_path(
    gateway_settings, fake_sdk, no_cached_clients, monkeypatch, caplog
):
    monkeypatch.setattr(settings, "apim_project_name", "")
    monkeypatch.setattr(settings, "apim_api_key", "legacy-api-key")

    client = llm_client.get_harness_llm_client()

    assert client.label == "apim"
    fake_sdk.project_cls.assert_not_called()
    assert "APIM_PROJECT_NAME" in caplog.text
    assert "sub-key" not in caplog.text


def test_gateway_sdk_failure_falls_back(gateway_settings, no_cached_clients, monkeypatch):
    project_cls = Mock(side_effect=ImportError("no azure-ai-projects"))
    monkeypatch.setitem(
        sys.modules, "azure.ai.projects", types.SimpleNamespace(AIProjectClient=project_cls)
    )
    monkeypatch.setitem(
        sys.modules, "azure.identity", types.SimpleNamespace(DefaultAzureCredential=Mock())
    )

    assert not llm_client._build_apim_gateway("m").available
    # Nothing else configured -> offline.
    assert not llm_client.get_super_agent_llm_client().available


def test_offline_when_nothing_configured(gateway_settings, no_cached_clients, monkeypatch):
    for name in ("apim_endpoint", "apim_subscription_key", "apim_foundry_name", "apim_project_name"):
        monkeypatch.setattr(settings, name, "")

    assert not llm_client.get_harness_llm_client().available
    assert not llm_client.get_super_agent_llm_client().available
    assert not settings.llm_enabled


# --- Agent Framework harness ----------------------------------------------


class _AsyncCM:
    def __init__(self, name: str, events: list[str], value=None):
        self.name, self.events, self.value = name, events, value

    async def __aenter__(self):
        self.events.append(f"enter:{self.name}")
        return self if self.value is None else self.value

    async def __aexit__(self, *exc):
        self.events.append(f"exit:{self.name}")


def test_harness_gateway_client_scope(gateway_settings, monkeypatch):
    events: list[str] = []
    openai_client = _AsyncCM("openai", events)
    project_client = _AsyncCM("project", events)
    project_client.get_openai_client = Mock(return_value=openai_client)
    project_cls = Mock(return_value=project_client)
    credential = _AsyncCM("credential", events)
    credential_cls = Mock(return_value=credential)
    chat_client_cls = MagicMock()
    monkeypatch.setitem(
        sys.modules, "azure.ai.projects.aio", types.SimpleNamespace(AIProjectClient=project_cls)
    )
    monkeypatch.setitem(
        sys.modules,
        "azure.identity.aio",
        types.SimpleNamespace(DefaultAzureCredential=credential_cls),
    )
    monkeypatch.setitem(
        sys.modules, "agent_framework.openai", types.SimpleNamespace(OpenAIChatClient=chat_client_cls)
    )
    build_af = Mock()
    monkeypatch.setattr(harness, "_build_af_client", build_af)

    async def run():
        async with harness._af_client_scope() as client:
            assert client is chat_client_cls.return_value
            assert "exit:openai" not in events  # still open during the run
            return client

    asyncio.run(run())

    build_af.assert_not_called()
    credential_cls.assert_called_once_with(managed_identity_client_id="umi-client-id")
    project_cls.assert_called_once_with(
        endpoint="https://apim.example.test/project", credential=credential
    )
    project_client.get_openai_client.assert_called_once_with(
        default_headers=llm_client.apim_gateway_headers()
    )
    chat_client_cls.assert_called_once_with(model="super-model", async_client=openai_client)
    assert events == [
        "enter:credential",
        "enter:project",
        "enter:openai",
        "exit:openai",
        "exit:project",
        "exit:credential",
    ]


def test_harness_uses_existing_client_without_gateway(gateway_settings, monkeypatch):
    monkeypatch.setattr(settings, "apim_foundry_name", "")
    sentinel = object()
    monkeypatch.setattr(harness, "_build_af_client", Mock(return_value=sentinel))

    async def run():
        async with harness._af_client_scope() as client:
            return client

    assert asyncio.run(run()) is sentinel
