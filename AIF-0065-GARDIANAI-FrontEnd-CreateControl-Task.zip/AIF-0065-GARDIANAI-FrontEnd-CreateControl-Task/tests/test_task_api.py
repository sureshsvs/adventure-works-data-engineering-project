from __future__ import annotations

from contextlib import nullcontext

from fastapi import FastAPI
from fastapi.testclient import TestClient

from gardianai_agentharness.api.routes import tasks as task_routes
from gardianai_agentharness.api.routes import super_agent as super_agent_routes
from gardianai_agentharness.services.document_store import DocumentRef, Task


def test_create_task_returns_registered_task_summary(monkeypatch):
    task = Task(
        id="task-id",
        title="Quarterly report review",
        logical_source_role_names=["quarterly-report"],
        prompt_name="quarterly-review",
        description="Review report for completeness",
        created_by=None,
        last_modified="2026-10-14T12:30:00Z",
        prompt_text="large prompt omitted from response",
        input_documents=[
            DocumentRef(
                id="document-id",
                name="report.pdf",
                path="/cache/report.pdf",
                doc_type="pdf",
                kind="input",
                test_case_id="task-id",
                size_bytes=123,
            )
        ],
    )

    class FakeTaskStore:
        def register_task(self, **kwargs):
            assert kwargs == {
                "title": "Quarterly report review",
                "logical_source_role_names": ["quarterly-report"],
                "prompt_name": "quarterly-review",
                "description": "Review report for completeness",
                "created_by": None,
                "task_scalars": None,
            }
            return task

    monkeypatch.setattr(task_routes, "get_task_store", lambda: FakeTaskStore())
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")

    response = TestClient(app).post(
        "/api/tasks",
        json={
            "title": "Quarterly report review",
            "logical_source_role_names": ["quarterly-report"],
            "prompt_name": "quarterly-review",
            "description": "Review report for completeness",
        },
    )

    assert response.status_code == 201
    body = response.json()
    assert body["id"] == "task-id"
    assert body["created_by"] is None
    assert body["description"] == "Review report for completeness"
    # No period supplied: period-scoped input documents are omitted.
    assert "input_documents" not in body
    assert "prompt_text" not in body


def test_create_task_maps_duplicate_title_to_conflict(monkeypatch):
    from gardianai_agentharness.services.task_store import DuplicateTaskTitleError

    class FakeTaskStore:
        def register_task(self, **kwargs):
            raise DuplicateTaskTitleError("Task title already exists")

    monkeypatch.setattr(task_routes, "get_task_store", lambda: FakeTaskStore())
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")

    response = TestClient(app).post(
        "/api/tasks",
        json={"title": "A", "logical_source_role_names": [], "prompt_name": "prompt"},
    )

    assert response.status_code == 409


def test_list_tasks_returns_ordered_summaries_without_prompt_text(monkeypatch):
    tasks = [
        Task(
            id="a-task",
            title="Alpha task",
            logical_source_role_names=["alpha"],
            prompt_name="alpha-prompt",
            created_by="creator",
            modified_by=None,
            last_modified="2026-10-14T12:30:00Z",
            prompt_text="large prompt omitted",
        ),
        Task(
            id="b-task",
            title="Beta task",
            logical_source_role_names=["beta"],
            prompt_name="beta-prompt",
            created_by=None,
            modified_by="editor",
            last_modified="2026-10-15T12:30:00Z",
            prompt_text="another large prompt omitted",
            input_documents=[
                DocumentRef(
                    id="document-id",
                    name="beta.pdf",
                    path="/cache/beta.pdf",
                    doc_type="pdf",
                    kind="input",
                    test_case_id="b-task",
                    size_bytes=456,
                )
            ],
        ),
    ]

    class FakeTaskStore:
        def list_tasks(self):
            return tasks

    monkeypatch.setattr(task_routes, "get_task_store", lambda: FakeTaskStore())
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")

    response = TestClient(app).get("/api/tasks")

    assert response.status_code == 200
    body = response.json()
    assert [task["id"] for task in body["tasks"]] == ["a-task", "b-task"]
    assert body["tasks"][1]["modified_by"] == "editor"
    # GET /tasks is period-neutral: no period-scoped input documents.
    assert all("input_documents" not in task for task in body["tasks"])
    assert all("prompt_text" not in task for task in body["tasks"])


def test_list_tasks_returns_empty_array_when_store_has_no_tasks(monkeypatch):
    class FakeTaskStore:
        def list_tasks(self):
            return []

    monkeypatch.setattr(task_routes, "get_task_store", lambda: FakeTaskStore())
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")

    response = TestClient(app).get("/api/tasks")

    assert response.status_code == 200
    assert response.json() == {"tasks": []}


def test_update_task_returns_summary_and_maps_errors(monkeypatch):
    from gardianai_agentharness.services.task_store import DuplicateTaskTitleError

    task = Task(
        id="task-id",
        title="Updated task",
        description="Updated description",
        logical_source_role_names=["source"],
        prompt_name="review",
        created_by="creator",
        modified_by="editor",
        last_modified="2026-10-19T12:00:00Z",
    )

    class FakeTaskStore:
        error = None
        result = task

        def update_task(self, task_id, **kwargs):
            assert task_id == "task-id"
            assert kwargs == {
                "title": "Updated task",
                "logical_source_role_names": ["source"],
                "prompt_name": "review",
                "description": "Updated description",
                "modified_by": "editor",
                "task_scalars": None,
            }
            if self.error:
                raise self.error
            return self.result

    store = FakeTaskStore()
    monkeypatch.setattr(task_routes, "get_task_store", lambda: store)
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")
    client = TestClient(app)
    payload = {
        "title": "Updated task",
        "logical_source_role_names": ["source"],
        "prompt_name": "review",
        "description": "Updated description",
        "modified_by": "editor",
    }

    response = client.put("/api/tasks/task-id", json=payload)
    assert response.status_code == 200
    assert response.json()["description"] == "Updated description"
    assert response.json()["modified_by"] == "editor"
    assert "prompt_text" not in response.json()

    store.result = None
    assert client.put("/api/tasks/task-id", json=payload).status_code == 404
    store.error = DuplicateTaskTitleError("duplicate")
    assert client.put("/api/tasks/task-id", json=payload).status_code == 409
    store.error = ValueError("invalid name")
    assert client.put("/api/tasks/task-id", json=payload).status_code == 422


def test_delete_task_returns_no_content_and_maps_missing(monkeypatch):
    class FakeTaskStore:
        exists = True

        def delete_task(self, task_id):
            assert task_id == "task-id"
            return self.exists

    store = FakeTaskStore()
    monkeypatch.setattr(task_routes, "get_task_store", lambda: store)
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")
    client = TestClient(app)

    response = client.delete("/api/tasks/task-id")
    assert response.status_code == 204
    assert response.content == b""

    store.exists = False
    assert client.delete("/api/tasks/task-id").status_code == 404


def test_list_task_options_returns_catalog_or_service_unavailable(monkeypatch):
    from gardianai_agentharness.services.blob_storage import BlobStorageListingError
    from gardianai_agentharness.services.period import InvalidPeriodError

    class FakeTaskStore:
        error = None

        def list_task_options(self, period=None):
            if self.error:
                raise self.error
            result = {
                "logical_source_role_names": ["source"],
                "prompt_names": ["review"],
            }
            if period is not None:
                result["logical_source_roles"] = [
                    {"name": "source", "file_name": "f.docx", "path": "Q/f.docx"}
                ]
            return result

    store = FakeTaskStore()
    monkeypatch.setattr(task_routes, "get_task_store", lambda: store)
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")
    client = TestClient(app)

    response = client.get("/api/tasks/options")
    assert response.status_code == 200
    assert response.json() == {
        "logical_source_role_names": ["source"],
        "prompt_names": ["review"],
    }

    with_period = client.get("/api/tasks/options?period=2025-Q4")
    assert with_period.status_code == 200
    assert with_period.json()["logical_source_roles"] == [
        {"name": "source", "file_name": "f.docx", "path": "Q/f.docx"}
    ]

    store.error = InvalidPeriodError("bad period")
    assert client.get("/api/tasks/options?period=bad").status_code == 422

    store.error = BlobStorageListingError("storage unavailable")
    assert client.get("/api/tasks/options").status_code == 503


def test_list_periods_returns_list_or_service_unavailable(monkeypatch):
    from gardianai_agentharness.services.blob_storage import BlobStorageListingError

    class FakeTaskStore:
        error = None

        def list_periods(self):
            if self.error:
                raise self.error
            return ["2025-Q4", "2025-Q3"]

    store = FakeTaskStore()
    monkeypatch.setattr(task_routes, "get_task_store", lambda: store)
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")
    client = TestClient(app)

    response = client.get("/api/periods")
    assert response.status_code == 200
    assert response.json() == {"periods": ["2025-Q4", "2025-Q3"]}

    store.error = BlobStorageListingError("storage unavailable")
    assert client.get("/api/periods").status_code == 503


def test_start_task_returns_job_id(monkeypatch):
    class FakeService:
        def start_task_generation(
            self, task_id, economy, reasoning_effort, one_off_prompt=None, period=None
        ):
            assert task_id == "task-id"
            assert economy is True
            assert reasoning_effort == "low"
            assert one_off_prompt == "extra instruction"
            return "job-id"

    monkeypatch.setattr(super_agent_routes, "get_super_agent_service", lambda: FakeService())
    app = FastAPI()
    app.include_router(super_agent_routes.router, prefix="/api")

    response = TestClient(app).post(
        "/api/super-agent/tasks/generate/start",
        json={
            "task_id": "task-id",
            "economy": True,
            "reasoning_effort": "low",
            "one_off_prompt": "extra instruction",
        },
    )

    assert response.status_code == 200
    assert response.json() == {"job_id": "job-id"}


def test_start_task_maps_unknown_and_unrunnable_errors(monkeypatch):
    from gardianai_agentharness.services.super_agent_service import (
        UnknownTaskError,
        UnrunnableTaskError,
    )

    class FakeService:
        def __init__(self, error):
            self.error = error

        def start_task_generation(self, *args, **kwargs):
            raise self.error

    app = FastAPI()
    app.include_router(super_agent_routes.router, prefix="/api")
    client = TestClient(app)

    monkeypatch.setattr(
        super_agent_routes,
        "get_super_agent_service",
        lambda: FakeService(UnknownTaskError("Unknown task")),
    )
    missing = client.post(
        "/api/super-agent/tasks/generate/start", json={"task_id": "missing"}
    )
    assert missing.status_code == 404

    monkeypatch.setattr(
        super_agent_routes,
        "get_super_agent_service",
        lambda: FakeService(UnrunnableTaskError("No prompt or inputs")),
    )
    unrunnable = client.post(
        "/api/super-agent/tasks/generate/start", json={"task_id": "empty"}
    )
    assert unrunnable.status_code == 422


def test_start_task_rejects_unknown_reasoning_effort():
    app = FastAPI()
    app.include_router(super_agent_routes.router, prefix="/api")

    response = TestClient(app).post(
        "/api/super-agent/tasks/generate/start",
        json={"task_id": "task-id", "reasoning_effort": "extreme"},
    )

    assert response.status_code == 422


def test_get_task_with_period_returns_preview(monkeypatch):
    from gardianai_agentharness.services.period import InvalidPeriodError

    base = Task(
        id="task-id",
        title="Task",
        logical_source_role_names=["Current QRA draft", "IR materials"],
        prompt_name="review",
    )

    class FakeTaskStore:
        def get_task(self, task_id):
            return base if task_id == "task-id" else None

        def task_document_lock(self, task_id):
            return nullcontext()

        def resolve_input_documents(self, task, period):
            if period == "bad":
                raise InvalidPeriodError("bad period")
            doc = DocumentRef(
                id="d1", name="current.pdf", path="/c/current.pdf",
                doc_type="pdf", kind="input", test_case_id=task.id, size_bytes=1,
            )
            return Task(
                id=task.id, title=task.title,
                logical_source_role_names=task.logical_source_role_names,
                prompt_name=task.prompt_name,
                input_documents=[doc],
                input_documents_period=period,
                unresolved_logical_source_role_names=["IR materials"],
                logical_source_roles=[
                    {
                        "name": "Current QRA draft",
                        "file_name": "current.pdf",
                        "path": "Quarterly/2025-Q4/External/QRA/current.pdf",
                        "last_modified": "2026-01-26T10:00:00Z",
                    },
                    {
                        "name": "IR materials",
                        "file_name": None,
                        "path": None,
                        "last_modified": None,
                    },
                ],
            )

    monkeypatch.setattr(task_routes, "get_task_store", lambda: FakeTaskStore())
    app = FastAPI()
    app.include_router(task_routes.router, prefix="/api")
    client = TestClient(app)

    # Without a period: no period-scoped fields.
    plain = client.get("/api/tasks/task-id").json()
    assert "input_documents" not in plain
    assert "logical_source_roles" not in plain

    # With a period: hydrated preview including unresolved roles.
    preview = client.get("/api/tasks/task-id?period=2025-Q4").json()
    assert preview["input_documents"][0]["name"] == "current.pdf"
    assert preview["input_documents_period"] == "2025-Q4"
    assert preview["unresolved_logical_source_role_names"] == ["IR materials"]
    assert preview["logical_source_roles"] == [
        {
            "name": "Current QRA draft",
            "file_name": "current.pdf",
            "path": "Quarterly/2025-Q4/External/QRA/current.pdf",
            "last_modified": "2026-01-26T10:00:00Z",
        },
        {"name": "IR materials", "file_name": None, "path": None, "last_modified": None},
    ]

    # Invalid period -> 422; unknown task -> 404.
    assert client.get("/api/tasks/task-id?period=bad").status_code == 422
    assert client.get("/api/tasks/missing?period=2025-Q4").status_code == 404