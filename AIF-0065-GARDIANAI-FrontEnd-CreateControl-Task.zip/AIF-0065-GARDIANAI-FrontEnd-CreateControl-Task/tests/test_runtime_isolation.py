"""Regression checks that tests cannot pollute the live test-case catalog."""

from pathlib import Path

from gardianai_agentharness.config import settings
from gardianai_agentharness.services.document_store import get_document_store
from gardianai_agentharness.services.super_agent_service import get_super_agent_service


def test_uploads_and_reports_use_temporary_storage(tmp_path):
    assert Path(settings.run_store_dir).is_relative_to(tmp_path)
    store = get_document_store()
    assert not any(tc.archetype == "custom" for tc in store.list_test_cases())
    tc = store.register_uploaded_test_case(
        title="Isolation sentinel",
        input_files=[("figures.csv", b"metric,value\nRevenue,100\n")],
        prompt_text="Check the supplied figures.",
    )
    assert Path(tc.folder).is_relative_to(tmp_path)
    assert (tmp_path / "uploads" / "index.json").exists()
    service = get_super_agent_service()
    assert not service._llm.available
    run = service.generate(tc.id, run_title="Isolation check")
    assert run["mode"] == "offline"
    assert (tmp_path / "runs" / run["report_filename"]).exists()


def test_next_test_starts_without_previous_uploads():
    assert not any(
        tc.archetype == "custom" for tc in get_document_store().list_test_cases()
    )
