"""OCR cache is blob-only; `fake_blob_storage` (conftest.py) fakes Azure."""

from __future__ import annotations

import pytest

from gardianai_agentharness.config import settings
from gardianai_agentharness.services.blob_storage import BlobStorageNotConfigured
from gardianai_agentharness.services.ocr_service import MistralOCRClient


def _write_fixture_pdf(tmp_path):
    path = tmp_path / "doc.pdf"
    path.write_bytes(b"%PDF-1.4 fake")
    return path


def test_raises_when_blob_storage_not_configured(monkeypatch, tmp_path):
    monkeypatch.setattr(settings, "azure_storage_account_url", "")
    monkeypatch.setattr(settings, "azure_storage_connection_string", "")
    path = _write_fixture_pdf(tmp_path)

    client = MistralOCRClient()
    client._call_ocr = lambda *a, **k: pytest.fail("must not call OCR")  # type: ignore[method-assign]

    with pytest.raises(BlobStorageNotConfigured):
        client.extract(path)


def test_cache_hit_skips_ocr_call(fake_blob_storage, tmp_path):
    path = _write_fixture_pdf(tmp_path)
    client = MistralOCRClient()
    blob_name = f"{settings.ocr_cache_prefix}/{client._cache_key(path)}.md"
    fake_blob_storage[(settings.sample_data_container, blob_name)] = b"cached markdown"
    client._call_ocr = lambda *a, **k: pytest.fail("must not call OCR")  # type: ignore[method-assign]

    result = client.extract(path)

    assert result == "cached markdown"


def test_cache_miss_calls_ocr_and_writes_cache(fake_blob_storage, tmp_path):
    path = _write_fixture_pdf(tmp_path)
    client = MistralOCRClient()
    client._call_ocr = lambda *a, **k: "freshly ocr'd markdown"  # type: ignore[method-assign]

    result = client.extract(path)

    assert result == "freshly ocr'd markdown"
    blob_name = f"{settings.ocr_cache_prefix}/{client._cache_key(path)}.md"
    key = (settings.sample_data_container, blob_name)
    assert fake_blob_storage[key] == b"freshly ocr'd markdown"
