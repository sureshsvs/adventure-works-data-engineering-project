from __future__ import annotations

from datetime import datetime, timezone

import pytest

from gardianai_agentharness.services import task_store
from gardianai_agentharness.services.document_store import Task
from gardianai_agentharness.services import blob_storage


class FakeContainer:
    def __init__(self, items=None):
        self.items = list(items or [])

    def query_items(self, query, **kwargs):
        if "c.title" in query:
            return [dict(item) for item in self.items]
        return list(self.items)

    def create_item(self, body):
        self.items.append(dict(body))

    def upsert_item(self, body):
        for index, item in enumerate(self.items):
            if item["id"] == body["id"]:
                self.items[index] = dict(body)
                return
        self.items.append(dict(body))

    def delete_item(self, *, item, partition_key):
        assert item == partition_key
        self.items = [stored for stored in self.items if stored["id"] != item]


@pytest.fixture
def fake_blobs(monkeypatch):
    modified_old = datetime(2025, 1, 1, tzinfo=timezone.utc)
    modified_new = datetime(2026, 1, 1, tzinfo=timezone.utc)
    entries = {
        "prompts/review.docx": ("prompts/review.docx", 10, modified_new),
        "source/report-old.pdf": ("source/report-old.pdf", 20, modified_old),
        "source/report-new.pdf": ("source/report-new.pdf", 30, modified_new),
    }
    monkeypatch.setattr(
        task_store.blob_storage,
        "list_task_blobs",
        lambda prefix: [entry for name, entry in entries.items() if name.startswith(prefix)],
    )
    monkeypatch.setattr(task_store.blob_storage, "download_task_blob", lambda name, dest: None)
    return entries


def test_register_task_persists_metadata_and_hydrates_inputs(monkeypatch, tmp_path, fake_blobs):
    container = FakeContainer()
    monkeypatch.setattr(task_store.settings, "sample_data_cache_dir", str(tmp_path))
    store = task_store.TaskStore(cosmos_container=container)
    monkeypatch.setattr(store, "get_text", lambda doc_id: "loaded prompt" if "prompt" in doc_id else "")

    task = store.register_task(
        title="Review quarterly report",
        logical_source_role_names=["source"],
        prompt_name="review",
        description="Review report for completeness",
        created_by="auditor",
    )

    assert task.description == "Review report for completeness"
    assert task.prompt_text == "loaded prompt"
    # Documents are resolved lazily per period, not at register time.
    assert task.input_documents == []
    assert set(container.items[0]) == {
        "id", "title", "description", "logical_source_role_names", "prompt_name",
        "created_by", "modified_by", "last_modified", "task_scalars"
    }
    assert container.items[0]["description"] == "Review report for completeness"
    assert container.items[0]["modified_by"] is None
    assert store.get_task(task.id) is task


def test_register_task_rejects_normalized_duplicate_title(monkeypatch, fake_blobs):
    container = FakeContainer([{"id": "existing", "title": " Quarterly Review "}])
    store = task_store.TaskStore(cosmos_container=container)
    monkeypatch.setattr(store, "get_text", lambda doc_id: "")

    with pytest.raises(task_store.DuplicateTaskTitleError):
        store.register_task(
            title="quarterly review",
            logical_source_role_names=[],
            prompt_name="review",
        )


def test_task_exposes_harness_defaults():
    task = Task(id="id", title="title", logical_source_role_names=[], prompt_name="prompt")

    assert task.number == 0
    assert task.folder is None
    assert task.expected_output_text == ""


def test_task_hydration_runs_during_initialization(monkeypatch, tmp_path, fake_blobs):
    container = FakeContainer(
        [
            {
                "id": "existing-id",
                "title": "Existing task",
                "description": "Stored description",
                "logical_source_role_names": ["source"],
                "prompt_name": "review",
                "created_by": None,
                "last_modified": "2026-01-01T00:00:00Z",
            }
        ]
    )
    monkeypatch.setattr(task_store.settings, "sample_data_cache_dir", str(tmp_path))
    monkeypatch.setattr(
        task_store.TaskStore,
        "get_text",
        lambda self, doc_id: "hydrated prompt" if "prompt" in doc_id else "",
    )

    store = task_store.TaskStore(cosmos_container=container)

    task = store.get_task("existing-id")
    assert task is not None
    assert task.description == "Stored description"
    assert task.prompt_text == "hydrated prompt"
    # Lazy resolution: no source documents are resolved at load time.
    assert task.input_documents == []


def test_update_task_persists_metadata_and_rehydrates(monkeypatch, tmp_path, fake_blobs):
    container = FakeContainer(
        [
            {
                "id": "existing-id",
                "title": "Existing task",
                "logical_source_role_names": ["source"],
                "prompt_name": "review",
                "created_by": "creator",
                "modified_by": None,
                "last_modified": "2026-01-01T00:00:00Z",
            }
        ]
    )
    monkeypatch.setattr(task_store.settings, "sample_data_cache_dir", str(tmp_path))
    monkeypatch.setattr(
        task_store.TaskStore,
        "get_text",
        lambda self, doc_id: "hydrated prompt" if "prompt" in doc_id else "",
    )
    store = task_store.TaskStore(cosmos_container=container)
    existing = store.get_task("existing-id")
    assert existing is not None
    old_document_ids = {document.id for document in existing.input_documents}
    store._text_cache.update({document_id: "stale" for document_id in old_document_ids})

    updated = store.update_task(
        existing.id,
        title="Updated task",
        logical_source_role_names=[],
        prompt_name="review",
        description="Updated description",
        modified_by="editor",
    )

    assert updated is not None
    assert updated.title == "Updated task"
    assert updated.description == "Updated description"
    assert updated.created_by == "creator"
    assert updated.modified_by == "editor"
    assert updated.last_modified != "2026-01-01T00:00:00Z"
    assert updated.input_documents == []
    assert all(document_id not in store.documents for document_id in old_document_ids)
    assert all(document_id not in store._text_cache for document_id in old_document_ids)
    assert container.items[0]["title"] == "Updated task"
    assert container.items[0]["description"] == "Updated description"
    assert container.items[0]["modified_by"] == "editor"

    cleared = store.update_task(
        existing.id,
        title="Updated task",
        logical_source_role_names=[],
        prompt_name="review",
        description=None,
    )
    assert cleared is not None
    assert cleared.description is None
    assert container.items[0]["description"] is None


def test_update_task_returns_none_and_rejects_duplicate_title(monkeypatch, fake_blobs):
    container = FakeContainer(
        [
            {
                "id": "one",
                "title": "First",
                "logical_source_role_names": [],
                "prompt_name": "review",
            },
            {
                "id": "two",
                "title": "Second",
                "logical_source_role_names": [],
                "prompt_name": "review",
            },
        ]
    )
    store = task_store.TaskStore(cosmos_container=container)
    monkeypatch.setattr(store, "get_text", lambda doc_id: "")

    assert store.update_task(
        "missing",
        title="Missing",
        logical_source_role_names=[],
        prompt_name="review",
    ) is None
    with pytest.raises(task_store.DuplicateTaskTitleError):
        store.update_task(
            "one",
            title=" second ",
            logical_source_role_names=[],
            prompt_name="review",
        )


def test_delete_task_removes_metadata_and_in_memory_indexes(monkeypatch, fake_blobs):
    container = FakeContainer(
        [
            {
                "id": "existing-id",
                "title": "Existing task",
                "logical_source_role_names": ["source"],
                "prompt_name": "review",
            }
        ]
    )
    store = task_store.TaskStore(cosmos_container=container)
    task = store.get_task("existing-id")
    assert task is not None
    document_ids = {document.id for document in task.input_documents}
    store._text_cache.update({document_id: "cached" for document_id in document_ids})

    assert store.delete_task(task.id) is True
    assert store.delete_task(task.id) is False
    assert store.get_task(task.id) is None
    assert container.items == []
    assert all(document_id not in store.documents for document_id in document_ids)
    assert all(document_id not in store._blob_rel for document_id in document_ids)
    assert all(document_id not in store._text_cache for document_id in document_ids)


def test_list_task_options_returns_fixed_roles_and_prompt_names(monkeypatch):
    blobs = [
        ("z-role/report.pdf", 10, None),
        ("prompts/review.docx", 10, None),
        ("prompts/nested/ignored.docx", 10, None),
        ("prompts/notes.txt", 10, None),
    ]
    monkeypatch.setattr(
        task_store.blob_storage, "list_task_blobs_strict", lambda prefix="": blobs
    )
    store = task_store.TaskStore(cosmos_container=FakeContainer())

    assert store.list_task_options() == {
        "logical_source_role_names": [
            "Current QRA draft",
            "IR materials",
            "Previous quarter QRA",
            "Quarterly databook",
            "Same quarter prior year",
        ],
        "prompt_names": ["review"],
    }



def test_list_task_options_with_period_adds_resolved_roles(monkeypatch):
    modified = datetime(2026, 1, 26, 10, 0, 0, tzinfo=timezone.utc)
    all_blobs = [
        ("Quarterly/2025-Q4/External/QRA/Shell QRA Q4 2025.docx", 10, modified),
        ("Quarterly/2025-Q4/External/QDB/databook.xlsx", 10, None),
        ("prompts/review.docx", 10, None),
    ]
    monkeypatch.setattr(
        task_store.blob_storage, "list_task_blobs_strict", lambda prefix="": all_blobs
    )
    monkeypatch.setattr(
        task_store.blob_storage,
        "list_task_blobs",
        lambda prefix: [b for b in all_blobs if b[0].startswith(prefix)],
    )
    store = task_store.TaskStore(cosmos_container=FakeContainer())

    options = store.list_task_options("2025-Q4")

    assert options["logical_source_roles"] == [
        {
            "name": "Current QRA draft",
            "file_name": "Shell QRA Q4 2025.docx",
            "path": "Quarterly/2025-Q4/External/QRA/Shell QRA Q4 2025.docx",
            "last_modified": "2026-01-26T10:00:00Z",
        },
        {"name": "Previous quarter QRA", "file_name": None, "path": None, "last_modified": None},
        {"name": "Same quarter prior year", "file_name": None, "path": None, "last_modified": None},
        {
            "name": "Quarterly databook",
            "file_name": "databook.xlsx",
            "path": "Quarterly/2025-Q4/External/QDB/databook.xlsx",
            "last_modified": None,
        },
        {"name": "IR materials", "file_name": None, "path": None, "last_modified": None},
    ]
    assert options["prompt_names"] == ["review"]
    # Period-neutral call omits the additive field.
    assert "logical_source_roles" not in store.list_task_options()


def test_list_periods_returns_valid_quarters_descending(monkeypatch):
    blobs = [
        ("Quarterly/2025-Q3/External/QRA/a.docx", 10, None),
        ("Quarterly/2025-Q4/External/QRA/b.docx", 10, None),
        ("Quarterly/2025-Q4/External/QDB/c.xlsx", 10, None),
        ("quarterly/2024-Q4/External/QRA/d.docx", 10, None),
        ("Quarterly/not-a-period/External/QRA/e.docx", 10, None),
        ("Quarterly/readme.txt", 10, None),
        ("prompts/review.docx", 10, None),
    ]
    monkeypatch.setattr(
        task_store.blob_storage, "list_task_blobs_strict", lambda prefix="": blobs
    )
    store = task_store.TaskStore(cosmos_container=FakeContainer())

    assert store.list_periods() == ["2025-Q4", "2025-Q3", "2024-Q4"]


def test_list_periods_empty_when_no_quarterly_folder(monkeypatch):
    monkeypatch.setattr(
        task_store.blob_storage,
        "list_task_blobs_strict",
        lambda prefix="": [("prompts/review.docx", 10, None)],
    )
    store = task_store.TaskStore(cosmos_container=FakeContainer())

    assert store.list_periods() == []


def test_task_blob_listing_uses_configured_container_and_prefix(monkeypatch):
    class Blob:
        name = "poc-testcases/prompts/review.docx"
        size = 17
        last_modified = datetime(2026, 1, 1, tzinfo=timezone.utc)

    class Container:
        def list_blobs(self, *, name_starts_with):
            assert name_starts_with == "poc-testcases/prompts/"
            return [Blob()]

    monkeypatch.setattr(blob_storage.settings, "sample_data_container", "gardianai-sampledata")
    monkeypatch.setattr(blob_storage.settings, "sample_data_prefix", "poc-testcases")
    monkeypatch.setattr(
        blob_storage, "_container_client", lambda name: (
            Container() if name == "gardianai-sampledata" else pytest.fail(name)
        )
    )

    assert blob_storage.list_task_blobs("prompts/") == [
        ("prompts/review.docx", 17, Blob.last_modified)
    ]


def test_strict_task_blob_listing_raises_on_storage_failure(monkeypatch):
    def fail_listing(container_name):
        raise OSError(f"unavailable: {container_name}")

    monkeypatch.setattr(blob_storage, "_container_client", fail_listing)

    with pytest.raises(blob_storage.BlobStorageListingError):
        blob_storage.list_task_blobs_strict()

    assert blob_storage.list_task_blobs("") == []


def test_task_blob_download_uses_configured_container_and_prefix(monkeypatch, tmp_path):
    downloaded = {}

    class Downloader:
        def readall(self):
            return b"blob content"

    class Container:
        def download_blob(self, name):
            downloaded["name"] = name
            return Downloader()

    monkeypatch.setattr(blob_storage.settings, "sample_data_container", "gardianai-sampledata")
    monkeypatch.setattr(blob_storage.settings, "sample_data_prefix", "poc-testcases")
    monkeypatch.setattr(
        blob_storage, "_container_client", lambda name: (
            Container() if name == "gardianai-sampledata" else pytest.fail(name)
        )
    )
    destination = tmp_path / "prompt.docx"

    blob_storage.download_task_blob("prompts/review.docx", destination)

    assert downloaded["name"] == "poc-testcases/prompts/review.docx"
    assert destination.read_bytes() == b"blob content"


def test_resolve_input_documents_period_scoped(monkeypatch, tmp_path):
    modified = datetime(2026, 1, 1, tzinfo=timezone.utc)
    entries = {
        "Quarterly/2025-Q4/External/QRA/current.pdf": (
            "Quarterly/2025-Q4/External/QRA/current.pdf",
            10,
            modified,
        ),
        "Quarterly/2025-Q3/External/QRA/previous.pdf": (
            "Quarterly/2025-Q3/External/QRA/previous.pdf",
            10,
            modified,
        ),
    }
    monkeypatch.setattr(task_store.settings, "sample_data_cache_dir", str(tmp_path))
    monkeypatch.setattr(
        task_store.blob_storage,
        "list_task_blobs",
        lambda prefix: [e for name, e in entries.items() if name.startswith(prefix)],
    )
    store = task_store.TaskStore(cosmos_container=FakeContainer())
    task = Task(
        id="t1",
        title="t",
        logical_source_role_names=[
            "Current QRA draft",
            "Previous quarter QRA",
            "IR materials",
        ],
        prompt_name="review",
    )

    resolved = store.resolve_input_documents(task, "2025-Q4")

    assert [d.name for d in resolved.input_documents] == ["current.pdf", "previous.pdf"]
    assert resolved.input_documents_period == "2025-Q4"
    assert resolved.unresolved_logical_source_role_names == ["IR materials"]
    # logical_source_roles comes from the same single listing pass.
    assert resolved.logical_source_roles == [
        {
            "name": "Current QRA draft",
            "file_name": "current.pdf",
            "path": "Quarterly/2025-Q4/External/QRA/current.pdf",
            "last_modified": "2026-01-01T00:00:00Z",
        },
        {
            "name": "Previous quarter QRA",
            "file_name": "previous.pdf",
            "path": "Quarterly/2025-Q3/External/QRA/previous.pdf",
            "last_modified": "2026-01-01T00:00:00Z",
        },
        {"name": "IR materials", "file_name": None, "path": None, "last_modified": None},
    ]
    assert task.input_documents == []
    assert task.input_documents_period is None


def test_resolve_input_documents_rejects_invalid_period(monkeypatch, tmp_path):
    monkeypatch.setattr(task_store.settings, "sample_data_cache_dir", str(tmp_path))
    store = task_store.TaskStore(cosmos_container=FakeContainer())
    task = Task(id="t1", title="t", logical_source_role_names=[], prompt_name="review")
    with pytest.raises(ValueError):
        store.resolve_input_documents(task, "2025-Q5")