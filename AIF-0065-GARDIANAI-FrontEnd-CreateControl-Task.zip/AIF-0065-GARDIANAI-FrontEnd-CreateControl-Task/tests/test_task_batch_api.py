from __future__ import annotations

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient

from gardianai_agentharness.api.routes import super_agent as routes
from gardianai_agentharness.services.case_scheduler import CapacityBusyError
from gardianai_agentharness.services.super_agent_service import TaskBatchValidationError
from gardianai_agentharness.services.super_agent_service import UnrunnableTaskError, UnknownTaskError
from gardianai_agentharness.services.task_run import TaskRunValidationError
from gardianai_agentharness.services.period import InvalidPeriodError


@pytest.fixture
def client():
    app = FastAPI()
    app.include_router(routes.router, prefix="/api")
    return TestClient(app)


def test_single_task_capacity_returns_retry_after(client, monkeypatch):
    class Service:
        def start_task_generation(self, *args, **kwargs):
            raise CapacityBusyError("Queue full")

    monkeypatch.setattr(routes, "get_super_agent_service", Service)
    response = client.post(
        "/api/super-agent/tasks/generate/start", json={"task_id": "task"}
    )
    assert response.status_code == 429
    assert response.headers["retry-after"] == "2"
    assert "Retry" in response.json()["detail"]


def test_retry_after_is_readable_by_cross_origin_frontend(monkeypatch):
    from gardianai_agentharness.config import settings
    from gardianai_agentharness.main import app

    class Service:
        def start_task_generation(self, *args, **kwargs):
            raise CapacityBusyError("Queue full")

    monkeypatch.setattr(routes, "get_super_agent_service", Service)
    response = TestClient(app).post(
        "/api/super-agent/tasks/generate/start",
        headers={"Origin": settings.cors_origin_list[0]},
        json={"task_id": "task"},
    )
    assert response.status_code == 429
    assert "retry-after" in response.headers["access-control-expose-headers"].lower()


def test_sample_start_forwards_one_off_prompt_once(client, monkeypatch):
    class Service:
        def start_generation(
            self, test_case_id, use_expected_template=None, economy=None,
            reasoning_effort=None, one_off_prompt=None, *, run_title, **kwargs,
        ):
            assert test_case_id == "sample"
            assert one_off_prompt == "Extra instructions"
            assert run_title == "Review"
            return "sample-job"

    monkeypatch.setattr(routes, "get_super_agent_service", Service)
    response = client.post(
        "/api/super-agent/generate/start",
        json={"test_case_id": "sample", "run_title": "Review",
              "one_off_prompt": "Extra instructions"},
    )
    assert response.status_code == 200
    assert response.json() == {"job_id": "sample-job"}


def test_task_batch_payload_and_preflight(client, monkeypatch):
    class Service:
        def preflight_tasks(self, task_ids, period):
            assert task_ids == ["task"]
            assert period == "2025-Q4"
            return {"valid": False, "errors": [
                {"task_id": "task", "detail": "Missing source: QRA"}
            ]}

        def start_task_batch_generation(self, **kwargs):
            assert kwargs["task_ids"] == ["task"]
            assert kwargs["run_title"] == "Quarterly review"
            assert kwargs["description"] == "Evidence"
            assert kwargs["grouping"] == "Finance"
            assert kwargs["period"] == "2025-Q4"
            assert kwargs["max_parallel_cases"] == 2
            assert kwargs["economy"] is True
            return "batch-id"

    monkeypatch.setattr(routes, "get_super_agent_service", Service)
    preflight = client.post("/api/super-agent/tasks/generate/preflight", json={
        "task_ids": ["task"], "period": "2025-Q4",
    })
    assert preflight.status_code == 200
    assert preflight.json()["errors"][0]["detail"] == "Missing source: QRA"
    response = client.post("/api/super-agent/tasks/generate/batch/start", json={
        "task_ids": ["task"], "run_title": " Quarterly review ",
        "description": "Evidence", "grouping": "Finance", "period": "2025-Q4",
        "max_parallel_cases": 2, "economy": True,
    })
    assert response.status_code == 200
    assert response.json() == {"batch_id": "batch-id", "job_id": "batch-id"}


@pytest.mark.parametrize("overrides", [
    {"task_ids": []}, {"task_ids": ["task", "task"]}, {"task_ids": [" "]},
    {"run_title": " "}, {"max_parallel_cases": 0}, {"max_parallel_cases": 5},
    {"max_parallel_cases": True}, {"reasoning_effort": "extreme"},
])
def test_task_batch_rejects_invalid_settings(client, monkeypatch, overrides):
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: pytest.fail(
        "Invalid requests must not reach admission"
    ))
    response = client.post("/api/super-agent/tasks/generate/batch/start", json={
        "task_ids": ["task"], "run_title": "Review", **overrides,
    })
    assert response.status_code == 422


def test_task_batch_validation_details_and_capacity(client, monkeypatch):
    class Service:
        error = None

        def start_task_batch_generation(self, **kwargs):
            raise self.error

    service = Service()
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    errors = [{"task_id": "task", "detail": "Period is required"}]
    service.error = TaskBatchValidationError(errors)
    response = client.post("/api/super-agent/tasks/generate/batch/start", json={
        "task_ids": ["task"], "run_title": "Review",
    })
    assert response.status_code == 422
    assert response.json()["detail"]["errors"] == errors
    service.error = CapacityBusyError("Queue full")
    busy = client.post("/api/super-agent/tasks/generate/batch/start", json={
        "task_ids": ["task"], "run_title": "Review",
    })
    assert busy.status_code == 429
    assert busy.headers["retry-after"] == "2"


def test_task_batch_history_and_detail(client, monkeypatch):
    batch = {
        "batch_id": "batch-id", "job_id": "batch-id", "run_title": "Review",
        "description": "Evidence", "period": "2025-Q4", "grouping": "Finance",
        "max_parallel_cases": 1, "created_at": "2026-10-28T07:15:00Z",
        "started_at": "2026-10-28T07:15:01Z", "completed_at": "2026-10-28T07:15:02Z",
        "status": "completed", "done": True, "total": 1, "finished_count": 1,
        "items": [{"task_id": "task", "task_title": "Task", "job_id": "item-job",
                   "status": "completed", "run_id": "run-id", "run": {"run_id": "run-id"}}],
    }

    class Service:
        def list_task_batches(self):
            return [batch]

        def get_task_batch(self, batch_id):
            return batch if batch_id == "batch-id" else None

    monkeypatch.setattr(routes, "get_super_agent_service", Service)
    history = client.get("/api/super-agent/tasks/batches")
    assert history.status_code == 200
    assert history.json()["batches"][0]["items"][0]["run_id"] == "run-id"
    detail = client.get("/api/super-agent/tasks/batches/batch-id")
    assert detail.status_code == 200
    assert detail.json()["grouping"] == "Finance"
    assert detail.json()["completed_at"] == "2026-10-28T07:15:02Z"
    assert client.get("/api/super-agent/tasks/batches/missing").status_code == 404


@pytest.mark.parametrize("endpoint", ["regenerate", "regenerate/start"])
@pytest.mark.parametrize("error,status", [
    (UnrunnableTaskError("unresolved source roles: QRA"), 422),
    (TaskRunValidationError("period is required to render this task"), 422),
    (InvalidPeriodError("period must be formatted YYYY-Q[1-4]"), 422),
    (UnknownTaskError("Unknown task: missing"), 404),
])
def test_task_regeneration_preserves_validation_status(client, monkeypatch, endpoint, error, status):
    class Service:
        def regenerate(self, *args, **kwargs):
            raise error

        start_regeneration = regenerate

    monkeypatch.setattr(routes, "get_super_agent_service", Service)
    response = client.post(f"/api/super-agent/{endpoint}", json={"run_id": "run-id"})
    assert response.status_code == status
    assert response.json()["detail"] == str(error)
