"""Reporting inputs are validated, rendered per run, and retained in history."""

from __future__ import annotations

import copy
import time
from unittest.mock import Mock

import pytest
from fastapi.testclient import TestClient
from pydantic import ValidationError

from gardianai_agentharness.api.routes import super_agent as routes
from gardianai_agentharness.api.schemas import (
    RegenerateRequest,
    SuperAgentBatchRequest,
    SuperAgentRunRequest,
)
from gardianai_agentharness.config import settings
from gardianai_agentharness.main import app
from gardianai_agentharness.services import super_agent_service as service_module
from gardianai_agentharness.services.case_scheduler import CapacityBusyError
from gardianai_agentharness.services.models import (
    GeneratedDocument,
    generation_run_from_dict,
)
from gardianai_agentharness.services.reporting_parameters import render_reporting_prompt
from gardianai_agentharness.services.run_store import AzureRunStore
from gardianai_agentharness.services.super_agent_service import (
    ReportingParameterError,
    get_super_agent_service,
)

REPORTING = {
    "report_version": "v2",
    "reporting_period": "Q4",
    "reporting_year": "2026",
}
ENDPOINTS = [
    ("/generate", "generate", {"test_case_id": "case", "run_title": "Review"}),
    ("/generate/start", "start_generation", {"test_case_id": "case", "run_title": "Review"}),
    (
        "/generate/batch/start",
        "start_batch_generation",
        {"test_case_ids": ["case"], "run_title": "Review"},
    ),
    ("/regenerate", "regenerate", {"run_id": "run_original"}),
    ("/regenerate/start", "start_regeneration", {"run_id": "run_original"}),
]


@pytest.fixture
def reporting_case(monkeypatch):
    service = get_super_agent_service()
    case = service._store.register_uploaded_test_case(
        title="Reporting inputs",
        input_files=[("input.csv", b"metric,value\nRevenue,100\n")],
        prompt_text="Check supplied figures.",
    )
    prompts = []

    def generate_document(tc, store, prompt, llm):
        prompts.append(prompt)
        return GeneratedDocument(title="Review"), "offline"

    monkeypatch.setattr(service_module, "generate_document", generate_document)
    return service, case, prompts


def _await_job(service, job_id):
    deadline = time.monotonic() + 5
    while time.monotonic() < deadline:
        result = service.job_status(job_id)
        assert result is not None
        if result["done"]:
            assert result["error"] is None
            return result
        time.sleep(0.01)
    pytest.fail("Reporting generation did not finish")


def _assert_reporting(run, expected=REPORTING):
    assert {field: run[field] for field in REPORTING} == expected


def test_prompt_replacements_are_literal_single_pass():
    prompt = "{{report_version}} / {{ reporting_period }} / {{reporting_year}}; {{report_version}}"
    assert render_reporting_prompt(
        prompt,
        report_version=r"\1 {{reporting_period}}",
        reporting_period="Q4 & <review>",
        reporting_year="2026",
    ) == r"\1 {{reporting_period}} / Q4 & <review> / 2026; \1 {{reporting_period}}"
    assert render_reporting_prompt("Keep {other} and 2025 unchanged.") == (
        "Keep {other} and 2025 unchanged."
    )


@pytest.mark.parametrize("field", list(REPORTING))
@pytest.mark.parametrize("value", [None, "", " \t "])
def test_missing_placeholder_values_fail(field, value):
    with pytest.raises(ReportingParameterError):
        render_reporting_prompt("Check {{" + field + "}}", **{field: value})


@pytest.mark.parametrize("year", ["", " ", "26", "20260", "20a6", "２０２６", 2026])
def test_reporting_year_is_a_stripped_four_digit_string(year):
    for schema, identity in [
        (SuperAgentRunRequest, {"test_case_id": "case", "run_title": "Review"}),
        (SuperAgentBatchRequest, {"test_case_ids": ["case"], "run_title": "Review"}),
        (RegenerateRequest, {"run_id": "run_original"}),
    ]:
        with pytest.raises(ValidationError):
            schema(**identity, reporting_year=year)


def test_shared_request_fields_trim_and_preserve_explicit_clears():
    for schema, identity in [
        (SuperAgentRunRequest, {"test_case_id": "case", "run_title": "Review"}),
        (SuperAgentBatchRequest, {"test_case_ids": ["case"], "run_title": "Review"}),
        (RegenerateRequest, {"run_id": "run_original"}),
    ]:
        request = schema(
            **identity, report_version=" v2 ", reporting_period=" \t ", reporting_year=" 2026 "
        )
        assert request.report_version == "v2"
        assert request.reporting_period == ""
        assert request.reporting_year == "2026"
        assert schema(**identity).report_version is None
        for field in ["report_version", "reporting_period"]:
            with pytest.raises(ValidationError):
                schema(**identity, **{field: "x" * 201})


@pytest.mark.parametrize("parallelism", [None, True, False, "1", 1.0, 0, 5])
def test_batch_parallelism_rejects_non_integer_or_out_of_range(parallelism):
    with pytest.raises(ValidationError):
        SuperAgentBatchRequest(
            test_case_ids=["case"], run_title="Review", max_parallel_cases=parallelism
        )


def test_batch_parallelism_default_is_resolved_for_each_request(monkeypatch):
    for parallelism in [1, 2, 4]:
        monkeypatch.setattr(settings, "super_agent_default_max_parallel_cases", parallelism)
        assert SuperAgentBatchRequest(
            test_case_ids=["case"], run_title="Review"
        ).max_parallel_cases == parallelism


@pytest.mark.parametrize(
    "invalid",
    [
        {"reporting_year": ""},
        {"reporting_year": 2026},
        {"reporting_year": "２０２６"},
        {"report_version": "x" * 201},
        {"reporting_period": "x" * 201},
    ],
)
@pytest.mark.parametrize("method", ["generate", "start_generation", "start_batch_generation"])
def test_service_rejects_invalid_reporting_before_work(reporting_case, method, invalid):
    service, case, prompts = reporting_case
    identity = [case.id] if method == "start_batch_generation" else case.id
    with pytest.raises(ReportingParameterError):
        getattr(service, method)(identity, run_title="Review", **invalid)
    assert prompts == []
    assert service.list_runs() == []


def test_prompt_rendering_does_not_mutate_library(reporting_case, fake_blob_storage):
    service, case, prompts = reporting_case
    template = "{{report_version}} / {{reporting_period}} / {{reporting_year}}"
    service._library.entries[case.id] = {
        "prompt": template, "version": 7, "updated_by": "auditor"
    }
    before_entries = copy.deepcopy(service._library.entries)
    before_blobs = dict(fake_blob_storage)
    run = service.generate(case.id, run_title="Reporting review", **REPORTING)
    assert prompts == ["v2 / Q4 / 2026"]
    assert service._library.entries == before_entries
    assert fake_blob_storage == before_blobs
    assert run["prompt_version"].endswith("@v7")
    _assert_reporting(run)
    _assert_reporting(service.get_run(run["run_id"]))
    _assert_reporting(service.list_runs()[0])


@pytest.mark.parametrize("background", [False, True])
@pytest.mark.parametrize(
    "overrides,expected",
    [
        ({}, REPORTING),
        (dict.fromkeys(REPORTING), REPORTING),
        ({"reporting_period": " Q1 "}, {**REPORTING, "reporting_period": "Q1"}),
        (
            {"report_version": "", "reporting_period": "", "reporting_year": "2027"},
            {"report_version": "", "reporting_period": "", "reporting_year": "2027"},
        ),
    ],
)
def test_regeneration_inherits_or_overrides_each_parameter(
    reporting_case, background, overrides, expected
):
    service, case, _ = reporting_case
    original = service.generate(
        case.id, run_title="Source label", description="Source notes", **REPORTING
    )
    if background:
        result = _await_job(
            service, service.start_regeneration(original["run_id"], **overrides)
        )["run"]
    else:
        result = service.regenerate(original["run_id"], **overrides)
    assert result["run_id"] != original["run_id"]
    assert result["run_title"] == "Source label"
    assert result["description"] == "Source notes"
    _assert_reporting(result, expected)
    _assert_reporting(service.get_run(original["run_id"]))
    _assert_reporting(service.get_run(result["run_id"]), expected)


@pytest.mark.parametrize("background", [False, True])
def test_regeneration_cannot_clear_a_required_placeholder(reporting_case, background):
    service, case, _ = reporting_case
    case.prompt_text = "Review {{report_version}}"
    original = service.generate(case.id, run_title="Review", **REPORTING)
    regenerate = service.start_regeneration if background else service.regenerate
    with pytest.raises(ReportingParameterError):
        regenerate(original["run_id"], report_version="")
    assert len(service.list_runs()) == 1


def test_background_generation_and_batch_persist_reporting(reporting_case):
    service, case, _ = reporting_case
    single = _await_job(
        service, service.start_generation(case.id, run_title="Review", **REPORTING)
    )
    _assert_reporting(single["run"])
    batch = _await_job(
        service,
        service.start_batch_generation(
            [case.id], run_title="Batch", max_parallel_cases=2, **REPORTING
        ),
    )
    _assert_reporting(batch["items"][0]["run"])


def test_coauthor_and_direct_edits_preserve_reporting(reporting_case, monkeypatch):
    service, case, _ = reporting_case
    run = service.generate(case.id, run_title="Review", **REPORTING)
    service._llm = Mock(available=True)
    monkeypatch.setattr(
        service_module,
        "coauthor_edit",
        lambda *args: (GeneratedDocument(title="Revised report"), "Edited."),
    )
    edited = service.coauthor(run["run_id"], "Improve wording")
    _assert_reporting(edited)
    assert edited["reply"] == "Edited."
    updated = service.update_document(
        run["run_id"],
        {
            "title": "Direct edit",
            "sections": [{"heading": "Review", "paragraphs": ["Edited text"]}],
        },
    )
    _assert_reporting(updated)
    _assert_reporting(service.get_run(run["run_id"]))
    _assert_reporting(service.list_runs()[0])


def test_old_runs_default_reporting_to_none():
    restored = generation_run_from_dict({"test_case_id": "legacy"})
    _assert_reporting(restored.to_dict(), dict.fromkeys(REPORTING))


def test_cosmos_reporting_round_trip_and_legacy_summaries(monkeypatch):
    container = Mock()
    store = AzureRunStore()
    monkeypatch.setattr(store, "_cosmos", lambda: container)
    run = generation_run_from_dict({"test_case_id": "case", **REPORTING})
    store.save(run, b"")
    item = container.upsert_item.call_args.args[0]
    _assert_reporting(item)
    container.read_item.return_value = item
    _assert_reporting(store.load(run.run_id).to_dict())
    container.query_items.return_value = [item, {"run_id": "run_old"}]
    summaries = store.list_summaries()
    _assert_reporting(summaries[0])
    _assert_reporting(summaries[1], dict.fromkeys(REPORTING))
    query = container.query_items.call_args.kwargs["query"]
    assert all(f"c.{field}" in query for field in REPORTING)


@pytest.mark.parametrize("endpoint,method,payload", ENDPOINTS)
def test_all_api_entrypoints_accept_omitted_reporting(monkeypatch, endpoint, method, payload):
    service = Mock()
    getattr(service, method).return_value = "job_id" if endpoint.endswith("/start") else {}
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    with TestClient(app) as client:
        response = client.post("/api/super-agent" + endpoint, json=payload)
    assert response.status_code == 200, response.text
    kwargs = getattr(service, method).call_args.kwargs
    _assert_reporting(kwargs, dict.fromkeys(REPORTING))
    if "batch" in endpoint:
        assert kwargs["max_parallel_cases"] == settings.super_agent_default_max_parallel_cases


@pytest.mark.parametrize("background", [False, True])
def test_generation_and_batch_without_reporting(reporting_case, background):
    service, case, prompts = reporting_case
    if background:
        run = _await_job(
            service, service.start_generation(case.id, run_title="Review")
        )["run"]
    else:
        run = service.generate(case.id, run_title="Review")
    _assert_reporting(run, dict.fromkeys(REPORTING))
    _assert_reporting(service.get_run(run["run_id"]), dict.fromkeys(REPORTING))
    batch = _await_job(
        service, service.start_batch_generation([case.id], run_title="Batch")
    )
    _assert_reporting(batch["items"][0]["run"], dict.fromkeys(REPORTING))
    assert prompts == ["Check supplied figures.", "Check supplied figures."]


@pytest.mark.parametrize("endpoint,method,payload", ENDPOINTS)
def test_all_api_entrypoints_forward_reporting(monkeypatch, endpoint, method, payload):
    service = Mock()
    getattr(service, method).return_value = "job_id" if endpoint.endswith("/start") else {}
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    request = {**payload, **{key: f" {value} " for key, value in REPORTING.items()}}
    if "batch" in endpoint:
        request["max_parallel_cases"] = 2
    with TestClient(app) as client:
        response = client.post("/api/super-agent" + endpoint, json=request)
    assert response.status_code == 200, response.text
    kwargs = getattr(service, method).call_args.kwargs
    _assert_reporting(kwargs)
    if "batch" in endpoint:
        assert kwargs["max_parallel_cases"] == 2


@pytest.mark.parametrize("endpoint", ["/regenerate", "/regenerate/start"])
@pytest.mark.parametrize(
    "overrides",
    [{}, dict.fromkeys(REPORTING), {"report_version": "", "reporting_period": ""}],
)
def test_api_regeneration_preserves_inheritance_and_explicit_clears(
    monkeypatch, endpoint, overrides
):
    service = Mock()
    method = "start_regeneration" if endpoint.endswith("/start") else "regenerate"
    getattr(service, method).return_value = "job_id" if endpoint.endswith("/start") else {}
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    with TestClient(app) as client:
        response = client.post(
            "/api/super-agent" + endpoint,
            json={"run_id": "run_original", **overrides},
        )
    assert response.status_code == 200, response.text
    kwargs = getattr(service, method).call_args.kwargs
    _assert_reporting(kwargs, {key: overrides.get(key) for key in REPORTING})


@pytest.mark.parametrize("endpoint,method,payload", ENDPOINTS)
@pytest.mark.parametrize(
    "exception,status",
    [
        (CapacityBusyError("All slots occupied"), 429),
        (ReportingParameterError("Missing reporting_period"), 422),
        (ValueError("Unknown case or run"), 404),
    ],
)
def test_all_api_entrypoints_map_reporting_and_capacity_errors(
    monkeypatch, endpoint, method, payload, exception, status
):
    service = Mock()
    getattr(service, method).side_effect = exception
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    with TestClient(app) as client:
        response = client.post("/api/super-agent" + endpoint, json=payload)
    assert response.status_code == status, response.text
    if status == 429:
        assert "busy" in response.json()["detail"].lower()
    else:
        assert response.json()["detail"] == str(exception)


@pytest.mark.parametrize("endpoint,method,payload", ENDPOINTS)
@pytest.mark.parametrize(
    "invalid",
    [
        {"reporting_year": ""},
        {"reporting_year": "２０２６"},
        {"report_version": "x" * 201},
        {"reporting_period": "x" * 201},
    ],
)
def test_api_rejects_invalid_reporting_before_service(
    monkeypatch, endpoint, method, payload, invalid
):
    service = Mock()
    monkeypatch.setattr(routes, "get_super_agent_service", lambda: service)
    with TestClient(app) as client:
        response = client.post("/api/super-agent" + endpoint, json={**payload, **invalid})
    assert response.status_code == 422
    getattr(service, method).assert_not_called()
