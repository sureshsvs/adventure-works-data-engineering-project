from __future__ import annotations

import httpx

from gardianai_agentharness.config import settings
from gardianai_agentharness.services import sharepoint_storage


def test_upload_report_creates_quarter_folder_and_uploads_docx(monkeypatch):
    monkeypatch.setattr(settings, "sharepoint_site_hostname", "tenant.sharepoint.com")
    monkeypatch.setattr(settings, "sharepoint_site_path", "/sites/audit")
    monkeypatch.setattr(settings, "sharepoint_drive_name", "Documents")
    monkeypatch.setattr(settings, "sharepoint_folder_path", "Reports/Actual outputs")
    monkeypatch.setattr(sharepoint_storage, "_get_graph_access_token", lambda: "test-token")

    folder_created = False
    uploaded: dict[str, object] = {}

    def handle(request: httpx.Request) -> httpx.Response:
        nonlocal folder_created
        path = request.url.path
        if path == "/v1.0/sites/tenant.sharepoint.com:/sites/audit":
            return httpx.Response(200, json={"id": "site-id"})
        if path == "/v1.0/sites/site-id/drives":
            return httpx.Response(
                200, json={"value": [{"id": "drive-id", "name": "Documents"}]}
            )
        if path == "/v1.0/drives/drive-id/root:/Reports/Actual outputs":
            return httpx.Response(200, json={"id": "output-folder-id"})
        if path == "/v1.0/drives/drive-id/items/output-folder-id:/Q1 2026":
            if folder_created:
                return httpx.Response(
                    200,
                    json={"id": "quarter-folder-id", "folder": {"childCount": 0}},
                )
            return httpx.Response(404, json={"error": {"code": "itemNotFound"}})
        if path == "/v1.0/drives/drive-id/items/output-folder-id/children":
            folder_created = True
            return httpx.Response(
                201,
                json={"id": "quarter-folder-id", "folder": {"childCount": 0}},
            )
        if path == "/v1.0/drives/drive-id/items/quarter-folder-id:/CTRL-01.docx:/content":
            uploaded["content"] = request.content
            uploaded["content_type"] = request.headers["content-type"]
            uploaded["authorization"] = request.headers["authorization"]
            return httpx.Response(
                201,
                json={
                    "id": "report-item-id",
                    "name": "CTRL-01.docx",
                    "webUrl": "https://tenant.sharepoint.com/report",
                },
            )
        return httpx.Response(500, text=f"Unexpected request: {request.method} {request.url}")

    real_client = httpx.Client
    monkeypatch.setattr(
        sharepoint_storage.httpx,
        "Client",
        lambda **kwargs: real_client(
            transport=httpx.MockTransport(handle), **kwargs
        ),
    )

    result = sharepoint_storage.upload_report(b"docx-bytes", "CTRL-01", "Q1 2026")

    assert result == {
        "filename": "CTRL-01.docx",
        "item_id": "report-item-id",
        "web_url": "https://tenant.sharepoint.com/report",
        "quarter": "Q1 2026",
    }
    assert folder_created
    assert uploaded == {
        "content": b"docx-bytes",
        "content_type": sharepoint_storage._DOCX_MEDIA,
        "authorization": "Bearer test-token",
    }


def test_upload_report_rejects_path_segments(monkeypatch):
    monkeypatch.setattr(settings, "sharepoint_site_hostname", "tenant.sharepoint.com")
    monkeypatch.setattr(settings, "sharepoint_site_path", "/sites/audit")
    monkeypatch.setattr(settings, "sharepoint_drive_name", "Documents")
    monkeypatch.setattr(sharepoint_storage, "_get_graph_access_token", lambda: "test-token")

    try:
        sharepoint_storage.upload_report(b"docx-bytes", "../other", "Q1 2026")
    except ValueError as exc:
        assert "single non-empty path segment" in str(exc)
    else:
        raise AssertionError("Expected invalid control_name to be rejected")