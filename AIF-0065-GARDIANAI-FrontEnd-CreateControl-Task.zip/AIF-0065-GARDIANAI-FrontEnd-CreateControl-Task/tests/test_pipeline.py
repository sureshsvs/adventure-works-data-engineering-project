"""Offline end-to-end tests for prompt-driven generation and report output.

These run with **stdlib only** (no FastAPI / LLM required), exercising document
ingestion, the offline document generator, run persistence, regeneration, upload
of a custom test case, and .docx report generation against the bundled sample
data.
"""

from __future__ import annotations

import io
import zipfile
from xml.etree import ElementTree as ET

import pytest

from gardianai_agentharness.services.document_store import get_document_store
from gardianai_agentharness.services.super_agent_service import get_super_agent_service


def test_sample_data_indexed():
    store = get_document_store()
    ids = {tc.id for tc in store.list_test_cases()}
    assert {"tc1", "tc2", "tc3", "tc4"}.issubset(ids)


def test_search_returns_hits():
    store = get_document_store()
    assert store.search("databook"), "expected databook documents in the index"


@pytest.mark.parametrize("tc_id", ["tc1", "tc2", "tc3", "tc4"])
def test_generate_produces_valid_docx(tc_id: str):
    svc = get_super_agent_service()
    run = svc.generate(tc_id, run_title="Sample report")

    doc = run["document"]
    assert doc["title"], "the generated document must have a title"
    assert doc["sections"], "the generated document must have sections"
    assert run["section_count"] >= 1

    report = svc.open_report(run["run_id"])
    assert report is not None
    _assert_valid_docx(report[0])


def test_regenerate_creates_a_new_run():
    svc = get_super_agent_service()
    run = svc.generate("tc1", run_title="Sample report")
    again = svc.regenerate(run["run_id"])
    assert again["run_id"] != run["run_id"]
    assert again["test_case_id"] == "tc1"


def test_upload_creates_runnable_test_case():
    store = get_document_store()
    tc = store.register_uploaded_test_case(
        title="Unit-test upload",
        input_files=[("figures.csv", b"metric,value\nEarnings,100\n")],
        prompt_text="Check the ingested figures for internal consistency.",
    )
    assert tc.archetype == "custom"
    assert tc.input_documents, "uploaded inputs must be registered"
    assert store.get_test_case(tc.id) is tc

    run = get_super_agent_service().generate(tc.id, run_title="Upload review")
    assert run["document"]["sections"]
    report = get_super_agent_service().open_report(run["run_id"])
    assert report is not None
    _assert_valid_docx(report[0])


def _assert_valid_docx(data: bytes):
    with zipfile.ZipFile(io.BytesIO(data)) as zf:
        names = zf.namelist()
        assert "word/document.xml" in names
        # Well-formed XML body.
        ET.fromstring(zf.read("word/document.xml"))
