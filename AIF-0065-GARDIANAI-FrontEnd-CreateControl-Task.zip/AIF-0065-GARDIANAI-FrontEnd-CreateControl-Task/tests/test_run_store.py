from __future__ import annotations

import json

from gardianai_agentharness.services.models import (
    GeneratedDocument,
    GenerationRun,
    HumanDisposition,
)
from gardianai_agentharness.services.run_store import LocalRunStore
from gardianai_agentharness.services.super_agent_service import SuperAgentService


def test_local_run_store_rejects_path_traversal_run_id(tmp_path):
    store = LocalRunStore(tmp_path / "runs")
    (tmp_path / "outside.json").write_text(json.dumps({}), encoding="utf-8")

    assert store.load("../outside") is None


def test_disposition_update_persists_metadata_without_changing_report(tmp_path):
    store = LocalRunStore(tmp_path)
    run = GenerationRun(
        test_case_id="tc-test",
        test_case_title="Test case",
        prompt_version="v1",
        model="test-model",
        mode="offline",
        document=GeneratedDocument(title="Report"),
        report_filename="report.docx",
    )
    original_report = b"unchanged report bytes"
    store.save(run, original_report)

    service = object.__new__(SuperAgentService)
    service._runs = store
    updated = service.update_disposition(
        run.run_id, HumanDisposition.APPROVED, "Reviewed and approved."
    )

    assert updated["human_disposition"] == HumanDisposition.APPROVED.value
    assert updated["reviewer_comment"] == "Reviewed and approved."
    persisted = store.load(run.run_id)
    assert persisted is not None
    assert persisted.human_disposition is HumanDisposition.APPROVED
    assert persisted.reviewer_comment == "Reviewed and approved."
    assert store.open_report(run.run_id) == (original_report, "report.docx")