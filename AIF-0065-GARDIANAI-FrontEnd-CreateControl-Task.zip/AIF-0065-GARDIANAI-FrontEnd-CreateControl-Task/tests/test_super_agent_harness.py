"""Offline checks for the harness's executable retrieval tools."""

from __future__ import annotations

import asyncio
import json
from unittest.mock import AsyncMock, Mock

import pytest

from gardianai_agentharness.services import super_agent_harness as harness

agent_framework = pytest.importorskip("agent_framework")


def _toolbox() -> Mock:
    toolbox = Mock()
    toolbox.tool_specs.return_value = [
        {
            "type": "function",
            "function": {
                "name": name,
                "description": f"Run {name}",
                "parameters": schema,
            },
        }
        for name, schema in [
            ("list_documents", {"type": "object", "properties": {}}),
            (
                "fetch_web_page",
                {
                    "type": "object",
                    "properties": {"url": {"type": "string"}},
                    "required": ["url"],
                },
            ),
        ]
    ]
    toolbox.dispatch.side_effect = lambda name, args: json.dumps(
        {"tool": name, "args": args}
    )
    return toolbox


def test_toolbox_tools_preserve_schemas_and_dispatch_names():
    toolbox = _toolbox()
    tools = harness._toolbox_tools(toolbox)

    async def invoke_tools():
        for tool, spec in zip(tools, toolbox.tool_specs(), strict=True):
            assert tool.name == spec["function"]["name"]
            assert tool.description == spec["function"]["description"]
            assert tool.parameters() == spec["function"]["parameters"]
            arguments = (
                {"url": "https://www.shell.com/example.html"}
                if tool.name == "fetch_web_page"
                else {}
            )
            result = await tool.invoke(arguments=arguments)
            assert json.loads(result[0].text) == {
                "tool": tool.name,
                "args": arguments,
            }

    asyncio.run(invoke_tools())
    assert toolbox.dispatch.call_count == 2


def test_run_harness_registers_toolbox_tools(monkeypatch, tmp_path):
    toolbox = _toolbox()
    agent = Mock()
    agent.run = AsyncMock(return_value=Mock(text='{"sections": []}'))
    factory = Mock(return_value=agent)
    monkeypatch.setattr(agent_framework, "create_harness_agent", factory)
    monkeypatch.setattr(harness, "_build_af_client", Mock(return_value=object()))
    monkeypatch.setattr(harness, "_record_harness_usage", Mock())

    result = asyncio.run(harness._run_harness("documents/", tmp_path, toolbox))

    assert result == '{"sections": []}'
    options = factory.call_args.kwargs
    assert [tool.name for tool in options["tools"]] == [
        "list_documents",
        "fetch_web_page",
    ]
    assert options["disable_web_search"] is True
    assert "fetch_web_page" in options["harness_instructions"]
    assert "not through the file tools" in options["harness_instructions"]
    agent.run.assert_awaited_once_with(
        options["agent_instructions"], session=agent.create_session.return_value
    )
