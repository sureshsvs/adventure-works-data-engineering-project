"""extract_xlsx must resolve per-cell number-format scale.

Real defect found in the Shell quarterly databook (Test case 2, CP sheet): a
custom format like ``#,##0,,`` divides the DISPLAYED value by 1,000,000 vs the
value Excel stores. Reading the raw stored value (as the old implementation
did) renders the Q4 2025/FY2025 columns ~1,000,000x larger than every other
period in the same row -- indistinguishable from a real databook error.
"""

from __future__ import annotations

import zipfile
import sys
from pathlib import Path

import pytest

from gardianai_agentharness.services.document_store import DocumentStore
from gardianai_agentharness.services.extractors import _format_scale, extract_pdf, extract_xlsx

_WORKBOOK = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheets><sheet name="CP" sheetId="1"/></sheets>
</workbook>"""

_STYLES = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0,,"/></numFmts>
  <cellXfs count="2"><xf numFmtId="0"/><xf numFmtId="164"/></cellXfs>
</styleSheet>"""

_SHEET1 = b"""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <sheetData>
    <row r="1">
      <c r="A1" s="0"><v>123</v></c>
      <c r="B1" s="1"><v>6898218563.35</v></c>
    </row>
  </sheetData>
</worksheet>"""


def _write_workbook(path: Path) -> None:
    with zipfile.ZipFile(path, "w") as zf:
        zf.writestr("xl/workbook.xml", _WORKBOOK)
        zf.writestr("xl/styles.xml", _STYLES)
        zf.writestr("xl/worksheets/sheet1.xml", _SHEET1)


def test_scale_format_divides_displayed_value(tmp_path):
    path = tmp_path / "databook.xlsx"
    _write_workbook(path)

    text = extract_xlsx(path)

    assert "## Sheet: CP" in text
    row = next(line for line in text.splitlines() if line.startswith("123"))
    cols = row.split("\t")
    assert cols[0] == "123", "a General-format cell must pass through unscaled"
    assert float(cols[1]) == 6898.21856335, (
        "a #,##0,, cell must be divided by 1e6 to match its DISPLAYED value, "
        "not the raw stored value"
    )


def test_format_scale_counts_trailing_commas():
    assert _format_scale("General") == 1
    assert _format_scale("#,##0") == 1
    assert _format_scale("#,##0,") == 1_000
    assert _format_scale("#,##0,,") == 1_000_000
    assert _format_scale('#,##0,,"m"') == 1_000_000
    assert _format_scale("#,##0,,;-#,##0,,") == 1_000_000


def _write_pdf(path, *, text=True):
    from pypdf import PdfWriter
    from pypdf.generic import (
        DecodedStreamObject, DictionaryObject, NameObject,
    )

    writer = PdfWriter()
    page = writer.add_blank_page(width=612, height=792)
    if text:
        font = DictionaryObject({
            NameObject("/Type"): NameObject("/Font"),
            NameObject("/Subtype"): NameObject("/Type1"),
            NameObject("/BaseFont"): NameObject("/Helvetica"),
        })
        page[NameObject("/Resources")] = DictionaryObject({
            NameObject("/Font"): DictionaryObject({
                NameObject("/F1"): writer._add_object(font),
            }),
        })
        stream = DecodedStreamObject()
        stream.set_data(b"BT /F1 12 Tf 72 720 Td (Revenue 100 Cost 40) Tj ET")
        page[NameObject("/Contents")] = writer._add_object(stream.flate_encode())
    with path.open("wb") as out:
        writer.write(out)


def test_pdf_extracts_compressed_text_and_page_locator(tmp_path):
    path = tmp_path / "financials.pdf"
    _write_pdf(path)
    text = extract_pdf(path)
    assert "## Page 1" in text
    assert "Revenue 100 Cost 40" in text
    assert not any(ord(c) < 32 and c not in "\r\n\t" for c in text)


def test_missing_pdf_reader_does_not_scrape_binary(tmp_path, monkeypatch):
    path = tmp_path / "financials.pdf"
    path.write_bytes(b"%PDF-1.4\n(stream and misleading binary text)")
    monkeypatch.setitem(sys.modules, "pypdf", None)
    with pytest.raises(RuntimeError, match="pypdf is not installed"):
        extract_pdf(path)


def test_bad_pdf_is_an_explicit_failure(tmp_path):
    path = tmp_path / "financials.pdf"
    path.write_bytes(b"%PDF-1.4\n(binary garbage)")
    with pytest.raises(RuntimeError, match="Cannot extract PDF"):
        extract_pdf(path)


def test_image_only_pdf_requires_ocr(tmp_path):
    path = tmp_path / "scan.pdf"
    _write_pdf(path, text=False)
    with pytest.raises(RuntimeError, match="no extractable text layer"):
        extract_pdf(path)


def test_failed_pdf_extraction_is_not_cached_as_empty_text(tmp_path):
    path = tmp_path / "financials.pdf"
    path.write_bytes(b"%PDF-1.4\n(binary garbage)")
    store = DocumentStore(root=tmp_path)
    ref = store._register(path, "input", "uploaded")
    with pytest.raises(RuntimeError, match="Cannot extract PDF"):
        store.get_text(ref.id)
    assert ref.id not in store._text_cache
    _write_pdf(path)
    assert "Revenue 100 Cost 40" in store.get_text(ref.id)
