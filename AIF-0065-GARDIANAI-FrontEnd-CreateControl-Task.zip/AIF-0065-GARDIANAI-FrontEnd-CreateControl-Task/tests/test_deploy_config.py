"""Offline contract/mocked CLI tests, not proof the private golden image works."""
from __future__ import annotations

import os
import re
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = ROOT / ".github/workflows/Deploy.ContainerApp.yml"
STORAGE = ROOT / ".github/scripts/azure_files_storage.sh"
ENTRYPOINT = ROOT / "backend-entrypoint.sh"
GOLDEN_BASE = "aztcacrngw0065devaif.azurecr.io/mc-aif-golden-repo/aif-golden-env:latest"


class DeployContractTests(unittest.TestCase):
    def test_golden_image_without_dependency_provisioning(self):
        dockerfile = (ROOT / "Dockerfile").read_text()
        self.assertEqual(dockerfile.splitlines()[0], f"FROM {GOLDEN_BASE}")
        for manifest in ("requirements*.txt", "pyproject.toml", "Pipfile*", "poetry.lock"):
            self.assertFalse(list(ROOT.glob(manifest)))
        text = dockerfile + ENTRYPOINT.read_text()
        self.assertNotRegex(
            text, r"pip\s+install|(?:apt-get|apk|tdnf|dnf|microdnf)\s+(?:add|install)"
            r"|python\S*\s+-m\s+venv|/opt/venv|ln\s+-s|alias\s+python",
        )
        self.assertIn("RUN sh /app/backend-entrypoint.sh --check", dockerfile)
        self.assertIn('CMD ["sh", "/app/backend-entrypoint.sh"]', dockerfile)
        self.assertIn('exec "$runtime" -m uvicorn', ENTRYPOINT.read_text())
        self.assertNotIn("import gardianai_agentharness", ENTRYPOINT.read_text())
        self.assertNotIn("ENTRYPOINT ", dockerfile)

    def test_workflow_preserves_loaded_mode_and_mounts(self):
        text = WORKFLOW.read_text()
        step = text.split("- name: Ensure Azure Files share and Container Apps storage", 1)[1]
        step = step.split("\n    - name:", 1)[0]
        self.assertIn("AZURE_FILES_AUTH_MODE_VAR: ${{ vars.AZURE_FILES_AUTH_MODE }}", step)
        self.assertNotRegex(step, re.compile(r"^\s+AZURE_FILES_AUTH_MODE:", re.M))
        self.assertIn("AZURE_FILES_ACCOUNT_KEY: ${{ secrets.AZURE_FILES_ACCOUNT_KEY }}", step)
        self.assertIn("run: bash .github/scripts/azure_files_storage.sh", step)
        self.assertNotIn("${{", step.split("run:", 1)[1])
        self.assertIn("# - name: Mount Azure Files share into the container", text)
        self.assertNotIn("\n    - name: Mount Azure Files share", text)
        self.assertIn('GOLDEN_PYTHON: ${{ vars.GOLDEN_PYTHON }}', text)
        self.assertIn('--build-arg "GOLDEN_PYTHON=${GOLDEN_PYTHON:-}"', text)
        for source in (text, STORAGE.read_text()):
            live = "\n".join(line for line in source.splitlines() if not line.lstrip().startswith("#"))
            self.assertNotIn("--azure-file-identity", live)
        self.assertIn("AZURE_FILES_AUTH_MODE=account-key", (ROOT / ".github/variables/dev.env").read_text())


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.log = self.root / "az.log"
        az = self.root / "az"
        az.write_text("""#!/bin/bash
printf '%s\\n' "$*" >> "$AZ_LOG"
if [ "$1 $2 $3 $4" = "containerapp env storage set" ]; then
  if [ "${FAIL_SET:-}" = true ]; then
    echo "$AZURE_FILES_ACCOUNT_KEY" >&2
    exit 4
  fi
fi
if [ "$1 $2 $3 $4" = "containerapp env storage show" ]; then
  [ -n "${FAKE_SHOW:-}" ] || exit 3
  printf '%b\\n' "$FAKE_SHOW"
fi
""")
        az.chmod(0o755)
        # A sentinel, not an actual credential.
        self.key = "test-account-key-not-a-real-credential"

    def run_storage(self, **overrides):
        env = {
            "PATH": f"{self.root}:/usr/bin:/bin",
            "AZ_LOG": str(self.log),
            "RESOURCE_GROUP": "rg",
            "STORAGE_ACCOUNT_NAME": "acct",
            "AZURE_FILES_SHARE_NAME": "gardianai-state",
            "ACA_ENV_NAME": "env",
            "ACA_STORAGE_NAME": "gardianai-files",
            "FAKE_SHOW": "acct\\tgardianai-state\\tReadWrite",
        }
        env.update({k: v for k, v in overrides.items() if v is not None})
        self.log.unlink(missing_ok=True)
        proc = subprocess.run(
            ["/bin/bash", "-x", str(STORAGE)], env=env, capture_output=True, text=True,
        )
        calls = self.log.read_text().splitlines() if self.log.exists() else []
        return proc, calls

    def test_default_and_blank_modes_are_read_only(self):
        for mode in (None, "", "  "):
            with self.subTest(mode=mode):
                proc, calls = self.run_storage(
                    AZURE_FILES_AUTH_MODE=mode, AZURE_FILES_AUTH_MODE_VAR=mode,
                    AZURE_FILES_ACCOUNT_KEY=self.key, GITHUB_ACTIONS="true",
                )
                self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
                self.assertIn("validate (from default)", proc.stdout)
                self.assertEqual(len(calls), 1)
                self.assertTrue(calls[0].startswith("containerapp env storage show"))
                self.assertNotIn(self.key, proc.stdout + proc.stderr + "\n".join(calls))

    def test_env_file_wins_when_github_variable_unset_or_blank(self):
        for var in (None, "", "  "):
            with self.subTest(var=var):
                proc, calls = self.run_storage(
                    AZURE_FILES_AUTH_MODE="account-key", AZURE_FILES_AUTH_MODE_VAR=var,
                    AZURE_FILES_ACCOUNT_KEY=self.key,
                )
                self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
                self.assertIn("account-key (from env file", proc.stdout)
                self.assertEqual(len(calls), 3)
                self.assertIn("--azure-file-account-key " + self.key, calls[1])
                for flag in ("--azure-file-account-name acct", "--azure-file-share-name gardianai-state", "--access-mode ReadWrite"):
                    self.assertIn(flag, calls[1])
                self.assertNotIn(self.key, proc.stdout + proc.stderr)

    def test_github_variable_wins_over_env_file(self):
        for var, file_mode, expected in (
            ("validate", "account-key", "validate"),
            (" ACCOUNT-KEY\r ", "validate", "account-key"),
        ):
            with self.subTest(var=var):
                proc, calls = self.run_storage(
                    AZURE_FILES_AUTH_MODE=file_mode, AZURE_FILES_AUTH_MODE_VAR=var,
                    AZURE_FILES_ACCOUNT_KEY=self.key,
                )
                self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
                self.assertIn(f"{expected} (from GitHub variable", proc.stdout)
                self.assertEqual(len(calls), 1 if expected == "validate" else 3)

    def test_missing_secret_fails_before_any_azure_call(self):
        for key in (None, ""):
            with self.subTest(key=key):
                proc, calls = self.run_storage(
                    AZURE_FILES_AUTH_MODE="account-key", AZURE_FILES_ACCOUNT_KEY=key,
                )
                self.assertNotEqual(proc.returncode, 0)
                self.assertIn("Not falling back to managed identity", proc.stdout)
                self.assertEqual(calls, [])

    def test_invalid_mode_has_no_fallback_or_azure_calls(self):
        for mode in ("acount-key", "managed-identity", "system", "sas"):
            with self.subTest(mode=mode):
                proc, calls = self.run_storage(AZURE_FILES_AUTH_MODE_VAR=mode)
                self.assertNotEqual(proc.returncode, 0)
                self.assertIn("Unsupported AZURE_FILES_AUTH_MODE", proc.stdout)
                self.assertEqual(calls, [])

    def test_required_configuration_fails_early(self):
        proc, calls = self.run_storage(STORAGE_ACCOUNT_NAME="")
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("Required variable STORAGE_ACCOUNT_NAME", proc.stdout)
        self.assertEqual(calls, [])

    def test_key_only_appears_in_github_mask_protocol(self):
        proc, _ = self.run_storage(
            AZURE_FILES_AUTH_MODE="account-key", AZURE_FILES_ACCOUNT_KEY=self.key,
            GITHUB_ACTIONS="true",
        )
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertIn(f"::add-mask::{self.key}", proc.stdout)
        visible = proc.stdout.replace(f"::add-mask::{self.key}", "") + proc.stderr
        self.assertNotIn(self.key, visible)

    def test_cli_failure_does_not_leak_key(self):
        proc, _ = self.run_storage(
            AZURE_FILES_AUTH_MODE="account-key", AZURE_FILES_ACCOUNT_KEY=self.key,
            FAIL_SET="true",
        )
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("account-key registration failed", proc.stdout)
        self.assertNotIn(self.key, proc.stdout + proc.stderr)

    def test_missing_registration(self):
        proc, _ = self.run_storage(FAKE_SHOW="")
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("Cannot read Container Apps environment storage", proc.stdout)

    def test_registration_must_match_expected_fields(self):
        for show in (
            "other\\tgardianai-state\\tReadWrite", "acct\\tother\\tReadWrite",
            "acct\\tgardianai-state\\tReadOnly", "acct", "\\t\\t",
        ):
            with self.subTest(show=show):
                proc, _ = self.run_storage(FAKE_SHOW=show)
                self.assertNotEqual(proc.returncode, 0)
                self.assertIn("does not match expected", proc.stdout)

    def test_cli_tsv_row_and_multiline_shapes(self):
        for show in ("acct\\tgardianai-state\\tReadWrite", "acct\\ngardianai-state\\nReadWrite"):
            with self.subTest(show=show):
                proc, calls = self.run_storage(FAKE_SHOW=show)
                self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
                self.assertIn("--query [properties.azureFile.accountName, properties.azureFile.shareName, properties.azureFile.accessMode]", calls[0])
                self.assertNotIn("accountKey", calls[0])
                self.assertIn("-o tsv", calls[0])


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.bin = self.root / "bin"
        self.bin.mkdir()
        self.modules = self.root / "modules"
        self.modules.mkdir()
        # Only mocks: execute the real import probe without host app dependencies.
        for name in (
            "fastapi", "uvicorn", "multipart.multipart", "pydantic_settings", "httpx",
            "openai", "pypdf", "azure.identity", "azure.ai.projects",
            "azure.storage.blob", "azure.cosmos",
        ):
            path = self.modules
            for part in name.split("."):
                path /= part
                path.mkdir(exist_ok=True)
                (path / "__init__.py").touch()
        self.log = self.root / "runtime.log"
        self.env = {
            "PATH": str(self.bin), "PYTHONPATH": str(self.modules),
            "HOST_PYTHON": sys.executable, "RUNTIME_LOG": str(self.log),
            "PYTHONDONTWRITEBYTECODE": "1",
        }

    def interpreter(self, name):
        path = self.bin / name
        path.write_text("""#!/bin/sh
printf '%s\\n' "$*" >> "$RUNTIME_LOG"
if [ "$1" = "-B" ]; then
  exec "$HOST_PYTHON" "$@"
fi
""")
        path.chmod(0o755)
        return path

    def run_runtime(self, *args, **overrides):
        return subprocess.run(
            ["/bin/sh", str(ENTRYPOINT), *args], env={**self.env, **overrides},
            text=True, capture_output=True,
        )

    def test_missing_path_runtime_is_actionable(self):
        proc = self.run_runtime("--check")
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("platform team must provide Python", proc.stderr)
        self.assertIn("verified absolute path", proc.stderr)
        self.assertNotIn("not found", proc.stderr)

    def test_invalid_explicit_path_does_not_fallback(self):
        self.interpreter("python3")
        for path in ("/not/a/platform/runtime", "python3"):
            with self.subTest(path=path):
                proc = self.run_runtime("--check", GOLDEN_PYTHON=path)
                self.assertNotEqual(proc.returncode, 0)
                self.assertFalse(self.log.exists())

    def test_existing_interpreter_names(self):
        for name in ("python3", "python"):
            with self.subTest(name=name):
                path = self.interpreter(name)
                proc = self.run_runtime("--check")
                self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
                self.assertEqual(self.log.read_text().splitlines(), ["-B -"])
                self.log.unlink()
                path.unlink()

    def test_verified_off_path_runtime_and_startup(self):
        path = self.interpreter("platform-python")
        proc = self.run_runtime(GOLDEN_PYTHON=str(path), PORT="8123")
        self.assertEqual(proc.returncode, 0, proc.stdout + proc.stderr)
        self.assertEqual(self.log.read_text().splitlines(), [
            "-B -", "-m uvicorn gardianai_agentharness.main:app --host 0.0.0.0 --port 8123",
        ])
        self.assertFalse(list(self.modules.rglob("__pycache__")))

    def test_import_failure_is_actionable_without_exception_secret(self):
        self.interpreter("python3")
        secret = "sentinel-must-not-appear-in-import-errors"
        (self.modules / "fastapi/__init__.py").write_text(
            "import os\nraise RuntimeError(os.environ['IMPORT_SECRET'])\n"
        )
        proc = self.run_runtime("--check", IMPORT_SECRET=secret)
        self.assertNotEqual(proc.returncode, 0)
        self.assertIn("dependency import check failed: fastapi", proc.stderr)
        self.assertIn("platform team", proc.stderr)
        self.assertNotIn(secret, proc.stdout + proc.stderr)
        self.assertNotIn("-m uvicorn", self.log.read_text())


if __name__ == "__main__":
    unittest.main()
