from __future__ import annotations

import io
import threading
import time
import zipfile

import pytest
from pydantic import ValidationError

from gardianai_agentharness.api.schemas import SuperAgentBatchRequest
from gardianai_agentharness.services.super_agent_service import get_super_agent_service


def _create_test_case(service, title: str):
    return service._store.register_uploaded_test_case(
        title=title,
        input_files=[("input.csv", b"item,value\nRevenue,100\n")],
        prompt_text="Check the supplied figures for consistency.",
    )


def test_batch_request_requires_at_least_one_test_case():
    with pytest.raises(ValidationError):
        SuperAgentBatchRequest(test_case_ids=[], run_title="Review")


def test_batch_runs_sequentially_and_isolates_failures(monkeypatch):
    service = get_super_agent_service()
    first_case = _create_test_case(service, "Batch first")
    failing_case = _create_test_case(service, "Batch failure")
    last_case = _create_test_case(service, "Batch last")
    first_started = threading.Event()
    release_first = threading.Event()
    executed: list[str] = []

    def fake_generate(
        test_case_id: str,
        use_expected_template: bool | None = None,
        economy: bool | None = None,
        reasoning_effort: str | None = None,
        *,
        run_title: str,
        description: str = "",
    ):
        executed.append(test_case_id)
        if test_case_id == first_case.id:
            first_started.set()
            assert release_first.wait(2)
            return {"run_id": "run-tc1", "test_case_id": test_case_id}
        if test_case_id == failing_case.id:
            raise RuntimeError("generation failed")
        return {"run_id": "run-tc3", "test_case_id": test_case_id}

    monkeypatch.setattr(service, "generate", fake_generate)
    with pytest.raises(ValueError, match="Unknown test case"):
        service.start_batch_generation([first_case.id, "missing"], run_title="Review")

    job_id = service.start_batch_generation(
        [first_case.id, failing_case.id, last_case.id], run_title="Review"
    )
    assert first_started.wait(2)
    running = service.job_status(job_id)
    assert running is not None
    assert running["batch"] is True
    assert running["current_item_index"] == 1
    assert [item["status"] for item in running["items"]] == [
        "running",
        "queued",
        "queued",
    ]

    release_first.set()
    deadline = time.monotonic() + 3
    status = service.job_status(job_id)
    while status and not status["done"] and time.monotonic() < deadline:
        time.sleep(0.01)
        status = service.job_status(job_id)

    assert status is not None and status["done"]
    assert status["status"] == "completed_with_errors"
    assert status["finished_count"] == status["total"] == 3
    assert executed == [first_case.id, failing_case.id, last_case.id]
    assert [item["status"] for item in status["items"]] == [
        "completed",
        "failed",
        "completed",
    ]
    assert status["items"][0]["run"]["run_id"] == "run-tc1"
    assert status["items"][1]["error"] == "generation failed"
    assert status["items"][2]["run"]["run_id"] == "run-tc3"


def test_batch_results_are_persisted_as_individual_reports():
    service = get_super_agent_service()
    first_case = _create_test_case(service, "Report first")
    second_case = _create_test_case(service, "Report second")
    job_id = service.start_batch_generation(
        [first_case.id, second_case.id], economy=True,
        run_title="Quarter-end batch", description="Compare disclosures",
    )
    deadline = time.monotonic() + 60
    status = service.job_status(job_id)
    while status and not status["done"] and time.monotonic() < deadline:
        time.sleep(0.05)
        status = service.job_status(job_id)

    assert status is not None and status["done"]
    assert status["status"] == "completed"
    assert status["run_title"] == "Quarter-end batch"
    assert status["description"] == "Compare disclosures"
    report_filenames = []
    run_ids = []
    for item in status["items"]:
        assert item["status"] == "completed"
        assert item["run"]["run_title"] == "Quarter-end batch"
        assert item["run"]["description"] == "Compare disclosures"
        assert item["run"]["test_case_id"] == item["test_case_id"]
        run_ids.append(item["run"]["run_id"])
        report_filenames.append(item["run"]["report_filename"])
        report = service.open_report(item["run"]["run_id"])
        assert report is not None
        with zipfile.ZipFile(io.BytesIO(report[0])) as docx:
            assert "word/document.xml" in docx.namelist()
    assert len(set(report_filenames)) == 2
    assert len(set(run_ids)) == 2
