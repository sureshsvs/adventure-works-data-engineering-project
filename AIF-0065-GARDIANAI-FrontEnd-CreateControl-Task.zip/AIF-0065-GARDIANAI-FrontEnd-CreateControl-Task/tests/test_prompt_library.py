"""Prompt library is blob-only; `fake_blob_storage` (conftest.py) fakes Azure."""

from __future__ import annotations

import json

import pytest

from gardianai_agentharness.config import settings
from gardianai_agentharness.services.blob_storage import BlobStorageNotConfigured
from gardianai_agentharness.services.prompt_library import PromptLibrary


def test_raises_when_blob_storage_not_configured(monkeypatch):
    monkeypatch.setattr(settings, "azure_storage_account_url", "")
    monkeypatch.setattr(settings, "azure_storage_connection_string", "")
    with pytest.raises(BlobStorageNotConfigured):
        PromptLibrary()


def test_first_construction_seeds_and_uploads_one_blob(fake_blob_storage):
    lib = PromptLibrary()
    assert lib.entries, "expected the library to seed from the sample test cases"

    blob_name = f"{settings.prompt_library_prefix}/prompt_library.json"
    key = (settings.sample_data_container, blob_name)
    assert key in fake_blob_storage
    assert json.loads(fake_blob_storage[key]) == lib.entries


def test_update_bumps_version_and_reuploads(fake_blob_storage):
    lib = PromptLibrary()
    entry_id = next(iter(lib.entries))
    original_version = lib.entries[entry_id]["version"]

    updated = lib.update(entry_id, "a new prompt", updated_by="tester")

    assert updated is not None
    assert updated["version"] == original_version + 1
    assert updated["prompt"] == "a new prompt"
    blob_name = f"{settings.prompt_library_prefix}/prompt_library.json"
    saved = json.loads(fake_blob_storage[(settings.sample_data_container, blob_name)])
    assert saved[entry_id]["version"] == original_version + 1


def test_reload_picks_up_existing_entries_without_reseeding(fake_blob_storage):
    first = PromptLibrary()
    entry_id = next(iter(first.entries))
    first.update(entry_id, "persisted prompt", updated_by="tester")

    second = PromptLibrary()

    assert second.entries[entry_id]["prompt"] == "persisted prompt"
    assert second.entries[entry_id]["updated_by"] == "tester"
