@echo off
REM Start both tiers for local development on Windows.
REM   1. FastAPI backend  (http://localhost:8000)
REM   2. React (Vite) SPA (http://localhost:5173)
REM Vite proxies /api to the backend in dev; nginx is the reverse proxy in prod.

cd /d "%~dp0"

if not exist ".venv" (
  echo [setup] creating .venv
  python -m venv .venv
)
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt

echo [start] FastAPI on http://localhost:8000
set PYTHONPATH=src
start "gardianai-api" cmd /k python -m uvicorn gardianai_agentharness.main:app --reload --port 8000

echo [start] Vite on http://localhost:5173
start "gardianai-web" cmd /k "cd frontend && npm install && npm run dev"
