"""One-off generator: build Design.pptx (stdlib only, no third-party deps).

Produces a single 16:9 slide styled like the reference "Solution Architecture"
diagram (orange column headers, light-yellow rounded boxes, red flow arrows,
platform + security footer bars) for the GARdian.AI Agent Harness.
"""

from __future__ import annotations

import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

OUT = Path("Design.pptx")

# 16:9 widescreen slide in EMU.
W, H = 12192000, 6858000

YELLOW = "FCEEA7"
YELLOW_HDR = "F6DE7A"
GRAY_BORDER = "BFBFBF"
ORANGE = "C55A11"
DARKBLUE = "1F3864"
RED = "FF0000"
FOOT = "F2F2F2"

_shapes: list[str] = []
_sid = [10]


def _next_id() -> int:
    _sid[0] += 1
    return _sid[0]


def _text_body(lines, header=None, align="l", body_color="404040",
               header_color=DARKBLUE, header_sz=1200, body_sz=900,
               header_bold=True):
    paras = []
    if header is not None:
        paras.append(
            f'<a:p><a:pPr algn="{align}"/>'
            f'<a:r><a:rPr lang="en-US" sz="{header_sz}" b="{1 if header_bold else 0}">'
            f'<a:solidFill><a:srgbClr val="{header_color}"/></a:solidFill></a:rPr>'
            f'<a:t>{escape(header)}</a:t></a:r></a:p>'
        )
    for ln in lines:
        paras.append(
            f'<a:p><a:pPr algn="{align}"/>'
            f'<a:r><a:rPr lang="en-US" sz="{body_sz}">'
            f'<a:solidFill><a:srgbClr val="{body_color}"/></a:solidFill></a:rPr>'
            f'<a:t>{escape(ln)}</a:t></a:r></a:p>'
        )
    if not paras:
        paras.append('<a:p><a:endParaRPr lang="en-US"/></a:p>')
    return (
        '<p:txBody><a:bodyPr wrap="square" lIns="72000" tIns="45000" '
        'rIns="72000" bIns="45000" anchor="t"><a:normAutofit/></a:bodyPr>'
        '<a:lstStyle/>' + "".join(paras) + "</p:txBody>"
    )


def box(x, y, w, h, header, lines, fill=YELLOW, line=GRAY_BORDER, align="l"):
    sid = _next_id()
    sp = (
        f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="box{sid}"/>'
        '<p:cNvSpPr/><p:nvPr/></p:nvSpPr>'
        f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
        '<a:prstGeom prst="roundRect"><a:avLst>'
        '<a:gd name="adj" fmla="val 6000"/></a:avLst></a:prstGeom>'
        f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>'
        f'<a:ln w="9525"><a:solidFill><a:srgbClr val="{line}"/></a:solidFill></a:ln>'
        '</p:spPr>'
        + _text_body(lines, header=header, align=align)
        + '</p:sp>'
    )
    _shapes.append(sp)


def textbox(x, y, w, h, lines, header=None, align="l", header_color=ORANGE,
            header_sz=1400, body_sz=900, body_color="595959"):
    sid = _next_id()
    sp = (
        f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="txt{sid}"/>'
        '<p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr>'
        f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
        '<a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
        + _text_body(lines, header=header, align=align, header_color=header_color,
                     header_sz=header_sz, body_sz=body_sz, body_color=body_color)
        + '</p:sp>'
    )
    _shapes.append(sp)


def bar(x, y, w, h, cells, fill=FOOT, title=None, title_color=ORANGE):
    """A footer bar with a bold title then evenly spaced label/desc cells."""
    sid = _next_id()
    _shapes.append(
        f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="bar{sid}"/><p:cNvSpPr/>'
        '<p:nvPr/></p:nvSpPr>'
        f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
        '<a:prstGeom prst="roundRect"><a:avLst>'
        '<a:gd name="adj" fmla="val 8000"/></a:avLst></a:prstGeom>'
        f'<a:solidFill><a:srgbClr val="{fill}"/></a:solidFill>'
        f'<a:ln w="9525"><a:solidFill><a:srgbClr val="{GRAY_BORDER}"/></a:solidFill>'
        '</a:ln></p:spPr>'
        + _text_body([]) + '</p:sp>'
    )
    cx = x + 150000
    if title:
        textbox(cx, y + h // 2 - 130000, 1500000, 300000, [], header=title,
                header_color=title_color, header_sz=1100)
        cx += 1500000
    cw = (x + w - cx - 150000) // len(cells)
    for label, desc in cells:
        textbox(cx, y + 120000, cw, h - 200000, [desc], header=label,
                header_color=DARKBLUE, header_sz=950, body_sz=800)
        cx += cw


def arrow(x, y, w=260000, h=180000):
    sid = _next_id()
    _shapes.append(
        f'<p:sp><p:nvSpPr><p:cNvPr id="{sid}" name="arr{sid}"/><p:cNvSpPr/>'
        '<p:nvPr/></p:nvSpPr>'
        f'<p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm>'
        '<a:prstGeom prst="rightArrow"><a:avLst/></a:prstGeom>'
        f'<a:solidFill><a:srgbClr val="{RED}"/></a:solidFill><a:ln><a:noFill/></a:ln>'
        '</p:spPr>' + _text_body([]) + '</p:sp>'
    )


def connector(x1, y1, x2, y2, color=RED, width=19050):
    """A straight arrow connector from (x1,y1) to (x2,y2) with a triangle head."""
    sid = _next_id()
    x, y = min(x1, x2), min(y1, y2)
    cx, cy = max(abs(x2 - x1), 1), max(abs(y2 - y1), 1)
    flip = (' flipH="1"' if x2 < x1 else "") + (' flipV="1"' if y2 < y1 else "")
    _shapes.append(
        f'<p:cxnSp><p:nvCxnSpPr><p:cNvPr id="{sid}" name="cxn{sid}"/>'
        '<p:cNvCxnSpPr/><p:nvPr/></p:nvCxnSpPr>'
        f'<p:spPr><a:xfrm{flip}><a:off x="{x}" y="{y}"/><a:ext cx="{cx}" cy="{cy}"/></a:xfrm>'
        '<a:prstGeom prst="straightConnector1"><a:avLst/></a:prstGeom>'
        f'<a:ln w="{width}"><a:solidFill><a:srgbClr val="{color}"/></a:solidFill>'
        '<a:tailEnd type="triangle"/></a:ln></p:spPr></p:cxnSp>'
    )


def slide_xml(shapes):
    """Wrap a list of shape XML strings into a full slide part."""
    return (
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
        'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
        'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
        '<p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill>'
        '<a:effectLst/></p:bgPr></p:bg>'
        '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/>'
        '</p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
        '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'
        + "".join(shapes)
        + '</p:spTree></p:cSld><p:clrMapOvr><a:overrideClrMapping '
        'bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" '
        'accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" '
        'hlink="hlink" folHlink="folHlink"/></p:clrMapOvr></p:sld>'
    )


def _reset_shapes():
    _shapes.clear()
    _sid[0] = 10


# ------------------------------------------------------------------- build slide
# Title
textbox(360000, 130000, 10500000, 480000, [], header="GARdian.AI SuperAgent — Deep-Research Report Generation",
        header_color="1A1A1A", header_sz=2200)

COLS = [
    ("Inputs", [
        ("Test case", ["prompt + input documents", "+ benchmark expected output"]),
        ("Uploaded pack", ["files + prompt (+ expected)", "→ runnable test case"]),
        ("Prompt library", ["versioned · superuser-editable"]),
        ("Domain skills + guardrails", ["auditor skills · PoC success criteria",
                                        "C4/C5/C6/C7 · scope discipline"]),
    ]),
    ("Ingestion + Retrieval", [
        ("document_store", ["index + extract + uploads"]),
        ("extractors", ["stdlib pdf/docx/xlsx/pptx/csv"]),
        ("Mistral Document AI OCR", ["page-by-page Markdown · cached"]),
        ("Retrieval tools", ["list / search / read_document",
                            "page/slide/sheet locators · shared corpus"]),
    ]),
    ("Reasoning Agent", [
        ("Strategy (tiered)", ["harness → deep-research",
                             "→ retrieval → full-text → offline"]),
        ("Harness (default)", ["temp file store + file tools",
                             "compaction · todo/plan-execute"]),
        ("Phases", ["plan → investigate → verify → synthesize"]),
        ("Azure AI Foundry model", ["SUPER_AGENT_MODEL · reasoning_effort",
                                     "economy → low-token path"]),
    ]),
    ("Output & Review", [
        ("DOCX report generator", ["stdlib WordprocessingML",
                                  "sections · tables · exec conclusion"]),
        ("GenerationRun persisted", ["run id · status · timestamps",
                                    "Blob (.docx) · Cosmos DB (run doc)"]),
        ("SuperAgent UI", ["preview · download .docx",
                          "regenerate · upload · history",
                          "co-author: edit + chat · sign-in/logout"]),
        ("End User / Auditor", ["review · download · re-run"]),
    ]),
]

n = len(COLS)
margin = 300000
gap = 340000
col_w = (W - 2 * margin - (n - 1) * gap) // n
hdr_y = 620000
box_top = 880000

col_x = []
for i in range(n):
    col_x.append(margin + i * (col_w + gap))

for i, (title, boxes) in enumerate(COLS):
    x = col_x[i]
    textbox(x, hdr_y, col_w, 300000, [], header=title, align="ctr",
            header_color=ORANGE, header_sz=1300)
    y = box_top
    for header, lines in boxes:
        h = 470000 + len(lines) * 250000
        box(x, y, col_w, h, header, lines, align="l")
        y += h + 170000

# Red flow arrows between columns (vertically centered in the diagram band).
arrow_y = 2650000
for i in range(n - 1):
    ax = col_x[i] + col_w + (gap - 260000) // 2
    arrow(ax, arrow_y)

# Footer bars.
bar(margin, 5500000, W - 2 * margin, 620000,
    [("Storage", "Blob (+ prompt library/OCR cache, blob-only) · Cosmos DB · Files"),
     ("Token economy", "ECONOMY · REASONING_EFFORT · TEMPLATE_CHARS"),
     ("Strategy flags", "use_harness · deep_research · shared_corpus"),
     ("Fallback", "harness → research → retrieval → full-text → offline")],
    title="Platform")

bar(margin, 6220000, W - 2 * margin, 470000,
    [("Uploads", "path-traversal-safe · type allow-list"),
     ("Shared corpus", "uploaded packs only · lazy"),
     ("Secrets", "env-only · none in code / logs")],
    title="Security", title_color=DARKBLUE, fill="FFF4E6")

textbox(360000, 6720000, 8000000, 120000, [],
        header="Copyright of Shell International B.V. · High-level design",
        header_color="808080", header_sz=800)
textbox(W - 1600000, 6720000, 1300000, 120000, [], header="INTERNAL",
        header_color=RED, header_sz=900, align="r")

# --------------------------------------------------------------------- pptx parts
SLIDE1 = slide_xml(_shapes)

# ===================================================================== Slide 2
# Block architecture with data flow between all components.
_reset_shapes()

BLUEBOX = "DDEBF7"
GREENBOX = "E2EFDA"
AZUREBOX = "FCE4D6"

textbox(360000, 130000, 11400000, 480000, [],
        header="GARdian.AI — Block Architecture & Data Flow",
        header_color="1A1A1A", header_sz=2200)

# Lane headers.
LANES = [
    (300000, 2100000, "Client"),
    (2650000, 2100000, "Edge / Auth"),
    (5000000, 3000000, "Backend — FastAPI (/api/*)"),
    (8300000, 3550000, "Azure services"),
]
for lx, lw, ltitle in LANES:
    textbox(lx, 640000, lw, 260000, [], header=ltitle, align="ctr",
            header_color=ORANGE, header_sz=1200)

# --- Client lane ---
box(300000, 1500000, 2100000, 1000000, "Browser · React SPA",
    ["Vite build (served by nginx)", "sends Bearer token", "+ Ocp-Apim-Subscription-Key"],
    fill=BLUEBOX)

# --- Edge / Auth lane ---
box(2650000, 980000, 2100000, 800000, "Azure Easy Auth",
    ["/.auth/me", "→ access_token"], fill=BLUEBOX)
box(2650000, 1950000, 2100000, 1050000, "nginx reverse proxy",
    ["serves SPA", "proxies /api/*", "forwards auth + APIM key"], fill=BLUEBOX)
box(2650000, 3170000, 2100000, 720000, "APIM (optional)",
    ["subscription-key gateway"], fill=BLUEBOX)

# --- Backend lane ---
box(5000000, 1180000, 3000000, 720000, "document_store",
    ["index · extract · stream pack", "lazy get_text() cache"], fill=GREENBOX)
box(5000000, 2020000, 3000000, 820000, "super_agent_service + run_store",
    ["tiered strategy · orchestrate", "persist run + report"], fill=GREENBOX)
box(5000000, 2960000, 3000000, 620000, "ocr_service",
    ["Mistral OCR client · Blob-cached"], fill=GREENBOX)
box(5000000, 3700000, 3000000, 620000, "report_service",
    ["DOCX (WordprocessingML)"], fill=GREENBOX)

# --- Azure services lane ---
box(8300000, 980000, 3550000, 760000, "Azure Blob Storage",
    ["sampledata pack (streamed)", "run reports · prompt library · OCR cache"], fill=AZUREBOX)
box(8300000, 1840000, 3550000, 640000, "Azure Cosmos DB",
    ["run documents · list query"], fill=AZUREBOX)
box(8300000, 2580000, 3550000, 640000, "Azure Files (mount)",
    ["harness scratch (local disk)"], fill=AZUREBOX)
box(8300000, 3320000, 3550000, 640000, "Azure AI Foundry",
    ["SuperAgent model · harness"], fill=AZUREBOX)
box(8300000, 4060000, 3550000, 640000, "Mistral Document AI",
    ["PDF → Markdown OCR"], fill=AZUREBOX)

# --- Data-flow connectors (numbered in the legend) ---
connector(2400000, 1800000, 2650000, 1360000)          # 1 SPA -> Easy Auth
connector(2400000, 2100000, 2650000, 2450000)          # 2 SPA -> nginx
connector(4750000, 2450000, 5000000, 2400000)          # 2 nginx -> FastAPI
connector(8000000, 1500000, 8300000, 1320000)          # 3 document_store -> Blob
connector(8000000, 3230000, 8300000, 1400000)          # 4 ocr -> Blob (blob-only cache)
connector(8000000, 3230000, 8300000, 4360000)          # 4 ocr -> Mistral
connector(8000000, 2380000, 8300000, 3600000)          # 5 service -> Foundry
connector(8000000, 2380000, 8300000, 1320000)          # 6 run_store -> Blob
connector(8000000, 2430000, 8300000, 2120000)          # 7 run_store -> Cosmos
connector(5000000, 3980000, 5000000, 2840000, color=DARKBLUE)  # report -> service (internal)

# --- Data-flow legend ---
box(300000, 4950000, 11550000, 1250000, None, [], fill=FOOT)
textbox(430000, 4990000, 11300000, 300000, [], header="Data flows",
        header_color=ORANGE, header_sz=1200)
LEGEND = [
    "1  Auth — SPA → Easy Auth  /.auth/me → access_token",
    "2  API — SPA → nginx → FastAPI  (/api/* with Bearer + Ocp-Apim-Subscription-Key)",
    "3  Pack — document_store streams the sampledata pack from Blob (lazy, cached)",
    "4  OCR — ocr_service → Mistral Document AI (PDF → Markdown); cache on Blob (blob-only)",
    "5  LLM — super_agent_service → Azure AI Foundry (harness / deep-research; llm mode)",
    "6  Report — report_service → .docx → Blob (run reports)",
    "7  Runs — run_store → Cosmos DB (run-document upsert + list query)",
    "8  Response — FastAPI → nginx → SPA (JSON + .docx download)",
]
half = (len(LEGEND) + 1) // 2
textbox(430000, 5320000, 5700000, 860000, LEGEND[:half], body_sz=950,
        body_color="404040")
textbox(6150000, 5320000, 5700000, 860000, LEGEND[half:], body_sz=950,
        body_color="404040")

textbox(360000, 6720000, 8000000, 120000, [],
        header="Copyright of Shell International B.V. · Block architecture",
        header_color="808080", header_sz=800)
textbox(W - 1600000, 6720000, 1300000, 120000, [], header="INTERNAL",
        header_color=RED, header_sz=900, align="r")

SLIDE2 = slide_xml(_shapes)

# ===================================================================== Slide 3
# SuperAgent services — module reference & call flow.
_reset_shapes()

textbox(360000, 130000, 11400000, 480000, [],
        header="SuperAgent Services — Module Reference & Call Flow",
        header_color="1A1A1A", header_sz=2200)

# Lane headers.
SA_LANES = [
    (300000, 3300000, "Orchestration"),
    (3900000, 3950000, "Generation strategies (tiered, degrade on failure)"),
    (8150000, 3700000, "Shared support"),
]
for lx, lw, ltitle in SA_LANES:
    textbox(lx, 640000, lw, 260000, [], header=ltitle, align="ctr",
            header_color=ORANGE, header_sz=1200)

# --- Orchestration lane ---
box(300000, 980000, 3300000, 1150000, "super_agent_service.py",
    ["SuperAgentService (singleton)",
     "generate / regenerate / co-author",
     "start_generation/_regeneration",
     "  -> background job + polling"], fill=GREENBOX)
box(300000, 2270000, 3300000, 900000, "super_agent_generation.py",
    ["generate_document() entry point",
     "tiered fallback + shared helpers",
     "(_SKILLS, _expected_template, _to_document)"], fill=GREENBOX)
box(300000, 3310000, 3300000, 700000, "report_service.py + run_store.py",
    ["render .docx -> persist run",
     "(local disk or Blob + Cosmos DB)"], fill=BLUEBOX)

# --- Generation strategies lane (tiered top -> bottom) ---
box(3900000, 980000, 3950000, 720000, "1  super_agent_harness.py",
    ["Agent Framework harness (top tier)",
     "temp workdir + read-only file tools"], fill=YELLOW)
box(3900000, 1780000, 3950000, 780000, "2  super_agent_research.py",
    ["deep-research: PLAN -> INVESTIGATE",
     "-> VERIFY -> SYNTHESIZE"], fill=YELLOW)
box(3900000, 2640000, 3950000, 620000, "3  single-pass tool retrieval",
    ["_generate_agentic() in super_agent_generation.py"], fill=YELLOW)
box(3900000, 3340000, 3950000, 620000, "4  full-context (legacy)",
    ["_build_context per-doc/total budgets"], fill=YELLOW)
box(3900000, 4040000, 3950000, 560000, "5  offline (deterministic)",
    ["no LLM configured -> honest draft, C7"], fill=AZUREBOX)

# --- Shared support lane ---
box(8150000, 980000, 3700000, 850000, "super_agent_retrieval.py",
    ["DocumentToolbox: list/search/read",
     "shared corpus · run_tool_loop"], fill=BLUEBOX)
box(8150000, 1930000, 3700000, 850000, "super_agent_context.py",
    ["build_context · fetch_web · parse_json",
     "progress report() · token tracking"], fill=BLUEBOX)
box(8150000, 2880000, 3700000, 700000, "document_store.py",
    ["get_text() — the single text",
     "materialisation point for all strategies"], fill=BLUEBOX)
box(8150000, 3780000, 3700000, 700000, "super_agent_coauthor.py",
    ["apply_direct_edit / coauthor_edit",
     "targeted section merge by heading"], fill=BLUEBOX)

# --- Call-flow connectors ---
connector(3600000, 1550000, 3900000, 1340000)          # service -> harness
connector(3600000, 1550000, 3900000, 2170000)          # service -> research
connector(3600000, 1550000, 3900000, 2950000)          # service -> tool retrieval
connector(3600000, 1550000, 3900000, 3650000)          # service -> full-context
connector(3600000, 1550000, 3900000, 4320000)          # service -> offline
connector(7850000, 1340000, 8150000, 1350000)          # harness -> retrieval (file tools)
connector(7850000, 2170000, 8150000, 2350000)          # research -> retrieval (tools)
connector(7850000, 2950000, 8150000, 2350000)          # tool retrieval -> retrieval
connector(7850000, 1700000, 8150000, 3230000)          # harness -> document_store
connector(8150000, 2350000, 8150000, 3230000, color=DARKBLUE)  # retrieval -> document_store
connector(3600000, 700000, 3900000, 1340000, color=DARKBLUE)   # generation.py orchestrates

# --- Legend / notes panel ---
box(300000, 4700000, 11550000, 1500000, None, [], fill=FOOT)
textbox(430000, 4740000, 11300000, 300000, [], header="Notes",
        header_color=ORANGE, header_sz=1200)
NOTES = [
    "Fallback order: harness -> deep-research -> tool retrieval -> full-context -> offline (each tier degrades on any failure)",
    "Every strategy grounds on document_store.get_text() and cites a document + page/slide/sheet location for each figure (C6 evidence trail)",
    "Token economy (SUPER_AGENT_ECONOMY): skips harness + deep-research, forces tier 3, low reasoning, 15k-char template",
    "Progress + token usage flow through super_agent_context.py context-vars, polled via GET /api/super-agent/jobs/{job_id}",
    "Post-generation: super_agent_coauthor.py edits a run's document in place (direct text edit, or a targeted chat edit scoped to one section)",
]
textbox(430000, 5060000, 11300000, 1100000, NOTES, body_sz=1000, body_color="404040")

textbox(360000, 6720000, 8000000, 120000, [],
        header="Copyright of Shell International B.V. · SuperAgent services",
        header_color="808080", header_sz=800)
textbox(W - 1600000, 6720000, 1300000, 120000, [], header="INTERNAL",
        header_color=RED, header_sz=900, align="r")

SLIDE3 = slide_xml(_shapes)

CONTENT_TYPES = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
    '<Default Extension="xml" ContentType="application/xml"/>'
    '<Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/>'
    '<Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/>'
    '<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/>'
    '<Override PartName="/ppt/slides/slide1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'
    '<Override PartName="/ppt/slides/slide2.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'
    '<Override PartName="/ppt/slides/slide3.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>'
    '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>'
    '</Types>'
)

RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/>'
    '</Relationships>'
)

PRESENTATION = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
    'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
    '<p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst>'
    '<p:sldIdLst><p:sldId id="256" r:id="rId2"/><p:sldId id="257" r:id="rId4"/><p:sldId id="258" r:id="rId5"/></p:sldIdLst>'
    f'<p:sldSz cx="{W}" cy="{H}" type="screen16x9"/>'
    '<p:notesSz cx="6858000" cy="9144000"/></p:presentation>'
)

PRESENTATION_RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>'
    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide1.xml"/>'
    '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme/theme1.xml"/>'
    '<Relationship Id="rId4" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide2.xml"/>'
    '<Relationship Id="rId5" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide3.xml"/>'
    '</Relationships>'
)



SLIDE_RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
    '</Relationships>'
)

_CLR = (
    '<a:clrScheme name="Office">'
    '<a:dk1><a:sysClr val="windowText" lastClr="000000"/></a:dk1>'
    '<a:lt1><a:sysClr val="window" lastClr="FFFFFF"/></a:lt1>'
    '<a:dk2><a:srgbClr val="1F3864"/></a:dk2><a:lt2><a:srgbClr val="EEECE1"/></a:lt2>'
    '<a:accent1><a:srgbClr val="C55A11"/></a:accent1>'
    '<a:accent2><a:srgbClr val="F6DE7A"/></a:accent2>'
    '<a:accent3><a:srgbClr val="A5A5A5"/></a:accent3>'
    '<a:accent4><a:srgbClr val="FFC000"/></a:accent4>'
    '<a:accent5><a:srgbClr val="4472C4"/></a:accent5>'
    '<a:accent6><a:srgbClr val="70AD47"/></a:accent6>'
    '<a:hlink><a:srgbClr val="0563C1"/></a:hlink>'
    '<a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme>'
)
_FONT = (
    '<a:fontScheme name="Office"><a:majorFont><a:latin typeface="Calibri Light"/>'
    '<a:ea typeface=""/><a:cs typeface=""/></a:majorFont>'
    '<a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/>'
    '</a:minorFont></a:fontScheme>'
)
_FMT = (
    '<a:fmtScheme name="Office">'
    '<a:fillStyleLst>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst>'
    '<a:lnStyleLst>'
    '<a:ln w="6350"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
    '<a:ln w="12700"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
    '<a:ln w="19050"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>'
    '</a:lnStyleLst>'
    '<a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle>'
    '<a:effectStyle><a:effectLst/></a:effectStyle>'
    '<a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst>'
    '<a:bgFillStyleLst>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>'
    '<a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst>'
    '</a:fmtScheme>'
)
THEME = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Office Theme">'
    '<a:themeElements>' + _CLR + _FONT + _FMT + '</a:themeElements>'
    '<a:objectDefaults/><a:extraClrSchemeLst/></a:theme>'
)

MASTER = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
    'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main">'
    '<p:cSld><p:bg><p:bgRef idx="1001"><a:schemeClr val="bg1"/></p:bgRef></p:bg>'
    '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/>'
    '</p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
    '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree>'
    '</p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" '
    'accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" '
    'accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
    '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst>'
    '</p:sldMaster>'
)
MASTER_RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/>'
    '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/>'
    '</Relationships>'
)
LAYOUT = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" '
    'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" '
    'xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" '
    'type="blank" preserve="1"><p:cSld name="Blank">'
    '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/>'
    '</p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/>'
    '<a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr></p:spTree>'
    '</p:cSld><p:clrMapOvr><a:overrideClrMapping bg1="lt1" tx1="dk1" bg2="lt2" '
    'tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" '
    'accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" '
    'folHlink="folHlink"/></p:clrMapOvr></p:sldLayout>'
)
LAYOUT_RELS = (
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/>'
    '</Relationships>'
)

with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    z.writestr("[Content_Types].xml", CONTENT_TYPES)
    z.writestr("_rels/.rels", RELS)
    z.writestr("ppt/presentation.xml", PRESENTATION)
    z.writestr("ppt/_rels/presentation.xml.rels", PRESENTATION_RELS)
    z.writestr("ppt/theme/theme1.xml", THEME)
    z.writestr("ppt/slideMasters/slideMaster1.xml", MASTER)
    z.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels", MASTER_RELS)
    z.writestr("ppt/slideLayouts/slideLayout1.xml", LAYOUT)
    z.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", LAYOUT_RELS)
    z.writestr("ppt/slides/slide1.xml", SLIDE1)
    z.writestr("ppt/slides/_rels/slide1.xml.rels", SLIDE_RELS)
    z.writestr("ppt/slides/slide2.xml", SLIDE2)
    z.writestr("ppt/slides/_rels/slide2.xml.rels", SLIDE_RELS)
    z.writestr("ppt/slides/slide3.xml", SLIDE3)
    z.writestr("ppt/slides/_rels/slide3.xml.rels", SLIDE_RELS)

print("wrote", OUT.resolve())
