#!/usr/bin/env bash
# First non-empty mode wins: GitHub variable, loaded env file, then validate.
set +x
set -euo pipefail

normalize() { printf '%s' "${1:-}" | tr -d '\r' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' | tr '[:upper:]' '[:lower:]'; }

mode_from_var="$(normalize "${AZURE_FILES_AUTH_MODE_VAR:-}")"
mode_from_file="$(normalize "${AZURE_FILES_AUTH_MODE:-}")"
if [ -n "$mode_from_var" ]; then
  mode="$mode_from_var"; source="GitHub variable AZURE_FILES_AUTH_MODE"
elif [ -n "$mode_from_file" ]; then
  mode="$mode_from_file"; source="env file AZURE_FILES_AUTH_MODE"
else
  mode="validate"; source="default"
fi

case "$mode" in
  validate|account-key) ;;
  *)
    echo "::error::Unsupported AZURE_FILES_AUTH_MODE (from ${source}). Use 'validate' or 'account-key'."
    exit 1
    ;;
esac
echo "Azure Files auth mode: ${mode} (from ${source})"

for var in RESOURCE_GROUP STORAGE_ACCOUNT_NAME AZURE_FILES_SHARE_NAME ACA_ENV_NAME ACA_STORAGE_NAME; do
  if [ -z "${!var:-}" ]; then
    echo "::error::Required variable ${var} is empty."
    exit 1
  fi
done

if [ "$mode" = "account-key" ]; then
  if [ -z "${AZURE_FILES_ACCOUNT_KEY:-}" ]; then
    echo "::error::AZURE_FILES_AUTH_MODE=account-key but secret AZURE_FILES_ACCOUNT_KEY is empty. Not falling back to managed identity."
    exit 1
  fi
  if [ "${GITHUB_ACTIONS:-}" = "true" ]; then
    printf '::add-mask::%s\n' "${AZURE_FILES_ACCOUNT_KEY}"
  fi

  # Idempotent creation is opt-in too; validate mode makes no Azure changes.
  az storage share-rm create \
    --resource-group "${RESOURCE_GROUP}" \
    --storage-account "${STORAGE_ACCOUNT_NAME}" \
    --name "${AZURE_FILES_SHARE_NAME}" \
    --quota 100 \
    --only-show-errors --output none 1>/dev/null 2>/dev/null || {
      echo "::error::Azure Files share creation failed. Ask the platform team to check the account/share and deployment permissions."
      exit 1
    }

  az containerapp env storage set \
    --name "${ACA_ENV_NAME}" -g "${RESOURCE_GROUP}" \
    --storage-name "${ACA_STORAGE_NAME}" \
    --azure-file-account-name "${STORAGE_ACCOUNT_NAME}" \
    --azure-file-account-key "${AZURE_FILES_ACCOUNT_KEY}" \
    --azure-file-share-name "${AZURE_FILES_SHARE_NAME}" \
    --access-mode ReadWrite \
    --only-show-errors --output none 1>/dev/null 2>/dev/null || {
      echo "::error::Azure Files account-key registration failed. Check secret AZURE_FILES_ACCOUNT_KEY (account key, not SAS) and deployment permissions with the platform team."
      exit 1
    }
fi

# Query only non-secret fields; never print the full registration or CLI errors.
if ! actual="$(az containerapp env storage show \
    --name "${ACA_ENV_NAME}" -g "${RESOURCE_GROUP}" \
    --storage-name "${ACA_STORAGE_NAME}" \
    --query "[properties.azureFile.accountName, properties.azureFile.shareName, properties.azureFile.accessMode]" \
    -o tsv --only-show-errors 2>/dev/null)"; then
  echo "::error::Cannot read Container Apps environment storage '${ACA_STORAGE_NAME}'. Ask the platform team to check registration and permissions, or opt in to account-key registration with secret AZURE_FILES_ACCOUNT_KEY."
  exit 1
fi
IFS=$'\t' read -r account share access <<<"$(printf '%s' "$actual" | tr -d '\r' | tr '\n' '\t')"

if [ "${account:-}" != "${STORAGE_ACCOUNT_NAME}" ] || [ "${share:-}" != "${AZURE_FILES_SHARE_NAME}" ] || [ "${access:-}" != "ReadWrite" ]; then
  echo "::error::Storage '${ACA_STORAGE_NAME}' does not match expected account=${STORAGE_ACCOUNT_NAME} share=${AZURE_FILES_SHARE_NAME} accessMode=ReadWrite."
  exit 1
fi
echo "Storage '${ACA_STORAGE_NAME}' matches expected account/share/ReadWrite."
