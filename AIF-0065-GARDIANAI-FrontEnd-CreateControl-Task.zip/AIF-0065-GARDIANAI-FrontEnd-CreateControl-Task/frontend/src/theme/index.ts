import type { ThemeProviderProps } from 'react-bootstrap';

// react-bootstrap ThemeProvider config: class prefixes and breakpoints.
export const bootstrapTheme: Pick<ThemeProviderProps, 'prefixes' | 'breakpoints' | 'minBreakpoint'> = {
  prefixes: {},
  breakpoints: ['xxl', 'xl', 'lg', 'md', 'sm', 'xs'],
  minBreakpoint: 'xs',
};

// Brand tokens; mirrored as CSS variables in gardian-theme.css.
export const brand = {
  yellow: '#FBCE07',
  red: '#DD1D21',
  navy: '#14235C',
} as const;
