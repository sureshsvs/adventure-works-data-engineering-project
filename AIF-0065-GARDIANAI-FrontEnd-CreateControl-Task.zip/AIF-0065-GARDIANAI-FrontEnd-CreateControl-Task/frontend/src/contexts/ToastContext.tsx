import { createContext, useCallback, useContext, useMemo, useRef, useState, type ReactNode } from 'react';
import { Toast, ToastContainer } from 'react-bootstrap';

type ToastVariant = 'success' | 'danger' | 'warning' | 'info';

interface ToastItem {
    id: number;
    variant: ToastVariant;
    title: string;
    message?: string;
}

interface ToastContextValue {
    notify: (variant: ToastVariant, title: string, message?: string) => void;
}

const ToastContext = createContext<ToastContextValue | undefined>(undefined);

const ICONS: Record<ToastVariant, string> = {
    success: 'bi-check-circle-fill',
    danger: 'bi-x-octagon-fill',
    warning: 'bi-exclamation-triangle-fill',
    info: 'bi-info-circle-fill',
};

export function ToastProvider({ children }: { children: ReactNode }) {
    const [toasts, setToasts] = useState<ToastItem[]>([]);
    const nextId = useRef(1);

    const notify = useCallback<ToastContextValue['notify']>((variant, title, message) => {
        const id = nextId.current++;
        setToasts((prev) => [...prev, { id, variant, title, message }]);
    }, []);

    const dismiss = (id: number) => setToasts((prev) => prev.filter((t) => t.id !== id));
    const value = useMemo(() => ({ notify }), [notify]);

    return (
        <ToastContext.Provider value={value}>
            {children}
            <ToastContainer position="top-end" className="p-3 position-fixed" style={{ zIndex: 1100 }}>
                {toasts.map((t) => (
                    <Toast
                        key={t.id}
                        onClose={() => dismiss(t.id)}
                        autohide
                        delay={t.variant === 'danger' ? 8000 : 4000}
                        bg={t.variant}
                    >
                        <Toast.Header>
                            <i className={`bi ${ICONS[t.variant]} me-2 text-${t.variant}`} aria-hidden="true" />
                            <strong className="me-auto">{t.title}</strong>
                        </Toast.Header>
                        {t.message && (
                            <Toast.Body className={t.variant === 'warning' ? '' : 'text-white'}>{t.message}</Toast.Body>
                        )}
                    </Toast>
                ))}
            </ToastContainer>
        </ToastContext.Provider>
    );
}

export function useToast(): ToastContextValue {
    const ctx = useContext(ToastContext);
    if (!ctx) throw new Error('useToast must be used within ToastProvider');
    return ctx;
}
