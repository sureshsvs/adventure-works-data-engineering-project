import { createContext, useContext, useMemo, useState, type ReactNode } from 'react';

import type { RunDraft } from '../types/run';

interface RunDraftContextValue {
    draft: RunDraft | null;
    setDraft: (draft: RunDraft | null) => void;
}

const RunDraftContext = createContext<RunDraftContextValue | undefined>(undefined);

// Carries the "Create New Run" form into the "Review & Generate" step.
export function RunDraftProvider({ children }: { children: ReactNode }) {
    const [draft, setDraft] = useState<RunDraft | null>(null);
    const value = useMemo(() => ({ draft, setDraft }), [draft]);
    return <RunDraftContext.Provider value={value}>{children}</RunDraftContext.Provider>;
}

export function useRunDraft(): RunDraftContextValue {
    const ctx = useContext(RunDraftContext);
    if (!ctx) throw new Error('useRunDraft must be used within RunDraftProvider');
    return ctx;
}
