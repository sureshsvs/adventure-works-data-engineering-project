import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';

export type ThemeMode = 'light' | 'dark';

interface ThemeContextValue {
    mode: ThemeMode;
    toggle: () => void;
}

const STORAGE_KEY = 'gardian.theme';
const ThemeContext = createContext<ThemeContextValue | undefined>(undefined);

function initialMode(): ThemeMode {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved === 'light' || saved === 'dark') return saved;
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function ThemeModeProvider({ children }: { children: ReactNode }) {
    const [mode, setMode] = useState<ThemeMode>(initialMode);

    useEffect(() => {
        document.documentElement.setAttribute('data-bs-theme', mode);
        localStorage.setItem(STORAGE_KEY, mode);
    }, [mode]);

    const toggle = useCallback(() => setMode((m) => (m === 'light' ? 'dark' : 'light')), []);
    const value = useMemo(() => ({ mode, toggle }), [mode, toggle]);

    return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useThemeMode(): ThemeContextValue {
    const ctx = useContext(ThemeContext);
    if (!ctx) throw new Error('useThemeMode must be used within ThemeModeProvider');
    return ctx;
}
