import axios from 'axios';

const baseURL = import.meta.env.VITE_API_URL || '/api';

export const apiClient = axios.create({
	baseURL,
	timeout: 600_000,
	headers: { 'Content-Type': 'application/json' },
});

let cachedAccessToken: string | null | undefined;

async function getAccessToken(): Promise<string | null> {
	if (cachedAccessToken !== undefined) return cachedAccessToken;
	try {
		const { data } = await axios.get<Array<{ access_token?: string }>>('/.auth/me');
		cachedAccessToken = data?.[0]?.access_token ?? null;
	} catch {
		cachedAccessToken = null;
	}
	return cachedAccessToken;
}

apiClient.interceptors.request.use(async (config) => {
	const token = await getAccessToken();
	if (token) config.headers.set('Authorization', `Bearer ${token}`);
	return config;
});

apiClient.interceptors.response.use(
	(response) => response,
	(error: unknown) => {
		if (axios.isAxiosError(error) && error.response?.status === 401) cachedAccessToken = undefined;
		return Promise.reject(error);
	}
);
