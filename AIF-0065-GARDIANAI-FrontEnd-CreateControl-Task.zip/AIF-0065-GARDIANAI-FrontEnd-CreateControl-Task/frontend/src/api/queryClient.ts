import { QueryClient } from '@tanstack/react-query';

import { isApiError } from '../utils/errors';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 30_000,
      refetchOnWindowFocus: false,
      retry: (failureCount, error) => {
        if (isApiError(error) && error.status !== undefined && error.status < 500) return false;
        return failureCount < 2;
      },
    },
  },
});

export const queryKeys = {
  tasks: ['tasks'] as const,
  task: (id: string, period?: string) => ['tasks', id, period ?? null] as const,
  taskOptions: (period?: string) => ['tasks', 'options', period ?? null] as const,
  periods: ['periods'] as const,
  generationRun: (id: string) => ['generation-run', id] as const,
};
