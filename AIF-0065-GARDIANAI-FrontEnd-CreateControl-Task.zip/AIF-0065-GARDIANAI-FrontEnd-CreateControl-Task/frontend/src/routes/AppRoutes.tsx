import { lazy, Suspense } from 'react';
import { Route, Routes } from 'react-router-dom';

import { LoadingSpinner } from '../components/common/Feedback';
import { MainLayout } from '../layouts/MainLayout';

const HomePage = lazy(() => import('../pages/HomePage'));
const ControlsLibraryPage = lazy(() => import('../pages/ControlsLibraryPage'));
const ControlFormPage = lazy(() => import('../pages/ControlFormPage'));
const ControlViewPage = lazy(() => import('../pages/ControlViewPage'));
const NewRunPage = lazy(() => import('../pages/NewRunPage'));
const ReviewGeneratePage = lazy(() => import('../pages/ReviewGeneratePage'));
const RunProgressPage = lazy(() => import('../pages/RunProgressPage'));
const ReportReviewPage = lazy(() => import('../pages/ReportReviewPage'));
const RunHistoryPage = lazy(() => import('../pages/RunHistoryPage'));
const SuperAgentRoute = lazy(() => import('../pages/SuperAgentRoute'));
const NotFoundPage = lazy(() => import('../pages/NotFoundPage'));

export function AppRoutes() {
    return (
        <Suspense fallback={<LoadingSpinner />}>
            <Routes>
                <Route element={<MainLayout />}>
                    <Route index element={<HomePage />} />
                    <Route path="controls" element={<ControlsLibraryPage />} />
                    <Route path="controls/new" element={<ControlFormPage />} />
                    <Route path="controls/:id" element={<ControlViewPage />} />
                    <Route path="controls/:id/edit" element={<ControlFormPage />} />
                    <Route path="runs/new" element={<NewRunPage />} />
                    <Route path="runs/review" element={<ReviewGeneratePage />} />
                    <Route path="runs/:batchId" element={<RunProgressPage />} />
                    <Route path="runs/:batchId/controls/:taskId" element={<ReportReviewPage />} />
                    <Route path="run-monitor" element={<RunHistoryPage />} />
                    <Route path="super-agent" element={<SuperAgentRoute />} />
                    <Route path="*" element={<NotFoundPage />} />
                </Route>
            </Routes>
        </Suspense>
    );
}
