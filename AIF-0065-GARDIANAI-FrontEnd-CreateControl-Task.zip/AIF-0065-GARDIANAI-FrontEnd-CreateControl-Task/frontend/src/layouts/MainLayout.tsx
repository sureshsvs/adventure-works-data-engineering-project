import { Container, Nav, Navbar } from 'react-bootstrap';
import { NavLink, Outlet } from 'react-router-dom';

//import { useThemeMode } from '../contexts/ThemeContext';
import { useCurrentUser } from '../hooks/useCurrentUser';
import { useRunPoller } from '../hooks/useRunBatches';

const NAV = [
    { to: '/', label: 'Home', end: true },
    { to: '/runs/new', label: 'New Run', end: false },
    { to: '/run-monitor', label: 'Run Monitor', end: false },
    { to: '/controls', label: 'Controls Library', end: false }

];

export function MainLayout() {
    //const { mode, toggle } = useThemeMode();
    const user = useCurrentUser();
    useRunPoller();

    return (
        <div className="d-flex flex-column min-vh-100">
            <Navbar expand="md" className="gar-navbar py-0" collapseOnSelect>
                <Container fluid="xxl" className="px-3 px-md-4">
                    <Navbar.Brand as={NavLink} to="/" className="gar-brand d-flex align-items-center gap-2 py-3">
                        <img src="/Shell-logo.svg" alt="Shell" height={28} />
                        GARdian.AI
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="main-nav" />
                    <Navbar.Collapse id="main-nav">
                        <Nav className="me-md-auto ms-md-3">
                            {NAV.map((n) => (
                                <Nav.Link key={n.to} as={NavLink} to={n.to} end={n.end} eventKey={n.to}>
                                    {n.label}
                                </Nav.Link>
                            ))}
                        </Nav>
                        <div className="d-flex align-items-center gap-3 pb-2 pb-md-0">
                            {/* <button
                                type="button"
                                className="btn btn-sm btn-outline-secondary"
                                onClick={toggle}
                                aria-label={`Switch to ${mode === 'light' ? 'dark' : 'light'} theme`}
                            >
                                <i className={`bi ${mode === 'light' ? 'bi-moon-stars' : 'bi-sun'}`} aria-hidden="true" />
                            </button> */}
                            <span className="d-flex align-items-center gap-2 fw-semibold">
                                <span className="gar-avatar">{user.charAt(0).toUpperCase()}</span>
                                {user}
                            </span>
                        </div>
                    </Navbar.Collapse>
                </Container>
            </Navbar>
            <main className="flex-grow-1">
                <Outlet />
            </main>
        </div>
    );
}

export function PageContainer({ children }: { children: React.ReactNode }) {
    return (
        <Container className="px-3 px-md-4 py-4">
            {children}
        </Container>
    );
}
