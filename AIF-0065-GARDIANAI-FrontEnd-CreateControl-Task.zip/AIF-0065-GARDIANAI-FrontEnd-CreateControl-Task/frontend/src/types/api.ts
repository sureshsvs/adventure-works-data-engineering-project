// Request/response contracts mirroring src/gardianai_agentharness/api/schemas.py.

export interface DocumentRef {
  id: string;
  name: string;
  doc_type: string;
  kind: string;
  test_case_id: string;
  size_bytes: number;
}

export interface Task {
  id: string;
  title: string;
  description: string | null;
  logical_source_role_names: string[];
  prompt_name: string;
  created_by: string | null;
  modified_by: string | null;
  last_modified: string | null;
  task_scalars: Record<string, string>;
  // Present only when requested with ?period=
  input_documents?: DocumentRef[];
  input_documents_period?: string;
  unresolved_logical_source_role_names?: string[];
}

export interface TaskPayload {
  title: string;
  logical_source_role_names: string[];
  prompt_name: string;
  description?: string | null;
  task_scalars?: Record<string, string> | null;
  created_by?: string | null;
  modified_by?: string | null;
}

export interface LogicalSourceRole {
  name: string;
  // Null when no supported file exists for the requested period.
  file_name: string | null;
  path: string | null;
}

export interface TaskOptions {
  prompt_names: string[];
  // Present only when requested with ?period=
  logical_source_roles?: LogicalSourceRole[];
}

export interface TaskRunRequest {
  task_id: string;
  period?: string;
  economy?: boolean;
  reasoning_effort?: 'high' | 'medium' | 'low';
  one_off_prompt?: string;
}

export interface DocTable {
  title?: string;
  headers: string[];
  rows: string[][];
}

export interface DocSection {
  heading: string;
  level: number;
  paragraphs: string[];
  tables: DocTable[];
}

export interface GeneratedDocument {
  title: string;
  subtitle: string;
  sections: DocSection[];
}

export type HumanDisposition = 'Approved' | 'Rejected' | 'Awaiting_Review' | 'Manual_fallback';

export interface GenerationRun {
  run_id: string;
  test_case_id: string;
  test_case_title: string;
  prompt_version: string;
  model: string;
  mode: string;
  status: string;
  created_at: string;
  completed_at: string;
  input_documents: string[];
  document: GeneratedDocument;
  report_filename: string;
  section_count: number;
  table_count: number;
  human_disposition: HumanDisposition;
  reviewer_comment: string;
}

export interface JobStatus {
  stage: string;
  detail: string;
  done: boolean;
  error: string | null;
  run: GenerationRun | null;
}

export interface DispositionPayload {
  disposition: HumanDisposition;
  reviewer_comment: string;
}

export interface SharePointUploadParams {
  runId: string;
  controlName: string;
  quarter?: string;
}
