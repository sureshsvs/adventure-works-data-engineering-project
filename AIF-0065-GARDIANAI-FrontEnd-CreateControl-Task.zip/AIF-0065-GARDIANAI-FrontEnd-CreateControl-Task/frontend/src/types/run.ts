// Client-side "Run" (batch) model. The backend only knows per-control jobs/runs,
// so the grouping is persisted locally until a backend batch API exists.

export type RunItemStatus = 'queued' | 'running' | 'completed' | 'failed';

export interface RunItem {
  taskId: string;
  taskTitle: string;
  roles: string[];
  jobId?: string;
  runId?: string;
  status: RunItemStatus;
  stage?: string;
  detail?: string;
  startedAt: string;
  completedAt?: string;
  error?: string;
}

export interface RunBatch {
  id: string;
  title: string;
  period: string;
  description: string;
  createdAt: string;
  createdBy: string;
  maxParallelCases?: number;
  items: RunItem[];
}

export interface RunDraft {
  title: string;
  period: string;
  description: string;
  taskIds: string[];
  maxParallelCases: number;
}
