export interface DocumentRef {
  id: string;
  name: string;
  doc_type: string;
  kind: string;
  test_case_id: string;
  size_bytes: number;
}

export interface TestCase {
  id: string;
  number: string;
  title: string;
  archetype: string;
  input_documents: DocumentRef[];
  prompt_text?: string;
  expected_output_text?: string;
}

export interface Task {
  id: string;
  title: string;
  description?: string | null;
}

export interface TaskValidationError {
  task_id: string;
  detail: string;
}

export interface TaskPreflight {
  valid: boolean;
  errors: TaskValidationError[];
}

export interface TaskBatchItem {
  task_id: string;
  task_title: string;
  job_id: string | null;
  status: string;
  run_id: string | null;
  run: GenerationRun | null;
  error: string | null;
  started_at?: string | null;
  completed_at?: string | null;
}

export interface TaskBatch extends ReportParameters {
  batch_id: string;
  job_id: string;
  run_title: string;
  description: string;
  period: string | null;
  grouping: string;
  status: string;
  done: boolean;
  total: number;
  finished_count: number;
  started_at?: string | null;
  completed_at?: string | null;
  items?: TaskBatchItem[];
  created_at: string;
}

export interface DocTable {
  title?: string;
  headers: string[];
  rows: string[][];
}

export interface DocSection {
  heading: string;
  level: number;
  paragraphs: string[];
  tables: DocTable[];
}

export interface GeneratedDocument {
  title: string;
  subtitle: string;
  sections: DocSection[];
}

export interface TokenCount {
  prompt: number;
  completion: number;
  total: number;
}

export interface TokenUsage {
  by_stage: Record<string, TokenCount>;
  total: TokenCount;
  ocr: { requests: number; pages: number };
}

export interface ReportParameters {
  max_parallel_cases?: 1 | 2 | 3 | 4;
}

export interface GenerationRun extends ReportParameters {
  run_id: string;
  run_title: string;
  description: string;
  test_case_id: string;
  test_case_title: string;
  prompt_version: string;
  model: string;
  mode: string;
  created_at: string;
  completed_at: string;
  input_documents: string[];
  document: GeneratedDocument;
  report_filename: string;
  section_count: number;
  table_count: number;
  token_usage: TokenUsage | null;
  use_expected_template: boolean;
  economy: boolean;
  reasoning_effort: string;
}

export interface RunSummary extends ReportParameters {
  run_id: string;
  run_title: string;
  description: string;
  test_case_id: string;
  test_case_title: string;
  created_at: string;
  mode: string;
  section_count: number;
  table_count: number;
  report_filename: string;
}

export interface JobStatus {
  status: 'queued' | 'running' | 'done' | 'error';
  stage: string;
  detail: string;
  done: boolean;
  error: string | null;
  run: GenerationRun | null;
  tokens: TokenUsage | null;
}

export interface BatchJobItem {
  test_case_id: string;
  test_case_title: string;
  status: 'queued' | 'running' | 'completed' | 'failed';
  stage: string;
  detail: string;
  run: GenerationRun | null;
  error: string | null;
  tokens: TokenUsage | null;
}

export interface BatchJobStatus extends Omit<JobStatus, 'status'>, ReportParameters {
  batch: true;
  run_title: string;
  description: string;
  status: 'queued' | 'running' | 'completed' | 'completed_with_errors';
  total: number;
  finished_count: number;
  current_item_index: number | null;
  current_test_case_id: string | null;
  items: BatchJobItem[];
}

export interface PromptEntry {
  id: string;
  test_case_id: string;
  title: string;
  archetype: string;
  prompt: string;
  controls: { control_id: string; name: string; description: string }[];
  version: number;
  updated_at: string;
  updated_by: string;
}
