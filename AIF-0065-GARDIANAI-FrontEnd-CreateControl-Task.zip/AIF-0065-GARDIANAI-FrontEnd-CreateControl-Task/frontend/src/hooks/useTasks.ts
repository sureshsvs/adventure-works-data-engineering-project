import { keepPreviousData, useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import { queryKeys } from '../api/queryClient';
import { taskService } from '../services/taskService';
import type { Task, TaskPayload } from '../types/api';

export const useTasks = () => useQuery({ queryKey: queryKeys.tasks, queryFn: taskService.list });

export const useTask = (id: string | undefined, period?: string) =>
  useQuery({
    queryKey: queryKeys.task(id ?? '', period),
    queryFn: () => taskService.get(id as string, period),
    enabled: Boolean(id),
  });

// With a period, the response also lists the latest file resolved for every source role.
export const useTaskOptions = (period?: string) =>
  useQuery({
    queryKey: queryKeys.taskOptions(period),
    queryFn: () => taskService.options(period),
    staleTime: 5 * 60_000,
    placeholderData: keepPreviousData,
  });

export const usePeriods = () =>
  useQuery({ queryKey: queryKeys.periods, queryFn: taskService.periods, staleTime: 5 * 60_000 });

export function useSaveTask(id?: string) {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (payload: TaskPayload) =>
      id ? taskService.update(id, payload) : taskService.create(payload),
    onSuccess: () => qc.invalidateQueries({ queryKey: queryKeys.tasks }),
  });
}

// Optimistically removes the task from the cached list; rolls back on failure.
export function useDeleteTask() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => taskService.remove(id),
    onMutate: async (id) => {
      await qc.cancelQueries({ queryKey: queryKeys.tasks });
      const previous = qc.getQueryData<Task[]>(queryKeys.tasks);
      qc.setQueryData<Task[]>(queryKeys.tasks, (old) => old?.filter((t) => t.id !== id));
      return { previous };
    },
    onError: (_err, _id, ctx) => {
      if (ctx?.previous) qc.setQueryData(queryKeys.tasks, ctx.previous);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: queryKeys.tasks }),
  });
}
