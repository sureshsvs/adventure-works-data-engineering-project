import { useEffect, useRef, useSyncExternalStore } from 'react';

import { api, type TaskBatchGenerationOptions } from '../services/api';
import { runBatchStore } from '../services/runBatchStore';
import { runService } from '../services/runService';
import { prepareAndAdmitTaskBatch, TaskPreparationError } from '../services/taskBatchAdmission';
import { toApiError } from '../utils/errors';
import type { RunBatch, RunItem } from '../types/run';

export function useRunBatches(): RunBatch[] {
  return useSyncExternalStore(runBatchStore.subscribe, runBatchStore.getSnapshot);
}

export function useRunBatch(id: string | undefined): RunBatch | undefined {
  const batches = useRunBatches();
  return batches.find((b) => b.id === id);
}

export interface StartItemInput {
  taskId: string;
  taskTitle: string;
  roles: string[];
}

// Preflight and submit the selected tasks as one backend-managed batch.
export async function executeBatch(
  meta: { title: string; period: string; description: string; createdBy: string },
  inputs: StartItemInput[],
  maxParallelCases = 1,
  onAdmissionWait: (message: string) => void = () => undefined
): Promise<RunBatch> {
  const parallelism = Math.min(4, Math.max(1, Math.trunc(maxParallelCases))) as 1 | 2 | 3 | 4;
  const options: TaskBatchGenerationOptions = {
    runTitle: meta.title,
    description: meta.description,
    period: meta.period,
    maxParallelCases: parallelism,
  };
  try {
    const accepted = await prepareAndAdmitTaskBatch(
      inputs.map((item) => item.taskId),
      options,
      new AbortController().signal,
      onAdmissionWait,
      () => undefined
    );
    const createdAt = new Date().toISOString();
    return runBatchStore.createWithId(accepted.batch_id, {
      ...meta,
      maxParallelCases: parallelism,
      items: inputs.map((item) => ({ ...item, status: 'queued', startedAt: createdAt })),
    });
  } catch (error) {
    if (error instanceof TaskPreparationError) {
      throw new Error(error.errors.map((item) => `${item.task_id}: ${item.detail}`).join('\n'));
    }
    throw error;
  }
}

export function retryItem(
  batch: RunBatch,
  item: RunItem,
  onAdmissionWait?: (message: string) => void
): Promise<RunBatch> {
  return executeBatch(
    {
      title: `${batch.title} - Retry`,
      period: batch.period,
      description: batch.description,
      createdBy: batch.createdBy,
    },
    [{ taskId: item.taskId, taskTitle: item.taskTitle, roles: item.roles }],
    batch.maxParallelCases ?? 1,
    onAdmissionWait
  );
}

const POLL_MS = 2500;
const HISTORY_REFRESH_MS = 30000;

export function useRunPoller(): void {
  const batches = useRunBatches();
  const batchesRef = useRef(batches);
  batchesRef.current = batches;
  const busy = useRef(false);
  const hasPending = batches.some((b) =>
    b.items.some((i) => i.status === 'queued' || (i.jobId && i.status === 'running'))
  );

  useEffect(() => {
    let cancelled = false;
    const refresh = async () => {
      if (busy.current) return;
      busy.current = true;
      try {
        const current = batchesRef.current;
        const serverBatches = current.filter((batch) => batch.id.startsWith('batch_'));
        const legacyBatches = current.filter((batch) => !batch.id.startsWith('batch_'));

        if (!hasPending || current.length === 0) {
          const history = await api.listTaskBatches();
          if (!cancelled) runBatchStore.syncServerBatches(history);
          return;
        }

        await Promise.all(serverBatches
          .filter((batch) => batch.items.some((item) => item.status === 'queued' || item.status === 'running'))
          .map(async (batch) => {
            try {
              const details = await api.getTaskBatch(batch.id);
              if (!cancelled) runBatchStore.upsertServerBatch(details);
            } catch {
              // Keep the last known state while the batch endpoint is temporarily unavailable.
            }
          }));

        const legacyItems = legacyBatches.flatMap((batch) =>
          batch.items
            .filter((item) => item.jobId && (item.status === 'running' || item.status === 'queued'))
            .map((item) => ({ batch, item }))
        );
        await Promise.all(legacyItems.map(async ({ batch, item }) => {
          try {
            const job = await runService.jobStatus(item.jobId as string);
            if (job.done) {
              runBatchStore.updateItem(batch.id, item.taskId, {
                status: job.error ? 'failed' : 'completed',
                runId: job.run?.run_id,
                error: job.error ?? undefined,
                completedAt: new Date().toISOString(),
                stage: job.stage,
                detail: job.detail,
              });
            } else {
              runBatchStore.updateItem(batch.id, item.taskId, {
                status: 'running',
                stage: job.stage,
                detail: job.detail,
              });
            }
          } catch (error) {
            if (toApiError(error).status === 404) {
              runBatchStore.updateItem(batch.id, item.taskId, {
                status: 'failed',
                error: 'Job is no longer available (server restarted). Retry the control.',
                completedAt: new Date().toISOString(),
              });
            }
          }
        }));
      } catch {
        // Keep the last successful snapshot if history cannot be refreshed.
      } finally {
        busy.current = false;
      }
    };

    void refresh();
    const timer = window.setInterval(() => void refresh(), hasPending ? POLL_MS : HISTORY_REFRESH_MS);
    return () => {
      cancelled = true;
      window.clearInterval(timer);
    };
  }, [hasPending]);
}
