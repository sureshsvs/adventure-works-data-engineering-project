import { useMemo, useState } from 'react';

// Client-side sort + paginate helper shared by list screens.
export function usePagination<T>(items: T[], pageSize = 10) {
  const [page, setPage] = useState(1);
  const pageCount = Math.max(1, Math.ceil(items.length / pageSize));
  const current = Math.min(page, pageCount);
  const pageItems = useMemo(
    () => items.slice((current - 1) * pageSize, current * pageSize),
    [items, current, pageSize]
  );
  return { page: current, setPage, pageCount, pageItems, total: items.length, pageSize };
}

export type SortDir = 'asc' | 'desc';

export function useSort<K extends string>(initialKey: K, initialDir: SortDir = 'asc') {
  const [key, setKey] = useState<K>(initialKey);
  const [dir, setDir] = useState<SortDir>(initialDir);
  const toggle = (next: K) => {
    if (next === key) setDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else {
      setKey(next);
      setDir('asc');
    }
  };
  return { key, dir, toggle };
}
