import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';

import { queryKeys } from '../api/queryClient';
import { runService } from '../services/runService';
import type { DispositionPayload, GenerationRun } from '../types/api';

export const useGenerationRun = (runId: string | undefined) =>
  useQuery({
    queryKey: queryKeys.generationRun(runId ?? ''),
    queryFn: () => runService.getRun(runId as string),
    enabled: Boolean(runId),
  });

// Optimistic disposition update with rollback.
export function useUpdateDisposition(runId: string) {
  const qc = useQueryClient();
  const key = queryKeys.generationRun(runId);
  return useMutation({
    mutationFn: (payload: DispositionPayload) => runService.updateDisposition(runId, payload),
    onMutate: async (payload) => {
      await qc.cancelQueries({ queryKey: key });
      const previous = qc.getQueryData<GenerationRun>(key);
      qc.setQueryData<GenerationRun>(key, (old) =>
        old
          ? { ...old, human_disposition: payload.disposition, reviewer_comment: payload.reviewer_comment }
          : old
      );
      return { previous };
    },
    onError: (_e, _p, ctx) => {
      if (ctx?.previous) qc.setQueryData(key, ctx.previous);
    },
    onSuccess: (run) => qc.setQueryData(key, run),
  });
}

export const useDownloadReport = () =>
  useMutation({ mutationFn: (runId: string) => runService.downloadReport(runId) });

export const useUploadToSharePoint = () =>
  useMutation({ mutationFn: runService.uploadToSharePoint });
