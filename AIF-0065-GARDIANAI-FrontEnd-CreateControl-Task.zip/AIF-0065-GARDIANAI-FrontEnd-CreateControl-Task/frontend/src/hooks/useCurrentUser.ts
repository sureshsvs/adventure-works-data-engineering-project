import { useQuery } from '@tanstack/react-query';
import axios from 'axios';

interface Claim {
  typ: string;
  val: string;
}

interface EasyAuthEntry {
  user_id?: string;
  id_token?: string;
  user_claims?: Claim[];
}

const claim = (claims: Claim[], ...types: string[]) =>
  claims.find((c) => types.some((t) => c.typ === t || c.typ.endsWith(`/${t}`)))?.val;

function nameFromJwt(token?: string): string | undefined {
  if (!token) return undefined;
  try {
    const payload = JSON.parse(atob(token.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))) as Record<string, string>;
    return payload.name ?? payload.preferred_username ?? payload.upn ?? payload.email;
  } catch {
    return undefined;
  }
}

async function fetchUserName(): Promise<string | null> {
  try {
    const { data } = await axios.get<EasyAuthEntry[]>('/.auth/me');
    // Outside Easy Auth the SPA fallback returns index.html, not an array.
    if (!Array.isArray(data) || data.length === 0) return import.meta.env.VITE_DEV_USER_NAME || null;
    const entry = data[0];
    const claims = entry.user_claims ?? [];
    const given = claim(claims, 'givenname', 'given_name');
    const surname = claim(claims, 'surname', 'family_name');
    return (
      claim(claims, 'name') ??
      (given && surname ? `${given} ${surname}` : undefined) ??
      nameFromJwt(entry.id_token) ??
      claim(claims, 'preferred_username', 'emailaddress', 'email', 'upn') ??
      entry.user_id ??
      null
    );
  } catch {
    return import.meta.env.VITE_DEV_USER_NAME || null;
  }
}

// Signed-in user from Azure Easy Auth (/.auth/me); VITE_DEV_USER_NAME is the local-dev fallback.
export function useCurrentUser(): string {
  const { data } = useQuery({
    queryKey: ['current-user'],
    queryFn: fetchUserName,
    staleTime: Infinity,
    retry: false,
  });
  return data ?? 'Guest';
}
