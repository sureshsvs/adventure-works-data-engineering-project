import { QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider } from 'react-bootstrap';

import { queryClient } from './api/queryClient';
import { RunDraftProvider } from './contexts/RunDraftContext';
import { ThemeModeProvider } from './contexts/ThemeContext';
import { ToastProvider } from './contexts/ToastContext';
import { AppRoutes } from './routes/AppRoutes';
import { bootstrapTheme } from './theme';

export default function App() {
  return (
    <ThemeProvider {...bootstrapTheme}>
      <ThemeModeProvider>
        <QueryClientProvider client={queryClient}>
          <ToastProvider>
            <RunDraftProvider>
              <AppRoutes />
            </RunDraftProvider>
          </ToastProvider>
        </QueryClientProvider>
      </ThemeModeProvider>
    </ThemeProvider>
  );
}
