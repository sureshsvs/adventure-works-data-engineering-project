import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';

interface Props {
    to: string;
    variant?: string;
    size?: 'sm' | 'lg';
    className?: string;
    children: ReactNode;
}

// Router link styled as a Bootstrap button.
export function LinkButton({ to, variant = 'primary', size, className = '', children }: Props) {
    return (
        <Link to={to} className={`btn btn-${variant} ${size ? `btn-${size}` : ''} ${className}`.trim()}>
            {children}
        </Link>
    );
}
