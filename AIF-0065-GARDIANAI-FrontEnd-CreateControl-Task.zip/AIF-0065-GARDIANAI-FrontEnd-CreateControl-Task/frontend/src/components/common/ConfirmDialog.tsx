import { Button, Modal, Spinner } from 'react-bootstrap';
import type { ReactNode } from 'react';

interface Props {
    show: boolean;
    title: string;
    children: ReactNode;
    confirmLabel?: string;
    busy?: boolean;
    onConfirm: () => void;
    onCancel: () => void;
}

export function ConfirmDialog({ show, title, children, confirmLabel = 'Delete', busy, onConfirm, onCancel }: Props) {
    return (
        <Modal show={show} onHide={busy ? undefined : onCancel} centered>
            <Modal.Header closeButton={!busy}>
                <Modal.Title as="h5">{title}</Modal.Title>
            </Modal.Header>
            <Modal.Body>{children}</Modal.Body>
            <Modal.Footer>
                <Button variant="outline-secondary" onClick={onCancel} disabled={busy}>
                    Cancel
                </Button>
                <Button variant="danger" onClick={onConfirm} disabled={busy}>
                    {busy && <Spinner size="sm" className="me-2" />}
                    {confirmLabel}
                </Button>
            </Modal.Footer>
        </Modal>
    );
}
