import { Form, InputGroup } from 'react-bootstrap';

interface Props {
    value: string;
    onChange: (value: string) => void;
    placeholder: string;
    className?: string;
}

export function SearchInput({ value, onChange, placeholder, className }: Props) {
    return (
        <InputGroup className={className}>
            <InputGroup.Text>
                <i className="bi bi-search" aria-hidden="true" />
            </InputGroup.Text>
            <Form.Control
                type="search"
                value={value}
                placeholder={placeholder}
                aria-label={placeholder}
                onChange={(e) => onChange(e.target.value)}
            />
        </InputGroup>
    );
}
