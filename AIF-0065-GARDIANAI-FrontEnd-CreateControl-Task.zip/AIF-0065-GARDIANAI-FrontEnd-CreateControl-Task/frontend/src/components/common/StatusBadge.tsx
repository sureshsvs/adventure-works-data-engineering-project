import { Badge } from 'react-bootstrap';

import { STATUS_LABEL, type BatchStatus } from '../../utils/format';

const ICON: Record<BatchStatus, string> = {
    completed: 'bi-check-circle-fill',
    failed: 'bi-x-circle-fill',
    running: 'bi-arrow-repeat',
    queued: 'bi-hourglass-split',
    partial: 'bi-exclamation-circle-fill',
};

export function StatusBadge({ status, label }: { status: BatchStatus; label?: string }) {
    return (
        <Badge bg="" className={`badge-soft ${status}`}>
            <i className={`bi ${ICON[status]} me-1`} aria-hidden="true" />
            {label ?? (status === 'partial' ? 'Partial' : STATUS_LABEL[status])}
        </Badge>
    );
}

export function RoleChips({ roles }: { roles: string[] }) {
    return (
        <span className="d-inline-flex flex-wrap gap-1">
            {roles.map((r) => (
                <span key={r} className="role-chip">
                    {r}
                </span>
            ))}
        </span>
    );
}
