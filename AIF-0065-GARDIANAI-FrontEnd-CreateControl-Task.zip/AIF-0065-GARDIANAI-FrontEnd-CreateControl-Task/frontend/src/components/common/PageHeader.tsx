import { Breadcrumb } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import type { ReactNode } from 'react';

export interface Crumb {
    label: string;
    to?: string;
}

interface Props {
    title: string;
    subtitle?: string;
    crumbs?: Crumb[];
    actions?: ReactNode;
}

export function PageHeader({ title, subtitle, crumbs, actions }: Props) {
    return (
        <div className="d-flex flex-wrap justify-content-between align-items-start gap-3 mb-3">
            <div>
                <h1 className="h3 page-title mb-1">{title}</h1>
                {subtitle && <p className="text-secondary mb-2">{subtitle}</p>}
                {crumbs && (
                    <Breadcrumb className="breadcrumb-gar mb-0" listProps={{ className: 'mb-0' }}>
                        {crumbs.map((c, i) =>
                            c.to && i < crumbs.length - 1 ? (
                                <Breadcrumb.Item key={c.label} linkAs={Link} linkProps={{ to: c.to }}>
                                    {c.label}
                                </Breadcrumb.Item>
                            ) : (
                                <Breadcrumb.Item key={c.label} active>
                                    {c.label}
                                </Breadcrumb.Item>
                            )
                        )}
                    </Breadcrumb>
                )}
            </div>
            {actions}
        </div>
    );
}
