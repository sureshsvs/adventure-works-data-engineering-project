import { Alert, Button, Spinner } from 'react-bootstrap';
import type { ReactNode } from 'react';

import { toApiError } from '../../utils/errors';

export function LoadingSpinner({ label = 'Loading…' }: { label?: string }) {
    return (
        <div className="d-flex justify-content-center align-items-center gap-2 py-5 text-secondary" role="status">
            <Spinner animation="border" size="sm" />
            <span>{label}</span>
        </div>
    );
}

export function ErrorAlert({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
    const { message } = toApiError(error);
    return (
        <Alert variant="danger" className="d-flex justify-content-between align-items-center gap-3">
            <span>
                <i className="bi bi-exclamation-octagon me-2" aria-hidden="true" />
                {message}
            </span>
            {onRetry && (
                <Button size="sm" variant="outline-danger" onClick={onRetry}>
                    Retry
                </Button>
            )}
        </Alert>
    );
}

export function EmptyState({
    icon = 'bi-inbox',
    title,
    children,
    action,
}: {
    icon?: string;
    title: string;
    children?: ReactNode;
    action?: ReactNode;
}) {
    return (
        <div className="text-center text-secondary py-5">
            <i className={`bi ${icon} display-5 d-block mb-2`} aria-hidden="true" />
            <h6 className="mb-1">{title}</h6>
            {children && <p className="mb-3 small">{children}</p>}
            {action}
        </div>
    );
}
