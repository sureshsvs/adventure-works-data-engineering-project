import { Fragment } from 'react';
import { Pagination } from 'react-bootstrap';

interface Props {
    page: number;
    pageCount: number;
    total: number;
    pageSize: number;
    onChange: (page: number) => void;
}

export function TablePagination({ page, pageCount, total, pageSize, onChange }: Props) {
    if (total === 0) return null;
    const from = (page - 1) * pageSize + 1;
    const to = Math.min(total, page * pageSize);
    const pages = Array.from({ length: pageCount }, (_, i) => i + 1).filter(
        (p) => p === 1 || p === pageCount || Math.abs(p - page) <= 1
    );

    return (
        <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
            <small className="text-secondary">
                Showing {from}–{to} of {total}
            </small>
            <Pagination size="sm" className="table-pagination mb-0 ms-auto">
                <Pagination.Item aria-label="Previous page" disabled={page <= 1} onClick={() => onChange(page - 1)}>
                    <i className="bi bi-chevron-left" aria-hidden="true" />
                </Pagination.Item>
                {pages.map((p, idx) => (
                    <Fragment key={p}>
                        {idx > 0 && p - pages[idx - 1] > 1 && <Pagination.Ellipsis disabled />}
                        <Pagination.Item active={p === page} onClick={() => onChange(p)}>
                            {p}
                        </Pagination.Item>
                    </Fragment>
                ))}
                <Pagination.Item aria-label="Next page" disabled={page >= pageCount} onClick={() => onChange(page + 1)}>
                    <i className="bi bi-chevron-right" aria-hidden="true" />
                </Pagination.Item>
            </Pagination>
        </div>
    );
}
