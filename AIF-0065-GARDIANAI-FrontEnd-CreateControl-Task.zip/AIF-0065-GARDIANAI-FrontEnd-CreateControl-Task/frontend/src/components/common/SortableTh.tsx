import type { ReactNode } from 'react';

import type { SortDir } from '../../hooks/useTable';

interface Props<K extends string> {
    sortKey: K;
    activeKey: K;
    dir: SortDir;
    onSort: (key: K) => void;
    children: ReactNode;
}

export function SortableTh<K extends string>({ sortKey, activeKey, dir, onSort, children }: Props<K>) {
    const active = sortKey === activeKey;
    return (
        <th
            className="th-sort"
            onClick={() => onSort(sortKey)}
            aria-sort={active ? (dir === 'asc' ? 'ascending' : 'descending') : 'none'}
        >
            {children}
            <i
                className={`bi ms-1 ${active ? (dir === 'asc' ? 'bi-caret-up-fill' : 'bi-caret-down-fill') : 'bi-chevron-expand text-secondary'}`}
                aria-hidden="true"
            />
        </th>
    );
}
