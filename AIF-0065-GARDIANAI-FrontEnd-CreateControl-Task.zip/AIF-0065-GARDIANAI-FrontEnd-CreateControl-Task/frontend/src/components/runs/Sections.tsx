import { Card, Table } from 'react-bootstrap';
import type { ReactNode } from 'react';

import { outputConfig, outputFolder } from '../../utils/output';

export function SectionCard({ title, children }: { title: ReactNode; children: ReactNode }) {
    return (
        <Card className="mb-3">
            <Card.Body>
                <h2 className="h6 fw-bold mb-3">{title}</h2>
                {children}
            </Card.Body>
        </Card>
    );
}

export function KeyValueTable({ rows, className = '' }: { rows: Array<[string, ReactNode]>; className?: string }) {
    return (
        <Table bordered responsive className={`mb-0 ${className}`}>
            <tbody>
                {rows.map(([k, v]) => (
                    <tr key={k}>
                        <th scope="row" className="label-cell">
                            {k}
                        </th>
                        <td>{v}</td>
                    </tr>
                ))}
            </tbody>
        </Table>
    );
}

export function OutputDestinationCard({
    runTitle,
    runCode,
    taskName,
    action,
}: {
    runTitle: string;
    runCode?: string;
    taskName?: string;
    action?: ReactNode;
}) {
    return (
        <SectionCard
            title={
                <span className="d-flex justify-content-between align-items-center">
                    Output Destination
                    {action}
                </span>
            }
        >
            <KeyValueTable
                className="output-destination-table"
                rows={[
                    ['SharePoint Site', outputConfig.site],
                    ['Output Folder', outputFolder(runTitle, runCode, taskName)],
                ]}
            />
        </SectionCard>
    );
}
