import { useEffect, useState } from 'react';
import { Button, Spinner, Table } from 'react-bootstrap';

import { LinkButton } from '../common/LinkButton';
import type { RunBatch, RunItem } from '../../types/run';
import { countByStatus, formatDateTime, humanizeStage } from '../../utils/format';
import { StatusBadge } from '../common/StatusBadge';

interface Props {
    batch: RunBatch;
    onRetry: (item: RunItem) => void;
    retrying: string | null;
}

export function RunControlsTable({ batch, onRetry, retrying }: Props) {
    return (
        <Table responsive hover className="table-gar mb-0">
            <thead>
                <tr>
                    <th style={{ width: '3rem' }}>#</th>
                    <th>Control/Task</th>
                    <th>Status</th>
                    <th>Started</th>
                    <th>Output</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                {batch.items.map((item, idx) => (
                    <tr key={item.taskId}>
                        <td>{idx + 1}</td>
                        <td>{item.taskTitle}</td>
                        <td>
                            <StatusBadge status={item.status} />
                        </td>
                        <td>{formatDateTime(item.startedAt)}</td>
                        <td>
                            {item.status === 'completed' && (
                                <span>
                                    <i className="bi bi-file-earmark-text me-1" aria-hidden="true" />
                                    Available
                                </span>
                            )}
                            {item.status === 'failed' && (
                                <span className="text-danger" title={item.error}>
                                    <i className="bi bi-exclamation-triangle me-1" aria-hidden="true" />
                                    Needs Attention
                                </span>
                            )}
                            {(item.status === 'running' || item.status === 'queued') && (
                                <span className="d-inline-flex align-items-center gap-2 text-secondary">
                                    {item.status === 'running' ? (
                                        <Spinner animation="border" size="sm" role="status" aria-label="Control running" />
                                    ) : (
                                        <i className="bi bi-hourglass-split" aria-hidden="true" />
                                    )}
                                    {item.status === 'running' ? 'Running' : 'Queued'}
                                </span>
                            )}
                        </td>
                        <td>
                            {item.status === 'completed' && item.runId && (
                                <LinkButton to={`/runs/${batch.id}/controls/${item.taskId}`} size="sm" variant="outline-primary">
                                    <i className="bi bi-eye me-1" aria-hidden="true" />
                                    View
                                </LinkButton>
                            )}
                            {item.status === 'failed' && (
                                <Button size="sm" variant="outline-secondary" disabled={retrying === item.taskId} onClick={() => onRetry(item)}>
                                    {retrying === item.taskId ? (
                                        <Spinner size="sm" className="me-1" />
                                    ) : (
                                        <i className="bi bi-arrow-repeat me-1" aria-hidden="true" />
                                    )}
                                    Retry
                                </Button>
                            )}
                        </td>
                    </tr>
                ))}
            </tbody>
        </Table>
    );
}

export function CurrentStageCard({ batch }: { batch: RunBatch }) {
    const counts = countByStatus(batch.items);
    const finished = counts.completed + counts.failed;
    const active = batch.items.find((i) => i.status === 'running') ?? batch.items.find((i) => i.status === 'queued');
    const hasActive = counts.running + counts.queued > 0;
    const [now, setNow] = useState(() => Date.now());

    useEffect(() => {
        if (!hasActive) return undefined;
        const timer = window.setInterval(() => setNow(Date.now()), 5000);
        return () => window.clearInterval(timer);
    }, [batch.id, hasActive]);

    const progressUnits = batch.items.reduce((total, item) => {
        if (item.status === 'completed' || item.status === 'failed') return total + 1;
        if (item.status !== 'running') return total;
        const startedAt = new Date(item.startedAt).getTime();
        if (!Number.isFinite(startedAt)) return total + 0.02;
        const elapsed = Math.max(0, now - startedAt);
        const estimate = Math.min(0.9, Math.max(0.02, (elapsed / (12 * 60 * 1000)) * 0.9));
        return total + estimate;
    }, 0);
    const pct = batch.items.length ? Math.min(100, Math.round((progressUnits / batch.items.length) * 100)) : 0;

    return (
        <div className="info-banner" role="status" aria-live="polite">
            <div className="fw-semibold mb-1">Current Stage</div>
            <div className="d-flex align-items-center gap-2 small text-secondary mb-2">
                {hasActive && <Spinner animation="border" size="sm" role="status" aria-label="Run in progress" />}
                <span>{active ? `${active.taskTitle}: ${active.detail || humanizeStage(active.stage)}` : 'All controls finished'}</span>
            </div>
            <div
                className="run-progress-track"
                role="progressbar"
                aria-label="Estimated run progress"
                aria-valuemin={0}
                aria-valuemax={100}
                aria-valuenow={pct}
            >
                <div className="run-progress-fill" style={{ width: `${pct}%` }} />
            </div>
            <div className="small mt-2">
                Estimated progress: {pct}% · {finished} of {batch.items.length} controls completed
                {counts.running > 0 && ` · ${counts.running} running`}
                {counts.queued > 0 && ` · ${counts.queued} queued`}
            </div>
        </div>
    );
}
