import { useEffect } from 'react';
import { Alert, Button, Form, Spinner } from 'react-bootstrap';
import { useForm } from 'react-hook-form';

import { useToast } from '../../contexts/ToastContext';
import { useUpdateDisposition } from '../../hooks/useGenerationRun';
import type { GenerationRun, HumanDisposition } from '../../types/api';
import { toApiError } from '../../utils/errors';

const OPTIONS: Array<{ value: HumanDisposition; label: string }> = [
    { value: 'Awaiting_Review', label: 'Awaiting review' },
    { value: 'Approved', label: 'Approved' },
    { value: 'Rejected', label: 'Rejected' },
    { value: 'Manual_fallback', label: 'Manual fallback' },
];

interface FormValues {
    disposition: HumanDisposition;
    reviewer_comment: string;
}

export function ReviewPanel({ run }: { run: GenerationRun }) {
    const { notify } = useToast();
    const mutation = useUpdateDisposition(run.run_id);
    const {
        register,
        handleSubmit,
        reset,
        formState: { errors, isDirty },
    } = useForm<FormValues>({
        defaultValues: { disposition: run.human_disposition, reviewer_comment: run.reviewer_comment },
    });

    useEffect(() => {
        reset({ disposition: run.human_disposition, reviewer_comment: run.reviewer_comment });
    }, [run.human_disposition, run.reviewer_comment, reset]);

    const onSubmit = (values: FormValues) =>
        mutation.mutate(values, {
            onSuccess: () => notify('success', 'Review saved'),
            onError: (e) => notify('danger', 'Could not save review', toApiError(e).message),
        });

    return (
        <Form onSubmit={handleSubmit(onSubmit)} className="review-panel p-3" noValidate>
            <h2 className="h6 fw-bold mb-3">Human Review</h2>
            <Form.Group className="mb-3" controlId="disposition">
                <Form.Label>Disposition</Form.Label>
                <Form.Select {...register('disposition', { required: 'Select a disposition' })} isInvalid={!!errors.disposition}>
                    {OPTIONS.map((o) => (
                        <option key={o.value} value={o.value}>
                            {o.label}
                        </option>
                    ))}
                </Form.Select>
            </Form.Group>
            <Form.Group className="mb-3" controlId="reviewer_comment">
                <Form.Label>Reviewer comment</Form.Label>
                <Form.Control
                    as="textarea"
                    rows={5}
                    isInvalid={!!errors.reviewer_comment}
                    {...register('reviewer_comment', { maxLength: { value: 2000, message: 'Maximum 2000 characters' } })}
                />
                <Form.Control.Feedback type="invalid">{errors.reviewer_comment?.message}</Form.Control.Feedback>
            </Form.Group>
            {mutation.isError && <Alert variant="danger">{toApiError(mutation.error).message}</Alert>}
            <Button type="submit" disabled={!isDirty || mutation.isPending} className="w-100">
                {mutation.isPending && <Spinner size="sm" className="me-2" />}
                Save review
            </Button>
        </Form>
    );
}
