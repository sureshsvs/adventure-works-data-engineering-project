import { Fragment } from 'react';
import { Table } from 'react-bootstrap';

import type { GeneratedDocument } from '../../types/api';

const HEADING_TAG = { 1: 'h2', 2: 'h3', 3: 'h4' } as const;

export function DocumentViewer({ document: doc }: { document: GeneratedDocument }) {
    return (
        <article className="doc-preview">
            <div className="fw-bold fs-5 mb-4 text-body-emphasis">GARdian.AI</div>
            <header className="mb-4">
                <h2 className="h4 doc-title">{doc.title}</h2>
                {doc.subtitle && <p className="doc-title text-secondary">{doc.subtitle}</p>}
            </header>
            {doc.sections.map((section, i) => {
                const Heading = HEADING_TAG[Math.min(Math.max(section.level, 1), 3) as 1 | 2 | 3];
                return (
                    <section key={`${section.heading}-${i}`} className="mb-4">
                        <Heading className="h5">{section.heading}</Heading>
                        {section.paragraphs.map((p, j) => (
                            <p key={j} className="mb-2" style={{ whiteSpace: 'pre-line' }}>
                                {p}
                            </p>
                        ))}
                        {section.tables.map((t, k) => (
                            <Fragment key={k}>
                                {t.title && <div className="fw-semibold small mt-3 mb-1">{t.title}</div>}
                                <Table bordered responsive size="sm" className="table-gar">
                                    <thead>
                                        <tr>
                                            {t.headers.map((h, c) => (
                                                <th key={c}>{h}</th>
                                            ))}
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {t.rows.map((row, r) => (
                                            <tr key={r}>
                                                {row.map((cell, c) => (
                                                    <td key={c}>{cell}</td>
                                                ))}
                                            </tr>
                                        ))}
                                    </tbody>
                                </Table>
                            </Fragment>
                        ))}
                    </section>
                );
            })}
        </article>
    );
}
