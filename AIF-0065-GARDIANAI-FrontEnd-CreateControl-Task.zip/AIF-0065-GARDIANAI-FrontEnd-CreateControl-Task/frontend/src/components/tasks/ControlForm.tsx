import { useEffect } from 'react';
import { Alert, Button, Card, Form, Spinner } from 'react-bootstrap';
import { Controller, useForm } from 'react-hook-form';

import type { Task, TaskOptions, TaskPayload } from '../../types/api';
import type { ApiError } from '../../utils/errors';
import { roleFileMap } from '../../utils/roles';

interface FormValues {
    title: string;
    logical_source_role_names: string[];
    prompt_name: string;
    description: string;
}

interface Props {
    task?: Task;
    options: TaskOptions;
    periods: string[];
    period: string;
    loadingRoleFiles: boolean;
    onPeriodChange: (period: string) => void;
    submitting: boolean;
    submitError: ApiError | null;
    submitLabel: string;
    onSubmit: (payload: TaskPayload) => void;
    onCancel: () => void;
}

export function ControlForm({
    task,
    options,
    periods,
    period,
    loadingRoleFiles,
    onPeriodChange,
    submitting,
    submitError,
    submitLabel,
    onSubmit,
    onCancel,
}: Props) {
    const roleFiles = roleFileMap(options);
    const logicalSourceRoleNames = options.logical_source_roles?.map((role) => role.name) ?? [];
    const {
        register,
        control,
        handleSubmit,
        reset,
        setError,
        formState: { errors },
    } = useForm<FormValues>({
        defaultValues: { title: '', logical_source_role_names: [], prompt_name: '', description: '' },
    });

    useEffect(() => {
        if (task) {
            reset({
                title: task.title,
                logical_source_role_names: task.logical_source_role_names,
                prompt_name: task.prompt_name,
                description: task.description ?? '',
            });
        }
    }, [task, reset]);

    // Map server-side validation (409 duplicate title, 422 field errors) onto the form.
    useEffect(() => {
        if (!submitError) return;
        if (submitError.status === 409) setError('title', { message: submitError.message });
        for (const [field, message] of Object.entries(submitError.fieldErrors)) {
            if (field in { title: 1, logical_source_role_names: 1, prompt_name: 1, description: 1 }) {
                setError(field as keyof FormValues, { message });
            }
        }
    }, [submitError, setError]);

    const submit = (v: FormValues) =>
        onSubmit({
            title: v.title.trim(),
            logical_source_role_names: v.logical_source_role_names,
            prompt_name: v.prompt_name,
            description: v.description.trim() || null,
            // Preserve scalars not editable in this UI.
            task_scalars: task?.task_scalars,
        });

    const showGlobalError = submitError && submitError.status !== 409 && Object.keys(submitError.fieldErrors).length === 0;

    return (
        <Card className="control-form" style={{ maxWidth: 800 }}>
            <Card.Body className="p-4">
                <Form onSubmit={handleSubmit(submit)} noValidate>
                    {showGlobalError && <Alert variant="danger">{submitError.message}</Alert>}

                    <Form.Group className="control-title mb-4" controlId="title">
                        <Form.Label className="fw-semibold">Control Name <span className="text-danger">*</span></Form.Label>
                        <Form.Control
                            placeholder="e.g. Annual Report Checklist"
                            isInvalid={!!errors.title}
                            {...register('title', {
                                required: 'Control name is required',
                                validate: (v) => v.trim().length >= 3 || 'Use at least 3 characters',
                                maxLength: { value: 150, message: 'Maximum 150 characters' },
                            })}
                        />
                        <Form.Control.Feedback type="invalid">{errors.title?.message}</Form.Control.Feedback>
                    </Form.Group>

                    <fieldset className="mb-4">
                        <legend className="fs-6 fw-semibold mb-0">Select Logical Source Roles <span className="text-danger">*</span></legend>
                        <div className="small text-secondary mb-2">
                            Choose the source roles required for this task. The latest file for the selected period is shown
                            for each role.
                        </div>
                        {periods.length > 0 && (
                            <Form.Group className="control-period mb-2" controlId="period">
                                <Form.Label className="small fw-semibold mb-1">
                                    Period <span className="text-danger">*</span>
                                </Form.Label>
                                <div className="d-flex align-items-center gap-2">
                                    <Form.Select
                                        size="sm"
                                        aria-label="Period used to resolve latest files"
                                        value={period}
                                        onChange={(e) => onPeriodChange(e.target.value)}
                                    >
                                        {periods.map((p) => (
                                            <option key={p} value={p}>
                                                {p}
                                            </option>
                                        ))}
                                    </Form.Select>
                                    {loadingRoleFiles && (
                                        <Spinner
                                            animation="border"
                                            size="sm"
                                            role="status"
                                            aria-label="Loading source files"
                                            className="flex-shrink-0"
                                        />
                                    )}
                                </div>
                            </Form.Group>
                        )}
                        <Controller
                            control={control}
                            name="logical_source_role_names"
                            rules={{ validate: (v) => v.length > 0 || 'Select at least one source role' }}
                            render={({ field }) => (
                                <>
                                    <div className="control-role-list">
                                        {logicalSourceRoleNames.map((role) => {
                                            const checked = field.value.includes(role);
                                            const file = roleFiles.get(role);
                                            const disabled = file !== undefined && !file.file_name;
                                            return (
                                                <label
                                                    key={role}
                                                    className={`select-row ${checked ? 'selected' : ''} ${disabled ? 'opacity-50' : ''}`}
                                                    style={disabled ? { cursor: 'not-allowed' } : undefined}
                                                >
                                                    <Form.Check
                                                        type="checkbox"
                                                        id={`role-${role}`}
                                                        label={role}
                                                        checked={checked}
                                                        disabled={disabled}
                                                        onChange={() =>
                                                            field.onChange(checked ? field.value.filter((r) => r !== role) : [...field.value, role])
                                                        }
                                                    />
                                                    {file && (
                                                        <small className={`control-role-file ms-4 ${file.file_name ? 'text-secondary' : 'text-warning-emphasis'}`}>
                                                            <i className={`bi ${file.file_name ? 'bi-file-earmark' : 'bi-exclamation-triangle'} me-1`} aria-hidden="true" />
                                                            {file.file_name ?? `No file for ${period}`}
                                                        </small>
                                                    )}
                                                </label>
                                            );
                                        })}
                                    </div>
                                    {errors.logical_source_role_names && (
                                        <div className="text-danger small" role="alert">
                                            {errors.logical_source_role_names.message}
                                        </div>
                                    )}
                                </>
                            )}
                        />
                    </fieldset>

                    <Form.Group className="control-prompt mb-4" controlId="prompt_name">
                        <Form.Label className="fw-semibold">Prompt Name <span className="text-danger">*</span></Form.Label>
                        <Form.Text className="d-block mb-2">Prompts are fetched from configured SharePoint locations</Form.Text>
                        <Form.Select isInvalid={!!errors.prompt_name} {...register('prompt_name', { required: 'Select a prompt' })}>
                            <option value="">Select a prompt…</option>
                            {options.prompt_names.map((p) => (
                                <option key={p} value={p}>
                                    {p}
                                </option>
                            ))}
                        </Form.Select>
                        <Form.Control.Feedback type="invalid">{errors.prompt_name?.message}</Form.Control.Feedback>
                    </Form.Group>

                    <Form.Group className="control-description mb-4" controlId="description">
                        <Form.Label className="fw-semibold">Description</Form.Label>
                        <Form.Control
                            as="textarea"
                            rows={3}
                            isInvalid={!!errors.description}
                            {...register('description', { maxLength: { value: 500, message: 'Maximum 500 characters' } })}
                        />
                        <Form.Control.Feedback type="invalid">{errors.description?.message}</Form.Control.Feedback>
                    </Form.Group>

                    <div className="d-flex justify-content-end gap-2">
                        <Button variant="outline-secondary" onClick={onCancel} disabled={submitting}>
                            Cancel
                        </Button>
                        <Button type="submit" disabled={submitting}>
                            {submitting && <Spinner size="sm" className="me-2" />}
                            {submitLabel}
                        </Button>
                    </div>
                </Form>
            </Card.Body>
        </Card>
    );
}
