import type { TaskBatch } from '../types';
import type { RunBatch, RunItem, RunItemStatus } from '../types/run';

// Browser cache for backend task batches and legacy locally tracked runs.
const STORAGE_KEY = 'gardian.runBatches.v1';
const COUNTER_KEY = 'gardian.runCounter.v1';
const DISMISSED_KEY = 'gardian.dismissedServerBatches.v1';

type Listener = () => void;

function load(): RunBatch[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? (JSON.parse(raw) as RunBatch[]) : [];
  } catch {
    return [];
  }
}

let snapshot: RunBatch[] = load();
let dismissed: Set<string>;
const listeners = new Set<Listener>();

try {
  dismissed = new Set(JSON.parse(localStorage.getItem(DISMISSED_KEY) ?? '[]') as string[]);
} catch {
  dismissed = new Set();
}

function commit(next: RunBatch[]): void {
  snapshot = next;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // Storage full/unavailable: keep in-memory state only.
  }
  listeners.forEach((l) => l());
}

function nextRunCode(): string {
  const n = Number(localStorage.getItem(COUNTER_KEY) ?? '0') + 1;
  localStorage.setItem(COUNTER_KEY, String(n));
  return `GAR${String(n).padStart(3, '0')}`;
}

function itemStatus(status: string): RunItemStatus {
  if (status === 'completed') return 'completed';
  if (status === 'failed' || status === 'interrupted') return 'failed';
  if (status === 'running') return 'running';
  return 'queued';
}

export function taskBatchToRunBatch(batch: TaskBatch): RunBatch {
  return {
    id: batch.batch_id,
    title: batch.run_title,
    period: batch.period ?? '',
    description: batch.description,
    createdAt: batch.created_at,
    createdBy: '',
    maxParallelCases: batch.max_parallel_cases,
    items: (batch.items ?? []).map((item) => ({
      taskId: item.task_id,
      taskTitle: item.task_title,
      roles: [],
      jobId: item.job_id ?? undefined,
      runId: item.run_id ?? undefined,
      status: itemStatus(item.status),
      stage: item.status,
      startedAt: item.started_at ?? batch.started_at ?? batch.created_at,
      completedAt: item.completed_at ?? undefined,
      error: item.error ?? undefined,
    })),
  };
}

export const runBatchStore = {
  subscribe(listener: Listener): () => void {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },

  getSnapshot: (): RunBatch[] => snapshot,

  get: (id: string): RunBatch | undefined => snapshot.find((b) => b.id === id),

  upsertServerBatch(batch: TaskBatch): RunBatch | undefined {
    const mapped = taskBatchToRunBatch(batch);
    if (dismissed.has(mapped.id)) return undefined;
    commit([mapped, ...snapshot.filter((current) => current.id !== mapped.id)]);
    return mapped;
  },

  syncServerBatches(serverBatches: TaskBatch[]): void {
    const mapped = serverBatches
      .map(taskBatchToRunBatch)
      .filter((batch) => !dismissed.has(batch.id));
    const serverIds = new Set(mapped.map((batch) => batch.id));
    const legacy = snapshot.filter((batch) => !batch.id.startsWith('batch_') && !serverIds.has(batch.id));
    commit([...mapped, ...legacy]);
  },

  createWithId(id: string, input: Omit<RunBatch, 'id' | 'createdAt'>): RunBatch {
    const batch: RunBatch = { ...input, id, createdAt: new Date().toISOString() };
    commit([batch, ...snapshot.filter((current) => current.id !== id)]);
    return batch;
  },

  create(input: Omit<RunBatch, 'id' | 'createdAt'>): RunBatch {
    const batch: RunBatch = { ...input, id: nextRunCode(), createdAt: new Date().toISOString() };
    commit([batch, ...snapshot]);
    return batch;
  },

  updateItem(batchId: string, taskId: string, patch: Partial<RunItem>): void {
    commit(
      snapshot.map((b) =>
        b.id === batchId
          ? { ...b, items: b.items.map((i) => (i.taskId === taskId ? { ...i, ...patch } : i)) }
          : b
      )
    );
  },

  remove(id: string): void {
    if (id.startsWith('batch_')) {
      dismissed.add(id);
      try {
        localStorage.setItem(DISMISSED_KEY, JSON.stringify([...dismissed]));
      } catch {
        // Keep the dismissal for this session if storage is unavailable.
      }
    }
    commit(snapshot.filter((b) => b.id !== id));
  },
};
