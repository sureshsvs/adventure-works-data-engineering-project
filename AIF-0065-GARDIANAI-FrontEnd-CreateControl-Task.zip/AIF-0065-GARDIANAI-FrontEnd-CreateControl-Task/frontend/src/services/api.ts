import axios from 'axios';

import type {
  GeneratedDocument,
  GenerationRun,
  BatchJobStatus,
  JobStatus,
  PromptEntry,
  RunSummary,
  TestCase,
  Task,
  TaskBatch,
  TaskPreflight,
} from '../types';

const baseURL = import.meta.env.VITE_API_URL || '/api';

// OCR + LLM runs over large PDFs can take a while on the first (uncached) run.
const client = axios.create({
  baseURL,
  timeout: 600000,
  headers: {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
  },
});

// Azure App Service "Easy Auth" exposes the signed-in user's tokens at /.auth/me.
// Cache the access token in memory; it's refreshed on demand and cleared on 401.
let cachedAccessToken: string | null = null;

export interface AuthUser {
  name: string;
}

// undefined = not yet fetched; null = no Easy Auth session (e.g. local dev).
let cachedUser: AuthUser | null | undefined;

async function fetchCurrentUser(): Promise<AuthUser | null> {
  if (cachedUser !== undefined) return cachedUser;
  try {
    const { data } = await axios.get<
      Array<{ user_id?: string; user_claims?: Array<{ typ: string; val: string }> }>
    >('/.auth/me');
    const claims = data?.[0]?.user_claims ?? [];
    const name =
      claims.find((c) => c.typ === 'name')?.val ??
      claims.find((c) => c.typ.endsWith('/claims/name'))?.val ??
      claims.find((c) => c.typ === 'preferred_username')?.val ??
      data?.[0]?.user_id;
    cachedUser = name ? { name } : null;
  } catch {
    cachedUser = null;
  }
  return cachedUser;
}

async function getAccessToken(): Promise<string | null> {
  if (cachedAccessToken) return cachedAccessToken;
  try {
    const { data } = await axios.get<Array<{ access_token?: string }>>('/.auth/me');
    cachedAccessToken = data?.[0]?.access_token ?? null;
  } catch {
    // No auth proxy in front (e.g. local dev) — proceed unauthenticated.
    cachedAccessToken = null;
  }
  return cachedAccessToken;
}

client.interceptors.request.use(async (config) => {
  const token = await getAccessToken();
  if (token) config.headers.set('Authorization', `Bearer ${token}`);
  return config;
});

// A rejected token is likely stale; drop it so the next call re-fetches from /.auth/me.
client.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error?.response?.status === 401) cachedAccessToken = null;
    return Promise.reject(error);
  }
);

// Per-run generation options exposed as UI controls (undefined = use server default).
export interface RunOptions {
  useExpectedTemplate?: boolean;
  economy?: boolean;
  reasoningEffort?: 'high' | 'medium' | 'low';
}

export interface GenerationOptions extends RunOptions {
  runTitle: string;
  description?: string;
}

export interface BatchGenerationOptions extends GenerationOptions {
  maxParallelCases?: 1 | 2 | 3 | 4;
}

export interface TaskBatchGenerationOptions extends BatchGenerationOptions {
  period?: string;
  grouping?: string;
}

function generationBody(opts: GenerationOptions) {
  return {
    ...runBody(opts),
    run_title: opts.runTitle.trim(),
    description: opts.description?.trim() ?? '',
  };
}

function runBody(opts?: RunOptions) {
  return {
    use_expected_template: opts?.useExpectedTemplate,
    economy: opts?.economy,
    reasoning_effort: opts?.reasoningEffort,
  };
}

export const api = {
  health: () => client.get('/health').then((r) => r.data),

  listTasks: (signal?: AbortSignal) =>
    client.get<{ tasks: Task[] }>('/tasks', { signal }).then((r) => r.data.tasks),

  preflightTasks: (taskIds: string[], period?: string, signal?: AbortSignal) =>
    client.post<TaskPreflight>('/super-agent/tasks/generate/preflight', {
      task_ids: taskIds,
      period,
    }, { signal, timeout: 30000 }).then((r) => r.data),

  startTaskBatchGeneration: (
    taskIds: string[],
    opts: TaskBatchGenerationOptions,
    signal?: AbortSignal,
    timeout = 15000,
  ) =>
    client.post<{ batch_id: string; job_id: string }>('/super-agent/tasks/generate/batch/start', {
      task_ids: taskIds,
      ...generationBody(opts),
      period: opts.period,
      grouping: opts.grouping ?? '',
      max_parallel_cases: opts.maxParallelCases ?? 1,
    }, { signal, timeout }).then((r) => r.data),

  listTaskBatches: (signal?: AbortSignal) =>
    client.get<{ batches: TaskBatch[] }>('/super-agent/tasks/batches', { signal })
      .then((r) => r.data.batches),

  getTaskBatch: (batchId: string, signal?: AbortSignal) =>
    client.get<TaskBatch>(`/super-agent/tasks/batches/${encodeURIComponent(batchId)}`, { signal })
      .then((r) => r.data),

  listTestCases: () =>
    client.get<{ test_cases: TestCase[] }>('/testcases/').then((r) => r.data.test_cases),

  runSuperAgent: (testCaseId: string, opts: GenerationOptions) =>
    client
      .post<GenerationRun>('/super-agent/generate', {
        test_case_id: testCaseId,
        ...generationBody(opts),
      })
      .then((r) => r.data),

  regenerate: (runId: string, opts?: RunOptions) =>
    client
      .post<GenerationRun>('/super-agent/regenerate', {
        run_id: runId,
        ...runBody(opts),
      })
      .then((r) => r.data),

  startGeneration: (testCaseId: string, opts: GenerationOptions) =>
    client
      .post<{ job_id: string }>('/super-agent/generate/start', {
        test_case_id: testCaseId,
        ...generationBody(opts),
      })
      .then((r) => r.data.job_id),

  startBatchGeneration: (testCaseIds: string[], opts: BatchGenerationOptions) =>
    client
      .post<{ job_id: string }>('/super-agent/generate/batch/start', {
        test_case_ids: testCaseIds,
        max_parallel_cases: opts.maxParallelCases ?? 1,
        ...generationBody(opts),
      })
      .then((r) => r.data.job_id),

  startRegenerate: (runId: string, opts?: RunOptions) =>
    client
      .post<{ job_id: string }>('/super-agent/regenerate/start', {
        run_id: runId,
        ...runBody(opts),
      })
      .then((r) => r.data.job_id),

  jobStatus: (jobId: string) =>
    client.get<JobStatus>(`/super-agent/jobs/${jobId}`).then((r) => r.data),

  batchJobStatus: (jobId: string) =>
    client.get<BatchJobStatus>(`/super-agent/jobs/${jobId}`).then((r) => r.data),

  uploadTestCase: (form: FormData) =>
    client
      .post<TestCase>('/super-agent/upload', form, {
        headers: { 'Content-Type': 'multipart/form-data' },
      })
      .then((r) => r.data),

  listRuns: () =>
    client.get<{ runs: RunSummary[] }>('/super-agent/runs').then((r) => r.data.runs),

  getRun: (runId: string) =>
    client.get<GenerationRun>(`/super-agent/runs/${runId}`).then((r) => r.data),

  updateDocument: (runId: string, document: GeneratedDocument) =>
    client
      .put<GenerationRun>(`/super-agent/runs/${runId}/document`, document)
      .then((r) => r.data),

  coauthor: (runId: string, message: string) =>
    client
      .post<GenerationRun & { reply: string }>(`/super-agent/runs/${runId}/coauthor`, {
        message,
      })
      .then((r) => r.data),

  // Fetched via the authenticated client (not a raw <a href>) so the bearer
  // token is attached to the request.
  downloadReport: async (runId: string): Promise<void> => {
    const response = await client.get<Blob>(`/super-agent/runs/${runId}/report`, {
      responseType: 'blob',
    });
    const disposition = response.headers['content-disposition'] as string | undefined;
    const filename = disposition?.match(/filename="?([^"]+)"?/)?.[1] || `${runId}.docx`;
    const url = URL.createObjectURL(response.data);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  },

  listPrompts: () =>
    client.get<{ prompts: PromptEntry[] }>('/prompts/').then((r) => r.data.prompts),

  updatePrompt: (id: string, prompt: string) =>
    client.put<PromptEntry>(`/prompts/${id}`, { prompt }).then((r) => r.data),

  currentUser: fetchCurrentUser,

  // Easy Auth's built-in logout endpoint; clears the session and redirects back.
  logoutUrl: () =>
    `/.auth/logout?post_logout_redirect_uri=${encodeURIComponent(window.location.origin)}`,
};
