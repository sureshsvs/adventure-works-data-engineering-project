import { apiClient } from '../api/client';
import type {
  DispositionPayload,
  GenerationRun,
  JobStatus,
  SharePointUploadParams,
  TaskRunRequest,
} from '../types/api';

export const runService = {
  startTaskGeneration: (req: TaskRunRequest) =>
    apiClient
      .post<{ job_id: string }>('/super-agent/tasks/generate/start', req)
      .then((r) => r.data.job_id),

  jobStatus: (jobId: string) =>
    apiClient.get<JobStatus>(`/super-agent/jobs/${encodeURIComponent(jobId)}`).then((r) => r.data),

  getRun: (runId: string) =>
    apiClient.get<GenerationRun>(`/super-agent/runs/${encodeURIComponent(runId)}`).then((r) => r.data),

  updateDisposition: (runId: string, payload: DispositionPayload) =>
    apiClient
      .patch<GenerationRun>(`/super-agent/runs/${encodeURIComponent(runId)}/disposition`, payload)
      .then((r) => r.data),

  uploadToSharePoint: ({ runId, controlName, quarter }: SharePointUploadParams) =>
    apiClient
      .post<Record<string, unknown>>(
        `/super-agent/runs/${encodeURIComponent(runId)}/report/sharepoint`,
        null,
        { params: { control_name: controlName, quarter } }
      )
      .then((r) => r.data),

  // Fetched through the authenticated client so auth headers are attached.
  downloadReport: async (runId: string): Promise<void> => {
    const response = await apiClient.get<Blob>(
      `/super-agent/runs/${encodeURIComponent(runId)}/report`,
      { responseType: 'blob' }
    );
    const header = response.headers['content-disposition'] as string | undefined;
    const filename = header?.match(/filename="?([^"]+)"?/)?.[1] ?? `${runId}.docx`;
    const url = URL.createObjectURL(response.data);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  },
};
