import { isAxiosError } from 'axios';

import { api, type TaskBatchGenerationOptions } from './api';
import type { TaskValidationError } from '../types';

const MAX_RETRIES = 3;
const MAX_WAIT_MS = 30000;
const ADMISSION_DEADLINE_MS = 60000;
const EXHAUSTED = 'Batch admission is still busy: retry limit or waiting budget exhausted. No batch was accepted. Try again later.';

export class TaskPreparationError extends Error {
  constructor(readonly errors: TaskValidationError[]) {
    super('Task preparation failed. Fix the errors before starting; no batch was queued.');
  }
}

export async function prepareAndAdmitTaskBatch(
  taskIds: string[],
  options: TaskBatchGenerationOptions,
  signal: AbortSignal,
  onWait: (message: string) => void,
  onPrepared: () => void,
) {
  const preflight = await api.preflightTasks(taskIds, options.period, signal);
  signal.throwIfAborted();
  if (!preflight.valid || preflight.errors.length) throw new TaskPreparationError(preflight.errors);
  onPrepared();
  return admitTaskBatch(taskIds, options, signal, onWait);
}

function retryAfterMs(value: unknown): number | undefined {
  if (typeof value !== 'string' && typeof value !== 'number') return undefined;
  const text = String(value).trim();
  if (!text) return undefined;
  const seconds = Number(text);
  if (Number.isFinite(seconds) && seconds >= 0) return seconds * 1000;
  const date = Date.parse(text);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : undefined;
}

function wait(ms: number, signal: AbortSignal) {
  return new Promise<void>((resolve, reject) => {
    signal.throwIfAborted();
    const abort = () => {
      window.clearTimeout(timer);
      reject(new Error('Batch submission cancelled.'));
    };
    const timer = window.setTimeout(() => {
      signal.removeEventListener('abort', abort);
      resolve();
    }, ms);
    signal.addEventListener('abort', abort, { once: true });
  });
}

// Only an explicit admission rejection is safe to retry; a lost response may
// already have created a batch.
export async function admitTaskBatch(
  taskIds: string[],
  options: TaskBatchGenerationOptions,
  signal: AbortSignal,
  onWait: (message: string) => void,
) {
  const deadline = Date.now() + ADMISSION_DEADLINE_MS;
  let waited = 0;
  for (let attempt = 0; ; attempt += 1) {
    signal.throwIfAborted();
    const remaining = deadline - Date.now();
    if (remaining <= 0) throw new Error(EXHAUSTED);
    try {
      return await api.startTaskBatchGeneration(taskIds, options, signal, Math.min(15000, remaining));
    } catch (error) {
      if (!isAxiosError(error) || error.response?.status !== 429) throw error;
      if (attempt >= MAX_RETRIES) throw new Error(EXHAUSTED);
      const delay = Math.max(
        1000 * 2 ** attempt,
        retryAfterMs(error.response.headers['retry-after']) ?? 0,
      );
      if (waited + delay > MAX_WAIT_MS || Date.now() + delay >= deadline) {
        throw new Error(EXHAUSTED);
      }
      onWait(`Admission busy. Retry ${attempt + 1} of ${MAX_RETRIES} in ${Math.ceil(delay / 1000)}s. No batch accepted yet.`);
      await wait(delay, signal);
      waited += delay;
    }
  }
}
