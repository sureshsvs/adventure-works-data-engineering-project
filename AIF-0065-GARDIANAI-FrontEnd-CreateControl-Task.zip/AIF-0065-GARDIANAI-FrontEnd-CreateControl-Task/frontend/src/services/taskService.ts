import { apiClient } from '../api/client';
import type { Task, TaskOptions, TaskPayload } from '../types/api';

export const taskService = {
  list: () => apiClient.get<{ tasks: Task[] }>('/tasks').then((r) => r.data.tasks),

  get: (id: string, period?: string) =>
    apiClient
      .get<Task>(`/tasks/${encodeURIComponent(id)}`, { params: period ? { period } : undefined })
      .then((r) => r.data),

  create: (payload: TaskPayload) => apiClient.post<Task>('/tasks', payload).then((r) => r.data),

  update: (id: string, payload: TaskPayload) =>
    apiClient.put<Task>(`/tasks/${encodeURIComponent(id)}`, payload).then((r) => r.data),

  remove: (id: string) => apiClient.delete(`/tasks/${encodeURIComponent(id)}`).then(() => undefined),

  options: (period?: string) =>
    apiClient
      .get<TaskOptions>('/tasks/options', { params: period ? { period } : undefined })
      .then((r) => r.data),

  periods: () => apiClient.get<{ periods: string[] }>('/periods').then((r) => r.data.periods),
};
