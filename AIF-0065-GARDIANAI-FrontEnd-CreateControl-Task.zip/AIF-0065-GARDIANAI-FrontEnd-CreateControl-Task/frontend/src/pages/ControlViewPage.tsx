import { Button, Card } from 'react-bootstrap';
import { useNavigate, useParams } from 'react-router-dom';

import { ErrorAlert, LoadingSpinner } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { usePeriods, useTask, useTaskOptions } from '../hooks/useTasks';
import { PageContainer } from '../layouts/MainLayout';
import { roleFileMap } from '../utils/roles';

export default function ControlViewPage() {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const periods = usePeriods();
    const period = periods.data?.[0] ?? '';
    const task = useTask(id);
    const options = useTaskOptions(period || undefined);
    const roleFiles = roleFileMap(options.data);

    return (
        <PageContainer>
            <PageHeader
                title="View Control / Task"
                subtitle="Review the control details of this reusable check."
                crumbs={[{ label: 'Controls Library', to: '/controls' }, { label: 'View Control/Task' }]}
            />
            {task.isLoading && <LoadingSpinner />}
            {task.error && <ErrorAlert error={task.error} onRetry={() => void task.refetch()} />}
            {task.data && (
                <Card style={{ maxWidth: 800 }}>
                    <Card.Body className="p-4">
                        <div className="mb-4">
                            <div className="fw-semibold mb-2">Control Name :</div>
                            <div>{task.data.title}</div>
                        </div>
                        <div className="mb-4">
                            <div className="fw-semibold mb-2">Period</div>
                            <div>{period || '—'}</div>
                        </div>

                        <div className="mb-4">
                            <div className="fw-semibold mb-1">Selected Logical Source Roles</div>
                            <div className="small text-secondary mb-3">
                                Documents are fetched from configured SharePoint locations
                            </div>
                            {options.error && <ErrorAlert error={options.error} onRetry={() => void options.refetch()} />}
                            <div className="border rounded p-3" style={{ maxWidth: 640 }}>
                                {task.data.logical_source_role_names.map((role) => {
                                    const file = roleFiles.get(role);
                                    return (
                                        <div key={role} className="mb-2">
                                            <div className="fw-semibold">{role}</div>
                                            {file === undefined ? (
                                                <span className="text-secondary small">{options.isFetching ? 'Loading…' : '—'}</span>
                                            ) : file.file_name ? (
                                                <span className="small">
                                                    <i className="bi bi-file-earmark me-1" aria-hidden="true" />
                                                    {file.file_name}
                                                </span>
                                            ) : (
                                                <span className="small text-warning-emphasis">
                                                    <i className="bi bi-exclamation-triangle me-1" aria-hidden="true" />
                                                    No file found for {period}
                                                </span>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                        <div className="mb-4">
                            <div className="fw-semibold mb-2">Prompt Name</div>
                            <div>{task.data.prompt_name}</div>
                        </div>
                        <div className="mb-4">
                            <div className="fw-semibold mb-2">Description</div>
                            <div>{task.data.description || <span className="text-secondary">No description</span>}</div>
                        </div>

                        <div className="d-flex justify-content-end gap-2">
                            <Button variant="outline-secondary" onClick={() => navigate('/controls')}>
                                Cancel
                            </Button>
                            <Button onClick={() => navigate(`/controls/${task.data.id}/edit`)}>Edit</Button>
                        </div>
                    </Card.Body>
                </Card>
            )}
        </PageContainer>
    );
}
