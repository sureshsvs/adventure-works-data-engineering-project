import legacyCss from '../index.css?inline';

import SuperAgentPage from './SuperAgentPage';

// Legacy index.css targets global selectors (.row, .nav-link, .badge…), so confine it to this page.
const scopedCss = `@scope (.legacy-sa) {\n${legacyCss.replace(':root', ':scope')}\n}`;

export default function SuperAgentRoute() {
    return (
        <div className="legacy-sa">
            <style>{scopedCss}</style>
            <div className="content">
                <SuperAgentPage />
            </div>
        </div>
    );
}
