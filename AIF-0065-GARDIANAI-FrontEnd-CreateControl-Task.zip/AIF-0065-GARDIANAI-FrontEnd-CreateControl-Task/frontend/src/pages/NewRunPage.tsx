import { useEffect, useState } from 'react';
import { Button, Card, Col, Form, Row } from 'react-bootstrap';
import { Controller, useForm } from 'react-hook-form';
import { useNavigate } from 'react-router-dom';

import { EmptyState, ErrorAlert, LoadingSpinner } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { SearchInput } from '../components/common/SearchInput';
import { useRunDraft } from '../contexts/RunDraftContext';
import { usePeriods, useTaskOptions, useTasks } from '../hooks/useTasks';
import { PageContainer } from '../layouts/MainLayout';
import type { RunDraft } from '../types/run';
import { missingRoles } from '../utils/roles';

export default function NewRunPage() {
    const navigate = useNavigate();
    const { draft, setDraft } = useRunDraft();
    const tasks = useTasks();
    const periods = usePeriods();
    const [search, setSearch] = useState('');

    const {
        register,
        control,
        handleSubmit,
        watch,
        setValue,
        formState: { errors },
    } = useForm<RunDraft>({
        defaultValues: draft
            ? { ...draft, maxParallelCases: draft.maxParallelCases ?? 1 }
            : { title: '', period: '', description: '', taskIds: [], maxParallelCases: 1 },
    });

    const period = watch('period');
    const options = useTaskOptions(period || undefined);

    // Periods come newest first; preselect the latest.
    useEffect(() => {
        if (!period && periods.data?.length) setValue('period', periods.data[0]);
    }, [period, periods.data, setValue]);

    const onSubmit = (values: RunDraft) => {
        setDraft({ ...values, title: values.title.trim(), description: values.description.trim() });
        navigate('/runs/review');
    };

    const q = search.trim().toLowerCase();
    const visible = (tasks.data ?? []).filter(
        (t) => !q || t.title.toLowerCase().includes(q) || (t.description ?? '').toLowerCase().includes(q)
    );

    return (
        <PageContainer>
            <PageHeader title="Create New Run" subtitle="Enter run details and select a control to start" />
            <Form onSubmit={handleSubmit(onSubmit)} noValidate>
                <Row className="g-3">
                    <Col lg={5}>
                        <Card className="h-100">
                            <Card.Body>
                                <h2 className="h5 fw-bold mb-3">Run Details</h2>
                                <Form.Group className="mb-3" controlId="title">
                                    <Form.Label className="fw-semibold">
                                        Run Title <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Form.Control
                                        isInvalid={!!errors.title}
                                        {...register('title', {
                                            required: 'Run title is required',
                                            validate: (v) => v.trim().length >= 3 || 'Use at least 3 characters',
                                            maxLength: { value: 120, message: 'Maximum 120 characters' },
                                        })}
                                    />
                                    <Form.Control.Feedback type="invalid">{errors.title?.message}</Form.Control.Feedback>
                                </Form.Group>

                                <Form.Group className="mb-3" controlId="period">
                                    <Form.Label className="fw-semibold">
                                        Reporting Period <span className="text-danger">*</span>
                                    </Form.Label>
                                    <Form.Select
                                        disabled={periods.isLoading}
                                        isInvalid={!!errors.period}
                                        {...register('period', { required: 'Select a reporting period' })}
                                    >
                                        <option value="">{periods.isLoading ? 'Loading…' : 'Select period…'}</option>
                                        {periods.data?.map((p) => (
                                            <option key={p} value={p}>
                                                {p}
                                            </option>
                                        ))}
                                    </Form.Select>
                                    <Form.Control.Feedback type="invalid">{errors.period?.message}</Form.Control.Feedback>
                                    {periods.error && <ErrorAlert error={periods.error} onRetry={() => void periods.refetch()} />}
                                </Form.Group>

                                <Form.Group controlId="description">
                                    <Form.Label className="fw-semibold">Description (Optional)</Form.Label>
                                    <Form.Control
                                        as="textarea"
                                        rows={4}
                                        isInvalid={!!errors.description}
                                        {...register('description', { maxLength: { value: 500, message: 'Maximum 500 characters' } })}
                                    />
                                    <Form.Control.Feedback type="invalid">{errors.description?.message}</Form.Control.Feedback>
                                </Form.Group>
                            </Card.Body>
                        </Card>
                    </Col>

                    <Col lg={7}>
                        <Card className="h-100">
                            <Card.Body>
                                <h2 className="h5 fw-bold mb-0">Select Controls</h2>
                                <p className="small text-secondary">Documents are fetched from configured SharePoint locations</p>
                                <SearchInput value={search} onChange={setSearch} placeholder="Search Control name" className="mb-3" />

                                {tasks.isLoading && <LoadingSpinner />}
                                {tasks.error && <ErrorAlert error={tasks.error} onRetry={() => void tasks.refetch()} />}
                                {tasks.data && visible.length === 0 && (
                                    <EmptyState icon="bi-journal-x" title="No controls found">
                                        Create controls in the Controls Library first.
                                    </EmptyState>
                                )}

                                <Controller
                                    control={control}
                                    name="taskIds"
                                    rules={{ validate: (v) => v.length > 0 || 'Select at least one control' }}
                                    render={({ field }) => (
                                        <div role="group" aria-label="Controls">
                                            <div className="run-control-list">
                                                {visible.map((t) => {
                                                    const checked = field.value.includes(t.id);
                                                    const unavailableRoles = options.isFetching
                                                        ? []
                                                        : missingRoles(t.logical_source_role_names, options.data);
                                                    const disabled = unavailableRoles.length > 0 && !checked;
                                                    return (
                                                        <label
                                                            key={t.id}
                                                            className={`select-row ${checked ? 'selected' : ''} ${disabled ? 'opacity-50' : ''}`}
                                                            style={disabled ? { cursor: 'not-allowed' } : undefined}
                                                        >
                                                            <Form.Check
                                                                type="checkbox"
                                                                id={`task-${t.id}`}
                                                                checked={checked}
                                                                disabled={disabled}
                                                                onChange={() =>
                                                                    field.onChange(checked ? field.value.filter((x) => x !== t.id) : [...field.value, t.id])
                                                                }
                                                                label={
                                                                    <>
                                                                        <div className="fw-semibold">{t.title}</div>
                                                                        <div className="small text-secondary">{t.description}</div>
                                                                        {unavailableRoles.length > 0 && (
                                                                            <div className="small text-warning-emphasis">
                                                                                <i className="bi bi-exclamation-triangle me-1" aria-hidden="true" />
                                                                                No file for {period}: {unavailableRoles.join(', ')}
                                                                            </div>
                                                                        )}
                                                                    </>
                                                                }
                                                            />
                                                        </label>
                                                    );
                                                })}
                                            </div>
                                            {errors.taskIds && (
                                                <div className="text-danger small" role="alert">
                                                    {errors.taskIds.message}
                                                </div>
                                            )}
                                        </div>
                                    )}
                                />
                                <Form.Group className="mt-3" controlId="batch-parallelism">
                                    <Form.Label className="fw-semibold mb-1">Batch Run</Form.Label>
                                    <Form.Text className="d-block mb-2">
                                        Run selected controls sequentially or with up to four controls at a time.
                                    </Form.Text>
                                    <Form.Select
                                        size="sm"
                                        style={{ maxWidth: 240 }}
                                        {...register('maxParallelCases', { valueAsNumber: true, required: true })}
                                    >
                                        <option value={1}>Sequential</option>
                                        <option value={2}>2 Parallel Execute</option>
                                        <option value={3}>3 Parallel Execute</option>
                                        <option value={4}>4 Parallel Execute</option>
                                    </Form.Select>
                                </Form.Group>
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
                <div className="d-flex justify-content-end mt-3">
                    <Button type="submit">
                        Next <i className="bi bi-chevron-right" aria-hidden="true" />
                    </Button>
                </div>
            </Form>
        </PageContainer>
    );
}
