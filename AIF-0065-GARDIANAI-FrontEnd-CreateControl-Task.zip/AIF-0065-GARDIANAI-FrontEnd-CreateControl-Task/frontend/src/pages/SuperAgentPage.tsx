import { useEffect, useRef, useState } from 'react';
import { isAxiosError } from 'axios';
import { Download, Play, RefreshCw, Upload } from 'lucide-react';

import { api } from '../services/api';
import TaskBatchPanel from './TaskBatchPanel';
import type {
  BatchJobStatus,
  DocSection,
  GeneratedDocument,
  GenerationRun,
  ReportParameters,
  RunSummary,
  TestCase,
  TokenUsage,
} from '../types';

const STAGES = [
  { key: 'prepare', label: 'Preparing' },
  { key: 'analyze', label: 'Analyzing documents' },
  { key: 'review', label: 'Reviewing calculations' },
  { key: 'compose', label: 'Composing report' },
  { key: 'render', label: 'Rendering .docx' },
];

const fmt = (n: number) => n.toLocaleString();

const stageLabel = (key: string) =>
  STAGES.find((s) => s.key === key)?.label ?? key;

function requestError(error: unknown, fallback: string) {
  if (isAxiosError(error)) {
    const detail = error.response?.data?.detail;
    if (typeof detail === 'string') return detail;
    if (detail) return JSON.stringify(detail);
    if (error.response?.status === 429) return 'The service is busy. Please try again later.';
  }
  return fallback;
}

function reportParameters(parameters: ReportParameters) {
  return [
    parameters.max_parallel_cases ? `Max parallel cases: ${parameters.max_parallel_cases}` : '',
  ].filter(Boolean).join(' · ');
}

export default function SuperAgentPage() {
  const [mode, setMode] = useState<'tasks' | 'samples'>('tasks');
  const [testCases, setTestCases] = useState<TestCase[]>([]);
  const [runs, setRuns] = useState<RunSummary[]>([]);
  const [selectedTc, setSelectedTc] = useState('');
  const [runTitle, setRunTitle] = useState('');
  const [description, setDescription] = useState('');
  const [maxParallelCases, setMaxParallelCases] = useState<1 | 2 | 3 | 4>(1);
  const [batchSelection, setBatchSelection] = useState<string[]>([]);
  const [batch, setBatch] = useState<BatchJobStatus | null>(null);
  const [batchLoading, setBatchLoading] = useState(false);
  const [batchError, setBatchError] = useState('');
  const [run, setRun] = useState<GenerationRun | null>(null);
  const [loading, setLoading] = useState(false);
  const [regenerating, setRegenerating] = useState(false);
  const [useTemplate, setUseTemplate] = useState(false);
  const [economy, setEconomy] = useState(false);
  const [reasoning, setReasoning] = useState<'high' | 'medium' | 'low'>('high');
  const [stage, setStage] = useState('');
  const [detail, setDetail] = useState('');
  const [tokens, setTokens] = useState<TokenUsage | null>(null);
  const [elapsed, setElapsed] = useState(0);
  const [jobError, setJobError] = useState('');

  useEffect(() => {
    refreshTestCases();
    refreshRuns();
  }, []);

  function refreshTestCases(selectId?: string) {
    api.listTestCases().then((tcs) => {
      setTestCases(tcs);
      if (selectId) setSelectedTc(selectId);
      else if (!selectedTc && tcs[0]) setSelectedTc(tcs[0].id);
    });
  }

  function refreshRuns() {
    api.listRuns().then(setRuns);
  }

  // Poll a background job, driving the animated stage stepper.
  async function runJob(start: () => Promise<string>) {
    setJobError('');
    setStage('queued');
    setDetail('');
    setTokens(null);
    setElapsed(0);
    const t0 = Date.now();
    const timer = window.setInterval(
      () => setElapsed(Math.floor((Date.now() - t0) / 1000)),
      1000,
    );
    try {
      const jobId = await start();
      for (;;) {
        const st = await api.jobStatus(jobId);
        setStage(st.status === 'queued' ? 'queued' : st.stage);
        setDetail(st.detail);
        if (st.tokens) setTokens(st.tokens);
        if (st.done || st.status === 'done' || st.status === 'error') {
          if (st.error || st.status === 'error') setJobError(st.error || 'Generation failed. Please try again.');
          else if (st.run) {
            setRun(st.run);
            refreshRuns();
          }
          break;
        }
        await new Promise((r) => setTimeout(r, 800));
      }
    } catch (error) {
      setJobError(requestError(error, 'The request failed. Please try again.'));
    } finally {
      window.clearInterval(timer);
      setStage('');
    }
  }

  async function doGenerate() {
    if (!selectedTc) return;
    if (!runTitle.trim()) {
      setJobError('Enter a run title before generating a report.');
      return;
    }
    setLoading(true);
    setRun(null);
    try {
      await runJob(() =>
        api.startGeneration(selectedTc, {
          runTitle,
          description,
          useExpectedTemplate: useTemplate,
          economy,
          reasoningEffort: reasoning,
        })
      );
    } finally {
      setLoading(false);
    }
  }

  async function doRegenerate() {
    if (!run) return;
    setRegenerating(true);
    try {
      await runJob(() =>
        api.startRegenerate(run.run_id, {
          useExpectedTemplate: useTemplate,
          economy,
          reasoningEffort: reasoning,
        })
      );
    } finally {
      setRegenerating(false);
    }
  }

  async function doBatch(ids: string[]) {
    if (ids.length === 0) return;
    if (!runTitle.trim()) {
      setBatchError('Enter a run title before starting a batch.');
      return;
    }
    setBatchError('');
    setBatch(null);
    setBatchLoading(true);
    try {
      const jobId = await api.startBatchGeneration(ids, {
        runTitle,
        description,
        maxParallelCases,
        useExpectedTemplate: useTemplate,
        economy,
        reasoningEffort: reasoning,
      });
      for (;;) {
        const status = await api.batchJobStatus(jobId);
        setBatch(status);
        if (status.done || status.status === 'completed' || status.status === 'completed_with_errors') {
          refreshRuns();
          break;
        }
        await new Promise((resolve) => window.setTimeout(resolve, 800));
      }
    } catch (error) {
      setBatchError(requestError(error, 'The batch request failed. Please try again.'));
    } finally {
      setBatchLoading(false);
    }
  }

  function toggleBatchSelection(testCaseId: string) {
    setBatchSelection((selected) =>
      selected.includes(testCaseId)
        ? selected.filter((id) => id !== testCaseId)
        : [...selected, testCaseId],
    );
  }

  async function openRun(runId: string) {
    setRun(await api.getRun(runId));
  }

  return (
    <div>
      <div className="page-head">
        <h1>SuperAgent</h1>
        <p>
          Generate auditable Word reports from saved tasks, or use sample test
          cases and uploaded inputs.
        </p>
      </div>

      <div className="row" style={{ marginBottom: 18 }} aria-label="Generation mode">
        <button className={mode === 'tasks' ? '' : 'ghost'} aria-pressed={mode === 'tasks'} onClick={() => setMode('tasks')}>Task batches</button>
        <button className={mode === 'samples' ? '' : 'ghost'} aria-pressed={mode === 'samples'} onClick={() => setMode('samples')}>Sample test cases</button>
      </div>
      <div hidden={mode !== 'tasks'}>
        <TaskBatchPanel onOpenRun={async (id) => {
          await openRun(id);
          setMode('samples');
        }} />
      </div>
      <div hidden={mode !== 'samples'}>
      <div className="panel">
        <div className="row" style={{ alignItems: 'flex-start', marginBottom: 16 }}>
          <div style={{ flex: 1, minWidth: 220 }}>
            <label className="muted" htmlFor="run-title">Run title (required)</label>
            <input
              id="run-title"
              required
              value={runTitle}
              onChange={(e) => setRunTitle(e.target.value)}
              placeholder="e.g. Q4 disclosure review"
              disabled={loading || regenerating || batchLoading}
              style={{ marginTop: 6 }}
            />
          </div>
          <div style={{ flex: 1, minWidth: 220 }}>
            <label className="muted" htmlFor="run-description">Description (optional)</label>
            <textarea
              id="run-description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Purpose, scope or notes to identify this run"
              rows={2}
              disabled={loading || regenerating || batchLoading}
              style={{ marginTop: 6 }}
            />
          </div>
        </div>
        <p className="muted">
          Enter a title to enable generation. The title and description apply to
          a single run or every result in a batch. Each result receives its own
          automatic run ID. Regeneration retains the original run labels.
        </p>
        <div className="row" style={{ alignItems: 'flex-end' }}>
          <div style={{ flex: 1 }}>
            <label className="muted">Test case</label>
            <select
              value={selectedTc}
              onChange={(e) => setSelectedTc(e.target.value)}
              style={{ marginTop: 6 }}
            >
              {testCases.map((tc) => (
                <option key={tc.id} value={tc.id}>
                  {tc.archetype === 'custom' ? 'Uploaded' : `Test case ${tc.number}`}{' '}
                  — {tc.title} ({tc.input_documents.length} docs)
                </option>
              ))}
            </select>
          </div>
          <label
            className="muted"
            style={{ display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}
            title="When off, the report is generated from the prompt alone, ignoring the benchmark expected output."
          >
            <input
              type="checkbox"
              checked={useTemplate}
              onChange={(e) => setUseTemplate(e.target.checked)}
              style={{ width: 'auto' }}
            />
            Use benchmark expected output
          </label>
          <label
            className="muted"
            style={{ display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}
            title="Economy mode: cheapest single-pass path, low reasoning, smaller template (skips harness + deep-research)."
          >
            <input
              type="checkbox"
              checked={economy}
              onChange={(e) => setEconomy(e.target.checked)}
              style={{ width: 'auto' }}
            />
            Economy
          </label>
          <label
            className="muted"
            style={{ display: 'flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap' }}
            title="Reasoning effort for the LLM (ignored when Economy is on — forced to low)."
          >
            Reasoning
            <select
              value={reasoning}
              onChange={(e) => setReasoning(e.target.value as 'high' | 'medium' | 'low')}
              disabled={economy}
              style={{ width: 'auto', marginTop: 0 }}
            >
              <option value="high">high</option>
              <option value="medium">medium</option>
              <option value="low">low</option>
            </select>
          </label>
          <button onClick={doGenerate} disabled={loading || regenerating || batchLoading || !selectedTc || !runTitle.trim()}>
            {loading ? <span className="spinner" /> : <Play size={16} />} Generate
            document
          </button>
        </div>
        <div style={{ marginTop: 18, borderTop: '1px solid var(--line)', paddingTop: 14 }}>
          <strong>Batch run</strong>
          <p className="muted" style={{ margin: '4px 0 10px' }}>
            Run selected test cases sequentially or up to four at a time in a single batch job.
          </p>
          <div className="row" style={{ marginBottom: 10 }}>
            <label className="muted" htmlFor="max-parallel-cases">Max parallel cases</label>
            <select
              id="max-parallel-cases"
              value={maxParallelCases}
              onChange={(e) => setMaxParallelCases(Number(e.target.value) as 1 | 2 | 3 | 4)}
              disabled={loading || regenerating || batchLoading}
              style={{ width: 'auto' }}
            >
              <option value={1}>1 (sequential)</option>
              <option value={2}>2 (parallel)</option>
              <option value={3}>3 (parallel)</option>
              <option value={4}>4 (parallel)</option>
            </select>
            <button
              onClick={() =>
                doBatch(testCases.filter((tc) => batchSelection.includes(tc.id)).map((tc) => tc.id))
              }
              disabled={loading || regenerating || batchLoading || batchSelection.length === 0 || !runTitle.trim()}
            >
              {batchLoading ? <span className="spinner" /> : <Play size={16} />} Run selected
            </button>
            <button
              className="ghost"
              onClick={() => doBatch(testCases.map((tc) => tc.id))}
              disabled={loading || regenerating || batchLoading || testCases.length === 0 || !runTitle.trim()}
            >
              Run all
            </button>
          </div>
          <div className="row" style={{ gap: '8px 20px' }}>
            {testCases.map((tc) => (
              <label
                key={tc.id}
                className="muted"
                style={{ display: 'flex', alignItems: 'center', gap: 6 }}
              >
                <input
                  type="checkbox"
                  checked={batchSelection.includes(tc.id)}
                  onChange={() => toggleBatchSelection(tc.id)}
                  disabled={batchLoading}
                  style={{ width: 'auto' }}
                />
                Test case {tc.number} — {tc.title}
              </label>
            ))}
          </div>
        </div>
      </div>

      <UploadPanel onUploaded={(tc) => refreshTestCases(tc.id)} />

      {(loading || regenerating) && (
        <ProgressStepper stage={stage} detail={detail} elapsed={elapsed} tokens={tokens} />
      )}
      {(batch || batchLoading || batchError) && (
        <div className="panel">
          <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <h3 style={{ margin: 0 }}>Batch progress</h3>
              {batch && (
                <>
                  <p style={{ margin: '6px 0 0' }}><strong>{batch.run_title}</strong></p>
                  {batch.description && (
                    <p className="muted" style={{ whiteSpace: 'pre-wrap' }}>{batch.description}</p>
                  )}
                  {reportParameters(batch) && <p className="muted">{reportParameters(batch)}</p>}
                  <p className="muted">
                    Status: <strong>{batch.status.replace(/_/g, ' ')}</strong>
                  </p>
                </>
              )}
              {batch && (
                <p className="muted" style={{ margin: '4px 0 0' }}>
                  {batch.finished_count} of {batch.total} test cases finished
                  {batch.current_item_index != null
                    ? ` · Running ${batch.current_item_index} of ${batch.total}`
                    : ''}
                </p>
              )}
              {batch?.current_test_case_id ? (
                <p className="muted" style={{ margin: '4px 0 0' }}>
                  {batch.items.find((item) => item.test_case_id === batch.current_test_case_id)?.test_case_title}
                  {' · '}{stageLabel(batch.stage)}
                  {batch.detail ? ` — ${batch.detail}` : ''}
                </p>
              ) : batch?.detail ? <p className="muted">{batch.detail}</p> : null}
            </div>
            {batchLoading && (
              <span className="muted">
                <span className="spinner" /> {batch?.status === 'queued' ? 'Queued…' : batch ? 'Processing…' : 'Submitting batch…'}
              </span>
            )}
          </div>
          {batch && (
            <>
              <div className="progress-bar" style={{ margin: '10px 0 14px' }}>
                <span style={{ width: `${batch.total ? Math.round((batch.finished_count / batch.total) * 100) : 0}%` }} />
              </div>
              {batch.tokens && (
                <>
                  <p className="muted">Total batch token usage (all test cases)</p>
                  <TokenSummary usage={batch.tokens} />
                </>
              )}
              {batch.items.map((item, index) => (
                <div
                  key={`${item.test_case_id}-${index}`}
                  className="row"
                  style={{ alignItems: 'center', justifyContent: 'space-between', padding: '8px 0', borderTop: '1px solid var(--line)' }}
                >
                  <div style={{ flex: 1 }}>
                    <strong>{item.test_case_title}</strong>{' '}
                    <span
                      className={`badge ${
                        item.status === 'failed'
                          ? 'high'
                          : item.status === 'completed'
                            ? 'pass'
                            : 'info'
                      }`}
                    >
                      {item.status}
                    </span>
                    {(item.stage || item.detail) && (
                      <p className="muted" style={{ margin: '6px 0 0' }}>
                        {item.stage ? stageLabel(item.stage) : ''}
                        {item.stage && item.detail ? ' — ' : ''}{item.detail}
                      </p>
                    )}
                    {item.tokens && (
                      <p className="muted" style={{ margin: '6px 0 0' }}>
                        {fmt(item.tokens.total.total)} tokens · {fmt(item.tokens.total.prompt)} in ·{' '}
                        {fmt(item.tokens.total.completion)} out
                        {item.tokens.ocr.pages > 0 ? ` · OCR ${fmt(item.tokens.ocr.pages)} pages` : ''}
                      </p>
                    )}
                    {item.run && (
                      <p className="muted" style={{ margin: '6px 0 0' }}>
                        Run ID: <code>{item.run.run_id}</code>
                      </p>
                    )}
                    {item.error && <p className="badge high" style={{ margin: '6px 0 0' }}>{item.error}</p>}
                  </div>
                  {item.run && (
                    <div className="row">
                      <button
                        className="ghost sm"
                        onClick={() => {
                          setSelectedTc(item.test_case_id);
                          setRun(item.run);
                        }}
                      >
                        Open run
                      </button>
                      <button className="ghost sm" onClick={() => api.downloadReport(item.run!.run_id)}>
                        <Download size={14} /> .docx
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </>
          )}
          {batchError && <p className="badge high">{batchError}</p>}
          {batch?.status === 'completed_with_errors' && (
            <p className="muted" style={{ marginBottom: 0 }}>The batch finished; some test cases failed.</p>
          )}
        </div>
      )}
      {jobError && !loading && !regenerating && (
        <div className="panel">
          <p className="badge high">{jobError}</p>
        </div>
      )}

      {run && (
        <RunView
          run={run}
          regenerating={regenerating || batchLoading}
          onRegenerate={doRegenerate}
          onRunUpdated={(updated) => {
            setRun(updated);
            refreshRuns();
          }}
        />
      )}

      <div className="panel">
        <h3 style={{ marginTop: 0 }}>Run history</h3>
        {runs.length === 0 && <p className="muted">No runs yet.</p>}
        {runs.map((r) => (
          <div
            key={r.run_id}
            className="row"
            style={{ alignItems: 'center', gap: 8 }}
          >
            <button
              className={`list-btn ${run?.run_id === r.run_id ? 'selected' : ''}`}
              style={{ flex: 1 }}
              onClick={() => openRun(r.run_id)}
            >
              <strong>{r.run_title || r.test_case_title}</strong>
              <span className="muted" style={{ display: 'block' }}>
                {r.test_case_title} · Run ID: <code>{r.run_id}</code>
              </span>
              {r.description && (
                <span className="muted" style={{ display: 'block', whiteSpace: 'pre-wrap' }}>
                  {r.description}
                </span>
              )}
              {reportParameters(r) && (
                <span className="muted" style={{ display: 'block' }}>{reportParameters(r)}</span>
              )}
              <span className="muted" style={{ display: 'block' }}>
                {new Date(r.created_at).toLocaleString()} · {r.mode} ·{' '}
                {r.section_count} sections · {r.table_count} tables
              </span>
            </button>
            {r.report_filename && (
              <button
                className="ghost sm"
                title="Download .docx report"
                onClick={() => api.downloadReport(r.run_id)}
              >
                <Download size={14} /> .docx
              </button>
            )}
          </div>
        ))}
      </div>
      </div>
    </div>
  );
}

function ProgressStepper({
  stage,
  detail,
  elapsed,
  tokens,
}: {
  stage: string;
  detail: string;
  elapsed: number;
  tokens: TokenUsage | null;
}) {
  const idx = STAGES.findIndex((s) => s.key === stage);
  const queued = stage === 'queued';
  const activeIdx = queued ? -1 : idx < 0 ? 0 : idx;
  const pct = queued ? 0 : Math.round(((activeIdx + 1) / (STAGES.length + 1)) * 100);
  return (
    <div className="panel">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h3 style={{ margin: 0 }}>
          <span className="spinner" /> {queued ? 'Queued — waiting to start…' : 'Generating…'}
        </h3>
        <span className="muted">
          {tokens ? `${fmt(tokens.total.total)} tokens · ` : ''}
          {elapsed}s
        </span>
      </div>
      {queued && detail && <p className="muted">{detail}</p>}
      <div className="progress-bar" style={{ margin: '10px 0 14px' }}>
        <span style={{ width: `${pct}%` }} />
      </div>
      <div className="stepper">
        {STAGES.map((s, i) => {
          const st = tokens?.by_stage?.[s.key];
          return (
            <div
              key={s.key}
              className={`step ${i < activeIdx ? 'done' : i === activeIdx ? 'active' : ''}`}
            >
              <span className="dot" />
              <span>
                {s.label}
                {i === activeIdx && detail ? ` — ${detail}` : ''}
                {st && st.total > 0 ? (
                  <span className="muted"> · {fmt(st.total)} tokens</span>
                ) : null}
              </span>
            </div>
          );
        })}
      </div>
      {tokens && tokens.ocr.pages > 0 && (
        <p className="muted" style={{ marginTop: 10 }}>
          OCR: {fmt(tokens.ocr.pages)} pages · {fmt(tokens.ocr.requests)} requests
        </p>
      )}
    </div>
  );
}

function UploadPanel({ onUploaded }: { onUploaded: (tc: TestCase) => void }) {
  const [title, setTitle] = useState('');
  const [promptText, setPromptText] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const promptRef = useRef<HTMLInputElement>(null);
  const expectedRef = useRef<HTMLInputElement>(null);
  const inputsRef = useRef<HTMLInputElement>(null);

  async function submit() {
    setError('');
    const inputs = inputsRef.current?.files;
    if (!inputs || inputs.length === 0) {
      setError('Add at least one input file.');
      return;
    }
    const promptFile = promptRef.current?.files?.[0];
    if (!promptFile && !promptText.trim()) {
      setError('Provide a prompt file or type the prompt.');
      return;
    }

    const form = new FormData();
    form.append('title', title);
    form.append('prompt_text', promptText);
    if (promptFile) form.append('prompt_file', promptFile);
    const expectedFile = expectedRef.current?.files?.[0];
    if (expectedFile) form.append('expected_file', expectedFile);
    Array.from(inputs).forEach((f) => form.append('input_files', f));

    setBusy(true);
    try {
      const tc = await api.uploadTestCase(form);
      onUploaded(tc);
      setTitle('');
      setPromptText('');
      if (promptRef.current) promptRef.current.value = '';
      if (expectedRef.current) expectedRef.current.value = '';
      if (inputsRef.current) inputsRef.current.value = '';
    } catch {
      setError('Upload failed. Check the files and try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel">
      <h3 style={{ marginTop: 0 }}>Upload a test case</h3>
      <p className="muted">
        Attach input documents plus a prompt (file or text) and, optionally, an
        expected-output benchmark. It becomes a runnable test case above.
      </p>

      <div style={{ marginBottom: 10 }}>
        <label className="muted">Title</label>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="e.g. My integrity check"
          style={{ marginTop: 6, width: '100%' }}
        />
      </div>

      <div className="row" style={{ gap: 16, flexWrap: 'wrap' }}>
        <div>
          <label className="muted">Prompt file (.docx/.txt)</label>
          <input ref={promptRef} type="file" accept=".docx,.txt,.md" style={{ marginTop: 6 }} />
        </div>
        <div>
          <label className="muted">Expected output (optional)</label>
          <input ref={expectedRef} type="file" accept=".docx,.txt,.md" style={{ marginTop: 6 }} />
        </div>
        <div>
          <label className="muted">Input documents (multiple)</label>
          <input
            ref={inputsRef}
            type="file"
            multiple
            accept=".pdf,.docx,.xlsx,.pptx,.txt,.md,.csv"
            style={{ marginTop: 6 }}
          />
        </div>
      </div>

      <div style={{ marginTop: 10 }}>
        <label className="muted">…or paste prompt text</label>
        <textarea
          value={promptText}
          onChange={(e) => setPromptText(e.target.value)}
          rows={3}
          placeholder="Paste the auditor prompt here if you don't have a prompt file."
          style={{ marginTop: 6, width: '100%' }}
        />
      </div>

      {error && (
        <p className="badge high" style={{ marginTop: 10 }}>
          {error}
        </p>
      )}

      <div className="row" style={{ marginTop: 12 }}>
        <button onClick={submit} disabled={busy}>
          {busy ? <span className="spinner" /> : <Upload size={16} />} Create test
          case
        </button>
      </div>
    </div>
  );
}

function TokenSummary({ usage }: { usage: TokenUsage }) {
  const [open, setOpen] = useState(false);
  const stages = Object.entries(usage.by_stage).filter(([, c]) => c.total > 0);
  return (
    <div className="panel" style={{ marginTop: 12 }}>
      <div className="row" style={{ justifyContent: 'space-between', alignItems: 'center' }}>
        <strong>{fmt(usage.total.total)} tokens</strong>
        <span className="muted">
          {fmt(usage.total.prompt)} in · {fmt(usage.total.completion)} out
          {usage.ocr.pages > 0 ? ` · OCR ${fmt(usage.ocr.pages)} pages` : ''}
        </span>
        {stages.length > 0 && (
          <button className="ghost sm" onClick={() => setOpen((o) => !o)}>
            {open ? 'Hide' : 'Per-stage'} breakdown
          </button>
        )}
      </div>
      {open && stages.length > 0 && (
        <table className="data" style={{ marginTop: 8 }}>
          <thead>
            <tr>
              <th>Stage</th>
              <th>Prompt</th>
              <th>Completion</th>
              <th>Total</th>
            </tr>
          </thead>
          <tbody>
            {stages.map(([key, c]) => (
              <tr key={key}>
                <td>{stageLabel(key)}</td>
                <td>{fmt(c.prompt)}</td>
                <td>{fmt(c.completion)}</td>
                <td>{fmt(c.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

function RunView({
  run,
  regenerating,
  onRegenerate,
  onRunUpdated,
}: {
  run: GenerationRun;
  regenerating: boolean;
  onRegenerate: () => void;
  onRunUpdated: (run: GenerationRun) => void;
}) {
  const doc = run.document;
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState<GeneratedDocument>(doc);
  const [savingEdit, setSavingEdit] = useState(false);
  const [editError, setEditError] = useState('');
  const [chatMessage, setChatMessage] = useState('');
  const [chatBusy, setChatBusy] = useState(false);
  const [chatLog, setChatLog] = useState<{ role: 'user' | 'assistant'; text: string }[]>([]);

  useEffect(() => {
    setDraft(run.document);
    setEditing(false);
  }, [run.run_id, run.document]);

  function updateParagraph(sectionIdx: number, pIdx: number, value: string) {
    setDraft((d) => ({
      ...d,
      sections: d.sections.map((s, i) =>
        i === sectionIdx
          ? { ...s, paragraphs: s.paragraphs.map((p, j) => (j === pIdx ? value : p)) }
          : s
      ),
    }));
  }

  function updateCell(sectionIdx: number, tableIdx: number, rowIdx: number, colIdx: number, value: string) {
    setDraft((d) => ({
      ...d,
      sections: d.sections.map((s, i) => {
        if (i !== sectionIdx) return s;
        return {
          ...s,
          tables: s.tables.map((t, ti) => {
            if (ti !== tableIdx) return t;
            return {
              ...t,
              rows: t.rows.map((row, ri) =>
                ri === rowIdx ? row.map((c, ci) => (ci === colIdx ? value : c)) : row
              ),
            };
          }),
        };
      }),
    }));
  }

  async function saveEdit() {
    setSavingEdit(true);
    setEditError('');
    try {
      const updated = await api.updateDocument(run.run_id, draft);
      onRunUpdated(updated);
      setEditing(false);
    } catch {
      setEditError('Save failed. Please check your connection and try again.');
    } finally {
      setSavingEdit(false);
    }
  }

  async function sendChat() {
    const message = chatMessage.trim();
    if (!message || chatBusy) return;
    setChatMessage('');
    setChatLog((log) => [...log, { role: 'user', text: message }]);
    setChatBusy(true);
    try {
      const { reply, ...updatedRun } = await api.coauthor(run.run_id, message);
      onRunUpdated(updatedRun as GenerationRun);
      setChatLog((log) => [...log, { role: 'assistant', text: reply }]);
    } catch {
      setChatLog((log) => [
        ...log,
        { role: 'assistant', text: 'Sorry, that edit could not be applied. Please try again.' },
      ]);
    } finally {
      setChatBusy(false);
    }
  }

  return (
    <div className="panel">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <div>
          <h3 style={{ margin: 0 }}>{run.run_title || run.test_case_title}</h3>
          <p className="muted" style={{ margin: '6px 0 0' }}>{run.test_case_title}</p>
        </div>
        <div className="row" style={{ gap: 8 }}>
          {editing ? (
            <>
              <button className="ghost sm" onClick={() => setEditing(false)} disabled={savingEdit}>
                Cancel
              </button>
              <button onClick={saveEdit} disabled={savingEdit}>
                {savingEdit ? <span className="spinner" /> : null} Save changes
              </button>
            </>
          ) : (
            <button className="ghost sm" onClick={() => setEditing(true)}>
              Edit
            </button>
          )}
          <button className="ghost sm" onClick={onRegenerate} disabled={regenerating}>
            {regenerating ? <span className="spinner" /> : <RefreshCw size={14} />}{' '}
            Regenerate
          </button>
          <button onClick={() => api.downloadReport(run.run_id)}>
            <Download size={16} /> Download report (.docx)
          </button>
        </div>
      </div>
      {run.description && <p style={{ whiteSpace: 'pre-wrap' }}>{run.description}</p>}
      <p className="muted">
        Run ID: <code>{run.run_id}</code> · <span className={`mode-pill ${run.mode}`}>{run.mode}</span>{' '}
        · model {run.model} · prompt {run.prompt_version}
      </p>
      <p className="muted">
        Template: {run.use_expected_template ? 'yes' : 'no'} · Economy:{' '}
        {run.economy ? 'on' : 'off'} · Reasoning: {run.reasoning_effort || 'n/a'}
      </p>
      {reportParameters(run) && <p className="muted">{reportParameters(run)}</p>}
      {editError && <p className="badge high">{editError}</p>}

      {run.token_usage && <TokenSummary usage={run.token_usage} />}

      <div className="doc-preview">
        {doc.title && <h2 style={{ marginBottom: 4 }}>{doc.title}</h2>}
        {doc.subtitle && <p className="muted">{doc.subtitle}</p>}
        {(editing ? draft : doc).sections.map((s, i) => (
          <SectionView
            key={i}
            section={s}
            editable={editing}
            onParagraphChange={(pIdx, value) => updateParagraph(i, pIdx, value)}
            onCellChange={(tableIdx, rowIdx, colIdx, value) =>
              updateCell(i, tableIdx, rowIdx, colIdx, value)
            }
          />
        ))}
      </div>

      <div className="panel" style={{ marginTop: 12, background: 'var(--panel-2, #f7f7f8)' }}>
        <h4 style={{ marginTop: 0 }}>Co-author via chat</h4>
        <p className="muted">
          Ask for a targeted change (e.g. "fix the capex figure in section 3"). Only
          the section(s) affected will be updated.
        </p>
        {chatLog.length > 0 && (
          <div className="chat-log">
            {chatLog.map((m, i) => (
              <div key={i} className={`chat-msg ${m.role}`}>
                <strong>{m.role === 'user' ? 'You' : 'Co-author'}:</strong> {m.text}
              </div>
            ))}
          </div>
        )}
        <div className="row" style={{ marginTop: 8, gap: 8 }}>
          <input
            style={{ flex: 1 }}
            value={chatMessage}
            onChange={(e) => setChatMessage(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !chatBusy) sendChat();
            }}
            placeholder="Describe the change you want…"
            disabled={chatBusy}
          />
          <button onClick={sendChat} disabled={chatBusy || !chatMessage.trim()}>
            {chatBusy ? <span className="spinner" /> : null} Send
          </button>
        </div>
      </div>
    </div>
  );
}

function SectionView({
  section,
  editable,
  onParagraphChange,
  onCellChange,
}: {
  section: DocSection;
  editable?: boolean;
  onParagraphChange?: (pIndex: number, value: string) => void;
  onCellChange?: (tableIndex: number, rowIndex: number, colIndex: number, value: string) => void;
}) {
  const Heading = (`h${Math.min(4, section.level + 2)}` as unknown) as keyof JSX.IntrinsicElements;
  return (
    <div style={{ marginTop: 12 }}>
      <Heading>{section.heading}</Heading>
      {section.paragraphs.map((p, i) =>
        editable ? (
          <textarea
            key={i}
            className="edit-textarea"
            value={p}
            onChange={(e) => onParagraphChange?.(i, e.target.value)}
          />
        ) : (
          <p key={i}>{p}</p>
        )
      )}
      {section.tables.map((t, i) => (
        <div key={i}>
          {t.title && <p className="muted"><strong>{t.title}</strong></p>}
          {t.headers.length > 0 && (
            <table className="data" style={{ marginTop: 6 }}>
              <thead>
                <tr>
                  {t.headers.map((h, j) => (
                    <th key={j}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {t.rows.map((row, r) => (
                  <tr key={r}>
                    {row.map((c, k) =>
                      editable ? (
                        <td key={k}>
                          <input
                            className="edit-input"
                            value={c}
                            onChange={(e) => onCellChange?.(i, r, k, e.target.value)}
                          />
                        </td>
                      ) : (
                        <td key={k}>{c}</td>
                      )
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      ))}
    </div>
  );
}
