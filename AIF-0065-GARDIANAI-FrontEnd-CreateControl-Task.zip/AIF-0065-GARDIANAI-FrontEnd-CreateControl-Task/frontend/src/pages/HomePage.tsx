import { Button, Card, Col, Row, Table } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

import { LinkButton } from '../components/common/LinkButton';
import { EmptyState } from '../components/common/Feedback';
import { StatusBadge } from '../components/common/StatusBadge';
import { useRunBatches } from '../hooks/useRunBatches';
import { useTasks } from '../hooks/useTasks';
import { PageContainer } from '../layouts/MainLayout';
import { batchStatus, batchSummary, countByStatus, formatDateTime } from '../utils/format';

function StatCard({ tone, icon, value, label }: { tone: string; icon: string; value: number | string; label: string }) {
    return (
        <Card className={`stat-card ${tone} h-100`}>
            <Card.Body className="d-flex align-items-center gap-3">
                <i className={`bi ${icon} fs-3`} aria-hidden="true" />
                <div>
                    <div className="stat-value">{value}</div>
                    <div>{label}</div>
                </div>
            </Card.Body>
        </Card>
    );
}

export default function HomePage() {
    const navigate = useNavigate();
    const batches = useRunBatches();
    const tasks = useTasks();
    const items = batches.flatMap((b) => b.items);
    const counts = countByStatus(items);
    const recent = batches.slice(0, 5);

    return (
        <>
            <section className="hero">
                <PageContainer>
                    <h1 className="page-title mb-1">Welcome to GARdian.AI</h1>
                    <p className="mb-4">Generate, review and refine your regulatory and assurance reports using AI Agents.</p>
                    <Row className="g-3">
                        <Col xs={6} lg={3}>
                            <StatCard tone="stat-blue" icon="bi-sliders" value={tasks.data?.length ?? '–'} label="Controls" />
                        </Col>
                        <Col xs={6} lg={3}>
                            <StatCard tone="stat-amber" icon="bi-file-earmark-text" value={batches.length} label="Recent Runs" />
                        </Col>
                        <Col xs={6} lg={3}>
                            <StatCard tone="stat-green" icon="bi-patch-check" value={counts.completed} label="Completed" />
                        </Col>
                        <Col xs={6} lg={3}>
                            <StatCard tone="stat-red" icon="bi-slash-circle" value={counts.failed} label="Failed" />
                        </Col>
                    </Row>
                </PageContainer>
            </section>

            <PageContainer>
                <Row className="g-4">
                    <Col lg={3}>
                        <Card>
                            <Card.Body>
                                <h2 className="h6 fw-bold mb-3">Quick Actions</h2>
                                <Button className="w-100 text-start mb-2 py-3" onClick={() => navigate('/runs/new')}>
                                    <i className="bi bi-plus-circle fs-5 me-2" aria-hidden="true" />
                                    <span className="fw-bold">Create New Run</span>
                                    <div className="small fw-normal">Generate a new report</div>
                                </Button>
                                <Button variant="outline-secondary" className="w-100 text-start mb-2" onClick={() => navigate('/run-monitor')}>
                                    <i className="bi bi-clipboard-data me-2" aria-hidden="true" />
                                    <strong>Run Monitor</strong>
                                    <div className="small">View past runs and reports</div>
                                </Button>
                                <Button variant="outline-secondary" className="w-100 text-start" onClick={() => navigate('/controls')}>
                                    <i className="bi bi-clipboard-check me-2" aria-hidden="true" />
                                    <strong>Control Library</strong>
                                    <div className="small">Create a new task</div>
                                </Button>
                            </Card.Body>
                        </Card>
                    </Col>
                    <Col lg={9}>
                        <Card>
                            <Card.Body>
                                <h2 className="h5 fw-bold mb-3">Recent Runs</h2>
                                {recent.length === 0 ? (
                                    <EmptyState
                                        icon="bi-clock-history"
                                        title="No runs yet"
                                        action={
                                            <LinkButton to="/runs/new">Create New Run</LinkButton>
                                        }
                                    >
                                        Runs you start will appear here.
                                    </EmptyState>
                                ) : (
                                    <Table responsive hover className="table-gar mb-0">
                                        <thead>
                                            <tr>
                                                <th>Run Title</th>
                                                <th>Reporting Period</th>
                                                <th>Control/Task</th>
                                                <th>Created On</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {recent.map((b) => (
                                                <tr key={b.id}>
                                                    <td>{b.title}</td>
                                                    <td>{b.period}</td>
                                                    <td>{b.items.length}</td>
                                                    <td className="text-nowrap">{formatDateTime(b.createdAt)}</td>
                                                    <td>
                                                        <StatusBadge status={batchStatus(b)} label={batchSummary(b)} />
                                                    </td>
                                                    <td>
                                                        <LinkButton to={`/runs/${b.id}`} size="sm" variant="outline-primary">
                                                            <i className="bi bi-eye me-1" aria-hidden="true" />
                                                            View Result
                                                        </LinkButton>
                                                    </td>
                                                </tr>
                                            ))}
                                        </tbody>
                                    </Table>
                                )}
                            </Card.Body>
                        </Card>
                    </Col>
                </Row>
            </PageContainer>
        </>
    );
}
