import { Fragment, useMemo, useState } from 'react';
import { Button, Card, Col, Form, Row, Table } from 'react-bootstrap';
import { Link } from 'react-router-dom';

import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { LinkButton } from '../components/common/LinkButton';
import { EmptyState } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { SearchInput } from '../components/common/SearchInput';
import { SortableTh } from '../components/common/SortableTh';
import { StatusBadge } from '../components/common/StatusBadge';
import { TablePagination } from '../components/common/TablePagination';
import { useToast } from '../contexts/ToastContext';
import { useRunBatches } from '../hooks/useRunBatches';
import { usePagination, useSort } from '../hooks/useTable';
import { useTasks } from '../hooks/useTasks';
import { PageContainer } from '../layouts/MainLayout';
import { runBatchStore } from '../services/runBatchStore';
import type { RunBatch, RunItemStatus } from '../types/run';
import { batchStatus, batchSummary, formatDateTime } from '../utils/format';

type SortKey = 'title' | 'items' | 'createdAt';

const EMPTY_FILTERS = { search: '', taskId: '', status: '' as '' | RunItemStatus, from: '', to: '' };

export default function RunHistoryPage() {
    const batches = useRunBatches();
    const tasks = useTasks();
    const { notify } = useToast();
    const [filters, setFilters] = useState(EMPTY_FILTERS);
    const [expanded, setExpanded] = useState<Set<string>>(new Set());
    const [toDelete, setToDelete] = useState<RunBatch | null>(null);
    const sort = useSort<SortKey>('createdAt', 'desc');

    const filtered = useMemo(() => {
        const q = filters.search.trim().toLowerCase();
        const from = filters.from ? new Date(`${filters.from}T00:00:00`).getTime() : null;
        const to = filters.to ? new Date(`${filters.to}T23:59:59`).getTime() : null;
        const list = batches.filter((b) => {
            const created = new Date(b.createdAt).getTime();
            return (
                (!q || b.title.toLowerCase().includes(q) || b.id.toLowerCase().includes(q) || b.items.some((i) => i.taskTitle.toLowerCase().includes(q))) &&
                (!filters.taskId || b.items.some((i) => i.taskId === filters.taskId)) &&
                (!filters.status || b.items.some((i) => i.status === filters.status)) &&
                (from === null || created >= from) &&
                (to === null || created <= to)
            );
        });
        const dir = sort.dir === 'asc' ? 1 : -1;
        return [...list].sort((a, b) => {
            if (sort.key === 'title') return a.title.localeCompare(b.title) * dir;
            if (sort.key === 'items') return (a.items.length - b.items.length) * dir;
            return (new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()) * dir;
        });
    }, [batches, filters, sort.key, sort.dir]);

    const pager = usePagination(filtered, 10);

    const setFilter = <K extends keyof typeof EMPTY_FILTERS>(key: K, value: (typeof EMPTY_FILTERS)[K]) => {
        setFilters((f) => ({ ...f, [key]: value }));
        pager.setPage(1);
    };

    const toggle = (id: string) =>
        setExpanded((prev) => {
            const next = new Set(prev);
            if (next.has(id)) next.delete(id);
            else next.add(id);
            return next;
        });

    const hasFilters = JSON.stringify(filters) !== JSON.stringify(EMPTY_FILTERS);

    return (
        <PageContainer>
            <PageHeader
                title="Run Monitor - Overview"
                subtitle="View all previously generated reports, their status and actions."
                actions={
                    <LinkButton to="/runs/new">
                        <i className="bi bi-plus-circle me-2" aria-hidden="true" />
                        Create New Run
                    </LinkButton>
                }
            />

            <Card className="mb-4">
                <Card.Body>
                    <Row className="g-3 align-items-end">
                        <Col md={6} lg={3}>
                            <Form.Label className="fw-semibold">Search</Form.Label>
                            <SearchInput value={filters.search} onChange={(v) => setFilter('search', v)} placeholder="Search by run title, control…" />
                        </Col>
                        <Col sm={6} md={3} lg={2}>
                            <Form.Label htmlFor="f-control" className="fw-semibold">Control</Form.Label>
                            <Form.Select id="f-control" value={filters.taskId} onChange={(e) => setFilter('taskId', e.target.value)}>
                                <option value="">All Controls</option>
                                {tasks.data?.map((t) => (
                                    <option key={t.id} value={t.id}>
                                        {t.title}
                                    </option>
                                ))}
                            </Form.Select>
                        </Col>
                        <Col sm={6} md={3} lg={2}>
                            <Form.Label htmlFor="f-status" className="fw-semibold">Status</Form.Label>
                            <Form.Select id="f-status" value={filters.status} onChange={(e) => setFilter('status', e.target.value as '' | RunItemStatus)}>
                                <option value="">All Status</option>
                                <option value="completed">Completed</option>
                                <option value="failed">Failed</option>
                                <option value="running">Running</option>
                            </Form.Select>
                        </Col>
                        <Col sm={6} md={4} lg={2}>
                            <Form.Label htmlFor="f-from" className="fw-semibold">From</Form.Label>
                            <Form.Control id="f-from" type="date" value={filters.from} max={filters.to || undefined} onChange={(e) => setFilter('from', e.target.value)} />
                        </Col>
                        <Col sm={6} md={4} lg={2}>
                            <Form.Label htmlFor="f-to" className="fw-semibold">To</Form.Label>
                            <Form.Control id="f-to" type="date" value={filters.to} min={filters.from || undefined} onChange={(e) => setFilter('to', e.target.value)} />
                        </Col>
                        <Col xs="auto">
                            <Button variant="link" className="text-danger text-decoration-none" disabled={!hasFilters} onClick={() => setFilters(EMPTY_FILTERS)}>
                                <i className="bi bi-arrow-counterclockwise me-1" aria-hidden="true" />
                                Clear Filters
                            </Button>
                        </Col>
                    </Row>
                </Card.Body>
            </Card>

            <Card>
                <Card.Body>
                    {pager.total === 0 ? (
                        <EmptyState icon="bi-clock-history" title={hasFilters ? 'No runs match your filters' : 'No runs yet'}>
                            {hasFilters ? 'Adjust or clear the filters.' : 'Start a new run to see it here.'}
                        </EmptyState>
                    ) : (
                        <>
                            <Table responsive className="table-gar mb-0">
                                <thead>
                                    <tr>
                                        <th style={{ width: '3rem' }}>#</th>
                                        <SortableTh sortKey="title" activeKey={sort.key} dir={sort.dir} onSort={sort.toggle}>Run Title</SortableTh>
                                        <SortableTh sortKey="items" activeKey={sort.key} dir={sort.dir} onSort={sort.toggle}>Control</SortableTh>
                                        <SortableTh sortKey="createdAt" activeKey={sort.key} dir={sort.dir} onSort={sort.toggle}>Started On</SortableTh>
                                        <th>Status</th>
                                        <th aria-label="Actions" />
                                    </tr>
                                </thead>
                                <tbody>
                                    {pager.pageItems.map((b, idx) => {
                                        const open = expanded.has(b.id);
                                        return (
                                            <Fragment key={b.id}>
                                                <tr>
                                                    <td className="text-nowrap">
                                                        <Button
                                                            variant="link"
                                                            size="sm"
                                                            className="p-0 me-2 text-body"
                                                            aria-expanded={open}
                                                            aria-label={`${open ? 'Collapse' : 'Expand'} ${b.title}`}
                                                            onClick={() => toggle(b.id)}
                                                        >
                                                            <i className={`bi ${open ? 'bi-chevron-down' : 'bi-chevron-right'}`} aria-hidden="true" />
                                                        </Button>
                                                        {(pager.page - 1) * pager.pageSize + idx + 1}
                                                    </td>
                                                    <td>
                                                        <Link to={`/runs/${b.id}`}>{b.title}</Link>
                                                        <div className="small text-secondary">{b.id} · {b.period}</div>
                                                    </td>
                                                    <td>{b.items.length} Controls</td>
                                                    <td className="text-nowrap">{formatDateTime(b.createdAt)}</td>
                                                    <td>
                                                        <StatusBadge status={batchStatus(b)} label={batchSummary(b)} />
                                                    </td>
                                                    <td className="text-end">
                                                        <Button variant="link" className="text-danger" aria-label={`Remove ${b.title}`} onClick={() => setToDelete(b)}>
                                                            <i className="bi bi-trash" aria-hidden="true" />
                                                        </Button>
                                                    </td>
                                                </tr>
                                                {open && (
                                                    <tr>
                                                        <td colSpan={6} className="bg-body-tertiary">
                                                            <Table bordered size="sm" responsive className="mb-0 bg-body">
                                                                <thead>
                                                                    <tr>
                                                                        <th>#</th>
                                                                        <th>Controls</th>
                                                                        <th>Started On</th>
                                                                        <th>Status</th>
                                                                        <th>Actions</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    {b.items.map((i, n) => (
                                                                        <tr key={i.taskId}>
                                                                            <td>{n + 1}</td>
                                                                            <td>{i.taskTitle}</td>
                                                                            <td className="text-nowrap">{formatDateTime(i.startedAt)}</td>
                                                                            <td>
                                                                                <StatusBadge status={i.status} />
                                                                            </td>
                                                                            <td>
                                                                                {i.status === 'completed' && i.runId ? (
                                                                                    <LinkButton to={`/runs/${b.id}/controls/${i.taskId}`} size="sm" variant="outline-primary">
                                                                                        <i className="bi bi-eye me-1" aria-hidden="true" />
                                                                                        View
                                                                                    </LinkButton>
                                                                                ) : (
                                                                                    <span className="text-secondary">—</span>
                                                                                )}
                                                                            </td>
                                                                        </tr>
                                                                    ))}
                                                                </tbody>
                                                            </Table>
                                                        </td>
                                                    </tr>
                                                )}
                                            </Fragment>
                                        );
                                    })}
                                </tbody>
                            </Table>
                            <TablePagination {...pager} onChange={pager.setPage} />
                        </>
                    )}
                </Card.Body>
            </Card>

            <ConfirmDialog
                show={toDelete !== null}
                title="Remove run from history"
                confirmLabel="Remove"
                onCancel={() => setToDelete(null)}
                onConfirm={() => {
                    if (toDelete) {
                        runBatchStore.remove(toDelete.id);
                        notify('success', 'Run removed', toDelete.title);
                    }
                    setToDelete(null);
                }}
            >
                Remove <strong>{toDelete?.title}</strong> from this browser's history? Generated reports on the server are not deleted.
            </ConfirmDialog>
        </PageContainer>
    );
}
