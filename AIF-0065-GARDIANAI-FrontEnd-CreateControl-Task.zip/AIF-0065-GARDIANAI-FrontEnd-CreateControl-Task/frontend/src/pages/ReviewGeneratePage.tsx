import { useState } from 'react';
import { Alert, Button, Spinner, Table } from 'react-bootstrap';
import { Navigate, useNavigate } from 'react-router-dom';

import { LoadingSpinner } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { OutputDestinationCard, SectionCard } from '../components/runs/Sections';
import { useRunDraft } from '../contexts/RunDraftContext';
import { useToast } from '../contexts/ToastContext';
import { useCurrentUser } from '../hooks/useCurrentUser';
import { executeBatch } from '../hooks/useRunBatches';
import { useTaskOptions, useTasks } from '../hooks/useTasks';
import { PageContainer } from '../layouts/MainLayout';
import { toApiError } from '../utils/errors';
import { missingRoles, roleFileMap } from '../utils/roles';

export default function ReviewGeneratePage() {
    const { draft, setDraft } = useRunDraft();
    const navigate = useNavigate();
    const { notify } = useToast();
    const user = useCurrentUser();
    const tasks = useTasks();
    const options = useTaskOptions(draft?.period);
    const [executing, setExecuting] = useState(false);

    if (!draft) return <Navigate to="/runs/new" replace />;
    if (tasks.isLoading) return <LoadingSpinner />;

    const selected = (tasks.data ?? []).filter((t) => draft.taskIds.includes(t.id));
    const roleFiles = roleFileMap(options.data);
    const withGaps = selected
        .map((t) => ({ title: t.title, missing: missingRoles(t.logical_source_role_names, options.data) }))
        .filter((x) => x.missing.length > 0);

    const execute = async () => {
        setExecuting(true);
        try {
            const batch = await executeBatch(
                { title: draft.title, period: draft.period, description: draft.description, createdBy: user },
                selected.map((t) => ({ taskId: t.id, taskTitle: t.title, roles: t.logical_source_role_names })),
                draft.maxParallelCases,
                (message) => notify('info', 'Waiting to start batch', message)
            );
            setDraft(null);
            notify('info', 'Run started', `${batch.id} · ${selected.length} control(s)`);
            navigate(`/runs/${batch.id}`, { replace: true });
        } catch (error) {
            notify('danger', 'Could not start run', toApiError(error).message);
            setExecuting(false);
        }
    };

    return (
        <PageContainer>
            <div className="run-review-page">
                <PageHeader title="Review & Generate" subtitle="Confirm run details and start execution for all selected controls." />

                <SectionCard title="Run Details">
                    <Table bordered responsive className="run-review-details mb-0">
                        <tbody>
                            <tr>
                                <th scope="row" className="label-cell">Run Title</th>
                                <td>{draft.title}</td>
                                <th scope="row" className="label-cell">Run ID</th>
                                <td className="text-secondary">(Generate when execution starts)</td>
                            </tr>
                            <tr>
                                <th scope="row" className="label-cell">Reporting Period</th>
                                <td>{draft.period}</td>
                                <th scope="row" className="label-cell">Batch Run</th>
                                <td>{draft.maxParallelCases === 1 ? 'Sequential' : `${draft.maxParallelCases} Parallel Execute`}</td>
                            </tr>
                            <tr>
                                <th scope="row" className="label-cell">Description</th>
                                <td colSpan={3}>{draft.description || '—'}</td>
                            </tr>
                        </tbody>
                    </Table>
                </SectionCard>

                <SectionCard title={`Selected Controls (${selected.length})`}>
                    <Table bordered responsive className="table-gar run-selected-controls mb-0">
                        <thead>
                            <tr>
                                <th className="run-control-number">#</th>
                                <th style={{ width: '30%' }}>Control / Task</th>
                                <th style={{ width: '22%' }}>Prompt</th>
                                <th>Source Roles &amp; Documents</th>
                            </tr>
                        </thead>
                        <tbody>
                            {selected.map((t, i) => (
                                <tr key={t.id}>
                                    <td className="run-control-number">{String(i + 1).padStart(2, '0')}</td>
                                    <td>
                                        <div className="run-control-title">{t.title}</div>
                                        {t.description && <small className="run-control-description">{t.description}</small>}
                                    </td>
                                    <td>
                                        <span className="run-prompt-name">
                                            <i className="bi bi-chat-square-text me-1" aria-hidden="true" />
                                            {t.prompt_name}
                                        </span>
                                    </td>
                                    <td>
                                        {t.logical_source_role_names.map((r) => {
                                            const file = roleFiles.get(r);
                                            return (
                                                <div key={r} className="run-review-source-item">
                                                    <span className="role-chip">{r}</span>
                                                    {file?.file_name ? (
                                                        <small className="run-review-source-file text-secondary">
                                                            <i className="bi bi-file-earmark me-1" aria-hidden="true" />
                                                            {file.file_name}
                                                        </small>
                                                    ) : file ? (
                                                        <small className="run-review-source-file text-danger">
                                                            <i className="bi bi-exclamation-triangle me-1" aria-hidden="true" />
                                                            No file for {draft.period}
                                                        </small>
                                                    ) : (
                                                        <small className="run-review-source-file text-secondary">
                                                            {options.isFetching ? 'Resolving file…' : 'File details unavailable'}
                                                        </small>
                                                    )}
                                                </div>
                                            );
                                        })}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </SectionCard>

                {options.error && (
                    <Alert variant="warning">Could not verify source files for {draft.period}. The run may still be attempted.</Alert>
                )}
                {withGaps.length > 0 && (
                    <Alert variant="warning">
                        <strong>Missing source files for {draft.period}.</strong> These controls may fail:
                        <ul className="mb-0">
                            {withGaps.map((g) => (
                                <li key={g.title}>
                                    {g.title}: {g.missing.join(', ')}
                                </li>
                            ))}
                        </ul>
                    </Alert>
                )}

                <OutputDestinationCard runTitle={draft.title} />

                <div className="info-banner mb-4">
                    <i className="bi bi-info-circle me-2" aria-hidden="true" />
                    All selected controls will be executed as part of a single run, using the selected {draft.maxParallelCases === 1 ? 'sequential' : `${draft.maxParallelCases}-parallel`} batch setting. Source files are resolved for the reporting period, and outputs are saved to the configured SharePoint destination.
                </div>

                <div className="d-flex justify-content-between">
                    <Button variant="outline-secondary" onClick={() => navigate('/runs/new')} disabled={executing}>
                        <i className="bi bi-arrow-left me-2" aria-hidden="true" />
                        Back
                    </Button>
                    <Button onClick={() => void execute()} disabled={executing || selected.length === 0}>
                        {executing ? <Spinner size="sm" className="me-2" /> : <i className="bi bi-play me-2" aria-hidden="true" />}
                        Execute Run ({selected.length} Controls)
                    </Button>
                </div>
            </div>
        </PageContainer>
    );
}
