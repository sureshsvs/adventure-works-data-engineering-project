import { useState } from 'react';
import { Alert, Col, Row } from 'react-bootstrap';
import { useNavigate, useParams } from 'react-router-dom';

import { LinkButton } from '../components/common/LinkButton';
import { EmptyState } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { StatusBadge } from '../components/common/StatusBadge';
import { CurrentStageCard, RunControlsTable } from '../components/runs/RunControlsTable';
import { KeyValueTable, OutputDestinationCard, SectionCard } from '../components/runs/Sections';
import { useToast } from '../contexts/ToastContext';
import { retryItem, useRunBatch } from '../hooks/useRunBatches';
import { PageContainer } from '../layouts/MainLayout';
import { outputConfig } from '../utils/output';
import { batchStatus, batchSummary, formatDateTime } from '../utils/format';
import type { RunItem } from '../types/run';

export default function RunProgressPage() {
    const { batchId } = useParams<{ batchId: string }>();
    const navigate = useNavigate();
    const batch = useRunBatch(batchId);
    const { notify } = useToast();
    const [retrying, setRetrying] = useState<string | null>(null);

    if (!batch) {
        return (
            <PageContainer>
                <EmptyState
                    icon="bi-question-circle"
                    title="Run not found"
                    action={<LinkButton to="/run-monitor">Go to Run Monitor</LinkButton>}
                >
                    This run is not stored in this browser.
                </EmptyState>
            </PageContainer>
        );
    }

    const status = batchStatus(batch);
    const inProgress = status === 'running';

    const onRetry = async (item: RunItem) => {
        setRetrying(item.taskId);
        try {
            const retryBatch = await retryItem(batch, item);
            notify('info', 'Retry batch started', item.taskTitle);
            navigate(`/runs/${retryBatch.id}`);
        } catch (error) {
            notify('danger', 'Could not retry control', error instanceof Error ? error.message : 'Unexpected error');
        } finally {
            setRetrying(null);
        }
    };

    return (
        <PageContainer>
            <div className="run-progress-page">
                <PageHeader
                    title={inProgress ? 'Run in Progress' : 'Run Results'}
                    subtitle="Selected controls run sequentially or in parallel according to the batch setting."
                />

                <SectionCard title="Job Details">
                    <Row className="g-3">
                        <Col lg={inProgress ? 7 : 12}>
                            <KeyValueTable
                                rows={[
                                    ['Run Title', batch.title],
                                    ['Run ID', batch.id],
                                    ['Reporting Period', batch.period],
                                    [
                                        'Batch Run',
                                        batch.maxParallelCases === undefined
                                            ? '—'
                                            : batch.maxParallelCases === 1
                                                ? 'Sequential'
                                                : `${batch.maxParallelCases} Parallel Execute`,
                                    ],
                                    ['Started At', formatDateTime(batch.createdAt)],
                                    ['Status', <StatusBadge status={status} label={batchSummary(batch)} />],
                                    ['Description', batch.description || '—'],
                                ]}
                            />
                        </Col>
                        {inProgress && (
                            <Col lg={5}>
                                <CurrentStageCard batch={batch} />
                            </Col>
                        )}
                    </Row>
                </SectionCard>

                <SectionCard title={`Controls in this Run (${batch.items.length})`}>
                    {batch.items.some((i) => i.status === 'failed') && (
                        <Alert variant="warning" className="py-2">
                            Some controls failed. Hover over “Needs Attention” for the reason, or retry the control.
                        </Alert>
                    )}
                    <RunControlsTable batch={batch} onRetry={(i) => void onRetry(i)} retrying={retrying} />
                </SectionCard>

                {!inProgress && (
                    <OutputDestinationCard
                        runTitle={batch.title}
                        runCode={batch.id}
                        action={
                            outputConfig.url ? (
                                <a href={outputConfig.url} target="_blank" rel="noopener noreferrer" className="fw-semibold small">
                                    <i className="bi bi-box-arrow-up-right me-1" aria-hidden="true" />
                                    Open in SharePoint
                                </a>
                            ) : undefined
                        }
                    />
                )}
            </div>
        </PageContainer>
    );
}
