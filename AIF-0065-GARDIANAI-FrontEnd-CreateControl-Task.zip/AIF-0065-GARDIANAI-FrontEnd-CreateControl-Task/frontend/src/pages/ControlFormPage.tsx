import { useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';

import { ControlForm } from '../components/tasks/ControlForm';
import { ErrorAlert, LoadingSpinner } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { useToast } from '../contexts/ToastContext';
import { useCurrentUser } from '../hooks/useCurrentUser';
import { usePeriods, useSaveTask, useTask, useTaskOptions } from '../hooks/useTasks';
import { PageContainer } from '../layouts/MainLayout';
import type { TaskPayload } from '../types/api';
import { toApiError } from '../utils/errors';

export default function ControlFormPage() {
    const { id } = useParams<{ id: string }>();
    const isEdit = Boolean(id);
    const navigate = useNavigate();
    const { notify } = useToast();
    const user = useCurrentUser();
    const periods = usePeriods();
    const [selectedPeriod, setSelectedPeriod] = useState('');
    // Periods are returned newest first; default to the latest.
    const period = selectedPeriod || periods.data?.[0] || '';
    const options = useTaskOptions(period || undefined);
    const task = useTask(id);
    const save = useSaveTask(id);

    const onSubmit = (payload: TaskPayload) => {
        const body = isEdit ? { ...payload, modified_by: user } : { ...payload, created_by: user };
        save.mutate(body, {
            onSuccess: (saved) => {
                notify('success', isEdit ? 'Control updated' : 'Control created', saved.title);
                navigate('/controls');
            },
            onError: (e) => {
                const err = toApiError(e);
                if (err.status !== 409 && Object.keys(err.fieldErrors).length === 0) notify('danger', 'Save failed', err.message);
            },
        });
    };

    const loading = periods.isLoading || options.isLoading || (isEdit && task.isLoading);
    const error = options.error ?? (isEdit ? task.error : null);

    return (
        <PageContainer>
            <PageHeader
                title={isEdit ? 'Edit Control / Task' : 'Create New Control / Task'}
                subtitle={isEdit ? "Edit the control details to update the reusable check." : "Define the control details to create a reusable check."}
                crumbs={[
                    { label: 'Controls Library', to: '/controls' },
                    { label: isEdit ? 'Edit Control/Task' : 'Create New Control/Task' },
                ]}
            />
            {loading && <LoadingSpinner />}
            {error && <ErrorAlert error={error} />}
            {options.data && (!isEdit || task.data) && (
                <ControlForm
                    task={task.data}
                    options={options.data}
                    periods={periods.data ?? []}
                    period={period}
                    loadingRoleFiles={options.isFetching}
                    onPeriodChange={setSelectedPeriod}
                    submitting={save.isPending}
                    submitError={save.error ? toApiError(save.error) : null}
                    submitLabel={isEdit ? 'Update' : 'Save'}
                    onSubmit={onSubmit}
                    onCancel={() => navigate('/controls')}
                />
            )}
        </PageContainer>
    );
}
