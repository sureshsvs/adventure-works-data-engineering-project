import { useEffect, useState } from 'react';
import { Save } from 'lucide-react';

import { api } from '../services/api';
import type { PromptEntry } from '../types';

export default function PromptLibraryPage() {
  const [prompts, setPrompts] = useState<PromptEntry[]>([]);
  const [selected, setSelected] = useState<PromptEntry | null>(null);
  const [draft, setDraft] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    api.listPrompts().then((p) => {
      setPrompts(p);
      if (p[0]) select(p[0]);
    });
  }, []);

  function select(entry: PromptEntry) {
    setSelected(entry);
    setDraft(entry.prompt);
    setSaved(false);
  }

  async function save() {
    if (!selected) return;
    setSaving(true);
    try {
      const updated = await api.updatePrompt(selected.id, draft);
      setPrompts((prev) => prev.map((p) => (p.id === updated.id ? updated : p)));
      setSelected(updated);
      setSaved(true);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div>
      <div className="page-head">
        <h1>Prompt Library</h1>
        <p>
          Versioned, superuser-maintainable control prompts. Every save bumps the
          version, which each SuperAgent run records for auditability.
        </p>
      </div>

      <div className="grid-2">
        <div className="panel">
          <h3 style={{ marginTop: 0 }}>Controls</h3>
          {prompts.map((p) => (
            <button
              key={p.id}
              className={`list-btn ${selected?.id === p.id ? 'selected' : ''}`}
              onClick={() => select(p)}
            >
              <strong>{p.title}</strong>
              <span className="muted">
                {'  '}
                {p.id} · v{p.version} · {p.controls.length} controls
              </span>
            </button>
          ))}
        </div>

        <div className="panel">
          {selected && (
            <>
              <div className="row" style={{ justifyContent: 'space-between' }}>
                <h3 style={{ margin: 0 }}>{selected.title}</h3>
                <span className="mode-pill">
                  v{selected.version} · updated by {selected.updated_by}
                </span>
              </div>
              <label className="muted">Auditor prompt</label>
              <textarea
                value={draft}
                onChange={(e) => {
                  setDraft(e.target.value);
                  setSaved(false);
                }}
                style={{ marginTop: 6 }}
              />
              <div className="row" style={{ marginTop: 10, alignItems: 'center' }}>
                <button onClick={save} disabled={saving || draft === selected.prompt}>
                  {saving ? <span className="spinner" /> : <Save size={16} />} Save new
                  version
                </button>
                {saved && <span className="muted">Saved ✓</span>}
              </div>

              <h4>Controls executed</h4>
              <table className="data">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Description</th>
                  </tr>
                </thead>
                <tbody>
                  {selected.controls.map((c) => (
                    <tr key={c.control_id}>
                      <td>{c.control_id}</td>
                      <td>{c.name}</td>
                      <td className="muted">{c.description}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
