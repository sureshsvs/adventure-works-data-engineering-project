import { useEffect, useRef, useState } from 'react';
import { isAxiosError } from 'axios';

import { api } from '../services/api';
import { prepareAndAdmitTaskBatch, TaskPreparationError } from '../services/taskBatchAdmission';
import type { Task, TaskBatch, TaskValidationError } from '../types';

const terminalStatuses = new Set(['completed', 'completed_with_errors', 'failed', 'error', 'cancelled', 'canceled', 'done']);
const isActive = (batch: TaskBatch) => !batch.done && !terminalStatuses.has(batch.status);
const detailText = (detail: unknown) =>
  typeof detail === 'string' ? detail : JSON.stringify(detail) ?? String(detail);

function requestError(error: unknown, fallback: string): string {
  if (isAxiosError(error) && error.response?.data?.detail != null) {
    return detailText(error.response.data.detail);
  }
  return error instanceof Error && !isAxiosError(error) ? error.message : fallback;
}

function validationErrors(error: unknown): TaskValidationError[] {
  if (!isAxiosError(error)) return [];
  const errors: unknown = error.response?.data?.detail?.errors;
  if (!Array.isArray(errors)) return [];
  return errors.flatMap((item) =>
    item && typeof item.task_id === 'string'
      ? [{ task_id: item.task_id, detail: detailText(item.detail) }]
      : [],
  );
}

export default function TaskBatchPanel({ onOpenRun }: { onOpenRun: (id: string) => Promise<void> }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [tasksLoading, setTasksLoading] = useState(true);
  const [tasksError, setTasksError] = useState('');
  const [selected, setSelected] = useState<string[]>([]);
  const [runTitle, setRunTitle] = useState('');
  const [description, setDescription] = useState('');
  const [period, setPeriod] = useState('');
  const [grouping, setGrouping] = useState('');
  const [parallel, setParallel] = useState<1 | 2 | 3 | 4>(1);
  const [economy, setEconomy] = useState(false);
  const [useTemplate, setUseTemplate] = useState(false);
  const [reasoning, setReasoning] = useState<'high' | 'medium' | 'low'>('high');
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [errors, setErrors] = useState<TaskValidationError[]>([]);
  const [batches, setBatches] = useState<TaskBatch[]>([]);
  const [selectedBatchId, setSelectedBatchId] = useState('');
  const [historyLoading, setHistoryLoading] = useState(true);
  const [historyError, setHistoryError] = useState('');
  const [pollError, setPollError] = useState('');
  const [reload, setReload] = useState(0);
  const submissionLock = useRef(false);
  const submissionController = useRef<AbortController | null>(null);

  useEffect(() => () => submissionController.current?.abort(), []);

  useEffect(() => {
    const controller = new AbortController();
    setTasksLoading(true);
    setTasksError('');
    api.listTasks(controller.signal).then((result) => {
      if (!controller.signal.aborted) setTasks(result);
    }).catch((failure) => {
      if (!controller.signal.aborted) setTasksError(requestError(failure, 'Could not load tasks.'));
    }).finally(() => {
      if (!controller.signal.aborted) setTasksLoading(false);
    });
    return () => controller.abort();
  }, [reload]);

  useEffect(() => {
    const controller = new AbortController();
    setHistoryLoading(true);
    setHistoryError('');
    api.listTaskBatches(controller.signal).then((records) => {
      if (controller.signal.aborted) return;
      const sorted = [...records].sort((a, b) => b.created_at.localeCompare(a.created_at));
      setBatches((current) => [
        ...sorted,
        ...current.filter((batch) => !records.some((record) => record.batch_id === batch.batch_id)),
      ]);
      setSelectedBatchId((id) => id || sorted.find(isActive)?.batch_id || sorted[0]?.batch_id || '');
    }).catch((failure) => {
      if (!controller.signal.aborted) setHistoryError(requestError(failure, 'Could not load batch history.'));
    }).finally(() => {
      if (!controller.signal.aborted) setHistoryLoading(false);
    });
    return () => controller.abort();
  }, [reload]);

  const activeKey = JSON.stringify(batches.filter(isActive).map((batch) => batch.batch_id).sort());
  useEffect(() => {
    const controller = new AbortController();
    let timer: number | undefined;
    const activeIds: string[] = JSON.parse(activeKey);
    const ids = [...new Set([...activeIds, ...(selectedBatchId ? [selectedBatchId] : [])])];
    if (!ids.length) return;
    async function poll() {
      const results = await Promise.allSettled(ids.map((id) => api.getTaskBatch(id, controller.signal)));
      if (controller.signal.aborted) return;
      const records = results.flatMap((result) => result.status === 'fulfilled' ? [result.value] : []);
      setBatches((current) => [
        ...current.map((batch) => records.find((record) => record.batch_id === batch.batch_id) ?? batch),
        ...records.filter((record) => !current.some((batch) => batch.batch_id === record.batch_id)),
      ]);
      const failure = results.find((result) => result.status === 'rejected');
      setPollError(failure?.status === 'rejected'
        ? requestError(failure.reason, 'Batch status unavailable. The last confirmed state is shown; reload history to check again.')
        : '');
      // Fetch status only; polling never resubmits generation.
      if (activeIds.length) timer = window.setTimeout(poll, 2000);
    }
    void poll();
    return () => {
      controller.abort();
      window.clearTimeout(timer);
    };
  }, [activeKey, selectedBatchId, reload]);

  function clearValidation() {
    setErrors([]);
    setError('');
    setMessage('');
  }

  async function submit() {
    if (submissionLock.current) return;
    if (!selected.length || !runTitle.trim()) {
      setError('Select tasks and enter a run title.');
      return;
    }
    submissionLock.current = true;
    const controller = new AbortController();
    submissionController.current = controller;
    setPending(true);
    setErrors([]);
    setError('');
    setMessage('Checking task preparation with the server. Nothing has been submitted for generation.');
    let admissionStarted = false;
    try {
      const taskIds = [...selected];
      const options = {
        runTitle, description, period: period.trim() || undefined, grouping: grouping.trim(),
        maxParallelCases: parallel, economy, useExpectedTemplate: useTemplate, reasoningEffort: reasoning,
      };
      const accepted = await prepareAndAdmitTaskBatch(taskIds, options, controller.signal, setMessage, () => {
        setMessage('Task preparation passed. Requesting batch admission…');
        admissionStarted = true;
      });
      if (controller.signal.aborted) return;
      // An accepted ID is the first point at which a batch appears locally.
      setBatches((current) => [{
        ...accepted, run_title: runTitle.trim(), description, period: options.period ?? null,
        grouping: options.grouping, max_parallel_cases: parallel, status: 'accepted', done: false,
        total: taskIds.length, finished_count: 0, created_at: new Date().toISOString(),
      }, ...current.filter((batch) => batch.batch_id !== accepted.batch_id)]);
      setSelectedBatchId(accepted.batch_id);
      setMessage(`Batch accepted: ${accepted.batch_id}.`);
    } catch (failure) {
      if (controller.signal.aborted) return;
      setErrors(failure instanceof TaskPreparationError ? failure.errors : validationErrors(failure));
      setError(requestError(failure, admissionStarted
        ? 'Batch admission could not be confirmed. The request was not retried. Reload history before submitting again to avoid duplicates.'
        : 'Task preparation could not be checked. No batch was submitted.'));
      setMessage('');
    } finally {
      submissionLock.current = false;
      if (!controller.signal.aborted) setPending(false);
    }
  }

  const batch = batches.find((record) => record.batch_id === selectedBatchId);
  async function openRun(id: string) {
    try {
      await onOpenRun(id);
    } catch (failure) {
      setPollError(requestError(failure, 'Could not open this run.'));
    }
  }
  async function download(id: string) {
    try {
      await api.downloadReport(id);
    } catch (failure) {
      setPollError(requestError(failure, 'Could not download this report.'));
    }
  }

  return (
    <>
      <div className="panel">
        <h2 style={{ marginTop: 0 }}>Task batch generation</h2>
        <p className="muted">Select saved tasks, not sample test cases. The server must validate task preparation for the chosen period before admission.</p>
        {tasksLoading && <p role="status">Loading tasks…</p>}
        {tasksError && <p role="alert">{tasksError}</p>}
        {!tasksLoading && !tasksError && !tasks.length && <p>No saved tasks are available.</p>}
        <form onSubmit={(event) => { event.preventDefault(); void submit(); }}>
          <fieldset disabled={pending} style={{ border: 0, padding: 0, margin: 0, minWidth: 0 }}>
            <div className="row">
              <label style={{ flex: 1, minWidth: 200 }}>Run title (required)
                <input required value={runTitle} onChange={(event) => setRunTitle(event.target.value)} />
              </label>
              <label style={{ flex: 1, minWidth: 200 }}>Period (required by period-scoped tasks)
                <input value={period} onChange={(event) => { setPeriod(event.target.value); clearValidation(); }} placeholder="Leave blank when tasks do not require a period" />
              </label>
              <label style={{ flex: 1, minWidth: 200 }}>Grouping (optional)
                <input value={grouping} onChange={(event) => setGrouping(event.target.value)} />
              </label>
            </div>
            <label>Description (optional)
              <textarea value={description} onChange={(event) => setDescription(event.target.value)} rows={2} style={{ minHeight: 70 }} />
            </label>
            <div className="row" style={{ alignItems: 'center', margin: '12px 0' }}>
              <label>Max parallel cases
                <select value={parallel} onChange={(event) => setParallel(Number(event.target.value) as 1 | 2 | 3 | 4)}>
                  {[1, 2, 3, 4].map((value) => <option key={value} value={value}>{value}{value === 1 ? ' (sequential)' : ''}</option>)}
                </select>
              </label>
              <label><input type="checkbox" style={{ width: 'auto' }} checked={economy} onChange={(event) => setEconomy(event.target.checked)} /> Economy</label>
              <label>Reasoning
                <select value={reasoning} disabled={economy} onChange={(event) => setReasoning(event.target.value as typeof reasoning)}>
                  <option value="high">high</option><option value="medium">medium</option><option value="low">low</option>
                </select>
              </label>
              <label><input type="checkbox" style={{ width: 'auto' }} checked={useTemplate} onChange={(event) => setUseTemplate(event.target.checked)} /> Use expected template</label>
            </div>
            <div className="row" style={{ marginBottom: 10 }}>
              <button type="button" className="ghost sm" disabled={tasksLoading || !!tasksError} onClick={() => { setSelected(tasks.map((task) => task.id)); clearValidation(); }}>Select all tasks</button>
              <button type="button" className="ghost sm" onClick={() => { setSelected([]); clearValidation(); }}>Clear selection</button>
            </div>
            {tasks.map((task) => (
              <label key={task.id} style={{ display: 'block', marginBottom: 10 }}>
                <input type="checkbox" style={{ width: 'auto' }} checked={selected.includes(task.id)}
                  aria-invalid={errors.some((item) => item.task_id === task.id)}
                  onChange={() => {
                    setSelected((current) => current.includes(task.id) ? current.filter((id) => id !== task.id) : [...current, task.id]);
                    clearValidation();
                  }} /> {task.title} <code className="muted">{task.id}</code>
              </label>
            ))}
            <button type="submit" disabled={tasksLoading || !!tasksError || !selected.length || !runTitle.trim()}>
              Validate and start {selected.length} task{selected.length === 1 ? '' : 's'}
            </button>
          </fieldset>
        </form>
        {message && <p role="status">{message}</p>}
        {error && <div role="alert"><p>{error}</p>
          {!!errors.length && <ul>{errors.map((item, index) => (
            <li key={`${item.task_id}-${index}`}><strong>{tasks.find((task) => task.id === item.task_id)?.title ?? item.task_id}</strong> ({item.task_id}): {item.detail}</li>
          ))}</ul>}
        </div>}
      </div>
      <div className="panel">
        <div className="row" style={{ alignItems: 'center', justifyContent: 'space-between' }}>
          <h3>Task batch history</h3>
          <button type="button" className="ghost sm" disabled={historyLoading} onClick={() => setReload((value) => value + 1)}>Reload history / tasks</button>
        </div>
        {historyLoading && <p role="status">Loading batch history…</p>}
        {historyError && <p role="alert">{historyError}</p>}
        {pollError && <p role="alert">{pollError}</p>}
        {!historyLoading && !historyError && !batches.length && <p className="muted">No task batches yet.</p>}
        {batches.map((record) => (
          <button type="button" key={record.batch_id} className={`list-btn ${record.batch_id === selectedBatchId ? 'selected' : ''}`}
            onClick={() => setSelectedBatchId(record.batch_id)} aria-pressed={record.batch_id === selectedBatchId}>
            <strong>{record.run_title}</strong>
            <span className="muted" style={{ display: 'block' }}>{record.period || 'No period'} · {record.status} · {record.finished_count}/{record.total} finished · {record.batch_id}</span>
          </button>
        ))}
        {batch && <section aria-label="Task batch progress">
          <h3>{batch.run_title}</h3>
          <p>Batch ID: <code>{batch.batch_id}</code> · Job ID: <code>{batch.job_id}</code></p>
          {batch.description && <p style={{ whiteSpace: 'pre-wrap' }}>{batch.description}</p>}
          <p>Period: {batch.period || 'None'} · Grouping: {batch.grouping || 'None'}{batch.max_parallel_cases ? ` · Max parallel cases: ${batch.max_parallel_cases}` : ''}</p>
          <p role="status">{batch.status} · {batch.finished_count} of {batch.total} tasks finished</p>
          <progress aria-label="Tasks finished" value={batch.finished_count} max={batch.total || 1} style={{ width: '100%' }} />
          {!batch.items && <p className="muted">Loading batch details from the server…</p>}
          {batch.items?.map((item) => {
            const runId = item.run_id || item.run?.run_id;
            return <div key={item.task_id} style={{ borderTop: '1px solid var(--line)', padding: '12px 0' }}>
              <strong>{item.task_title || item.task_id}</strong> · {item.status}
              <p className="muted">Task: {item.task_id}{item.job_id ? ` · Job: ${item.job_id}` : ''}{runId ? ` · Run: ${runId}` : ''}</p>
              {item.error && <p role="alert">{item.error}</p>}
              {runId && <div className="row">
                <button type="button" className="ghost sm" onClick={() => void openRun(runId)}>Open run</button>
                <button type="button" className="ghost sm" onClick={() => void download(runId)}>Download .docx</button>
              </div>}
            </div>;
          })}
        </section>}
      </div>
    </>
  );
}
