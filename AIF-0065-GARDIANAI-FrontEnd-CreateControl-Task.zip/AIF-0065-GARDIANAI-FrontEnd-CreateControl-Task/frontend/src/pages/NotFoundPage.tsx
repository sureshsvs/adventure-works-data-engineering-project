import { LinkButton } from '../components/common/LinkButton';
import { EmptyState } from '../components/common/Feedback';
import { PageContainer } from '../layouts/MainLayout';

export default function NotFoundPage() {
    return (
        <PageContainer>
            <EmptyState
                icon="bi-compass"
                title="Page not found"
                action={<LinkButton to="/">Go Home</LinkButton>}
            />
        </PageContainer>
    );
}
