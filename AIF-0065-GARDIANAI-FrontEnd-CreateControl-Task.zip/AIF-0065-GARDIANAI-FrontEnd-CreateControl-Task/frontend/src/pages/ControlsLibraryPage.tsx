import { useMemo, useState } from 'react';
import { Button, Card, Table } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

import { LinkButton } from '../components/common/LinkButton';
import { ConfirmDialog } from '../components/common/ConfirmDialog';
import { EmptyState, ErrorAlert, LoadingSpinner } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { RoleChips } from '../components/common/StatusBadge';
import { SearchInput } from '../components/common/SearchInput';
import { SortableTh } from '../components/common/SortableTh';
import { TablePagination } from '../components/common/TablePagination';
import { useToast } from '../contexts/ToastContext';
import { usePagination, useSort } from '../hooks/useTable';
import { useDeleteTask, useTasks } from '../hooks/useTasks';
import { PageContainer } from '../layouts/MainLayout';
import type { Task } from '../types/api';
import { toApiError } from '../utils/errors';

type SortKey = 'title' | 'description';

export default function ControlsLibraryPage() {
    const navigate = useNavigate();
    const { notify } = useToast();
    const { data: tasks, isLoading, error, refetch } = useTasks();
    const del = useDeleteTask();
    const [search, setSearch] = useState('');
    const [toDelete, setToDelete] = useState<Task | null>(null);
    const sort = useSort<SortKey>('title');

    const filtered = useMemo(() => {
        const q = search.trim().toLowerCase();
        debugger;
        const list = (tasks ?? []).filter(
            (t) =>
                !q ||
                t.title.toLowerCase().includes(q) ||
                (t.description ?? '').toLowerCase().includes(q) ||
                t.logical_source_role_names.some((r) => r.toLowerCase().includes(q))
        );
        const dir = sort.dir === 'asc' ? 1 : -1;
        return [...list].sort((a, b) =>
            (sort.key === 'title' ? a.title : a.description ?? '').localeCompare(
                sort.key === 'title' ? b.title : b.description ?? '',
                undefined,
                { sensitivity: 'base' }
            ) * dir
        );
    }, [tasks, search, sort.key, sort.dir]);

    const pager = usePagination(filtered, 10);

    const confirmDelete = () => {
        if (!toDelete) return;
        const target = toDelete;
        del.mutate(target.id, {
            onSuccess: () => notify('success', 'Control deleted', target.title),
            onError: (e) => notify('danger', 'Delete failed', toApiError(e).message),
            onSettled: () => setToDelete(null),
        });
    };

    return (
        <PageContainer>
            <PageHeader
                title="Controls/Tasks Library"
                subtitle="Manage reusable controls, their source documents, and the prompts used to generate reports."
            />
            <Card>
                <Card.Body>
                    <div className="mb-3">
                        <SearchInput
                            value={search}
                            onChange={(v) => {
                                setSearch(v);
                                pager.setPage(1);
                            }}
                            placeholder="Search controls/task"
                        />
                        <div className="d-flex justify-content-end mt-3">
                            <LinkButton to="/controls/new">
                                <i className="bi bi-plus-circle me-2" aria-hidden="true" />
                                New Controls/Tasks
                            </LinkButton>
                        </div>
                    </div>

                    {isLoading && <LoadingSpinner />}
                    {error && <ErrorAlert error={error} onRetry={() => void refetch()} />}

                    {tasks && pager.total === 0 && (
                        <EmptyState icon="bi-journal-x" title={search ? 'No matching controls' : 'No controls yet'}>
                            {search ? 'Try a different search term.' : 'Create your first reusable control.'}
                        </EmptyState>
                    )}

                    {pager.total > 0 && (
                        <>
                            <Table responsive hover className="table-gar mb-0">
                                <thead>
                                    <tr>
                                        <th style={{ width: '3rem' }}>#</th>
                                        <SortableTh sortKey="title" activeKey={sort.key} dir={sort.dir} onSort={sort.toggle}>
                                            Control/Task
                                        </SortableTh>
                                        <SortableTh sortKey="description" activeKey={sort.key} dir={sort.dir} onSort={sort.toggle}>
                                            Description
                                        </SortableTh>
                                        <th>Source Roles</th>
                                        <th className="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {pager.pageItems.map((t, i) => (
                                        <tr key={t.id}>
                                            <td>{(pager.page - 1) * pager.pageSize + i + 1}</td>
                                            <td>{t.title}</td>
                                            <td>{t.description}</td>
                                            <td>
                                                <RoleChips roles={t.logical_source_role_names} />
                                            </td>
                                            <td className="text-center text-nowrap">
                                                <Button variant="link" aria-label={`Edit ${t.title}`} onClick={() => navigate(`/controls/${t.id}/edit`)}>
                                                    <i className="bi bi-pencil" aria-hidden="true" />
                                                </Button>
                                                <Button variant="link" aria-label={`View ${t.title}`} onClick={() => navigate(`/controls/${t.id}`)}>
                                                    <i className="bi bi-eye" aria-hidden="true" />
                                                </Button>
                                                <Button variant="link" className="text-danger" aria-label={`Delete ${t.title}`} onClick={() => setToDelete(t)}>
                                                    <i className="bi bi-trash" aria-hidden="true" />
                                                </Button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </Table>
                            <TablePagination {...pager} onChange={pager.setPage} />
                        </>
                    )}
                </Card.Body>
            </Card>

            <ConfirmDialog
                show={toDelete !== null}
                title="Delete control"
                busy={del.isPending}
                onConfirm={confirmDelete}
                onCancel={() => setToDelete(null)}
            >
                Delete <strong>{toDelete?.title}</strong>? This cannot be undone.
            </ConfirmDialog>
        </PageContainer>
    );
}
