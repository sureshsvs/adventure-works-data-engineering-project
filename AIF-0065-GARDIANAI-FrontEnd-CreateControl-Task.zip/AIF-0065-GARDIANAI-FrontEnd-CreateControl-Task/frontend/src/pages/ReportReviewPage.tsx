import { Col, Row, Tab, Table, Tabs } from 'react-bootstrap';
import { useParams } from 'react-router-dom';

import { LinkButton } from '../components/common/LinkButton';
import { EmptyState, ErrorAlert, LoadingSpinner } from '../components/common/Feedback';
import { PageHeader } from '../components/common/PageHeader';
import { StatusBadge } from '../components/common/StatusBadge';
import { DocumentViewer } from '../components/runs/DocumentViewer';
//import { ReviewPanel } from '../components/runs/ReviewPanel';
import { KeyValueTable, OutputDestinationCard, SectionCard } from '../components/runs/Sections';
import { useGenerationRun } from '../hooks/useGenerationRun';
import { useRunBatch } from '../hooks/useRunBatches';
import { PageContainer } from '../layouts/MainLayout';
import { fileExtension, formatDateTime } from '../utils/format';

export default function ReportReviewPage() {
    const { batchId, taskId } = useParams<{ batchId: string; taskId: string }>();
    const batch = useRunBatch(batchId);
    const item = batch?.items.find((i) => i.taskId === taskId);
    const run = useGenerationRun(item?.runId);

    if (!batch || !item) {
        return (
            <PageContainer>
                <EmptyState icon="bi-question-circle" title="Report not found" action={<LinkButton to="/run-monitor">Run Monitor</LinkButton>} />
            </PageContainer>
        );
    }

    return (
        <PageContainer>
            <PageHeader
                title="Review Generated Report"
                subtitle="Review the AI generated report and take the next action."
                crumbs={[
                    { label: 'Run Monitor', to: '/run-monitor' },
                    { label: batch.title, to: `/runs/${batch.id}` },
                    { label: item.taskTitle },
                ]}
            />

            {run.isLoading && <LoadingSpinner label="Loading report…" />}
            {run.error && <ErrorAlert error={run.error} onRetry={() => void run.refetch()} />}

            {run.data && (
                <Row className="g-3">
                    <Col lg={9}>
                        <div className="card">
                            <Tabs defaultActiveKey="output" className="px-3 pt-2" mountOnEnter>
                                <Tab eventKey="output" title="AI Output" className="p-3">
                                    <div className="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
                                        <span className="fw-semibold">{item.taskTitle}</span>
                                        <span className="d-flex align-items-center gap-2 small">
                                            <StatusBadge status="completed" />
                                            <span className="text-secondary">{formatDateTime(run.data.completed_at)}</span>
                                        </span>
                                    </div>
                                    {/* <div className="d-flex flex-wrap gap-2 mb-3">
                                        <Button size="sm" variant="outline-secondary" onClick={onDownload} disabled={download.isPending}>
                                            {download.isPending ? <Spinner size="sm" className="me-1" /> : <i className="bi bi-download me-1" aria-hidden="true" />}
                                            Download DOCX
                                        </Button>
                                        <Button size="sm" variant="outline-secondary" onClick={onUpload} disabled={upload.isPending}>
                                            {upload.isPending ? <Spinner size="sm" className="me-1" /> : <i className="bi bi-cloud-upload me-1" aria-hidden="true" />}
                                            Upload to SharePoint
                                        </Button>
                                    </div> */}
                                    <DocumentViewer document={run.data.document} />
                                </Tab>

                                <Tab eventKey="info" title="Run Information" className="p-3">
                                    <SectionCard title="Run Details">
                                        <KeyValueTable
                                            rows={[
                                                ['Run Title', batch.title],
                                                ['Run ID', batch.id],
                                                ['Reporting Period', batch.period],
                                                ['Description', batch.description || '—'],
                                                ['Model', `${run.data.model} (${run.data.mode})`],
                                                ['Prompt Version', run.data.prompt_version || '—'],
                                            ]}
                                        />
                                    </SectionCard>
                                    <SectionCard title="Selected Controls (1)">
                                        <KeyValueTable rows={[['Control/Task', item.taskTitle]]} />
                                    </SectionCard>
                                    <SectionCard title={`Input Sources (${run.data.input_documents.length})`}>
                                        <Table responsive className="table-gar mb-0">
                                            <thead>
                                                <tr>
                                                    <th style={{ width: '3rem' }}>#</th>
                                                    <th>Document</th>
                                                    <th>Type</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {run.data.input_documents.map((d, i) => (
                                                    <tr key={`${d}-${i}`}>
                                                        <td>{i + 1}</td>
                                                        <td>{d}</td>
                                                        <td>{fileExtension(d)}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </Table>
                                    </SectionCard>
                                    <OutputDestinationCard runTitle={batch.title} runCode={batch.id} taskName={item.taskTitle} />
                                </Tab>
                            </Tabs>
                        </div>
                    </Col>
                    {/* <Col lg={3}>
                        <ReviewPanel run={run.data} />
                    </Col> */}
                </Row>
            )}
        </PageContainer>
    );
}
