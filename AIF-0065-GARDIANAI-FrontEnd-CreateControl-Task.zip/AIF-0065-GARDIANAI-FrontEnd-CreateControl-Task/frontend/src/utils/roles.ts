import type { LogicalSourceRole, TaskOptions } from '../types/api';

export function roleFileMap(options?: TaskOptions): Map<string, LogicalSourceRole> {
  return new Map((options?.logical_source_roles ?? []).map((r) => [r.name, r]));
}

// Roles of a control with no file for the selected period; empty until the period lookup has loaded.
export function missingRoles(roleNames: string[], options?: TaskOptions): string[] {
  if (!options?.logical_source_roles) return [];
  const map = roleFileMap(options);
  return roleNames.filter((n) => !map.get(n)?.file_name);
}
