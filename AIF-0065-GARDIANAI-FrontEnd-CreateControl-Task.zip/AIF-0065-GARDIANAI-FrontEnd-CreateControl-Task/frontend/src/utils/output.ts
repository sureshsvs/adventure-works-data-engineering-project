export const outputConfig = {
  site: import.meta.env.VITE_SHAREPOINT_SITE || 'MC SharePoint-GAR/GAR Outputs',
  root: (import.meta.env.VITE_SHAREPOINT_OUTPUT_ROOT || '/Outputs').replace(/\/$/, ''),
  url: import.meta.env.VITE_SHAREPOINT_URL || '',
};

export function outputFolder(runTitle: string, runCode?: string, taskName?: string): string {
  const parts = [outputConfig.root, runTitle.trim().replace(/\s+/g, '-'), runCode ?? '{RUN_ID}'];
  parts.push(taskName ? taskName.trim().replace(/\s+/g, '-') : '{Task_Name}');
  return parts.join('/') + '/';
}
