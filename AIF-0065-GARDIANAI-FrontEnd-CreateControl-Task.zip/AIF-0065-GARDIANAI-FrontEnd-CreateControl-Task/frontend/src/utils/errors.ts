import axios from 'axios';

export interface ApiError {
  status?: number;
  message: string;
  // Field-level messages from FastAPI/Pydantic 422 responses, keyed by field name.
  fieldErrors: Record<string, string>;
}

export function isApiError(value: unknown): value is ApiError {
  return typeof value === 'object' && value !== null && 'fieldErrors' in value && 'message' in value;
}

interface ValidationItem {
  loc?: Array<string | number>;
  msg?: string;
}

export function toApiError(error: unknown): ApiError {
  if (isApiError(error)) return error;
  if (axios.isAxiosError(error)) {
    const status = error.response?.status;
    const detail: unknown = (error.response?.data as { detail?: unknown } | undefined)?.detail;
    if (Array.isArray(detail)) {
      const fieldErrors: Record<string, string> = {};
      for (const item of detail as ValidationItem[]) {
        const field = item.loc?.[item.loc.length - 1];
        if (field !== undefined) fieldErrors[String(field)] = item.msg ?? 'Invalid value';
      }
      return { status, message: 'Please correct the highlighted fields.', fieldErrors };
    }
    if (typeof detail === 'string') return { status, message: detail, fieldErrors: {} };
    if (typeof detail === 'object' && detail !== null) {
      const body = detail as { message?: unknown; errors?: unknown };
      const validationDetails = Array.isArray(body.errors)
        ? body.errors
            .map((item) => {
              if (typeof item !== 'object' || item === null) return '';
              const error = item as { task_id?: unknown; detail?: unknown };
              return [error.task_id, error.detail].filter((part) => typeof part === 'string').join(': ');
            })
            .filter(Boolean)
        : [];
      const message = typeof body.message === 'string' ? body.message : error.message;
      return {
        status,
        message: validationDetails.length ? `${message}\n${validationDetails.join('\n')}` : message,
        fieldErrors: {},
      };
    }
    if (!error.response) {
      return { message: 'Unable to reach the server. Check your connection.', fieldErrors: {} };
    }
    return { status, message: error.message, fieldErrors: {} };
  }
  return { message: error instanceof Error ? error.message : 'Unexpected error', fieldErrors: {} };
}
