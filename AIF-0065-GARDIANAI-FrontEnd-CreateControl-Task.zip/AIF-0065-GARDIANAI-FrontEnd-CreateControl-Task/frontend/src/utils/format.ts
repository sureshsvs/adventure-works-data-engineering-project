import type { RunBatch, RunItem, RunItemStatus } from '../types/run';

const dateFmt = new Intl.DateTimeFormat('en-GB', {
  day: '2-digit',
  month: 'short',
  year: 'numeric',
  hour: '2-digit',
  minute: '2-digit',
  hour12: false,
});

export function formatDateTime(iso?: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return '—';
  return dateFmt.format(d).replace(',', '').replace(/(\d{4}) /, '$1, ');
}

export const STATUS_LABEL: Record<RunItemStatus, string> = {
  queued: 'Queued',
  running: 'Running',
  completed: 'Completed',
  failed: 'Failed',
};

export function countByStatus(items: RunItem[]): Record<RunItemStatus, number> {
  const counts: Record<RunItemStatus, number> = { queued: 0, running: 0, completed: 0, failed: 0 };
  for (const item of items) counts[item.status] += 1;
  return counts;
}

export type BatchStatus = RunItemStatus | 'partial';

export function batchStatus(batch: RunBatch): BatchStatus {
  const c = countByStatus(batch.items);
  if (c.running + c.queued > 0) return 'running';
  if (c.failed === 0) return 'completed';
  return c.completed === 0 ? 'failed' : 'partial';
}

export function batchSummary(batch: RunBatch): string {
  const c = countByStatus(batch.items);
  const parts: string[] = [];
  if (c.completed) parts.push(`${c.completed} Completed`);
  if (c.failed) parts.push(`${c.failed} Failed`);
  if (c.running + c.queued) parts.push(`${c.running + c.queued} Running`);
  return parts.join(', ') || '—';
}

export function humanizeStage(stage?: string): string {
  if (!stage) return 'Starting…';
  const text = stage.replace(/[_-]+/g, ' ').trim();
  return text.charAt(0).toUpperCase() + text.slice(1);
}

export function fileExtension(name: string): string {
  const idx = name.lastIndexOf('.');
  return idx >= 0 ? name.slice(idx + 1).toUpperCase() : 'FILE';
}
