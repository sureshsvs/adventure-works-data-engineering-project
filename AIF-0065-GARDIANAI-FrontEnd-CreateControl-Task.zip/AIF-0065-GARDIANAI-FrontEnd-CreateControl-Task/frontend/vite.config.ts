import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';

// The dev server proxies /api straight to the FastAPI backend so the browser
// only talks to Vite. In production nginx plays this reverse-proxy role.
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:8000',
        changeOrigin: true,
      },
    },
  },
});
